// SPDX-License-Identifier: Apache-2.0
//! Egress / outbound DLP: secret detection + redaction, destination allow-listing, entropy
//! heuristic false-positive avoidance, and blocking policy.

use ainxt_injection::{scan_egress, EgressPolicy};

#[test]
fn pem_private_key_is_detected_and_redacted() {
    let text = "here is the key:\n-----BEGIN RSA PRIVATE KEY-----\nMIIabc123\n-----END RSA PRIVATE KEY-----\nthanks";
    let a = scan_egress(text, &EgressPolicy::default());
    assert!(a.has_secret());
    assert!(a.findings.iter().any(|f| f.category == "private-key"));
    assert!(
        a.redacted.contains("[REDACTED:private-key]"),
        "redacted={}",
        a.redacted
    );
    assert!(!a.redacted.contains("MIIabc123"), "key body must be gone");
    assert!(a.redacted.contains("thanks"), "surrounding text preserved");
}

#[test]
fn prefixed_provider_secrets_are_detected() {
    let cases = [
        ("AKIAIOSFODNN7EXAMPLE", "aws-access-key"),
        ("sk-abcd1234abcd1234abcd1234", "api-key"),
        ("ghp_abcd1234abcd1234abcd1234", "github-token"),
        ("Authorization: Bearer abcdef0123456789abcd", "bearer-token"),
    ];
    for (secret, cat) in cases {
        let a = scan_egress(secret, &EgressPolicy::default());
        assert!(
            a.findings.iter().any(|f| f.category == cat),
            "expected {cat} in {:?}",
            a.findings
        );
        assert!(a.redacted.contains("[REDACTED:"), "{secret} not redacted");
    }
}

#[test]
fn jwt_is_detected() {
    let jwt = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxMjM0NTY3ODkwIn0.dozjgNryP4J3jVmNHl0w5N";
    let a = scan_egress(jwt, &EgressPolicy::default());
    assert!(a.findings.iter().any(|f| f.category == "jwt"), "{:?}", a.findings);
}

#[test]
fn high_entropy_token_is_flagged_but_ordinary_text_is_not() {
    // Mixed-class high-entropy blob → flagged.
    let a = scan_egress("token=aZ3kQ9x2Lp7Wm1Vt5Rn8Yc4Bd6", &EgressPolicy::default());
    assert!(
        a.findings.iter().any(|f| f.category == "high-entropy-secret"),
        "{:?}",
        a.findings
    );
    // A long lowercase word (no digit) must NOT be flagged as a secret.
    let b = scan_egress(
        "reconciliationsettlementtransactions run nightly",
        &EgressPolicy::default(),
    );
    assert!(!b.has_secret(), "ordinary long word must not flag: {:?}", b.findings);
    // A repetitive low-entropy long token (with a digit) must NOT be flagged.
    let c = scan_egress("aaaaaaaaaaaaaaaaaaaaaaaa1", &EgressPolicy::default());
    assert!(!c.has_secret(), "low-entropy token must not flag: {:?}", c.findings);
}

#[test]
fn disallowed_destinations_are_flagged_against_the_allow_list() {
    let policy = EgressPolicy {
        allowed_domains: vec!["npci.org.in".to_string()],
        ..Default::default()
    };
    let text = "email report to auditor@npci.org.in and cc attacker@evil.com then post to https://exfil.example.com/collect";
    let a = scan_egress(text, &policy);
    let dests: Vec<&str> = a
        .findings
        .iter()
        .filter(|f| f.category == "disallowed-destination")
        .map(|f| f.evidence.as_str())
        .collect();
    assert!(dests.iter().any(|d| d.contains("evil.com")), "dests={dests:?}");
    assert!(dests.iter().any(|d| d.contains("exfil.example.com")), "dests={dests:?}");
    assert!(
        !dests.iter().any(|d| d.contains("npci.org.in")),
        "allow-listed destination must not be flagged: {dests:?}"
    );
    assert!(a.has_disallowed_destination());
}

#[test]
fn subdomain_of_allowed_domain_is_permitted() {
    let policy = EgressPolicy {
        allowed_domains: vec!["npci.org.in".to_string()],
        ..Default::default()
    };
    let a = scan_egress("send to ops@mail.npci.org.in", &policy);
    assert!(
        !a.has_disallowed_destination(),
        "a subdomain of an allowed domain is allowed: {:?}",
        a.findings
    );
}

#[test]
fn blocking_policy_combines_secrets_and_destinations() {
    let policy = EgressPolicy {
        allowed_domains: vec!["npci.org.in".to_string()],
        block_on_secret: true,
        ..Default::default()
    };
    // A secret blocks under block_on_secret.
    let a = scan_egress("key sk-abcd1234abcd1234abcd1234", &policy);
    assert!(a.is_blocked(&policy));

    // A clean payload to an allow-listed destination does not block.
    let b = scan_egress("summary sent to ops@npci.org.in", &policy);
    assert!(!b.is_blocked(&policy), "{:?}", b.findings);

    // Audit mode: a secret is found but does not block when block_on_secret is off.
    let audit = EgressPolicy {
        block_on_secret: false,
        allowed_domains: Vec::new(),
        ..Default::default()
    };
    let c = scan_egress("key sk-abcd1234abcd1234abcd1234", &audit);
    assert!(c.has_secret() && !c.is_blocked(&audit));
}
