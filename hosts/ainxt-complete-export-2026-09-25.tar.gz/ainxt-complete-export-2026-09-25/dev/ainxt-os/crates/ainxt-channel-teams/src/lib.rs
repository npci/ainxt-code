// SPDX-License-Identifier: Apache-2.0
//! ainxt-channel-teams — Microsoft Teams Bot Framework channel adapter for the AiNxt Bot Platform.
//!
//! Handles incoming Bot Framework Activity JSON from Microsoft Teams, forwards the message
//! to the AiNxt bot chat API, and posts the response back via the Bot Framework reply URL.
//!
//! # Usage
//! ```rust,ignore
//! use ainxt_channel_teams::TeamsAdapter;
//!
//! let adapter = TeamsAdapter::new(
//!     "my-app-id",
//!     "my-app-password",
//!     "http://localhost:8080",
//!     "upi-assistant",
//! );
//! let router = adapter.router();
//! // Merge into your axum app: app.merge(router)
//! ```
//!
//! # Teams setup
//! 1. Register a Bot in Azure Bot Service
//! 2. Set the messaging endpoint to `https://your-host/teams/messages`
//! 3. Copy the App ID and App Password into your config
//! 4. Add the bot to your Teams channel

use std::sync::Arc;

use axum::extract::State;
use axum::http::StatusCode;
use axum::response::{IntoResponse, Response};
use axum::routing::post;
use axum::{Json, Router};
use serde::{Deserialize, Serialize};

// ---------------------------------------------------------------------------
// Bot Framework Activity types
// ---------------------------------------------------------------------------

/// A Bot Framework Activity (the top-level message envelope from Teams).
#[derive(Debug, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct Activity {
    /// Activity type: `"message"`, `"conversationUpdate"`, etc.
    #[serde(rename = "type")]
    pub kind: String,
    /// The message text (for `message` activities).
    pub text: Option<String>,
    /// The conversation reference (used to reply).
    pub conversation: Option<Conversation>,
    /// The service URL (used to post replies back).
    pub service_url: Option<String>,
    /// The activity ID (used as the reply-to reference).
    pub id: Option<String>,
    /// The channel ID (e.g. `"msteams"`).
    pub channel_id: Option<String>,
    /// The sender's account.
    pub from: Option<ChannelAccount>,
    /// The recipient (the bot's account).
    pub recipient: Option<ChannelAccount>,
}

/// A Bot Framework conversation reference.
#[derive(Debug, Deserialize, Serialize, Clone)]
#[serde(rename_all = "camelCase")]
pub struct Conversation {
    pub id: String,
    pub is_group: Option<bool>,
    pub name: Option<String>,
}

/// A Bot Framework channel account (user or bot).
#[derive(Debug, Deserialize, Serialize, Clone)]
#[serde(rename_all = "camelCase")]
pub struct ChannelAccount {
    pub id: String,
    pub name: Option<String>,
}

/// A Bot Framework reply activity.
#[derive(Debug, Serialize)]
#[serde(rename_all = "camelCase")]
struct ReplyActivity {
    #[serde(rename = "type")]
    kind: String,
    text: String,
    conversation: Conversation,
    from: ChannelAccount,
    recipient: ChannelAccount,
    reply_to_id: Option<String>,
}

// ---------------------------------------------------------------------------
// Teams adapter
// ---------------------------------------------------------------------------

/// The Microsoft Teams Bot Framework adapter.
///
/// Receives Bot Framework Activity JSON from Teams, forwards `message` activities
/// to the AiNxt bot chat API, and posts the response back via the Bot Framework
/// reply URL.
#[derive(Clone)]
pub struct TeamsAdapter {
    inner: Arc<TeamsAdapterInner>,
}

struct TeamsAdapterInner {
    app_id: String,
    app_password: String,
    ainxt_base_url: String,
    bot_id: String,
    http: reqwest::Client,
}

impl TeamsAdapter {
    /// Create a new Teams adapter.
    ///
    /// # Arguments
    /// * `app_id` — Azure AD application (client) ID.
    /// * `app_password` — Azure AD application password / client secret.
    /// * `ainxt_base_url` — Base URL of the AiNxt server (e.g. `http://localhost:8080`).
    /// * `bot_id` — The AiNxt bot ID to forward messages to.
    pub fn new(
        app_id: impl Into<String>,
        app_password: impl Into<String>,
        ainxt_base_url: impl Into<String>,
        bot_id: impl Into<String>,
    ) -> Self {
        TeamsAdapter {
            inner: Arc::new(TeamsAdapterInner {
                app_id: app_id.into(),
                app_password: app_password.into(),
                ainxt_base_url: ainxt_base_url.into().trim_end_matches('/').to_string(),
                bot_id: bot_id.into(),
                http: reqwest::Client::new(),
            }),
        }
    }

    /// Build the axum [`Router`] with the Teams messages endpoint.
    ///
    /// Mount at `POST /teams/messages`.
    pub fn router(self) -> Router {
        Router::new()
            .route("/teams/messages", post(teams_messages_handler))
            .with_state(self)
    }
}

// ---------------------------------------------------------------------------
// Token acquisition
// ---------------------------------------------------------------------------

/// Acquire a Bot Framework access token from Azure AD.
///
/// Uses the client credentials flow (app_id + app_password → Bearer token).
async fn acquire_bot_token(http: &reqwest::Client, app_id: &str, app_password: &str) -> Result<String, String> {
    let token_url = "https://login.microsoftonline.com/botframework.com/oauth2/v2.0/token";
    let params = [
        ("grant_type", "client_credentials"),
        ("client_id", app_id),
        ("client_secret", app_password),
        ("scope", "https://api.botframework.com/.default"),
    ];

    let res = http
        .post(token_url)
        .form(&params)
        .send()
        .await
        .map_err(|e| e.to_string())?;

    if !res.status().is_success() {
        let status = res.status();
        let text = res.text().await.unwrap_or_default();
        return Err(format!("token request failed HTTP {}: {}", status, text));
    }

    let json: serde_json::Value = res.json().await.map_err(|e| e.to_string())?;
    json.get("access_token")
        .and_then(|t| t.as_str())
        .map(|s| s.to_string())
        .ok_or_else(|| "no access_token in response".to_string())
}

// ---------------------------------------------------------------------------
// Event handler
// ---------------------------------------------------------------------------

async fn teams_messages_handler(
    State(adapter): State<TeamsAdapter>,
    Json(activity): Json<Activity>,
) -> Response {
    // Only handle message activities.
    if activity.kind != "message" {
        return StatusCode::OK.into_response();
    }

    let text = match activity.text.as_deref() {
        Some(t) if !t.trim().is_empty() => t.trim().to_string(),
        _ => return StatusCode::OK.into_response(),
    };

    let service_url = activity.service_url.clone().unwrap_or_default();
    let conversation = activity.conversation.clone();
    let from = activity.from.clone();
    let recipient = activity.recipient.clone();
    let activity_id = activity.id.clone();

    // Spawn async task to avoid blocking the Teams 15-second timeout.
    let adapter_clone = adapter.clone();
    tokio::spawn(async move {
        handle_teams_message(
            adapter_clone,
            text,
            service_url,
            conversation,
            from,
            recipient,
            activity_id,
        )
        .await;
    });

    StatusCode::ACCEPTED.into_response()
}

async fn handle_teams_message(
    adapter: TeamsAdapter,
    text: String,
    service_url: String,
    conversation: Option<Conversation>,
    from: Option<ChannelAccount>,
    recipient: Option<ChannelAccount>,
    activity_id: Option<String>,
) {
    let inner = &adapter.inner;

    let conv = match conversation {
        Some(c) => c,
        None => return,
    };

    // Build the AiNxt chat request.
    let user_id = from.as_ref().map(|f| f.id.as_str()).unwrap_or("teams-user");
    let session = format!("teams-{}-{}", conv.id, user_id);
    let turn = format!("t-{}", chrono_ts());
    let chat_url = format!(
        "{}/v1/bots/{}/chat",
        inner.ainxt_base_url, inner.bot_id
    );

    let body = serde_json::json!({
        "session": session,
        "turn": turn,
        "input": text,
        "data_class": "public",
    });

    // Call the AiNxt bot chat API.
    let response_text = match call_ainxt_chat(&inner.http, &chat_url, body).await {
        Ok(t) => t,
        Err(e) => format!("⚠ Error: {}", e),
    };

    if response_text.is_empty() || service_url.is_empty() {
        return;
    }

    // Acquire a Bot Framework token.
    let token = match acquire_bot_token(&inner.http, &inner.app_id, &inner.app_password).await {
        Ok(t) => t,
        Err(e) => {
            eprintln!("[ainxt-channel-teams] token error: {}", e);
            return;
        }
    };

    // Post the reply back to Teams.
    let reply_url = format!(
        "{}/v3/conversations/{}/activities",
        service_url.trim_end_matches('/'),
        conv.id
    );

    let bot_account = recipient.unwrap_or(ChannelAccount {
        id: inner.app_id.clone(),
        name: Some("AiNxt Bot".to_string()),
    });
    let user_account = from.unwrap_or(ChannelAccount {
        id: "teams-user".to_string(),
        name: None,
    });

    let reply = ReplyActivity {
        kind: "message".to_string(),
        text: response_text,
        conversation: conv,
        from: bot_account,
        recipient: user_account,
        reply_to_id: activity_id,
    };

    let _ = inner
        .http
        .post(&reply_url)
        .bearer_auth(&token)
        .json(&reply)
        .send()
        .await;
}

/// Call the AiNxt bot chat SSE endpoint and collect the full text response.
async fn call_ainxt_chat(
    http: &reqwest::Client,
    url: &str,
    body: serde_json::Value,
) -> Result<String, String> {
    let res = http
        .post(url)
        .header("Content-Type", "application/json")
        .header("Accept", "text/event-stream")
        .json(&body)
        .send()
        .await
        .map_err(|e| e.to_string())?;

    if !res.status().is_success() {
        let status = res.status();
        let text = res.text().await.unwrap_or_default();
        return Err(format!("HTTP {}: {}", status, text));
    }

    let mut full_text = String::new();
    let text = res.text().await.map_err(|e| e.to_string())?;

    for line in text.lines() {
        if let Some(data) = line.strip_prefix("data: ") {
            let data = data.trim();
            if data == "[DONE]" {
                break;
            }
            if let Ok(ev) = serde_json::from_str::<serde_json::Value>(data) {
                let event_type = ev.get("type").and_then(|t| t.as_str()).unwrap_or("");
                let delta = ev.get("text")
                    .or_else(|| ev.get("delta"))
                    .or_else(|| ev.get("content"))
                    .and_then(|v| v.as_str())
                    .unwrap_or("");

                if event_type == "text_delta" || event_type == "TextDelta"
                    || event_type == "token" || event_type == "chunk"
                    || (!delta.is_empty() && event_type != "turn.completed" && event_type != "TurnCompleted")
                {
                    full_text.push_str(delta);
                }
            }
        }
    }

    Ok(full_text.trim().to_string())
}

fn chrono_ts() -> u64 {
    std::time::SystemTime::now()
        .duration_since(std::time::UNIX_EPOCH)
        .map(|d| d.as_millis() as u64)
        .unwrap_or(0)
}

// ---------------------------------------------------------------------------
// Tests
// ---------------------------------------------------------------------------

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn teams_adapter_new() {
        let adapter = TeamsAdapter::new(
            "app-id",
            "app-password",
            "http://localhost:8080",
            "my-bot",
        );
        assert_eq!(adapter.inner.bot_id, "my-bot");
        assert_eq!(adapter.inner.app_id, "app-id");
        assert_eq!(adapter.inner.ainxt_base_url, "http://localhost:8080");
    }

    #[test]
    fn activity_deserialize() {
        let json = r#"{
            "type": "message",
            "text": "Hello bot!",
            "serviceUrl": "https://smba.trafficmanager.net/teams/",
            "conversation": { "id": "conv-123" },
            "from": { "id": "user-456", "name": "Alice" }
        }"#;
        let activity: Activity = serde_json::from_str(json).unwrap();
        assert_eq!(activity.kind, "message");
        assert_eq!(activity.text.as_deref(), Some("Hello bot!"));
    }
}
