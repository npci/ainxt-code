// SPDX-License-Identifier: Apache-2.0
//! ainxt-bot — Bot manifest, registry, and channel configuration for the AiNxt Bot Platform.
//!
//! This crate provides the core data structures and in-memory registry for managing bots
//! on the AiNxt Bot Platform. Each bot is defined by a [`BotManifest`] that specifies its
//! identity, persona (system prompt), model policy, autonomy level, and channel configuration.
//!
//! # Example
//! ```rust
//! use ainxt_bot::{BotManifest, BotRegistry, BotStatus, Autonomy, ChannelConfig};
//! use std::sync::Arc;
//!
//! let registry = BotRegistry::new();
//! let bot = BotManifest {
//!     id: "upi-assistant".to_string(),
//!     name: "UPI Assistant".to_string(),
//!     description: "Answers UPI payment questions".to_string(),
//!     persona: "You are a helpful UPI payment assistant.".to_string(),
//!     model_policy: "standard".to_string(),
//!     autonomy: Autonomy::Auto,
//!     channels: ChannelConfig::default(),
//!     knowledge_namespace: Some("upi_kb".to_string()),
//!     created_at: "2026-09-23T00:00:00Z".to_string(),
//!     status: BotStatus::Active,
//! };
//! registry.register(bot);
//! ```

use std::collections::HashMap;
use std::sync::{Arc, Mutex};

use chrono::Utc;
use serde::{Deserialize, Serialize};
use uuid::Uuid;

// ---------------------------------------------------------------------------
// Bot status
// ---------------------------------------------------------------------------

/// Operational status of a bot.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "lowercase")]
pub enum BotStatus {
    /// Bot is running and accepting requests.
    Active,
    /// Bot is paused — requests are rejected with a 503.
    Paused,
    /// Bot encountered an unrecoverable error.
    Error,
}

impl Default for BotStatus {
    fn default() -> Self {
        BotStatus::Active
    }
}

impl std::fmt::Display for BotStatus {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            BotStatus::Active => write!(f, "active"),
            BotStatus::Paused => write!(f, "paused"),
            BotStatus::Error => write!(f, "error"),
        }
    }
}

// ---------------------------------------------------------------------------
// Autonomy level
// ---------------------------------------------------------------------------

/// How autonomously the bot acts.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "lowercase")]
pub enum Autonomy {
    /// Bot acts fully autonomously — no human-in-the-loop.
    Auto,
    /// Bot suggests actions but waits for human confirmation.
    Assisted,
    /// Bot escalates to a human agent when uncertain.
    Escalate,
}

impl Default for Autonomy {
    fn default() -> Self {
        Autonomy::Auto
    }
}

// ---------------------------------------------------------------------------
// Channel configuration
// ---------------------------------------------------------------------------

/// Slack channel adapter configuration.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct SlackConfig {
    /// Slack bot OAuth token (xoxb-...).
    pub bot_token: String,
    /// Slack signing secret for request verification.
    pub signing_secret: String,
    /// Default channel ID to post responses to.
    pub channel_id: String,
}

/// Microsoft Teams channel adapter configuration.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct TeamsConfig {
    /// Azure AD application (client) ID.
    pub app_id: String,
    /// Azure AD application password / client secret.
    pub app_password: String,
    /// Azure AD tenant ID.
    pub tenant_id: String,
}

/// Which channels this bot is active on.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ChannelConfig {
    /// Serve the embedded web chat widget.
    #[serde(default)]
    pub web: bool,
    /// Slack Events API adapter. `None` = disabled.
    #[serde(default)]
    pub slack: Option<SlackConfig>,
    /// Microsoft Teams Bot Framework adapter. `None` = disabled.
    #[serde(default)]
    pub teams: Option<TeamsConfig>,
    /// Expose the raw REST API (`POST /v1/bots/{id}/chat`).
    #[serde(default = "default_true")]
    pub rest: bool,
}

fn default_true() -> bool {
    true
}

impl Default for ChannelConfig {
    fn default() -> Self {
        ChannelConfig {
            web: true,
            slack: None,
            teams: None,
            rest: true,
        }
    }
}

// ---------------------------------------------------------------------------
// Bot manifest
// ---------------------------------------------------------------------------

/// The full definition of a bot on the AiNxt Bot Platform.
///
/// A manifest is the single source of truth for a bot's identity, behaviour, and channel
/// configuration. It can be serialised to/from YAML (for the `bots/` directory) or JSON
/// (for the REST API).
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct BotManifest {
    /// Stable, URL-safe identifier (e.g. `"upi-assistant"`).
    pub id: String,
    /// Human-readable display name.
    pub name: String,
    /// Short description shown in the Bot Builder UI.
    pub description: String,
    /// System prompt / persona injected before every conversation turn.
    #[serde(alias = "system_prompt")]
    pub persona: String,
    /// Model complexity policy: `"fast"` | `"standard"` | `"complex"`.
    #[serde(default = "default_model_policy")]
    pub model_policy: String,
    /// Autonomy level.
    #[serde(default)]
    pub autonomy: Autonomy,
    /// Channel configuration.
    #[serde(default)]
    pub channels: ChannelConfig,
    /// Knowledge namespace for RAG retrieval (e.g. `"upi_kb"`). `None` = no RAG.
    #[serde(default)]
    pub knowledge_namespace: Option<String>,
    /// ISO-8601 creation timestamp.
    #[serde(default = "now_rfc3339")]
    pub created_at: String,
    /// Current operational status.
    #[serde(default)]
    pub status: BotStatus,
}

fn default_model_policy() -> String {
    "standard".to_string()
}

fn now_rfc3339() -> String {
    Utc::now().to_rfc3339()
}

impl BotManifest {
    /// Create a new bot manifest with a generated UUID as the id.
    pub fn new(name: impl Into<String>, persona: impl Into<String>) -> Self {
        BotManifest {
            id: Uuid::new_v4().to_string(),
            name: name.into(),
            description: String::new(),
            persona: persona.into(),
            model_policy: default_model_policy(),
            autonomy: Autonomy::default(),
            channels: ChannelConfig::default(),
            knowledge_namespace: None,
            created_at: now_rfc3339(),
            status: BotStatus::Active,
        }
    }

    /// Deserialise a bot manifest from a YAML string.
    pub fn from_yaml(s: &str) -> Result<Self, serde_yaml::Error> {
        serde_yaml::from_str(s)
    }

    /// Serialise this manifest to a YAML string.
    pub fn to_yaml(&self) -> Result<String, serde_yaml::Error> {
        serde_yaml::to_string(self)
    }

    /// Deserialise a bot manifest from a JSON string.
    pub fn from_json(s: &str) -> Result<Self, serde_json::Error> {
        serde_json::from_str(s)
    }

    /// Serialise this manifest to a JSON string.
    pub fn to_json(&self) -> Result<String, serde_json::Error> {
        serde_json::to_string(self)
    }

    /// Returns `true` if the bot is currently accepting requests.
    pub fn is_active(&self) -> bool {
        self.status == BotStatus::Active
    }
}

// ---------------------------------------------------------------------------
// Bot registry
// ---------------------------------------------------------------------------

/// Thread-safe in-memory registry of all registered bots.
///
/// The registry is the single source of truth for the bot platform's runtime state.
/// It is shared across all HTTP handlers via `Arc<BotRegistry>`.
#[derive(Debug, Default)]
pub struct BotRegistry {
    inner: Arc<Mutex<HashMap<String, BotManifest>>>,
}

impl BotRegistry {
    /// Create an empty registry.
    pub fn new() -> Self {
        BotRegistry::default()
    }

    /// Register (or replace) a bot. Returns the bot's id.
    pub fn register(&self, bot: BotManifest) -> String {
        let id = bot.id.clone();
        self.inner
            .lock()
            .expect("bot registry lock")
            .insert(id.clone(), bot);
        id
    }

    /// Look up a bot by id. Returns `None` if not found.
    pub fn get(&self, id: &str) -> Option<BotManifest> {
        self.inner
            .lock()
            .expect("bot registry lock")
            .get(id)
            .cloned()
    }

    /// List all registered bots (order is unspecified).
    pub fn list(&self) -> Vec<BotManifest> {
        self.inner
            .lock()
            .expect("bot registry lock")
            .values()
            .cloned()
            .collect()
    }

    /// Update the status of a bot. Returns `false` if the bot was not found.
    pub fn update_status(&self, id: &str, status: BotStatus) -> bool {
        let mut guard = self.inner.lock().expect("bot registry lock");
        if let Some(bot) = guard.get_mut(id) {
            bot.status = status;
            true
        } else {
            false
        }
    }

    /// Remove a bot from the registry. Returns the removed manifest, or `None`.
    pub fn remove(&self, id: &str) -> Option<BotManifest> {
        self.inner
            .lock()
            .expect("bot registry lock")
            .remove(id)
    }

    /// Returns the number of registered bots.
    pub fn len(&self) -> usize {
        self.inner.lock().expect("bot registry lock").len()
    }

    /// Returns `true` if no bots are registered.
    pub fn is_empty(&self) -> bool {
        self.len() == 0
    }
}

// ---------------------------------------------------------------------------
// Tests
// ---------------------------------------------------------------------------

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn register_and_get() {
        let reg = BotRegistry::new();
        let bot = BotManifest::new("Test Bot", "You are a test bot.");
        let id = reg.register(bot.clone());
        let found = reg.get(&id).expect("bot should be found");
        assert_eq!(found.name, "Test Bot");
    }

    #[test]
    fn update_status() {
        let reg = BotRegistry::new();
        let bot = BotManifest::new("Bot", "persona");
        let id = reg.register(bot);
        assert!(reg.update_status(&id, BotStatus::Paused));
        assert_eq!(reg.get(&id).unwrap().status, BotStatus::Paused);
    }

    #[test]
    fn remove() {
        let reg = BotRegistry::new();
        let bot = BotManifest::new("Bot", "persona");
        let id = reg.register(bot);
        assert!(reg.remove(&id).is_some());
        assert!(reg.get(&id).is_none());
    }

    #[test]
    fn yaml_roundtrip() {
        let bot = BotManifest {
            id: "upi-assistant".to_string(),
            name: "UPI Assistant".to_string(),
            description: "Answers UPI questions".to_string(),
            persona: "You are a UPI assistant.".to_string(),
            model_policy: "standard".to_string(),
            autonomy: Autonomy::Auto,
            channels: ChannelConfig::default(),
            knowledge_namespace: Some("upi_kb".to_string()),
            created_at: "2026-09-23T00:00:00Z".to_string(),
            status: BotStatus::Active,
        };
        let yaml = bot.to_yaml().expect("serialize");
        let back = BotManifest::from_yaml(&yaml).expect("deserialize");
        assert_eq!(back.id, bot.id);
        assert_eq!(back.name, bot.name);
        assert_eq!(back.knowledge_namespace, bot.knowledge_namespace);
    }
}
