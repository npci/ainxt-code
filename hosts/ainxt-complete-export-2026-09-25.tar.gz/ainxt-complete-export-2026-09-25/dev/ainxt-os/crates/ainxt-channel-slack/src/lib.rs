// SPDX-License-Identifier: Apache-2.0
//! ainxt-channel-slack — Slack Events API channel adapter for the AiNxt Bot Platform.
//!
//! Handles incoming Slack events, verifies the request signature (HMAC-SHA256),
//! and forwards messages to the AiNxt bot chat API, posting the response back to Slack.
//!
//! # Usage
//! ```rust,ignore
//! use ainxt_channel_slack::SlackAdapter;
//!
//! let adapter = SlackAdapter::new(
//!     "my-signing-secret",
//!     "xoxb-my-bot-token",
//!     "http://localhost:8080",
//!     "upi-assistant",
//! );
//! let router = adapter.router();
//! // Merge into your axum app: app.merge(router)
//! ```
//!
//! # Slack setup
//! 1. Create a Slack app at <https://api.slack.com/apps>
//! 2. Enable Events API, set the Request URL to `https://your-host/slack/events`
//! 3. Subscribe to `message.channels` and `app_mention` events
//! 4. Copy the Signing Secret and Bot Token into your config

use std::sync::Arc;

use axum::body::Bytes;
use axum::extract::State;
use axum::http::{HeaderMap, StatusCode};
use axum::response::{IntoResponse, Response};
use axum::routing::post;
use axum::Router;
use serde::{Deserialize, Serialize};

// ---------------------------------------------------------------------------
// Slack event types
// ---------------------------------------------------------------------------

/// Top-level Slack Events API payload.
#[derive(Debug, Deserialize)]
pub struct SlackPayload {
    /// Event type: `"url_verification"` or `"event_callback"`.
    #[serde(rename = "type")]
    pub kind: String,
    /// URL verification challenge (only present for `url_verification`).
    pub challenge: Option<String>,
    /// The inner event (only present for `event_callback`).
    pub event: Option<SlackEvent>,
    /// The team/workspace ID.
    pub team_id: Option<String>,
}

/// Inner Slack event.
#[derive(Debug, Deserialize)]
pub struct SlackEvent {
    /// Event type: `"message"`, `"app_mention"`, etc.
    #[serde(rename = "type")]
    pub kind: String,
    /// The message text.
    pub text: Option<String>,
    /// The channel the message was posted in.
    pub channel: Option<String>,
    /// The user who sent the message.
    pub user: Option<String>,
    /// Thread timestamp (for threaded replies).
    pub thread_ts: Option<String>,
    /// Message timestamp (used as the reply thread anchor).
    pub ts: Option<String>,
    /// Bot ID — set when the message was sent by a bot (to avoid loops).
    pub bot_id: Option<String>,
}

/// Response to a Slack URL verification challenge.
#[derive(Debug, Serialize)]
struct ChallengeResponse {
    challenge: String,
}

// ---------------------------------------------------------------------------
// Slack adapter
// ---------------------------------------------------------------------------

/// The Slack Events API adapter.
///
/// Verifies incoming requests using HMAC-SHA256 over the Slack signing secret,
/// then forwards `message` events to the AiNxt bot chat API and posts the
/// response back to Slack via `chat.postMessage`.
#[derive(Clone)]
pub struct SlackAdapter {
    inner: Arc<SlackAdapterInner>,
}

struct SlackAdapterInner {
    signing_secret: String,
    bot_token: String,
    ainxt_base_url: String,
    bot_id: String,
    http: reqwest::Client,
}

impl SlackAdapter {
    /// Create a new Slack adapter.
    ///
    /// # Arguments
    /// * `signing_secret` — Slack app signing secret (from the app settings page).
    /// * `bot_token` — Slack bot OAuth token (`xoxb-...`).
    /// * `ainxt_base_url` — Base URL of the AiNxt server (e.g. `http://localhost:8080`).
    /// * `bot_id` — The AiNxt bot ID to forward messages to.
    pub fn new(
        signing_secret: impl Into<String>,
        bot_token: impl Into<String>,
        ainxt_base_url: impl Into<String>,
        bot_id: impl Into<String>,
    ) -> Self {
        SlackAdapter {
            inner: Arc::new(SlackAdapterInner {
                signing_secret: signing_secret.into(),
                bot_token: bot_token.into(),
                ainxt_base_url: ainxt_base_url.into().trim_end_matches('/').to_string(),
                bot_id: bot_id.into(),
                http: reqwest::Client::new(),
            }),
        }
    }

    /// Build the axum [`Router`] with the Slack events endpoint.
    ///
    /// Mount at `POST /slack/events`.
    pub fn router(self) -> Router {
        Router::new()
            .route("/slack/events", post(slack_events_handler))
            .with_state(self)
    }
}

// ---------------------------------------------------------------------------
// Signature verification
// ---------------------------------------------------------------------------

/// Verify the Slack request signature (HMAC-SHA256).
///
/// Slack signs every request with `HMAC-SHA256(signing_secret, "v0:{timestamp}:{body}")`.
/// The signature is in the `X-Slack-Signature` header; the timestamp is in
/// `X-Slack-Request-Timestamp`. We reject requests older than 5 minutes.
fn verify_slack_signature(
    signing_secret: &str,
    headers: &HeaderMap,
    body: &[u8],
) -> Result<(), &'static str> {
    let timestamp = headers
        .get("x-slack-request-timestamp")
        .and_then(|v| v.to_str().ok())
        .ok_or("missing X-Slack-Request-Timestamp")?;

    let signature = headers
        .get("x-slack-signature")
        .and_then(|v| v.to_str().ok())
        .ok_or("missing X-Slack-Signature")?;

    // Reject stale requests (replay protection).
    let ts: i64 = timestamp.parse().map_err(|_| "invalid timestamp")?;
    let now = std::time::SystemTime::now()
        .duration_since(std::time::UNIX_EPOCH)
        .map(|d| d.as_secs() as i64)
        .unwrap_or(0);
    if (now - ts).abs() > 300 {
        return Err("request timestamp too old");
    }

    // Compute expected signature using manual HMAC-SHA256 (same approach as ainxt-server).
    let base = format!("v0:{}:{}", timestamp, String::from_utf8_lossy(body));
    let mac = hmac_sha256(signing_secret.as_bytes(), base.as_bytes());
    let expected = format!("v0={}", hex_encode(&mac));

    // Constant-time compare.
    if !ct_eq(expected.as_bytes(), signature.as_bytes()) {
        return Err("signature mismatch");
    }

    Ok(())
}

/// HMAC-SHA256 (RFC 2104) — manual implementation using only the `sha2` crate.
/// Block size B = 64 for SHA-256.
fn hmac_sha256(key: &[u8], msg: &[u8]) -> [u8; 32] {
    use sha2::{Digest, Sha256};
    const B: usize = 64;
    let mut k = [0u8; B];
    if key.len() > B {
        let h = Sha256::digest(key);
        k[..32].copy_from_slice(&h);
    } else {
        k[..key.len()].copy_from_slice(key);
    }
    let mut ipad = [0x36u8; B];
    let mut opad = [0x5cu8; B];
    for i in 0..B {
        ipad[i] ^= k[i];
        opad[i] ^= k[i];
    }
    let mut inner = Sha256::new();
    inner.update(ipad);
    inner.update(msg);
    let inner_digest = inner.finalize();
    let mut outer = Sha256::new();
    outer.update(opad);
    outer.update(inner_digest);
    let mut out = [0u8; 32];
    out.copy_from_slice(&outer.finalize());
    out
}

/// Encode bytes as a lowercase hex string (no external crate needed).
fn hex_encode(bytes: &[u8]) -> String {
    const HEX: &[u8; 16] = b"0123456789abcdef";
    let mut out = String::with_capacity(bytes.len() * 2);
    for &b in bytes {
        out.push(HEX[(b >> 4) as usize] as char);
        out.push(HEX[(b & 0xf) as usize] as char);
    }
    out
}

/// Constant-time byte comparison (no early return on mismatch).
fn ct_eq(a: &[u8], b: &[u8]) -> bool {
    if a.len() != b.len() {
        return false;
    }
    let mut diff = 0u8;
    for (x, y) in a.iter().zip(b.iter()) {
        diff |= x ^ y;
    }
    diff == 0
}

// ---------------------------------------------------------------------------
// Event handler
// ---------------------------------------------------------------------------

async fn slack_events_handler(
    State(adapter): State<SlackAdapter>,
    headers: HeaderMap,
    body: Bytes,
) -> Response {
    // 1. Verify signature.
    if let Err(reason) = verify_slack_signature(&adapter.inner.signing_secret, &headers, &body) {
        return (StatusCode::UNAUTHORIZED, reason).into_response();
    }

    // 2. Parse payload.
    let payload: SlackPayload = match serde_json::from_slice(&body) {
        Ok(p) => p,
        Err(e) => {
            return (StatusCode::BAD_REQUEST, format!("invalid JSON: {}", e)).into_response()
        }
    };

    // 3. Handle URL verification challenge (Slack sends this when you first configure the endpoint).
    if payload.kind == "url_verification" {
        let challenge = payload.challenge.unwrap_or_default();
        return axum::Json(ChallengeResponse { challenge }).into_response();
    }

    // 4. Handle event callbacks.
    if payload.kind == "event_callback" {
        if let Some(event) = payload.event {
            // Ignore bot messages to avoid infinite loops.
            if event.bot_id.is_some() {
                return StatusCode::OK.into_response();
            }

            // Only handle message and app_mention events.
            if event.kind == "message" || event.kind == "app_mention" {
                let text = event.text.unwrap_or_default();
                let channel = event.channel.unwrap_or_default();
                let thread_ts = event.thread_ts.or(event.ts).unwrap_or_default();
                let user = event.user.unwrap_or_else(|| "slack-user".to_string());

                // Spawn async task to avoid blocking the Slack 3-second timeout.
                let adapter_clone = adapter.clone();
                tokio::spawn(async move {
                    handle_slack_message(adapter_clone, text, channel, thread_ts, user).await;
                });
            }
        }
    }

    StatusCode::OK.into_response()
}

async fn handle_slack_message(
    adapter: SlackAdapter,
    text: String,
    channel: String,
    thread_ts: String,
    user: String,
) {
    let inner = &adapter.inner;

    // Build the AiNxt chat request.
    let session = format!("slack-{}-{}", channel, user);
    let turn = format!("t-{}", chrono_ts());
    let chat_url = format!(
        "{}/v1/bots/{}/chat",
        inner.ainxt_base_url, inner.bot_id
    );

    let body = serde_json::json!({
        "session": session,
        "turn": turn,
        "input": text,
        "data_class": "public",
    });

    // Call the AiNxt bot chat API and collect the full response.
    let response_text = match call_ainxt_chat(&inner.http, &chat_url, body).await {
        Ok(t) => t,
        Err(e) => format!("⚠ Error: {}", e),
    };

    if response_text.is_empty() {
        return;
    }

    // Post the response back to Slack.
    let post_url = "https://slack.com/api/chat.postMessage";
    let mut msg = serde_json::json!({
        "channel": channel,
        "text": response_text,
    });
    if !thread_ts.is_empty() {
        msg["thread_ts"] = serde_json::Value::String(thread_ts);
    }

    let _ = inner
        .http
        .post(post_url)
        .bearer_auth(&inner.bot_token)
        .json(&msg)
        .send()
        .await;
}

/// Call the AiNxt bot chat SSE endpoint and collect the full text response.
async fn call_ainxt_chat(
    http: &reqwest::Client,
    url: &str,
    body: serde_json::Value,
) -> Result<String, String> {
    let res = http
        .post(url)
        .header("Content-Type", "application/json")
        .header("Accept", "text/event-stream")
        .json(&body)
        .send()
        .await
        .map_err(|e| e.to_string())?;

    if !res.status().is_success() {
        let status = res.status();
        let text = res.text().await.unwrap_or_default();
        return Err(format!("HTTP {}: {}", status, text));
    }

    // Read the SSE stream and accumulate text deltas.
    let mut full_text = String::new();
    let text = res.text().await.map_err(|e| e.to_string())?;

    for line in text.lines() {
        if let Some(data) = line.strip_prefix("data: ") {
            let data = data.trim();
            if data == "[DONE]" {
                break;
            }
            if let Ok(ev) = serde_json::from_str::<serde_json::Value>(data) {
                let event_type = ev.get("type").and_then(|t| t.as_str()).unwrap_or("");
                let delta = ev.get("text")
                    .or_else(|| ev.get("delta"))
                    .or_else(|| ev.get("content"))
                    .and_then(|v| v.as_str())
                    .unwrap_or("");

                if event_type == "text_delta" || event_type == "TextDelta"
                    || event_type == "token" || event_type == "chunk"
                    || (!delta.is_empty() && event_type != "turn.completed" && event_type != "TurnCompleted")
                {
                    full_text.push_str(delta);
                }
            }
        }
    }

    Ok(full_text.trim().to_string())
}

fn chrono_ts() -> u64 {
    std::time::SystemTime::now()
        .duration_since(std::time::UNIX_EPOCH)
        .map(|d| d.as_millis() as u64)
        .unwrap_or(0)
}

// ---------------------------------------------------------------------------
// Tests
// ---------------------------------------------------------------------------

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn ct_eq_works() {
        assert!(ct_eq(b"hello", b"hello"));
        assert!(!ct_eq(b"hello", b"world"));
        assert!(!ct_eq(b"hello", b"hell"));
    }

    #[test]
    fn slack_adapter_new() {
        let adapter = SlackAdapter::new("secret", "xoxb-token", "http://localhost:8080", "my-bot");
        assert_eq!(adapter.inner.bot_id, "my-bot");
        assert_eq!(adapter.inner.ainxt_base_url, "http://localhost:8080");
    }
}
