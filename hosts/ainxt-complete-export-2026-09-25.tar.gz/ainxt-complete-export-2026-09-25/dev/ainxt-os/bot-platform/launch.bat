@echo off
title AiNxt Workspace
cd /d "%~dp0"

where node >nul 2>&1
if %ERRORLEVEL% neq 0 (
  echo [ERROR] Node.js not found. Install from https://nodejs.org
  pause & exit /b 1
)

echo.
echo  Stopping any existing server on port 7700...
for /f "tokens=5" %%p in ('netstat -ano 2^>nul ^| findstr ":7700 " ^| findstr "LISTENING"') do (
  taskkill /PID %%p /F >nul 2>&1
  echo  Stopped PID %%p
)
timeout /t 1 /nobreak >nul

echo.
echo  ╔══════════════════════════════════════════╗
echo  ║   AiNxt Workspace                        ║
echo  ║   http://localhost:7700/ui/              ║
echo  ╚══════════════════════════════════════════╝
echo.
echo  Starting server...

REM Open browser after 3 seconds
start "" /b cmd /c "timeout /t 3 /nobreak >nul && start http://localhost:7700/ui/"

node server.js
pause
