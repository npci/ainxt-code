' AiNxt Workspace — System Tray Launcher
' Double-click this file to start AiNxt in the background and open the browser.
' No install required. Requires Node.js 18+ on PATH.

Option Explicit

Dim shell, fso, scriptDir, serverScript, logFile, nodeExe

Set shell = CreateObject("WScript.Shell")
Set fso   = CreateObject("Scripting.FileSystemObject")

scriptDir  = fso.GetParentFolderName(WScript.ScriptFullName)
serverScript = scriptDir & "\server.js"
logFile      = scriptDir & "\server.log"

' ── Find node ────────────────────────────────────────────────────────────────
nodeExe = ""
On Error Resume Next
nodeExe = shell.Exec("where node").StdOut.ReadLine()
On Error GoTo 0

If nodeExe = "" Then
  MsgBox "Node.js not found." & vbCrLf & vbCrLf & _
         "Install from https://nodejs.org (v18+ required)", _
         vbCritical, "AiNxt Workspace"
  WScript.Quit 1
End If

' ── Kill any existing server on port 7700 ────────────────────────────────────
shell.Run "cmd /c for /f ""tokens=5"" %p in ('netstat -ano 2^>nul ^| findstr "":7700 ""') do taskkill /PID %p /F >nul 2>&1", 0, True

' ── Start server (hidden window, output to log) ───────────────────────────────
Dim cmd
cmd = "cmd /c node """ & serverScript & """ > """ & logFile & """ 2>&1"
shell.Run cmd, 0, False   ' 0 = hidden, False = don't wait

' ── Wait for server to be ready (poll /health up to 10s) ─────────────────────
Dim http, ready, attempts
Set http = CreateObject("MSXML2.XMLHTTP")
ready    = False
attempts = 0

Do While Not ready And attempts < 20
  WScript.Sleep 500
  attempts = attempts + 1
  On Error Resume Next
  http.Open "GET", "http://localhost:7700/health", False
  http.Send
  If http.Status = 200 Then ready = True
  On Error GoTo 0
Loop

' ── Open browser ─────────────────────────────────────────────────────────────
If ready Then
  shell.Run "http://localhost:7700/ui/"
Else
  MsgBox "AiNxt server did not start in time." & vbCrLf & _
         "Check: " & logFile, vbExclamation, "AiNxt Workspace"
End If

' ── Show tray notification via PowerShell ────────────────────────────────────
If ready Then
  Dim ps
  ps = "powershell -WindowStyle Hidden -Command """ & _
       "[void][System.Reflection.Assembly]::LoadWithPartialName('System.Windows.Forms');" & _
       "$n=New-Object System.Windows.Forms.NotifyIcon;" & _
       "$n.Icon=[System.Drawing.SystemIcons]::Application;" & _
       "$n.Visible=$true;" & _
       "$n.BalloonTipTitle='AiNxt Workspace';" & _
       "$n.BalloonTipText='Running at http://localhost:7700 — click to open';" & _
       "$n.BalloonTipIcon='Info';" & _
       "$n.ShowBalloonTip(4000);" & _
       "Start-Sleep 5;" & _
       "$n.Dispose()" & """"
  shell.Run ps, 0, False
End If
