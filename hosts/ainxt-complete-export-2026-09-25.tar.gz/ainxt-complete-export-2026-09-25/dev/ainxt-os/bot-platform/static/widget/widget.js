/**
 * AiNxt Bot Widget — Embeddable chat widget.
 *
 * Embed with a single script tag:
 *   <script src="http://localhost:7700/widget.js"
 *           data-bot="upi-assistant"
 *           data-theme="dark"
 *           data-title="UPI Assistant"
 *           data-welcome="Hi! Ask me anything about UPI.">
 *   </script>
 *
 * Connects to the AiNxt Bot Platform server (same origin by default).
 * The platform server proxies to the AiNxt OS runtime — no CORS issues,
 * no Rust install, no build step.
 *
 * SPDX-License-Identifier: Apache-2.0
 */
(function () {
  'use strict';

  var script = document.currentScript || (function () {
    var s = document.getElementsByTagName('script');
    return s[s.length - 1];
  })();

  var BOT_ID      = script.getAttribute('data-bot')         || 'default';
  var BASE_URL    = (script.getAttribute('data-base-url')   || '').replace(/\/$/, '');
  var THEME       = script.getAttribute('data-theme')        || 'dark';
  var BOT_TITLE   = script.getAttribute('data-title')        || 'AiNxt Assistant';
  var PLACEHOLDER = script.getAttribute('data-placeholder')  || 'Ask me anything…';
  var WELCOME     = script.getAttribute('data-welcome')      ||
    'Hello! I\'m your AI assistant. How can I help you today?';

  var sessionId   = 'w-' + Math.random().toString(36).slice(2, 10);
  var turnCount   = 0;
  var isOpen      = false;
  var isStreaming = false;
  var activeFetch = null;

  // ── Styles ────────────────────────────────────────────────────────────────
  var CSS = `
#ainxt-launcher {
  position: fixed; bottom: 24px; right: 24px; z-index: 99998;
  width: 56px; height: 56px; border-radius: 50%; border: none; cursor: pointer;
  background: #6366f1; color: #fff; box-shadow: 0 4px 20px rgba(99,102,241,.5);
  display: flex; align-items: center; justify-content: center;
  transition: transform .2s, box-shadow .2s;
}
#ainxt-launcher:hover { transform: scale(1.08); box-shadow: 0 6px 28px rgba(99,102,241,.65); }
#ainxt-launcher svg { width: 26px; height: 26px; fill: #fff; transition: opacity .2s; }
#ainxt-launcher .ico-close { display: none; }
#ainxt-launcher.open .ico-chat  { display: none; }
#ainxt-launcher.open .ico-close { display: block; }

#ainxt-panel {
  position: fixed; bottom: 92px; right: 24px; z-index: 99997;
  width: 380px; height: 560px; border-radius: 20px; overflow: hidden;
  display: flex; flex-direction: column;
  box-shadow: 0 20px 60px rgba(0,0,0,.4);
  transform: scale(.92) translateY(16px); opacity: 0; pointer-events: none;
  transition: transform .22s cubic-bezier(.34,1.56,.64,1), opacity .18s;
}
#ainxt-panel.open { transform: scale(1) translateY(0); opacity: 1; pointer-events: all; }

[data-ainxt-theme="dark"] #ainxt-panel  { background: #1a1a24; color: #e2e2f0; }
[data-ainxt-theme="light"] #ainxt-panel { background: #fff;    color: #111; }

#ainxt-header {
  padding: 14px 16px; display: flex; align-items: center; gap: 10px;
  border-bottom: 1px solid rgba(255,255,255,.07);
  background: #22222e;
}
[data-ainxt-theme="light"] #ainxt-header { background: #f5f5f8; border-color: #e5e5ea; }
#ainxt-header-avatar {
  width: 34px; height: 34px; border-radius: 50%; background: #6366f1;
  display: flex; align-items: center; justify-content: center; flex-shrink: 0;
}
#ainxt-header-avatar svg { width: 18px; height: 18px; fill: #fff; }
#ainxt-header-info { flex: 1; min-width: 0; }
#ainxt-header-name { font-size: 14px; font-weight: 600; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
#ainxt-header-status { font-size: 11px; color: #22c55e; display: flex; align-items: center; gap: 4px; }
#ainxt-header-status::before { content: ''; width: 6px; height: 6px; border-radius: 50%; background: #22c55e; }
#ainxt-clear-btn {
  background: none; border: none; cursor: pointer; padding: 6px; border-radius: 8px;
  color: #8888aa; transition: color .15s, background .15s;
}
#ainxt-clear-btn:hover { color: #e2e2f0; background: rgba(255,255,255,.07); }
#ainxt-clear-btn svg { width: 16px; height: 16px; fill: currentColor; display: block; }

#ainxt-messages {
  flex: 1; overflow-y: auto; padding: 16px; display: flex; flex-direction: column; gap: 10px;
  scroll-behavior: smooth;
}
#ainxt-messages::-webkit-scrollbar { width: 4px; }
#ainxt-messages::-webkit-scrollbar-thumb { background: #2e2e3e; border-radius: 2px; }

.ainxt-msg { display: flex; gap: 8px; animation: ainxtFadeIn .18s ease; }
.ainxt-msg.user { flex-direction: row-reverse; }
.ainxt-msg-avatar {
  width: 28px; height: 28px; border-radius: 50%; flex-shrink: 0;
  display: flex; align-items: center; justify-content: center; font-size: 12px;
}
.ainxt-msg.bot  .ainxt-msg-avatar { background: #6366f1; }
.ainxt-msg.user .ainxt-msg-avatar { background: #374151; }
.ainxt-msg-avatar svg { width: 14px; height: 14px; fill: #fff; }
.ainxt-msg-bubble {
  max-width: 78%; padding: 10px 13px; border-radius: 16px; font-size: 13.5px; line-height: 1.55;
  word-break: break-word; white-space: pre-wrap;
}
.ainxt-msg.bot  .ainxt-msg-bubble { background: #22222e; border: 1px solid #2e2e3e; border-radius: 4px 16px 16px 16px; }
.ainxt-msg.user .ainxt-msg-bubble { background: #6366f1; color: #fff; border-radius: 16px 4px 16px 16px; }
[data-ainxt-theme="light"] .ainxt-msg.bot .ainxt-msg-bubble { background: #f0f0f5; border-color: #e5e5ea; color: #111; }

.ainxt-typing { display: flex; gap: 4px; align-items: center; padding: 4px 0; }
.ainxt-typing span {
  width: 7px; height: 7px; border-radius: 50%; background: #6366f1;
  animation: ainxtBounce 1.1s infinite;
}
.ainxt-typing span:nth-child(2) { animation-delay: .18s; }
.ainxt-typing span:nth-child(3) { animation-delay: .36s; }

#ainxt-input-area {
  padding: 12px; border-top: 1px solid rgba(255,255,255,.07);
  display: flex; gap: 8px; align-items: flex-end;
  background: #22222e;
}
[data-ainxt-theme="light"] #ainxt-input-area { background: #f5f5f8; border-color: #e5e5ea; }
#ainxt-input {
  flex: 1; background: #2e2e3e; border: 1px solid #3a3a4e; border-radius: 12px;
  color: #e2e2f0; font-size: 13.5px; padding: 9px 13px; resize: none;
  outline: none; font-family: inherit; line-height: 1.45; max-height: 120px;
  transition: border-color .15s;
}
[data-ainxt-theme="light"] #ainxt-input { background: #fff; border-color: #d1d5db; color: #111; }
#ainxt-input:focus { border-color: #6366f1; }
#ainxt-input::placeholder { color: #6b7280; }
#ainxt-send {
  width: 38px; height: 38px; border-radius: 10px; border: none; cursor: pointer;
  background: #6366f1; color: #fff; display: flex; align-items: center; justify-content: center;
  flex-shrink: 0; transition: background .15s, transform .1s;
}
#ainxt-send:hover:not(:disabled) { background: #4f46e5; transform: scale(1.05); }
#ainxt-send:disabled { background: #374151; cursor: not-allowed; }
#ainxt-send svg { width: 16px; height: 16px; fill: #fff; }

#ainxt-powered {
  text-align: center; font-size: 10px; color: #4b5563; padding: 4px 0 8px;
  background: #22222e;
}
[data-ainxt-theme="light"] #ainxt-powered { background: #f5f5f8; }
#ainxt-powered a { color: #6366f1; text-decoration: none; }

@keyframes ainxtFadeIn { from { opacity: 0; transform: translateY(6px); } to { opacity: 1; transform: translateY(0); } }
@keyframes ainxtBounce { 0%,60%,100% { transform: translateY(0); } 30% { transform: translateY(-5px); } }

@media (max-width: 440px) {
  #ainxt-panel { width: 100vw; height: 100dvh; bottom: 0; right: 0; border-radius: 0; }
  #ainxt-launcher { bottom: 16px; right: 16px; }
}
`;

  // ── Build DOM ─────────────────────────────────────────────────────────────
  function init() {
    var style = document.createElement('style');
    style.textContent = CSS;
    document.head.appendChild(style);

    var root = document.createElement('div');
    root.setAttribute('data-ainxt-theme', THEME);

    root.innerHTML =
      '<button id="ainxt-launcher" aria-label="Open chat">' +
        '<svg class="ico-chat" viewBox="0 0 24 24"><path d="M20 2H4c-1.1 0-2 .9-2 2v18l4-4h14c1.1 0 2-.9 2-2V4c0-1.1-.9-2-2-2z"/></svg>' +
        '<svg class="ico-close" viewBox="0 0 24 24"><path d="M19 6.41L17.59 5 12 10.59 6.41 5 5 6.41 10.59 12 5 17.59 6.41 19 12 13.41 17.59 19 19 17.59 13.41 12z"/></svg>' +
      '</button>' +
      '<div id="ainxt-panel" role="dialog" aria-label="Chat">' +
        '<div id="ainxt-header">' +
          '<div id="ainxt-header-avatar"><svg viewBox="0 0 24 24"><path d="M12 2a2 2 0 0 1 2 2c0 .74-.4 1.39-1 1.73V7h1a7 7 0 0 1 7 7H3a7 7 0 0 1 7-7h1V5.73c-.6-.34-1-.99-1-1.73a2 2 0 0 1 2-2M7 14a1 1 0 0 0-1 1 1 1 0 0 0 1 1 1 1 0 0 0 1-1 1 1 0 0 0-1-1m10 0a1 1 0 0 0-1 1 1 1 0 0 0 1 1 1 1 0 0 0 1-1 1 1 0 0 0-1-1M5 18a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2v-1H5v1z"/></svg></div>' +
          '<div id="ainxt-header-info">' +
            '<div id="ainxt-header-name">' + esc(BOT_TITLE) + '</div>' +
            '<div id="ainxt-header-status">Online</div>' +
          '</div>' +
          '<button id="ainxt-clear-btn" title="Clear conversation"><svg viewBox="0 0 24 24"><path d="M6 19c0 1.1.9 2 2 2h8c1.1 0 2-.9 2-2V7H6v12zM19 4h-3.5l-1-1h-5l-1 1H5v2h14V4z"/></svg></button>' +
        '</div>' +
        '<div id="ainxt-messages"></div>' +
        '<div id="ainxt-input-area">' +
          '<textarea id="ainxt-input" rows="1" placeholder="' + esc(PLACEHOLDER) + '"></textarea>' +
          '<button id="ainxt-send" aria-label="Send"><svg viewBox="0 0 24 24"><path d="M2.01 21L23 12 2.01 3 2 10l15 2-15 2z"/></svg></button>' +
        '</div>' +
        '<div id="ainxt-powered">Powered by <a href="#" target="_blank">AiNxt OS</a></div>' +
      '</div>';

    document.body.appendChild(root);

    var launcher = root.querySelector('#ainxt-launcher');
    var panel    = root.querySelector('#ainxt-panel');
    var messages = root.querySelector('#ainxt-messages');
    var input    = root.querySelector('#ainxt-input');
    var sendBtn  = root.querySelector('#ainxt-send');
    var clearBtn = root.querySelector('#ainxt-clear-btn');

    // Show welcome message
    appendBotMsg(messages, WELCOME);

    // Toggle panel
    launcher.addEventListener('click', function () {
      isOpen = !isOpen;
      launcher.classList.toggle('open', isOpen);
      panel.classList.toggle('open', isOpen);
      if (isOpen) { input.focus(); }
    });

    // Clear conversation
    clearBtn.addEventListener('click', function () {
      messages.innerHTML = '';
      sessionId = 'w-' + Math.random().toString(36).slice(2, 10);
      turnCount = 0;
      appendBotMsg(messages, WELCOME);
    });

    // Send on Enter (Shift+Enter = newline)
    input.addEventListener('keydown', function (e) {
      if (e.key === 'Enter' && !e.shiftKey) {
        e.preventDefault();
        sendMessage();
      }
    });
    input.addEventListener('input', function () {
      this.style.height = 'auto';
      this.style.height = Math.min(this.scrollHeight, 120) + 'px';
    });
    sendBtn.addEventListener('click', sendMessage);

    function sendMessage() {
      var text = input.value.trim();
      if (!text || isStreaming) return;

      turnCount++;
      var turnId = 't' + turnCount;

      // Show user bubble
      appendUserMsg(messages, text);
      input.value = '';
      input.style.height = 'auto';

      // Show typing indicator
      var typingEl = appendTyping(messages);
      sendBtn.disabled = true;
      isStreaming = true;

      // Bot bubble (filled as tokens arrive)
      var botBubble = null;
      var botText   = '';

      var url = BASE_URL + '/v1/bots/' + encodeURIComponent(BOT_ID) + '/chat';
      var body = JSON.stringify({
        session:    sessionId,
        turn:       turnId,
        input:      text,
        data_class: 'internal',
      });

      fetch(url, {
        method:  'POST',
        headers: { 'Content-Type': 'application/json' },
        body:    body,
      }).then(function (resp) {
        if (!resp.ok) {
          typingEl.remove();
          appendBotMsg(messages, '⚠️ Error ' + resp.status + ': could not reach the bot.');
          done();
          return;
        }
        var reader = resp.body.getReader();
        var decoder = new TextDecoder();
        var buf = '';

        function pump() {
          reader.read().then(function (r) {
            if (r.done) { done(); return; }
            buf += decoder.decode(r.value, { stream: true });
            var parts = buf.split('\n\n');
            buf = parts.pop();
            parts.forEach(function (part) {
              part.split('\n').forEach(function (line) {
                if (!line.startsWith('data: ')) return;
                try {
                  var ev = JSON.parse(line.slice(6));
                  if (ev.type === 'text.delta' && ev.text) {
                    if (!botBubble) {
                      typingEl.remove();
                      botBubble = appendBotMsg(messages, '');
                    }
                    botText += ev.text;
                    botBubble.querySelector('.ainxt-msg-bubble').textContent = botText;
                    messages.scrollTop = messages.scrollHeight;
                  }
                  if (ev.type === 'turn.completed') { done(); }
                  if (ev.type === 'error') {
                    if (!botBubble) typingEl.remove();
                    appendBotMsg(messages, '⚠️ ' + (ev.message || 'Runtime error'));
                    done();
                  }
                } catch (_) {}
              });
            });
            pump();
          }).catch(function () { done(); });
        }
        pump();
      }).catch(function (err) {
        typingEl.remove();
        appendBotMsg(messages, '⚠️ Network error: ' + err.message);
        done();
      });
    }

    function done() {
      isStreaming = false;
      sendBtn.disabled = false;
      input.focus();
    }
  }

  // ── DOM helpers ───────────────────────────────────────────────────────────
  function appendUserMsg(container, text) {
    var el = document.createElement('div');
    el.className = 'ainxt-msg user';
    el.innerHTML =
      '<div class="ainxt-msg-avatar">You</div>' +
      '<div class="ainxt-msg-bubble">' + esc(text) + '</div>';
    container.appendChild(el);
    container.scrollTop = container.scrollHeight;
    return el;
  }

  function appendBotMsg(container, text) {
    var el = document.createElement('div');
    el.className = 'ainxt-msg bot';
    el.innerHTML =
      '<div class="ainxt-msg-avatar"><svg viewBox="0 0 24 24"><path d="M12 2a2 2 0 0 1 2 2c0 .74-.4 1.39-1 1.73V7h1a7 7 0 0 1 7 7H3a7 7 0 0 1 7-7h1V5.73c-.6-.34-1-.99-1-1.73a2 2 0 0 1 2-2M7 14a1 1 0 0 0-1 1 1 1 0 0 0 1 1 1 1 0 0 0 1-1 1 1 0 0 0-1-1m10 0a1 1 0 0 0-1 1 1 1 0 0 0 1 1 1 1 0 0 0 1-1 1 1 0 0 0-1-1M5 18a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2v-1H5v1z"/></svg></div>' +
      '<div class="ainxt-msg-bubble">' + esc(text) + '</div>';
    container.appendChild(el);
    container.scrollTop = container.scrollHeight;
    return el;
  }

  function appendTyping(container) {
    var el = document.createElement('div');
    el.className = 'ainxt-msg bot';
    el.innerHTML =
      '<div class="ainxt-msg-avatar"><svg viewBox="0 0 24 24"><path d="M12 2a2 2 0 0 1 2 2c0 .74-.4 1.39-1 1.73V7h1a7 7 0 0 1 7 7H3a7 7 0 0 1 7-7h1V5.73c-.6-.34-1-.99-1-1.73a2 2 0 0 1 2-2M7 14a1 1 0 0 0-1 1 1 1 0 0 0 1 1 1 1 0 0 0 1-1 1 1 0 0 0-1-1m10 0a1 1 0 0 0-1 1 1 1 0 0 0 1 1 1 1 0 0 0 1-1 1 1 0 0 0-1-1M5 18a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2v-1H5v1z"/></svg></div>' +
      '<div class="ainxt-msg-bubble"><div class="ainxt-typing"><span></span><span></span><span></span></div></div>';
    container.appendChild(el);
    container.scrollTop = container.scrollHeight;
    return el;
  }

  function esc(s) {
    return String(s)
      .replace(/&/g, '&amp;').replace(/</g, '&lt;')
      .replace(/>/g, '&gt;').replace(/"/g, '&quot;');
  }

  // Expose open/close API
  window.AiNxtWidget = { open: function () { if (!isOpen) document.getElementById('ainxt-launcher').click(); } };

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();
