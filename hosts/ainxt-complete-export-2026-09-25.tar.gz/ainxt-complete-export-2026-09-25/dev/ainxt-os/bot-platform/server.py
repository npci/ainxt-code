#!/usr/bin/env python3
# SPDX-License-Identifier: Apache-2.0
"""
AiNxt Bot Platform Server
=========================
A pure-Python HTTP server that:
  - Manages a registry of bots (in-memory + bots/*.yaml)
  - Proxies chat requests to the AiNxt OS runtime (UAT: https://10.236.8.77)
  - Serves the Bot Builder UI and embeddable web widget
  - Exposes a clean REST API for bot CRUD + chat

No Rust, no npm, no build step required.
Run:  python server.py
"""

import json
import os
import re
import ssl
import time
import uuid
import threading
import urllib.request
import urllib.error
from datetime import datetime, timezone
from http.server import BaseHTTPRequestHandler, HTTPServer
from pathlib import Path
from typing import Optional
from urllib.parse import urlparse, parse_qs

# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------

RUNTIME_URL   = os.environ.get("AINXT_RUNTIME_URL", "https://10.236.8.77/ainxt/v1/api/runtime")
RUNTIME_USER  = os.environ.get("AINXT_RUNTIME_USER", "bot-platform")
RUNTIME_CAPS  = os.environ.get("AINXT_RUNTIME_CAPS", "chat.send")
SERVER_HOST   = os.environ.get("BOT_PLATFORM_HOST", "0.0.0.0")
SERVER_PORT   = int(os.environ.get("BOT_PLATFORM_PORT", "7700"))
BOTS_DIR      = Path(__file__).parent / "bots"
STATIC_DIR    = Path(__file__).parent / "static"

# ---------------------------------------------------------------------------
# Bot Registry
# ---------------------------------------------------------------------------

class BotRegistry:
    """Thread-safe in-memory bot registry, backed by bots/*.yaml files."""

    def __init__(self):
        self._lock = threading.Lock()
        self._bots: dict[str, dict] = {}
        self._load_from_disk()

    def _load_from_disk(self):
        """Load all *.yaml bot definitions from the bots/ directory."""
        BOTS_DIR.mkdir(exist_ok=True)
        for f in BOTS_DIR.glob("*.yaml"):
            try:
                bot = _parse_yaml(f.read_text(encoding="utf-8"))
                if bot.get("id"):
                    self._bots[bot["id"]] = _normalise_bot(bot)
                    print(f"  Loaded bot: {bot['id']} ({bot.get('name', '?')})")
            except Exception as e:
                print(f"  [WARN] Failed to load {f.name}: {e}")

    def register(self, bot: dict) -> dict:
        bot = _normalise_bot(bot)
        with self._lock:
            self._bots[bot["id"]] = bot
        _save_bot_yaml(bot)
        return bot

    def get(self, bot_id: str) -> Optional[dict]:
        with self._lock:
            return self._bots.get(bot_id)

    def list(self) -> list[dict]:
        with self._lock:
            return list(self._bots.values())

    def update_status(self, bot_id: str, status: str) -> bool:
        with self._lock:
            if bot_id not in self._bots:
                return False
            self._bots[bot_id]["status"] = status
        return True

    def remove(self, bot_id: str) -> Optional[dict]:
        with self._lock:
            bot = self._bots.pop(bot_id, None)
        if bot:
            p = BOTS_DIR / f"{bot_id}.yaml"
            p.unlink(missing_ok=True)
        return bot


def _normalise_bot(bot: dict) -> dict:
    """Fill in defaults for a bot manifest."""
    return {
        "id":                  bot.get("id") or str(uuid.uuid4()),
        "name":                bot.get("name", "Unnamed Bot"),
        "description":         bot.get("description", ""),
        "persona":             bot.get("persona") or bot.get("system_prompt", ""),
        "model_policy":        bot.get("model_policy", "standard"),
        "autonomy":            bot.get("autonomy", "auto"),
        "knowledge_namespace": bot.get("knowledge_namespace"),
        "status":              bot.get("status", "active"),
        "created_at":          bot.get("created_at") or datetime.now(timezone.utc).isoformat(),
        "channels": {
            "web":   bot.get("channels", {}).get("web", True),
            "rest":  bot.get("channels", {}).get("rest", True),
            "slack": bot.get("channels", {}).get("slack", False),
            "teams": bot.get("channels", {}).get("teams", False),
        },
    }


def _save_bot_yaml(bot: dict):
    """Persist a bot manifest as YAML (simple serialiser, no dependency)."""
    BOTS_DIR.mkdir(exist_ok=True)
    lines = []
    for k, v in bot.items():
        if isinstance(v, dict):
            lines.append(f"{k}:")
            for dk, dv in v.items():
                lines.append(f"  {dk}: {json.dumps(dv)}")
        elif isinstance(v, str) and "\n" in v:
            lines.append(f"{k}: |")
            for line in v.splitlines():
                lines.append(f"  {line}")
        else:
            lines.append(f"{k}: {json.dumps(v)}")
    (BOTS_DIR / f"{bot['id']}.yaml").write_text("\n".join(lines) + "\n", encoding="utf-8")


def _parse_yaml(text: str) -> dict:
    """Minimal YAML parser for bot manifests (key: value, block scalars, nested dicts)."""
    result: dict = {}
    lines = text.splitlines()
    i = 0
    while i < len(lines):
        line = lines[i]
        if not line.strip() or line.strip().startswith("#"):
            i += 1
            continue
        # Nested block (2-space indent)
        m = re.match(r'^(\w[\w_-]*):\s*$', line)
        if m:
            key = m.group(1)
            nested: dict = {}
            i += 1
            while i < len(lines) and (lines[i].startswith("  ") or not lines[i].strip()):
                nl = lines[i]
                nm = re.match(r'^\s+(\w[\w_-]*):\s*(.*)', nl)
                if nm:
                    nk, nv = nm.group(1), nm.group(2).strip()
                    nested[nk] = _coerce(nv)
                i += 1
            result[key] = nested
            continue
        # Block scalar (|)
        m = re.match(r'^(\w[\w_-]*):\s*\|\s*$', line)
        if m:
            key = m.group(1)
            i += 1
            block_lines = []
            while i < len(lines) and (lines[i].startswith("  ") or lines[i].strip() == ""):
                block_lines.append(lines[i][2:] if lines[i].startswith("  ") else "")
                i += 1
            result[key] = "\n".join(block_lines).rstrip()
            continue
        # Simple key: value
        m = re.match(r'^(\w[\w_-]*):\s*(.*)', line)
        if m:
            result[m.group(1)] = _coerce(m.group(2).strip())
        i += 1
    return result


def _coerce(v: str):
    """Coerce a YAML scalar string to a Python value."""
    if v in ("true", "True"):   return True
    if v in ("false", "False"): return False
    if v in ("null", "~", ""):  return None
    if v.startswith('"') and v.endswith('"'):
        try: return json.loads(v)
        except: pass
    try: return int(v)
    except: pass
    return v


# ---------------------------------------------------------------------------
# Runtime proxy
# ---------------------------------------------------------------------------

# Shared SSL context that skips verification (UAT uses self-signed cert)
_SSL_CTX = ssl.create_default_context()
_SSL_CTX.check_hostname = False
_SSL_CTX.verify_mode = ssl.CERT_NONE


def _runtime_chat_stream(bot: dict, session: str, turn: str, user_input: str,
                          data_class: str = "internal", user: str = "bot-platform"):
    """
    Generator that streams SSE events from the AiNxt OS runtime.
    Yields raw bytes (each SSE frame) as they arrive.
    """
    # Prepend persona as system prompt if set
    if bot.get("persona", "").strip():
        augmented = (
            f"[SYSTEM PROMPT]\n{bot['persona'].strip()}\n[END SYSTEM PROMPT]\n\n"
            f"User: {user_input}"
        )
    else:
        augmented = user_input

    # Bot-scoped session so bots don't share session state
    scoped_session = f"bot:{bot['id']}:{session}"

    payload = json.dumps({
        "session":    scoped_session,
        "turn":       turn,
        "input":      augmented,
        "data_class": data_class,
        "caps":       ["chat.send"],
    }).encode("utf-8")

    url = f"{RUNTIME_URL}/v1/chat"
    req = urllib.request.Request(url, data=payload, method="POST")
    req.add_header("Content-Type", "application/json")
    req.add_header("X-AInxt-User", user)
    req.add_header("X-AInxt-Caps", "chat.send")

    try:
        with urllib.request.urlopen(req, context=_SSL_CTX, timeout=120) as resp:
            while True:
                chunk = resp.read(4096)
                if not chunk:
                    break
                yield chunk
    except urllib.error.HTTPError as e:
        body = e.read().decode("utf-8", errors="replace")
        yield f"data: {{\"type\":\"error\",\"message\":{json.dumps(body)}}}\n\n".encode()
    except Exception as e:
        yield f"data: {{\"type\":\"error\",\"message\":{json.dumps(str(e))}}}\n\n".encode()


# ---------------------------------------------------------------------------
# HTTP request handler
# ---------------------------------------------------------------------------

REGISTRY = BotRegistry()


class BotPlatformHandler(BaseHTTPRequestHandler):
    """Single handler for all bot platform routes."""

    def log_message(self, fmt, *args):
        print(f"  {self.address_string()} {fmt % args}")

    # ── routing ──────────────────────────────────────────────────────────────

    def do_GET(self):
        path = urlparse(self.path).path.rstrip("/") or "/"

        if path == "/v1/bots":
            return self._json(200, REGISTRY.list())
        if m := re.fullmatch(r"/v1/bots/([^/]+)", path):
            bot = REGISTRY.get(m.group(1))
            return self._json(200, bot) if bot else self._json(404, {"error": "not found"})
        if path in ("/", "/ui", "/ui/"):
            return self._serve_file(STATIC_DIR / "ui" / "index.html", "text/html")
        if path == "/widget.js":
            return self._serve_file(STATIC_DIR / "widget" / "widget.js", "application/javascript")
        if path == "/widget.css":
            return self._serve_file(STATIC_DIR / "widget" / "widget.css", "text/css")
        if path == "/widget-demo.html":
            return self._serve_file(STATIC_DIR / "widget-demo.html", "text/html")
        if path == "/health":
            return self._json(200, {"status": "ok", "runtime": RUNTIME_URL,
                                    "bots": len(REGISTRY.list()), "ts": datetime.now(timezone.utc).isoformat()})
        return self._json(404, {"error": "not found"})

    def do_POST(self):
        path = urlparse(self.path).path.rstrip("/")
        body = self._read_body()

        # Create bot
        if path == "/v1/bots":
            try:
                data = json.loads(body) if body else {}
            except json.JSONDecodeError as e:
                return self._json(400, {"error": f"invalid JSON: {e}"})
            bot = REGISTRY.register(data)
            return self._json(201, bot)

        # Bot chat (SSE streaming)
        if m := re.fullmatch(r"/v1/bots/([^/]+)/chat", path):
            bot_id = m.group(1)
            bot = REGISTRY.get(bot_id)
            if not bot:
                return self._json(404, {"error": f"bot '{bot_id}' not found"})
            if bot["status"] != "active":
                return self._json(503, {"error": f"bot '{bot_id}' is {bot['status']}"})
            try:
                data = json.loads(body) if body else {}
            except json.JSONDecodeError as e:
                return self._json(400, {"error": f"invalid JSON: {e}"})

            session    = data.get("session", str(uuid.uuid4()))
            turn       = data.get("turn", str(uuid.uuid4()))
            user_input = data.get("input", "")
            data_class = data.get("data_class", "internal")
            user       = data.get("user", RUNTIME_USER)

            # Stream SSE back to the caller
            self.send_response(200)
            self.send_header("Content-Type", "text/event-stream")
            self.send_header("Cache-Control", "no-cache")
            self.send_header("X-Accel-Buffering", "no")
            self.send_header("Access-Control-Allow-Origin", "*")
            self.end_headers()
            try:
                for chunk in _runtime_chat_stream(bot, session, turn, user_input, data_class, user):
                    self.wfile.write(chunk)
                    self.wfile.flush()
            except BrokenPipeError:
                pass
            return

        # Pause / resume
        if m := re.fullmatch(r"/v1/bots/([^/]+)/(pause|resume)", path):
            bot_id, action = m.group(1), m.group(2)
            status = "paused" if action == "pause" else "active"
            if REGISTRY.update_status(bot_id, status):
                return self._json(200, {"id": bot_id, "status": status})
            return self._json(404, {"error": f"bot '{bot_id}' not found"})

        return self._json(404, {"error": "not found"})

    def do_DELETE(self):
        path = urlparse(self.path).path.rstrip("/")
        if m := re.fullmatch(r"/v1/bots/([^/]+)", path):
            bot = REGISTRY.remove(m.group(1))
            return self._json(200, bot) if bot else self._json(404, {"error": "not found"})
        return self._json(404, {"error": "not found"})

    def do_OPTIONS(self):
        self.send_response(204)
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, DELETE, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type, Authorization")
        self.end_headers()

    # ── helpers ───────────────────────────────────────────────────────────────

    def _read_body(self) -> bytes:
        length = int(self.headers.get("Content-Length", 0))
        return self.rfile.read(length) if length else b""

    def _json(self, status: int, data):
        body = json.dumps(data, default=str).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Access-Control-Allow-Origin", "*")
        self.end_headers()
        self.wfile.write(body)

    def _serve_file(self, path: Path, content_type: str):
        if not path.exists():
            return self._json(404, {"error": f"file not found: {path.name}"})
        body = path.read_bytes()
        self.send_response(200)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------

def main():
    print()
    print("╔══════════════════════════════════════════════════════════════╗")
    print("║           AiNxt Bot Platform — Starting                      ║")
    print("╠══════════════════════════════════════════════════════════════╣")
    print(f"║  Runtime:  {RUNTIME_URL:<49}║")
    print(f"║  Server:   http://{SERVER_HOST}:{SERVER_PORT:<43}║")
    print("╚══════════════════════════════════════════════════════════════╝")
    print()
    print("Loading bots from bots/ directory...")

    server = HTTPServer((SERVER_HOST, SERVER_PORT), BotPlatformHandler)

    print()
    print("╔══════════════════════════════════════════════════════════════╗")
    print("║           ✅  AiNxt Bot Platform is running!                 ║")
    print("╠══════════════════════════════════════════════════════════════╣")
    print("║                                                              ║")
    print(f"║  🔧 Bot Builder UI:   http://localhost:{SERVER_PORT}/ui/           ║")
    print(f"║  💬 Widget Demo:      http://localhost:{SERVER_PORT}/widget-demo.html║")
    print(f"║  🔌 REST API:         http://localhost:{SERVER_PORT}/v1/bots        ║")
    print(f"║  ❤️  Health:           http://localhost:{SERVER_PORT}/health         ║")
    print("║                                                              ║")
    print("╚══════════════════════════════════════════════════════════════╝")
    print()
    print("Test the UPI Assistant:")
    print(f'  curl -X POST http://localhost:{SERVER_PORT}/v1/bots/upi-assistant/chat \\')
    print('    -H "Content-Type: application/json" \\')
    print('    -d \'{"session":"s1","turn":"t1","input":"What is UPI?","data_class":"internal"}\'')
    print()
    print("Press Ctrl+C to stop.")
    print()

    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\nShutting down.")
        server.shutdown()


if __name__ == "__main__":
    main()
