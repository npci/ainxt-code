#!/usr/bin/env node
// SPDX-License-Identifier: Apache-2.0
/**
 * AiNxt Workspace Server
 * ======================
 * Pure Node.js 18 — zero npm dependencies, zero build step.
 *
 * All AI complexity lives in AiNxt OS runtime (https://10.236.8.77).
 * This server is a thin shell: session management + SSE proxy + static files.
 *
 * Routes
 *   GET  /health
 *   GET  /v1/sessions                  list conversation threads
 *   POST /v1/sessions                  create thread  { name, agent_id? }
 *   GET  /v1/sessions/:id/messages     message history
 *   POST /v1/sessions/:id/chat         SSE → runtime
 *   GET  /v1/agents                    list agents
 *   POST /v1/agents                    register agent  { id, name, persona, ... }
 *   GET  /v1/agents/:id
 *   DELETE /v1/agents/:id
 *   POST /v1/agents/:id/pause
 *   POST /v1/agents/:id/resume
 *   GET  /ui/                          workspace UI
 *   GET  /widget.js  /widget.css       embeddable widget
 */

'use strict';

const http   = require('http');
const https  = require('https');
const fs     = require('fs');
const path   = require('path');
const crypto = require('crypto');

// ─── Config ──────────────────────────────────────────────────────────────────
const RUNTIME_URL  = process.env.AINXT_RUNTIME_URL  || 'https://10.236.8.77/ainxt/v1/api/runtime';
const RUNTIME_USER = process.env.AINXT_RUNTIME_USER || 'ainxt-workspace';
const HOST         = process.env.BOT_PLATFORM_HOST  || '0.0.0.0';
const PORT         = parseInt(process.env.BOT_PLATFORM_PORT || '7700', 10);
const AGENTS_DIR   = path.join(__dirname, 'bots');
const STATIC_DIR   = path.join(__dirname, 'static');

// ─── In-memory stores ─────────────────────────────────────────────────────────
const _agents   = new Map();   // id → agent
const _sessions = new Map();   // id → session  { id, name, agent_id, messages[], created_at }
const _primed   = new Set();   // scoped session ids already primed with persona

// ─── Agent helpers ────────────────────────────────────────────────────────────
function normaliseAgent(raw) {
  return {
    id:           raw.id || crypto.randomUUID(),
    name:         raw.name         || raw.id || 'Unnamed Agent',
    description:  raw.description  || '',
    persona:      raw.persona      || raw.system_prompt || '',
    model_policy: raw.model_policy || 'standard',
    autonomy:     raw.autonomy     || 'auto',
    status:       raw.status       || 'active',
    channels:     raw.channels     || { web: true, rest: true, slack: false, teams: false },
    skills:       raw.skills       || [],
    created_at:   raw.created_at   || new Date().toISOString(),
  };
}

function loadAgentsFromDisk() {
  fs.mkdirSync(AGENTS_DIR, { recursive: true });
  for (const f of fs.readdirSync(AGENTS_DIR).filter(f => f.endsWith('.yaml'))) {
    try {
      const raw   = fs.readFileSync(path.join(AGENTS_DIR, f), 'utf8');
      const agent = parseYaml(raw);
      if (agent.id) { _agents.set(agent.id, normaliseAgent(agent)); console.log(`  Agent: ${agent.id}`); }
    } catch (e) { console.warn(`  [WARN] ${f}: ${e.message}`); }
  }
}

function saveAgentToDisk(agent) {
  const yaml = toYaml(agent);
  fs.writeFileSync(path.join(AGENTS_DIR, `${agent.id}.yaml`), yaml, 'utf8');
}

function registerAgent(data) {
  const agent = normaliseAgent(data);
  _agents.set(agent.id, agent);
  saveAgentToDisk(agent);
  return agent;
}

// ─── Session helpers ──────────────────────────────────────────────────────────
function createSession(name, agentId) {
  const id = 'sess-' + crypto.randomUUID().slice(0, 8);
  const sess = {
    id,
    name:       name || 'New conversation',
    agent_id:   agentId || null,
    messages:   [],
    created_at: new Date().toISOString(),
  };
  _sessions.set(id, sess);
  return sess;
}

function addMessage(sessId, role, text) {
  const sess = _sessions.get(sessId);
  if (!sess) return;
  sess.messages.push({ role, text, ts: new Date().toISOString() });
}

// ─── Runtime proxy ────────────────────────────────────────────────────────────
function runtimePost(scopedSession, turnId, inputText, dataClass, user) {
  const payload = JSON.stringify({
    session:    scopedSession,
    turn:       turnId,
    input:      inputText,
    data_class: dataClass || 'internal',
    caps:       ['chat.send'],
  });

  const parsed    = new URL(`${RUNTIME_URL}/v1/chat`);
  const isHttps   = parsed.protocol === 'https:';
  const options   = {
    hostname:           parsed.hostname,
    port:               parsed.port || (isHttps ? 443 : 80),
    path:               parsed.pathname + (parsed.search || ''),
    method:             'POST',
    headers: {
      'Content-Type':   'application/json',
      'Content-Length': Buffer.byteLength(payload),
      'X-AInxt-User':   user || RUNTIME_USER,
      'X-AInxt-Caps':   'chat.send',
    },
    rejectUnauthorized: false,
  };

  return new Promise((resolve, reject) => {
    const req = (isHttps ? https : http).request(options, resolve);
    req.on('error', reject);
    req.write(payload);
    req.end();
  });
}

function drainSSE(proxyRes) {
  return new Promise(resolve => {
    const chunks = [];
    proxyRes.on('data', c => chunks.push(c));
    proxyRes.on('end',  () => resolve(Buffer.concat(chunks).toString('utf8')));
    proxyRes.on('error',() => resolve(''));
  });
}

// Extract all text.delta text from a raw SSE string
function extractText(sseRaw) {
  let out = '';
  for (const line of sseRaw.split('\n')) {
    if (!line.startsWith('data: ')) continue;
    try {
      const ev = JSON.parse(line.slice(6));
      if (ev.type === 'text.delta' && ev.text) out += ev.text;
    } catch {}
  }
  return out.trim();
}

// ─── Intent detection ─────────────────────────────────────────────────────────
function detectCreateAgentIntent(text) {
  const t = text.toLowerCase();
  // Match "create/build/make ... agent/bot/assistant" anywhere in the sentence
  return /\b(create|make|build|set up|deploy|add)\b.{0,80}\b(agent|bot|assistant)\b/.test(t);
}

// ─── Extract system prompt from runtime response ───────────────────────────────
// The runtime often returns a full agent spec with a "System Prompt" section.
// We extract it so the UI can offer a one-click Deploy button.
function extractSystemPrompt(responseText) {
  // Pattern 1: markdown heading "System Prompt" followed by content
  let m = responseText.match(/#+\s*System\s*Prompt\s*\n+([\s\S]+?)(?=\n#+\s|\n\*\*Output Schema|\n\*\*Verdict|\n---|\n\*\*Want|$)/i);
  if (m) return m[1].trim();

  // Pattern 2: bold "**System Prompt**" label
  m = responseText.match(/\*\*System\s*Prompt\*\*\s*\n+([\s\S]+?)(?=\n\*\*|\n#+|$)/i);
  if (m) return m[1].trim();

  // Pattern 3: "You are X" paragraph at the start (plain persona)
  m = responseText.match(/^(You are [^\n]{10,}(?:\n(?!\n)[^\n]+)*)/m);
  if (m && m[1].length > 40) return m[1].trim();

  return null;
}

// Extract agent name from runtime response or user input
function extractAgentName(responseText, userInput) {
  // 1. From response: bold heading like "**UPI Dispute Resolution Agent**"
  let m = responseText.match(/\*\*([A-Za-z][^*\n]{3,60}?(?:agent|bot|assistant|monitor|evaluator|reviewer|helper|advisor)[^*\n]{0,20})\*\*/i);
  if (m) return titleCase(m[1].trim());

  // 2. From response: markdown heading
  m = responseText.match(/^#+\s+([A-Za-z][^\n#]{3,60})/m);
  if (m) return titleCase(m[1].trim());

  // 3. From user input: "create a X agent that..." — grab the X part
  m = userInput.match(/(?:create|make|build|set\s+up|deploy)\s+a\s+(.{3,60}?)\s+(?:agent|bot|assistant)/i);
  if (m) return titleCase(m[1].trim()) + ' Agent';

  // 4. From user input: "create an agent called X" or "create agent: X"
  m = userInput.match(/(?:agent|bot)\s+(?:called|named|for)\s+(.{3,50})/i);
  if (m) return titleCase(m[1].trim());

  // 5. Last resort: use first 4 meaningful words of user input
  const words = userInput.replace(/^(create|make|build|a|an|the|new)\s+/gi, '').split(/\s+/).slice(0, 4);
  if (words.length >= 2) return titleCase(words.join(' '));

  return null;
}

function titleCase(str) {
  return str.replace(/\w\S*/g, w => w.charAt(0).toUpperCase() + w.slice(1).toLowerCase());
}

// ─── Workspace intent router ──────────────────────────────────────────────────
// The runtime model has a hardcoded system prompt it cannot override.
// Workspace-level questions (list agents, capabilities, etc.) are answered
// DIRECTLY by the server — no runtime call needed, no hallucination possible.
// Only questions that need real AI reasoning go to the runtime.

// Returns { handled: true, text: '...' } OR { handled: false }
function handleWorkspaceIntent(userInput) {
  const t = userInput.toLowerCase().trim();

  // ── Create agent ───────────────────────────────────────────────────────────
  // Match any short "create/make/build agent" phrase with no specific purpose yet
  if (/^(create|make|build|new|add)\s+(a\s+)?(new\s+)?(agent|bot|assistant)/.test(t) &&
      t.length < 40) {
    return { handled: true, text: `Sure — what should this agent do?\n\nJust describe it in plain English, for example:\n\n- *"A UPI payment assistant that answers merchant queries"*\n- *"A JD evaluator that scores job descriptions"*\n- *"A code reviewer for Python and JavaScript"*\n- *"A daily settlement report summariser"*\n\nTell me the purpose and I'll design and deploy it instantly.` };
  }

  // ── List agents ────────────────────────────────────────────────────────────
  if (/(show|list|what|my)\s+(my\s+)?(agents?|bots?)/.test(t) ||
      /agents?\s+(do\s+i\s+have|available|running|exist)/.test(t) ||
      t === 'agents') {
    const list = [..._agents.values()];
    if (!list.length) {
      return { handled: true, text: `You don't have any agents yet.\n\nJust tell me what you need — for example:\n\n- *"Create a UPI payment assistant"*\n- *"Build a JD evaluator agent"*\n- *"Make a code review bot"*\n\nI'll design it and deploy it for you instantly.` };
    }
    const lines = list.map(a =>
      `**${a.name}** (${a.id}) — ${a.status === 'active' ? '🟢 active' : '⏸ paused'}${a.description ? '\n  ' + a.description : ''}`
    ).join('\n\n');
    return { handled: true, text: `You have **${list.length} agent${list.length > 1 ? 's' : ''}**:\n\n${lines}\n\nWant to chat with one, pause it, or create a new one?` };
  }

  // ── Capabilities / skills ──────────────────────────────────────────────────
  if (/(what\s+(skills|can\s+you|capabilities|features|do\s+you\s+do)|skills\s+available|what\s+is\s+this|what\s+does\s+this|what\s+can\s+you)/.test(t)) {
    const agentCount = _agents.size;
    return { handled: true, text: `**AiNxt Workspace** — your local AI platform for NPCI, powered by AiNxt OS.\n\nHere's what I can do right now:\n\n**🤖 Agents** — Create, deploy and manage AI agents through conversation. You have ${agentCount} agent${agentCount !== 1 ? 's' : ''} running.\n\n**📄 Documents** — Generate TDDs, PRDs, SOPs, reports, emails. Just describe what you need.\n\n**🔍 Code** — Review, write, debug or explain code in any language. Paste it here.\n\n**💬 UPI / Payments** — Answer questions about UPI, IMPS, RuPay, NACH, FASTag, BBPS, settlement, disputes.\n\n**📊 Analysis** — Summarise data, spot patterns, draft insights.\n\n**🔌 Embed anywhere** — Every agent gets a web widget and REST API automatically.\n\nWhat would you like to do?` };
  }

  // ── Health / status ────────────────────────────────────────────────────────
  if (/^(status|health|are\s+you\s+(up|running|working)|is\s+(this|it)\s+(working|up))/.test(t)) {
    return { handled: true, text: `✅ **AiNxt Workspace is running.**\n\n- Runtime: connected to AiNxt OS at \`${RUNTIME_URL}\`\n- Agents registered: ${_agents.size}\n- Port: ${PORT}\n\nEverything is working. What do you need?` };
  }

  // ── Not a workspace-level question — let the runtime handle it ─────────────
  return { handled: false };
}

// ─── Main chat handler ────────────────────────────────────────────────────────
async function handleChat(sessId, userInput, res) {
  const sess    = _sessions.get(sessId);
  if (!sess) { json(res, 404, { error: 'session not found' }); return; }

  const scopedSess = `ws:${sessId}`;
  const turnId     = `t-${Date.now()}-${Math.random().toString(36).slice(2,6)}`;
  const user       = RUNTIME_USER;

  // Record user message
  addMessage(sessId, 'user', userInput);

  // ── Step 1: Try to handle locally (no runtime call needed) ─────────────────
  const local = handleWorkspaceIntent(userInput);
  if (local.handled) {
    // Stream the local answer as a fake SSE response so the UI handles it
    // identically to a real runtime response (markdown, chips, etc.)
    res.writeHead(200, {
      'Content-Type':      'text/event-stream',
      'Cache-Control':     'no-cache',
      'X-Accel-Buffering': 'no',
      'Access-Control-Allow-Origin': '*',
    });
    res.write(`data: {"type":"text.delta","text":${JSON.stringify(local.text)}}\n\n`);
    res.write(`data: {"type":"turn.completed"}\n\n`);
    res.end();
    addMessage(sessId, 'assistant', local.text);
    return;
  }

  // ── Step 2: Send to runtime for real AI reasoning ──────────────────────────
  let proxyRes;
  try {
    proxyRes = await runtimePost(scopedSess, turnId, userInput, 'internal', user);
  } catch (e) {
    json(res, 502, { error: `Runtime unreachable: ${e.message}` });
    return;
  }

  res.writeHead(200, {
    'Content-Type':      'text/event-stream',
    'Cache-Control':     'no-cache',
    'X-Accel-Buffering': 'no',
    'Access-Control-Allow-Origin': '*',
  });

  // Collect full response text while streaming it through
  let fullText = '';
  const chunks = [];

  proxyRes.on('data', chunk => {
    chunks.push(chunk);
    try { res.write(chunk); } catch {}
  });

  proxyRes.on('end', () => {
    fullText = extractText(Buffer.concat(chunks).toString('utf8'));
    addMessage(sessId, 'assistant', fullText);

    // Detect if the runtime returned a deployable agent spec (system prompt block).
    // If so, emit a special SSE event BEFORE closing the stream so the UI can
    // show a one-click Deploy button without any extra round-trip.
    if (detectCreateAgentIntent(userInput) && fullText) {
      // Extract agent name — try response first, fall back to user input
      const agentName = extractAgentName(fullText, userInput);

      if (agentName) {
        const agentId = agentName.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)/g, '');

        // Build the best persona we can:
        // If runtime gave a "System Prompt" block, use that.
        // Otherwise use the full response — it describes what the agent does.
        const systemPrompt = extractSystemPrompt(fullText) || fullText;

        const deployEvent = JSON.stringify({
          type:       'agent.deploy_ready',
          agent_id:   agentId,
          agent_name: agentName,
          persona:    systemPrompt,
          session_id: sessId,
        });
        try { res.write(`data: ${deployEvent}\n\n`); } catch {}
        console.log(`  [DEPLOY-READY] ${agentName} (${agentId})`);
      }
    }

    try { res.end(); } catch {}
  });

  proxyRes.on('error', e => {
    try {
      res.write(`data: {"type":"error","message":${JSON.stringify(e.message)}}\n\n`);
      res.end();
    } catch {}
  });
}

// ─── YAML helpers (no deps) ───────────────────────────────────────────────────
function parseYaml(text) {
  const result = {};
  let currentKey = null, multilineLines = null;
  for (const raw of text.split('\n')) {
    const line = raw.replace(/\r$/, '');
    if (multilineLines !== null) {
      if (line.startsWith('  ') || line.trim() === '') { multilineLines.push(line.replace(/^  /, '')); continue; }
      result[currentKey] = multilineLines.join('\n').trim();
      multilineLines = null;
    }
    if (line.startsWith('#') || !line.trim()) continue;
    const m = line.match(/^([a-zA-Z_][a-zA-Z0-9_]*):\s*(.*)/);
    if (!m) continue;
    const [, k, v] = m;
    if (v.trim() === '|') { currentKey = k; multilineLines = []; continue; }
    result[k] = castYaml(v.trim());
  }
  if (multilineLines !== null) result[currentKey] = multilineLines.join('\n').trim();
  return result;
}

function castYaml(v) {
  if (v === 'true')  return true;
  if (v === 'false') return false;
  if (v === 'null' || v === '~' || v === '') return null;
  if (v.startsWith('"') && v.endsWith('"')) try { return JSON.parse(v); } catch {}
  const n = Number(v);
  if (!isNaN(n) && v !== '') return n;
  return v;
}

function toYaml(obj) {
  let out = '';
  for (const [k, v] of Object.entries(obj)) {
    if (v === null || v === undefined) { out += `${k}: null\n`; continue; }
    if (typeof v === 'object' && !Array.isArray(v)) {
      out += `${k}:\n`;
      for (const [sk, sv] of Object.entries(v)) out += `  ${sk}: ${JSON.stringify(sv)}\n`;
      continue;
    }
    if (typeof v === 'string' && v.includes('\n')) { out += `${k}: |\n  ${v.replace(/\n/g, '\n  ')}\n`; continue; }
    out += `${k}: ${JSON.stringify(v)}\n`;
  }
  return out;
}

// ─── HTTP helpers ─────────────────────────────────────────────────────────────
function json(res, status, body) {
  const data = JSON.stringify(body);
  res.writeHead(status, { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' });
  res.end(data);
}

const MIME = { '.html':'text/html','.js':'application/javascript','.css':'text/css',
               '.json':'application/json','.png':'image/png','.svg':'image/svg+xml','.ico':'image/x-icon' };

function serveFile(filePath, res) {
  if (!fs.existsSync(filePath)) { json(res, 404, { error: 'not found' }); return; }
  const ext  = path.extname(filePath);
  const body = fs.readFileSync(filePath);
  res.writeHead(200, { 'Content-Type': MIME[ext] || 'application/octet-stream',
                       'Cache-Control': 'no-cache' });
  res.end(body);
}

function readBody(req) {
  return new Promise((resolve, reject) => {
    const chunks = [];
    req.on('data', c => chunks.push(c));
    req.on('end',  () => resolve(Buffer.concat(chunks).toString('utf8')));
    req.on('error', reject);
  });
}

// ─── Router ───────────────────────────────────────────────────────────────────
async function router(req, res) {
  const method   = req.method.toUpperCase();
  const pathname = req.url.split('?')[0].replace(/\/$/, '') || '/';

  // CORS preflight
  if (method === 'OPTIONS') {
    res.writeHead(204, { 'Access-Control-Allow-Origin': '*',
                         'Access-Control-Allow-Methods': 'GET,POST,DELETE,OPTIONS',
                         'Access-Control-Allow-Headers': 'Content-Type' });
    res.end(); return;
  }

  const body = (method === 'POST' || method === 'PUT') ? await readBody(req) : '';

  // ── GET routes ──────────────────────────────────────────────────────────────
  if (method === 'GET') {
    if (pathname === '/health') {
      return json(res, 200, {
        status:       'ok',
        runtime:      RUNTIME_URL,
        agents:       _agents.size,
        sessions:     _sessions.size,
        ts:           new Date().toISOString(),
      });
    }

    // Sessions
    if (pathname === '/v1/sessions')
      return json(res, 200, [..._sessions.values()].map(s => ({
        id: s.id, name: s.name, agent_id: s.agent_id,
        message_count: s.messages.length, created_at: s.created_at,
      })));

    let m = pathname.match(/^\/v1\/sessions\/([^/]+)\/messages$/);
    if (m) {
      const sess = _sessions.get(m[1]);
      return sess ? json(res, 200, sess.messages) : json(res, 404, { error: 'session not found' });
    }

    // Agents
    if (pathname === '/v1/agents') return json(res, 200, [..._agents.values()]);
    if (pathname === '/v1/bots')   return json(res, 200, [..._agents.values()]); // compat

    m = pathname.match(/^\/v1\/agents\/([^/]+)$/);
    if (m) {
      const a = _agents.get(m[1]);
      return a ? json(res, 200, a) : json(res, 404, { error: 'not found' });
    }

    // Static
    if (pathname === '' || pathname === '/' || pathname === '/ui')
      return serveFile(path.join(STATIC_DIR, 'ui', 'index.html'), res);
    if (pathname.startsWith('/ui'))
      return serveFile(path.join(STATIC_DIR, 'ui', 'index.html'), res);
    if (pathname === '/widget.js')
      return serveFile(path.join(STATIC_DIR, 'widget', 'widget.js'), res);
    if (pathname === '/widget.css')
      return serveFile(path.join(STATIC_DIR, 'widget', 'widget.css'), res);
    if (pathname === '/widget-demo.html')
      return serveFile(path.join(STATIC_DIR, 'widget-demo.html'), res);

    return json(res, 404, { error: 'not found' });
  }

  // ── POST routes ─────────────────────────────────────────────────────────────
  if (method === 'POST') {
    let data = {};
    try { if (body) data = JSON.parse(body); } catch (e) { return json(res, 400, { error: 'invalid JSON' }); }

    // Create session
    if (pathname === '/v1/sessions') {
      const sess = createSession(data.name, data.agent_id);
      return json(res, 201, sess);
    }

    // Chat in session (SSE)
    let m = pathname.match(/^\/v1\/sessions\/([^/]+)\/chat$/);
    if (m) {
      await handleChat(m[1], data.input || '', res);
      return;
    }

    // Create agent
    if (pathname === '/v1/agents' || pathname === '/v1/bots') {
      if (!data.id || !data.name) return json(res, 400, { error: 'id and name required' });
      return json(res, 201, registerAgent(data));
    }

    // Deploy agent — one-click registration from a runtime-generated spec
    if (pathname === '/v1/agents/deploy') {
      const { id, name, persona, description, session_id } = data;
      if (!name) return json(res, 400, { error: 'name required' });
      const agentId = (id || name.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)/g, ''));
      const agent = registerAgent({
        id:          agentId,
        name,
        description: description || `Deployed from conversation`,
        persona:     persona || '',
        status:      'active',
        channels:    { web: true, rest: true, slack: false, teams: false },
      });
      // Link the session to this agent so subsequent chat uses it
      if (session_id && _sessions.has(session_id)) {
        _sessions.get(session_id).agent_id = agentId;
      }
      console.log(`  [DEPLOYED] ${name} (${agentId})`);
      return json(res, 201, agent);
    }

    // Pause / resume agent
    m = pathname.match(/^\/v1\/agents\/([^/]+)\/(pause|resume)$/);
    if (!m) m = pathname.match(/^\/v1\/bots\/([^/]+)\/(pause|resume)$/);
    if (m) {
      const agent = _agents.get(m[1]);
      if (!agent) return json(res, 404, { error: 'not found' });
      agent.status = m[2] === 'pause' ? 'paused' : 'active';
      saveAgentToDisk(agent);
      return json(res, 200, agent);
    }

    // Legacy bot chat (widget compat)
    m = pathname.match(/^\/v1\/bots\/([^/]+)\/chat$/);
    if (m) {
      const agent = _agents.get(m[1]);
      if (!agent) return json(res, 404, { error: `agent '${m[1]}' not found` });
      if (agent.status !== 'active') return json(res, 503, { error: `agent is ${agent.status}` });
      // Create a throwaway session for widget calls
      const widgetSess = createSession(`widget:${m[1]}`, m[1]);
      await handleChat(widgetSess.id, data.input || '', res);
      return;
    }

    return json(res, 404, { error: 'not found' });
  }

  // ── DELETE routes ────────────────────────────────────────────────────────────
  if (method === 'DELETE') {
    let m = pathname.match(/^\/v1\/agents\/([^/]+)$/);
    if (!m) m = pathname.match(/^\/v1\/bots\/([^/]+)$/);
    if (m) {
      const agent = _agents.get(m[1]);
      if (!agent) return json(res, 404, { error: 'not found' });
      _agents.delete(m[1]);
      const yamlPath = path.join(AGENTS_DIR, `${m[1]}.yaml`);
      if (fs.existsSync(yamlPath)) fs.unlinkSync(yamlPath);
      return json(res, 200, { deleted: m[1] });
    }
    return json(res, 404, { error: 'not found' });
  }

  json(res, 405, { error: 'method not allowed' });
}

// ─── Boot ─────────────────────────────────────────────────────────────────────
console.log('\n╔══════════════════════════════════════════════════════════════╗');
console.log('║           AiNxt Workspace — Starting                        ║');
console.log('╠══════════════════════════════════════════════════════════════╣');
console.log(`║  Runtime:  ${RUNTIME_URL.padEnd(50)}║`);
console.log(`║  Node.js:  ${process.version.padEnd(50)}║`);
console.log('╚══════════════════════════════════════════════════════════════╝\n');

console.log('Loading agents...');
loadAgentsFromDisk();

const server = http.createServer((req, res) => {
  router(req, res).catch(e => {
    console.error('[ERROR]', e);
    try { json(res, 500, { error: e.message }); } catch {}
  });
});

server.listen(PORT, HOST, () => {
  console.log('\n╔══════════════════════════════════════════════════════════════╗');
  console.log('║           ✅  AiNxt Workspace is running!                    ║');
  console.log('╠══════════════════════════════════════════════════════════════╣');
  console.log('║                                                              ║');
  console.log(`║  🚀 Open:  http://localhost:${PORT}/ui/                       ║`);
  console.log(`║  ❤️  Health: http://localhost:${PORT}/health                   ║`);
  console.log('║                                                              ║');
  console.log('╚══════════════════════════════════════════════════════════════╝\n');
});
