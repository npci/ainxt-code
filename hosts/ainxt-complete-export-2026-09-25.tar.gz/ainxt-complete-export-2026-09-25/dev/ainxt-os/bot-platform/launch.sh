#!/bin/bash
# AiNxt Bot Platform — Launch Script
# No Rust, no npm, no build step. Just Python 3.
# SPDX-License-Identifier: Apache-2.0
set -euo pipefail
cd "$(dirname "$0")"

if ! command -v python3 &>/dev/null; then
  echo "ERROR: python3 not found. Install from https://python.org"
  exit 1
fi

export AINXT_RUNTIME_URL="${AINXT_RUNTIME_URL:-https://10.236.8.77/ainxt/v1/api/runtime}"
export AINXT_RUNTIME_USER="${AINXT_RUNTIME_USER:-bot-platform}"
export BOT_PLATFORM_PORT="${BOT_PLATFORM_PORT:-7700}"

python3 server.py
