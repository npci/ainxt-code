# Contributing to AiNxt Runtime

Thank you for your interest. This project is an **independently engineered, clean-room** codebase and is licensed under **Apache-2.0**. To keep it legally clean for everyone who adopts it, contributions must follow the rules below.

## 1. Developer Certificate of Origin (DCO) — required
Every commit must be signed off, certifying you have the right to submit it under the project license. Add a `Signed-off-by` line (use `git commit -s`):

```
Signed-off-by: Your Name <your.email@example.com>
```

By signing off you agree to the Developer Certificate of Origin 1.1:

> By making a contribution to this project, I certify that:
> (a) The contribution was created in whole or in part by me and I have the right to submit it under the open source license indicated in the file; or
> (b) The contribution is based upon previous work that, to the best of my knowledge, is covered under an appropriate open source license and I have the right under that license to submit that work with modifications, whether created in whole or in part by me, under the same open source license (unless I am permitted to submit under a different license), as indicated in the file; or
> (c) The contribution was provided directly to me by some other person who certified (a), (b) or (c) and I have not modified it.
> (d) I understand and agree that this project and the contribution are public and that a record of the contribution (including all personal information I submit with it, including my sign-off) is maintained indefinitely and may be redistributed consistent with this project and the open source license(s) involved.

The DCO is enforced in CI — commits without a valid `Signed-off-by` fail the merge check. (A CLA may be adopted later at the maintainers' discretion; DCO is the default.)

## 2. Clean-room rules (non-negotiable — the project's IP integrity depends on this)
- **Never copy** source code, identifiers, class/function/variable names, constants, enums, error messages, comments, prompts, documentation, tests, folder layouts, branding, or project-specific terminology from any other project.
- External projects may be **studied as references only**. If you consulted one, say so in the PR description — do not reproduce its expression.
- All prompts, system messages, and error text must be authored originally for AiNxt.
- Every substantive design decision gets an **ADR** (`../docs/architecture/adr/`) — this is our evidence of independent implementation.

## 3. Dependencies (legal-clearance gate)
- New dependencies must be **permissive-licensed** (Apache-2.0 / MIT / BSD / ISC / Unicode / Zlib). **Copyleft (GPL/LGPL/AGPL/MPL/EPL/CDDL) is not allowed** in the OSS tree — shell out to an installed binary instead of vendoring.
- Any new dependency must be added to `THIRD_PARTY_INVENTORY.yaml` and pass the `deny.toml` (cargo-deny) CI gate. The build **fails** on a disallowed or unknown license.
- Unknown/unclear licenses are treated as **disallowed** until cleared.

## 4. Core / enterprise split
NPCI-specific compliance rules, AD/RBAC integration, and IP-bearing connectors do **not** belong in this OSS tree — they live in the separate private enterprise repository. CI blocks such paths from landing here (ADR-028).

## 5. Standard workflow
1. Open an issue / RFC for anything non-trivial.
2. Branch, implement, add tests (house bar: mechanism + acceptance test).
3. `git commit -s` (DCO), open a PR; CI runs license gate + DCO + clean-room lint + tests.
4. CODEOWNERS review = approval; a signed tag on the release ref = production.

By contributing, you agree your contributions are licensed under Apache-2.0 and that you have followed the clean-room and dependency rules above.
