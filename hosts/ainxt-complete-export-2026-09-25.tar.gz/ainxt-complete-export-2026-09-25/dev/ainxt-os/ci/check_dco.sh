#!/usr/bin/env bash
# DCO check (ADR-028 / CONTRIBUTING.md): every commit in BASE..HEAD must carry a valid
# 'Signed-off-by:' trailer. CI passes the MR diff base + commit sha.
set -eu
BASE="${1:-HEAD~1}"
HEAD="${2:-HEAD}"

if ! git rev-parse --git-dir >/dev/null 2>&1; then
  echo "dco: not a git repo — skipping"; exit 0
fi
# If BASE is empty/invalid (e.g., first commit), fall back to just HEAD.
if ! git rev-parse --verify "$BASE" >/dev/null 2>&1; then
  BASE="$HEAD^" 2>/dev/null || BASE="$HEAD"
fi

missing=0
range="$(git rev-list "${BASE}..${HEAD}" 2>/dev/null || git rev-list -1 "$HEAD")"
for c in $range; do
  if ! git log -1 --format=%B "$c" | grep -qiE '^Signed-off-by: .+ <.+@.+>'; then
    echo "DCO MISSING on commit ${c}: $(git log -1 --format=%s "$c")"
    missing=1
  fi
done

if [ "$missing" -eq 0 ]; then
  echo "DCO: OK"
else
  echo "DCO: FAIL — every commit needs a 'Signed-off-by' trailer (use: git commit -s)"
fi
exit "$missing"
