#!/usr/bin/env bash
# Gate #0 OSS hygiene: every Rust source carries an SPDX license header, and none of the
# release-critical files still contains an unreplaced Gate-#0 placeholder token. Exits non-zero on
# any violation. (Docs under docs/ legitimately *mention* the old placeholder strings as the values
# to fix, so the placeholder scan is scoped to the release-critical files only.)
set -euo pipefail
cd "$(dirname "$0")/.."

fail=0

# 1. SPDX header on every crate .rs source.
missing="$(find crates -name '*.rs' -print0 | xargs -0 grep -L 'SPDX-License-Identifier' || true)"
if [ -n "$missing" ]; then
  echo "ERROR: .rs files missing an SPDX-License-Identifier header:"
  echo "$missing"
  fail=1
fi

# 2. No unreplaced Gate-#0 placeholder tokens in the release-critical files.
critical_files="Cargo.toml NOTICE SECURITY.md LICENSE README.md"
for f in $critical_files; do
  [ -f "$f" ] || continue
  for tok in 'example.invalid' 'security@ainxt.example' 'COPYRIGHT HOLDER — set at' 'The AiNxt Authors'; do
    # `authors = ["The AiNxt Authors"]` in Cargo.toml is an accepted OSS-conventional collective and
    # is NOT a blocker; only flag "The AiNxt Authors" if it appears in NOTICE as the copyright line.
    if [ "$tok" = 'The AiNxt Authors' ] && [ "$f" != "NOTICE" ]; then
      continue
    fi
    if grep -q -- "$tok" "$f" 2>/dev/null; then
      echo "ERROR: unreplaced Gate-#0 placeholder '$tok' in $f"
      fail=1
    fi
  done
done

if [ "$fail" -ne 0 ]; then
  echo "OSS gate FAILED — see errors above (Gate #0 / GATE_0_CONFIRM.md)."
  exit 1
fi
echo "OSS gate OK: SPDX headers present on all crate sources; no Gate-#0 placeholders in release-critical files."
