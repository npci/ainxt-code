#!/usr/bin/env bash
# Clean-room lint (ADR-028): fail if any distinctive vendor token appears in AiNxt source.
# Scans code files only (rs/toml/sh/yml); excludes ci/ (holds the denylist) and target/.
set -eu
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
DENYLIST="$ROOT/ci/clean_room_denylist.txt"
status=0

while IFS= read -r token; do
  [ -z "$token" ] && continue
  case "$token" in \#*) continue ;; esac
  hits="$(grep -RIni --binary-files=without-match \
        --include='*.rs' --include='*.toml' --include='*.sh' \
        --include='*.yml' --include='*.yaml' \
        --exclude-dir='ci' --exclude-dir='target' --exclude-dir='.git' \
        -e "$token" "$ROOT" 2>/dev/null || true)"
  if [ -n "$hits" ]; then
    echo "CLEAN-ROOM VIOLATION: forbidden token '$token':"
    echo "$hits"
    status=1
  fi
done < "$DENYLIST"

if [ "$status" -eq 0 ]; then
  echo "clean-room lint: OK (no forbidden vendor tokens in source)"
fi
exit "$status"
