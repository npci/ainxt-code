#!/usr/bin/env bash
# Core/enterprise boundary check (ADR-007/028): NPCI-specific / IP-bearing private-plugin
# paths must NEVER land in the OSS tree. Fail if any matching path exists.
set -eu
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
# Path fragments that indicate private enterprise plugins (extend as the split is formalized).
PATTERNS="pci_dss_rules ad_rbac_internal npci_private enterprise_plugin"
status=0

for p in $PATTERNS; do
  found="$(find "$ROOT" -path "$ROOT/target" -prune -o -iname "*${p}*" -print 2>/dev/null || true)"
  if [ -n "$found" ]; then
    echo "BOUNDARY VIOLATION: OSS tree contains private-plugin path matching '${p}':"
    echo "$found"
    status=1
  fi
done

if [ "$status" -eq 0 ]; then
  echo "core/enterprise boundary: OK (no private-plugin paths in the OSS tree)"
fi
exit "$status"
