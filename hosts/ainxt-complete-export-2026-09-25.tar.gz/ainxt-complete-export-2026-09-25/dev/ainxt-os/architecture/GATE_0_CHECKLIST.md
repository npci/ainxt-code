# Gate #0 — Legal/OSS Clearance Checklist (release-blocking)

Operationalizes **ADR-028** (legal/OSS clearance gate) and **ADR-007** (licensing) and **ADR-019**
(liability). **No public release, and no external pilot, until every ❌/⚠ below is ✅.** Legal-first
is the project's #1 rule. Status as of 2026-07-19.

Legend: ✅ done · ⚠ partial / needs work · ❌ blocked (mostly human/legal) · 🔒 human-only

## A. Licensing & provenance
- ✅ License locked to Apache-2.0 — `runtime/LICENSE`, `NOTICE`, ADR-007.
- ✅ Permissive-only dependency gate — `runtime/deny.toml` (advisories/licenses/bans/sources); `cargo deny check` green.
- ✅ Third-party license inventory — `runtime/THIRD_PARTY_LICENSES.md` (machine-generated, 170 crates, all permissive).
- ✅ Clean-room provenance — ADRs + vendor-studies are the evidence; deny denylist for vendor tokens clean.
- ⚠ Model-weight license/origin register (`MODEL_WEIGHTS_REGISTER.md`, ADR-018) — referenced but not yet populated (no models shipped; populate before shipping any weights).
- ⚠ `wasmtime` (WASM plugin host, ADR-024) uses `Apache-2.0 WITH LLVM-exception` — needs an explicit reviewed `deny.toml` exception BEFORE it is added as a dependency. Not yet a dep, so not yet blocking; a tripwire.

## B. Identity & entity (🔒 human — currently placeholders that BLOCK release)
- ❌ Real copyright holder — `NOTICE` says `[COPYRIGHT HOLDER — set at Gate #0]`; set the real legal entity.
- ❌ Real repository URL — `runtime/Cargo.toml` `repository = "https://example.invalid/ainxt-runtime"`; set the real URL.
- ❌ Monitored security contact — `SECURITY.md` `security@ainxt.example` is not monitored; set a real address.
- ❌ Trademark clearance for the "AiNxt" name (🔒 legal).

## C. Governance files
- ✅ `LICENSE`, `NOTICE`, `README.md` (status now honest), `SECURITY.md`, `CONTRIBUTING.md` (DCO), `CODE_OF_CONDUCT.md`.
- ✅ `CODEOWNERS`, `GOVERNANCE.md`, `MAINTAINERS.md` (added 2026-07-19; placeholders to fill with real teams).
- ❌ Real maintainer/security/legal teams behind the `@ainxt-*` handles (🔒).
- ⚠ DCO vs CLA decision — DCO is the documented default (CONTRIBUTING); confirm with legal (🔒).

## D. Repo hygiene & CI
- ❌ **Extract `runtime/` into its own standalone repository** — it currently lives inside the proprietary monorepo; the OSS tree must be separated (ADR-028 core/enterprise split).
- ✅ Core/enterprise split enforced by construction — no NPCI PCI/DSS / AD-RBAC / IP-connector code in this tree (gates are traits + generic defaults).
- ⚠ Gate CI standing — `cargo deny` + clippy + tests are proven locally; wire them (plus a per-file license-header check and a NOTICE-placeholder-block check) as required CI jobs on the standalone repo.
- ⚠ Pre-receive PII/secret gate (ADR-026 §10) — designed; not yet installed on a git host.

## E. Liability / responsible use (🔒 human — ADR-019)
- ❌ Liability/indemnity/insurance posture for an OSS payments-adjacent runtime — legal sign-off.
- ⚠ Output-ownership / responsible-AI use terms (ADR-011) — designed; confirm at release.

## Bottom line
The **engineering** side of Gate #0 is largely green (license, deny gate, inventory, clean-room,
governance files, core/enterprise split). The **human/legal** side is **not started**: real entity,
repo URL, security contact, trademark, liability sign-off, and the standalone-repo extraction. These
are the true release blockers and require the project owner + legal — they cannot be closed in code.
