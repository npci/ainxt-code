# AiNxt Runtime — How Every Feature Works (Turn Pipeline + Per-Feature Traces)

**Status:** Design doc (no code). Companion to `VENDOR_SYNTHESIS.md` and `HARNESS_SDK.md`.
**Thesis:** Every feature — Chat, doc-gen, comparison, SDLC, Code/CLI, Buddy, skill-gen, agent-creation — is the **same canonical turn pipeline**. What differs per feature is only (a) the **Surface Profile** (a declarative manifest: capabilities, prompt, model policy, autonomy, RBAC) and (b) the **Renderer** (React / Rust CLI / REST / desktop). The enterprise-hard machinery is implemented and tested **once** in the spine.

---

## 1. The canonical turn pipeline

Every request from every renderer flows through this. Gates that cannot be skipped are marked 🔒.

```
Renderer ──Request{session, profile_id, input, jwt, attachments}──► Runtime

 1. Session Manager      resolve/create Session actor (single-writer, bounded inbox)
                         load Event-Log projection (cached incremental, not full replay)
 2. Identity + Policy 🔒  validate JWT → RBAC + dept scope; budget check; rate-limit/backpressure (503 if over)
 3. Compliance IN    🔒  redact PAN/CVV/PII/secrets from input (redact-and-proceed, never block)
 4. Context Engine       assemble: profile system-prompt + memory projection
                         + retrieval (pgvector hybrid RAG and/or symbol repo-map)
                         + connector data (if profile grants it)
                         condense if over budget (hard/soft triggers, degrading fallback)
 5. Model Router         choose model: profile policy → complexity classify → tier → model_registry
                         (respects BLOCKED_MODELS; user-selectable models honored)
 6. Provider Gateway     stream from provider → normalize wire format → shared Event enum
                         (one cancellation token shared by stream + all tool futures)

 7. Agent Loop (need-driven; hard iteration cap + deterministic stuck-detector)
    repeat while there are unanswered tool calls:
      model emits text deltas + native-JSON tool calls
      for each tool call (parallel; same-file edits serialized):
        7a. Compliance 🔒   redact tool-call args
        7b. Approval Gate    capability permission check; blocking tri-state
                             (approve / approve-for-session / reject+feedback);
                             HITL gates (SDLC) use THIS same seam
        7c. Tool Runtime     dispatch — native or MCP tool (indistinguishable);
                             sandbox if the capability requires it
        7d. Compliance 🔒   redact tool result
        7e. append (action, observation) to Event Log; feed observation to model

 8. Compliance OUT   🔒  redact final response
 9. Stream           Event enum → SSE / WebSocket / in-proc channel → renderer
10. Persist + Observe    durable append-only Event Log + rebuildable index;
                         OpenTelemetry trace; budget/usage updated; audit record
```

Everything below is this pipeline with a different **Profile** and **Renderer**. Nothing re-implements the loop.

---

## 2. Per-feature traces

### 2.1 Chat (grounded Q&A — the "ChatGPT/Claude equivalent")
- **Profile:** capabilities = `kb.search` (read-only); autonomy = none; model policy = user-selectable (this is what makes it "ChatGPT- or Claude-equivalent" — the *user picks the provider*, the runtime is model-agnostic).
- **Trace:** steps 1–6 with Context Engine doing pgvector hybrid RAG over `docs_kb:platform` + namespace; usually 0–1 tool calls; stream answer out. Multi-turn memory via the Event-Log projection.
- **Renderer:** Web Chat (React) over SSE.

### 2.2 Chat → Document generation
- **Profile:** adds capability `artifact.generate_document` (docx/pptx/pdf/xlsx).
- **Trace:** intent detection (4-stage cascade) confirms `doc_generation`; the **content resolver** determines *what* goes in the doc — resolving anaphora ("this/that/the above") to the prior substantive answer, **never** using the instruction text as content (see `CONVERSATION_INTELLIGENCE.md`). Then `artifact.generate_document{format, content}` runs in the **doc sandbox** (Artifact Runtime) → artifact reference → in-app preview. Compliance on content is audit-and-proceed (never corrupts the artifact).
- **Canonical bug this prevents:** "UPI growth?" → answer, then "generate this as pdf" must yield a PDF of the UPI answer, not a PDF saying "generate this as pdf".
- **Point:** doc-gen is a *capability*, not a feature-specific code path — CLI or Buddy calling it get identical results, and content-resolution is model-agnostic (works on self-hosted Qwen/Gemma via constrained decoding).

### 2.3 Chat → Comparison (compare models, or compare documents)
- **Profile:** capability `compare.fanout`.
- **Trace:** the capability spawns N parallel sub-turns through the **Model Router** (one per provider/model) sharing the parent cancellation token; results returned as structured blocks; renderer lays them side-by-side. "Compare two documents" is the same primitive pointed at a diff capability.
- **Point:** fan-out is a runtime primitive (also used by the SDLC judge-loop) — built once.

### 2.4 SDLC (feature/bug pipeline)
- **Profile:** autonomy = high; the **3-tier loop** (planner → coder+critic → judge-audited goal loop); capabilities = GitLab/Jira connectors, sandbox test-runner, the **edit engine** (parse→dry-run→write, no fuzzy fallback).
- **Trace:** entry is often an **inbound connector event** (GitLab/Jira webhook via Connector Runtime), not a UI request. Pre-flight checks (token/repo/ticket) run first. Each **HITL approval gate is the runtime's Approval Gate seam** (7b) — design approval, solution approval. Run events append to the Event Log (async Postgres write via Kafka). The judge loop re-prompts with "what's missing" until an independent judge confirms or a cap hits.
- **Renderer:** SDLC UI + status pushed back to Jira/GitLab.

### 2.5 Code / CLI (desktop + headless)
- **Profile:** capabilities = file read/write, bash (sandboxed), edit engine, MCP tools; secure-code-gate (SAST) as a post-edit capability.
- **Trace:** same loop; edits go through the parse→dry-run→write discipline; bash runs behind the sandbox facade + declarative approval policy. Desktop renders rich diffs/file-tree; headless CLI renders stream-json/exit codes — **same runtime, different renderer**.
- **Point:** Desktop talks to the runtime **directly** (no CLI wrapper). CLI is headless-only.

### 2.6 Buddy (Cowork)
- **Profile:** curated office capabilities + connectors (Graph/Outlook/Teams/SharePoint) + doc-gen; memory for per-user personalization; **no bash/code/KB-search**; computer-use as a *gated* capability.
- **Trace:** same loop; connector calls go to the **server-side Connector Runtime** (OAuth tokens encrypted in Postgres, scoped to JWT sub) → so Buddy works in the **web app and desktop identically**. Only local computer-use is desktop-restricted (it needs a local OS).
- **Point:** Buddy is a Profile, not a CLI mode — zero CLI dependency.

### 2.7 Skill generation
- **Profile:** an agent whose task is to author a **Skill spec** (behavioral = prompt-injected SOP; execution = sandboxed `run()` code).
- **Trace:** normal loop produces a validated spec → the conversational Studio **emits a PR** to the control repo (`skills/<name>/SKILL.md` + manifest front-matter), never a DB row (ADR-026: control plane is git-native, not Postgres). Governance is git-native: branch = DRAFT, PR + CI (lint/schema/sandbox dry-run) = PENDING_APPROVAL, CODEOWNERS-reviewed merge = APPROVED, signed tag on the env/prod ref = PRODUCTION. CODEOWNERS is both authoring RBAC and the named owner of record; git history is the audit trail. RBAC/visibility for the skill live in the manifest front-matter and are read by the **Policy Engine at run time** (RBAC-on-EXECUTE) — not a DB column.
- **Enforcement:** the Skill Runtime loads only from the pinned control-repo ref (tag/SHA) at startup + hot-reload; it refuses any skill not resolvable to a signed commit reachable from the env tag.
- **Acceptance test:** a PR that edits a skill's front-matter to escalate RBAC without CODEOWNERS sign-off must fail merge protection — the skill never reaches PRODUCTION, and the running Policy Engine continues enforcing the last tagged manifest.
- **Point:** the created skill is then a capability *any* profile can list — build once, expose everywhere. Skill *usage* telemetry (invocation counts, latency) stays data-plane (event log/telemetry store), never git.

### 2.8 Agent creation
- **Profile:** an agent that authors an **Agent spec** (persona + capability refs + MCP servers + sub-agents; single-level inheritance).
- **Trace:** spec validated → the Studio **emits a PR** to the control repo (`agents/<name>/AGENT.md` + manifest front-matter) — same DRAFT→PENDING_APPROVAL→APPROVED→PRODUCTION git governance as §2.7 (ADR-026): CODEOWNERS review + CI, merge, signed tag. Git is the source of truth for the spec, not Postgres. RBAC/visibility are manifest front-matter fields evaluated by the **Policy Engine at execute time**, not stored/queried DB columns; the agent is then runnable via the same loop with the Compliance Gate wired in.
- **Enforcement:** the same pinned-ref loader as skills applies at load; the Policy Engine additionally re-checks the manifest's RBAC front-matter on every invocation, so authoring-time approval alone never grants execute-time access.
- **Acceptance test:** invoking an agent whose manifest front-matter requires a capability the caller's JWT role doesn't hold must be denied at the Policy Engine gate even though the agent spec merged and tagged cleanly — proving RBAC is enforced on execute, not just on authoring.
- **Point:** a created agent is a harness with the default (chat) renderer — invocable from Chat, CLI, a Workflow step, or a connector trigger, identically. Agent *run* history/audit is data-plane (event log), never git.

---

## 3. Why this is enterprise-grade by construction
- The **🔒 gates** (identity/policy, compliance in/tool/out, approval) are in the pipeline, not the feature. A feature cannot forget them because it does not own the loop.
- **Backpressure, cancellation, retries, stuck-detection** are loop properties → every feature inherits them.
- **One scenario matrix** (planned — see backlog; not yet written) run against the pipeline validates all features at once.
- Adding a feature = writing a **Profile** (declarative) + optionally a **capability** — not a new agent stack.

---

## 4. Verification & review principles (explicit)

These apply to every feature, not just SDLC/Code:

### 4.1 Cross-model review (not just fresh-context)
A model reviewing its own output is biased. The **Reviewer/Judge runs on a *different model* than the producer** (e.g., Coder=Qwen → Judge=Claude; or Coder=Claude → Judge=GPT) for a genuinely independent second opinion. **Data-class constraint:** for regulated data, both must be in-house OSS, so cross-model = two different OSS models (e.g., Qwen producer, GLM judge). This is a differentiator over single-model coding tools.

### 4.2 Post-generation artifact verification (does the output match the ASK?)
Verification runs **after** an artifact is produced, not only before. Once a doc/deck/report/answer is generated, an **artifact-vs-intent check** confirms: correct **content** (matches the resolved referent/subject), requested **format/scope**, **completeness**, and **groundedness** (claims supported). On divergence → repair/regenerate; only then is it returned. This is the "never declare done until proven" loop applied to artifacts, closing the gap that let "generate this as pdf" ship a wrong PDF. Deterministic checks where possible (format, presence of required sections), model-judge for semantic match — cross-model per §4.1.

### 4.3 Two-sided verification, universally
Every producing action is bracketed: **pre** (intent + content/referent resolution) and **post** (artifact/code/answer verified against the ask). Code uses the review pipeline; documents use artifact verification; answers use groundedness/citation-faithfulness. Nothing is returned as "done" without the post-check passing or an honest explanation of why it couldn't.
