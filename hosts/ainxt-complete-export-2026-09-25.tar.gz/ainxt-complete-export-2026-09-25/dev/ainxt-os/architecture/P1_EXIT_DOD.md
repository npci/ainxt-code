# P1 Exit — Definition-of-Done Status

**Status (2026-07-19):** P1 runtime-core spine BUILT + adversarially reviewed. Functional
acceptance matrix, scaled concurrency/load, and chaos/resilience are **green locally**. Sustained
soak, real-infra integration, and CI standing remain — see "Not yet proven" (stated honestly per
`feedback_enterprise_grade_no_poc`).

## What is built (16 crates, one turn pipeline)

`ainxt-types · ainxt-protocol · ainxt-runtime (engine) · ainxt-providers · ainxt-server ·
ainxt-context · ainxt-eventlog · ainxt-tools · ainxt-convo · ainxt-guardrails · ainxt-injection ·
ainxt-config · ainxt-telemetry · ainxt-session · ainxt-prompt · ainxt-scenario (DoD harness)`

Turn pipeline: authz → compliance-IN → guardrails-IN → data-class routing (tier-aware, failover) →
provider event-enum stream → tool authz + injection-gate + approval + exactly-once dispatch →
compliance-OUT → injection scan/fence → audit → telemetry.

## Evidence (all green: `cargo test --workspace`, `clippy -D warnings`, `cargo deny`)

- **199 tests / 2 ignored (live-provider) / 0 failed**; clippy clean; cargo-deny advisories/bans/
  licenses/sources clean (permissive-only OSS tree).
- **Every P1 subsystem was adversarially reviewed** (8 review workflows). Real defects were found
  and fixed each time — e.g. an injection fence break-out, a payments-account authz+idempotency
  bug, a non-canonical idempotency key (double-execution), cross-provider cost misattribution, and
  three session-manager concurrency bugs (config-panic-under-lock, panic-orphan, hung-turn leak).
- **P1 acceptance matrix** (`ainxt-runtime/tests/dod_p1_matrix.rs`): the fully-assembled runtime,
  driven through the scenario harness **with a failing primary provider (pervasive failover)**,
  passes **9 scenarios** spanning the P1 categories — provider-failover, compliance-redaction,
  data-class-leak, huge-input, unicode/RTL, malformed-model-output, double-execution, RBAC-deny,
  plus a chat smoke test — with layered oracles (crash/spec/invariant/performance) and JUnit for
  CI. Scenarios are written to fail-RED if their invariant breaks (no false-greens): the crash
  oracle surfaces a terminal `Event::Error` (not just `Err`); redaction is proven on a PAN
  **streamed/split across deltas** (per-delta redaction would leak); huge/RTL inputs are echoed
  back so empty output cannot masquerade as success; malformed args are asserted to never reach
  the tool.
- **Concurrency / load** (`ainxt-session`): 1500 concurrent sessions all complete; admission
  control caps live sessions at the global cap under a burst (503, bounded memory); serial-per-
  session + cross-session concurrency proven under a multi-threaded runtime; idle self-reaping
  proven (bounded memory); per-turn timeout bounds a hung turn.
- **Chaos / resilience** (`ainxt-runtime`, `ainxt-session`): cancel-mid-turn, retry+backoff,
  provider failover, terminal-after-output, turn-panic isolation, injection taint-gating —
  all covered, degrade gracefully (no panic; errors surfaced; resources freed).

### Enterprise invariants proven end-to-end
Mandatory gates as required constructor args (no build without compliance/authz/audit) · data-class
exclusion non-overridable (regulated data never routes to cloud; a forced ineligible provider is
refused — proven in `pipeline_test`, plus an unauthorized turn never invokes a provider) ·
exactly-once side-effecting tools (canonical semantic key; durable event-log ledger across restart)
· compliance redact-in/out — **streaming-aware** (a secret split across output chunks is buffered
whole and redacted), via the OSS **placeholder** detector (digit-run PANs + `PAN=`/key markers);
full PII RECALL is the enterprise PCI/DSS plugin behind the same seam · on-behalf-of fine-grained
tool+resource authz
(confused-deputy) · prompt-injection defense (untrusted fence + scan + taint-gate on RAG *and* tool
results; side-effecting/egress tools gated on a tainted turn) · guardrails (default-off, opt-in) ·
approval gate fail-closed for high-risk/MCP tools · integer-money cost attribution per provider ·
model-agnostic prompt assembly with instruction precedence.

## Not yet proven here (needs the GPU/infra box, or is a tracked follow-up)

- **Sustained load & soak:** true ≥2000 req/s sustained throughput + latency SLOs, GPU serving
  (vLLM/TGI), and a multi-hour memory-leak soak need the infra box with real providers. Proven
  here: 1500 concurrent sessions functional + admission cap + structural memory bounding.
- **Real integration:** real Postgres/Redis in CI containers (event-log/ledger have file-backed
  durable impls + restart tests; DB impls pending); live provider HTTP (adapters exist with
  `#[ignore]` live tests — no keys/network here).
- **Network chaos / air-gap** and connector-loss degradation → P2 Connector Runtime.
- **CI standing:** the clearance-gate CI + scenario-matrix runner are proven locally; standing them
  in GitLab CI (green empty → green matrix) is the Phase-0 exit infra item.
- **The full 1,000+ scenario corpus:** #9 delivers the *runner* + a representative category-
  spanning matrix; the 1,000+ authored, git-native scenario files (ADR-026) load on top later.
- **Compliance RECALL:** the exercised detector is the OSS placeholder (digit-run PANs + `PAN=`
  markers, now streaming-aware); real PII recall (Aadhaar/UPI/name-combos/entropy) is the
  enterprise PCI/DSS plugin — not measured here. Some invariants are proven in focused unit tests
  rather than the matrix (data-class exclusion + forced-refusal + provider-not-invoked-on-deny in
  `pipeline_test`; canonical-key semantic dedup in `ainxt-tools`), and the matrix's chat scenario
  is a smoke test, not a distinct category.
- **Tool-safety pipeline assembly (corrected 2026-07-19 after the OSS-readiness audit):** the tool
  authz + injection-gate + approval + exactly-once dispatch pipeline is *implemented* in the engine,
  but until 2026-07-19 the composition binary (`ainxt-runtimed`) did NOT call `.with_tools()`, so the
  pipeline was **inert in every runnable binary** (it only ran in unit tests that wired it manually).
  This is now fixed — `build_engine` assembles a `ToolRuntime` (fail-closed, empty registry) so the
  pipeline is live; **tool *configuration* (which tools a deployment registers) and a durable ledger
  remain follow-ups**. Do not read "delivered" as "assembled end-to-end" for earlier revisions.
- **Known wiring residuals:** server transport calls the engine directly (not via SessionManager +
  503 mapping yet); `session`/`telemetry`/`prompt` config consumed at the composition binary, not
  from `RuntimeConfig` end-to-end; the engine's `sink.send` isn't cancel-raced (a hung sink is
  bounded by the per-turn timeout, not cancel); BH numeric-via-tools is a prompt directive, not
  runtime-enforced; `max_input_bytes` config exists but isn't enforced in the engine.
- **Human Gate #0 (legal/OSS sign-off + real copyright entity + model-weight license clearance)**
  remains the standing P0 blocker before any public open-source release.
