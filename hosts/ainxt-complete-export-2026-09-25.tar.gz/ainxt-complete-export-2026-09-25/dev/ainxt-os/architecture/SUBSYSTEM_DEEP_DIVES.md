# AiNxt Runtime — Subsystem Deep Dives

**Status:** Design doc (no code). Companion to `RUNTIME_FEATURE_FLOWS.md` and `HARNESS_SDK.md`.
**Purpose:** End-to-end mechanics for the subsystems that decide whether the runtime is production-grade or a demo. Each section states the flow, then the **hard parts** (the failure modes that make naive versions PoCs) and how the design handles them.

---

## 1. SDLC judge-loop (3-tier autonomous execution), end-to-end

**Flow (feature/bug run):**
1. **Intake** — a GitLab/Jira webhook enters via the Connector Runtime (inbound), creating a `Run{run_id, issue, repo}`. `_preflight_check` validates GitLab token → repo connectivity → Jira token (soft) → ticket readability. Hard-fail ⇒ Run = FAILED, stop.
2. **Context** — `_fetch_repo_context` authoritatively detects language (`.sdlc.yml` → GitLab tree → embeddings; confidence 0.0 ⇒ block, never default to Python). Repo-map + retrieval assembled.
3. **Planner (outer goal, tier 3)** — produces a design/plan with explicit **acceptance criteria**. → **HITL gate #1 (design approval)** via the runtime Approval Gate (blocking; human approves/rejects+feedback). On resume, `repo` is read from `run.context`, never reconstructed.
4. **Coder (reactive loop, tier 1)** — implements via the edit engine (parse→dry-run→write; `_restore_missing_imports`; method-preservation; field-rename guard). Tools: read/edit/bash in sandbox.
5. **Per-step Critic (tier 2)** — after each diff, a *cheap* critic checks: compiles? matches plan scope? obvious regression? Feedback injected as an observation → coder revises. Catches the 80% of errors before the expensive judge runs.
6. **Deterministic verify** — build + tests + lint run in the sandbox. This gate is **code, not a model** — "tests pass" is never model-judged. Failures feed the reactive loop (self-heal, bounded).
7. **Judge (outer goal audit, tier 3)** — an **independent** judge (fresh context, ideally different model) evaluates the diff against the acceptance criteria + ticket intent. Critically it does **not** see the coder's rationalizations — anti-sycophancy. If incomplete it emits a **specific, actionable "what's missing"** that becomes the coder's next goal. Loops until judge confirms OR round-cap hit.
8. **Terminate** — returns typed `complete | capped`. `capped` ⇒ surface the gap report to the human, never claim done. → **HITL gate #2 (solution approval)** → `gitlab_create_mr` (idempotent: 409 ⇒ `_find_existing_mr`; review as note body, no inline anchors).
9. Every step appends to the Event Log (async Kafka→Postgres).

**Hard parts I flagged:**
- *Judge sycophancy* → independence (separate context/model), evaluate against machine-checkable criteria first, semantic judgment only for what tests can't cover.
- *Infinite polish* → hard round-cap + a **no-progress stuck-detector on diffs** (abort to human, don't burn tokens).
- *"Done" lies* → the deterministic verify gate owns pass/fail; the judge only adjudicates completeness; `capped` is a first-class, honest outcome.
- *Resume correctness* → repo/context always from `run.context`, the known past regression.

---

## 2. Buddy connector auth (M365/Graph), end-to-end — works in web AND desktop

**Flow:**
1. **Connect** — user clicks "Connect Outlook" in the web (or desktop) app. The **gateway** (server-side) starts OAuth2 auth-code + PKCE against Entra ID, reusing the SSO Entra app **plus** added Graph scopes; `state` for CSRF; redirect URI → gateway callback.
2. **Callback** — gateway exchanges `code` for `{access, refresh}` at the token endpoint — routed through `HTTPS_PROXY`/web02 in air-gapped prod. Tokens **encrypted (FERNET, versioned keys for rotation)** and stored in Postgres `user_connector_tokens` keyed by `(jwt.sub, connector, tenant)`. **Never on the client.**
3. **Use (turn time)** — a Buddy capability needs Graph → Connector Runtime resolves the token for `(user_id, connector)` → checks expiry → refreshes via `refresh_token` under a **Redis distributed lock** (double-checked) so concurrent workers/turns don't race → calls Graph (through the proxy in prod). Per-request resolution only — never a process-wide token (same discipline as GitLab thread-local).
4. **Deauthorize** — explicit verb clears the stored token per `(user, connector)`.

**Why this makes web work:** the tokens and connector execution live in the runtime, not the desktop's local agent. Web and desktop are identical renderers over the same Connector Runtime. **Only local computer-use stays desktop** (needs a local OS).

**Hard parts I flagged:**
- *Refresh races across 2,000-user workers* → Redis lock + double-checked read.
- *Key rotation* → MultiFernet (versioned keys), decrypt-with-any/encrypt-with-newest.
- *Incremental consent* → if a capability needs an unconsented scope, trigger step-up consent, don't silently fail.
- *Tenant reality* → Microsoft blocks personal-tenant self-registration; requires a one-time NPCI Entra-admin app registration + admin consent for Graph scopes.
- *Air-gap* → Graph unreachable ⇒ connector **soft-degrades** (Buddy keeps working), never crashes the turn.

---

## 3. Document generation, end-to-end

**Design choice (self-decided):** prefer **skill + structured-spec rendering** over free-form code-gen. A model that writes raw `python-pptx` is fragile; a model that fills a validated document IR that a deterministic renderer emits is reliable.

**Flow:**
1. A Chat/Buddy turn → model calls `artifact.generate_document{type, spec}` where `spec` is a structured IR (sections, headings, tables, charts, image prompts).
2. The **Artifact Runtime** runs the matching **doc skill** in the isolated doc sandbox (network-off, resource-capped): docx via the doc skill in the doc-sandbox; pptx via the Presenton path (`template:layoutId` format — the QM prefix fix); xlsx/pdf similarly.
3. Images are generated via **Gemini Imagen / DALL·E only** (enterprise rule — never stock-photo APIs).
4. Output stored in the Artifact store (S3/MinIO or blob) with a reference; renderer shows in-app preview + download.
5. Compliance on doc content = **audit-and-proceed** (never redact inside a doc — it would corrupt it; never hard-block a build).

**Hard parts:** deterministic layout (IR + renderer, not code), chart/data-viz as a typed capability, large decks (stream section-by-section), and template fidelity (the Presenton `template:layoutId` prefix regression).

---

## 4. Creating code and executing it

**Create:** the edit engine — parse the model's edit envelope → **dry-run classify** against an in-memory snapshot → write only safe edits; exact+whitespace matching, **no silent semantic-fuzzy fallback**; unmatched anchors → structured error → bounded same-turn self-correction. Full-file gen paths re-inject imports/methods the LLM dropped.

**Execute (two tiers):**
- **Quick exec** — one-off Python/Bash in a container: `--network none`, 512MB / 50% CPU, auto-removed. PCI check on code *before* run.
- **Sandbox-as-server** — for multi-step dev, the runtime runs as an HTTP/WS server **inside** the sandbox exposing files/bash/git; local and remote execution are structurally identical (so a dev box and a CI runner behave the same).

**Self-healing:** execute → detect error → LLM fix → retry, **bounded** (cap + stuck-detector), never infinite.

---

## 5. Skills — what they are, where they're injected

Two types, injected at **different points of step 4 (Context Engine)**:
- **Behavioral** — plain-text SOP/domain instructions injected **into the system prompt** with full instructional authority. No code runs. Shapes the entire turn (e.g., "NPCI settlement RCA procedure").
- **Execution** — Python `run()` executes **before** the LLM call (in the sandbox); its output is injected into a `## Context` block the model sees. Grounds the turn with computed/live data.

**Selection:** a Profile lists skill refs, **or** a skill-selection step matches skills to the query by relevance (same idea as tool selection). **Source of truth = the git-native control plane** (ADR-026), never Postgres and never hardcoded as a Python/Rust runtime override — the standing rule (`feedback_db_source_of_truth.md`) is preserved in spirit, refined in store (ADR-026 §13). Each skill is **one directory** under `skills/behavioral/<id>/` or `skills/execution/<id>/`, containing `definition.md` (front-matter manifest + body); an execution skill's `run.*` sits beside its manifest, reviewed in the same PR (ADR-026 §4). Governance is re-hosted on git primitives, not a DB status field (ADR-026 §7): `DRAFT` = a feature branch → `PENDING_APPROVAL` = an open PR (CI runs schema + compliance gate) → `APPROVED` = merged to `main` (CODEOWNERS approval + signed commits) → `PRODUCTION` = a signed semver tag promoted onto the `env/prod` ref. A **pre-receive compliance hook** on the git host (the same PCI/DSS + PII detectors as `agents/compliance_engine.py`) scans every changed file on push and rejects PII/secrets before they ever land in history — this replaces the write-time DB compliance check, and unlike the redact-and-proceed rule elsewhere it deliberately **blocks** the push rather than mutating a skill's body (ADR-026 §10).

**Injection order in the prompt:** persona → behavioral skills → guard prompts → `## Context` (execution-skill output + retrieval) → history → user turn.

---

## 6. Context management, end-to-end

**Assembled fresh each turn (step 4), from:**
- System prompt (persona + behavioral skills + guard prompts) — Prompt Engine.
- Conversation history — **Event-Log projection**, incrementally cached (extend the tail on append; full rebuild only on branch-switch) — the fix for 30k-event threads.
- Retrieval — **docs:** pgvector hybrid (HNSW + BM25 → RRF → rerank top-6); **code:** symbol repo-map (tree-sitter tags → reference graph → PageRank → binary-search to token budget).
- Memory — session (Redis) + episodic (Postgres) + user personalization (Buddy).
- Live connector data (if the profile grants it) + execution-skill output.

**Budgeting:** priority order system > pinned > retrieved > history-tail; truncate least-important first; **condenser** as one pluggable component (hard/soft triggers: explicit / token-budget / event-count; strictest cut wins; min-progress guard rejects near-empty condensations; degrading last-resort, never all-or-nothing).

**RBAC scope separation:** Chat/Voice (no `repo_filter`) → `docs_kb:platform` + namespace only. Projects/Threads (`repo_filter`) → that repo only, RBAC-gated. This prevents cross-tenant/cross-repo leakage — a payment-org non-negotiable.

---

## 7. Conversation intelligence layer (what makes Chat feel like ChatGPT/Claude)

Chat is not "call the model" — it's an orchestration wrapper around the model call:
1. **Follow-up detection + query rewrite** — decide if the turn is a follow-up; rewrite it into a standalone retrieval query using history (the bare-question-loses-context regression; rewrite cache in Redis db0). Wrong here ⇒ RAG retrieves garbage.
2. **Intent + complexity classification** — chitchat vs task vs doc-gen vs code; simple/medium/complex → model tier.
3. **Retrieve → generate → cite** — grounded answer with source citations.
4. **Referent & content resolution** — when an action needs content (doc-gen, summarize, email), resolve *what* the content is from context; **never equate the instruction with the content**. ("generate this as pdf" ⇒ content = the prior UPI answer, not the words "generate this as pdf".)
5. **Memory** — extract durable user facts/prefs (`remember`); recall on future turns.
6. **Thread hygiene** — title-gen (ephemeral cheap-model session), long-thread compaction, suggested follow-ups.
7. **Coherence** — multi-turn state via the Event Log; streaming via the event enum.

**Hard part:** the rewrite/follow-up + referent-resolution steps are the highest-leverage correctness levers in chat — most "the bot forgot what we were talking about" and "it put my instruction in the PDF" bugs live here. Full design + acceptance tests: `CONVERSATION_INTELLIGENCE.md`.

---

## 8. Code-in-desktop: grep across millions of files

**Two complementary mechanisms:**
- **Live filesystem tools** — `grep` (bundled **ripgrep** for speed; respects `.gitignore`), `glob`, `list_dir`, `read_file`. Used for exact/structural search in the working tree. Results **capped + paginated**; large files chunked; the `fs` capability is **scoped to granted directories** (least-privilege) — the desktop passes the working dir(s) the user opened.
- **Indexed semantic retrieval** — the repo-map + pgvector index (built by `index_queue` workers) for "find code by meaning," not just literal text.

**When each:** literal/regex/symbol lookup → ripgrep (no index needed, instant). "Where is settlement retry logic conceptually" → semantic retrieval. The agent picks per query.

**Hard parts:** ripgrep is the workhorse (millions of files stay fast); result caps prevent context blowup; `.gitignore`/binary skipping; fs capability scoping enforces that the agent can't read outside granted dirs; file contents pass the compliance gate on read.

---

## Cross-cutting: why none of these is a PoC
Every subsystem above shares the same spine gates (identity/policy, compliance in/tool/out, approval), the same loop properties (cancel/timeout/retry/stuck-detect/backpressure), and the same Event Log. Each "hard part" is solved **once, in the spine**, and inherited by every feature — which is the only way to make eight subsystems production-grade without eight separate hardening efforts.
