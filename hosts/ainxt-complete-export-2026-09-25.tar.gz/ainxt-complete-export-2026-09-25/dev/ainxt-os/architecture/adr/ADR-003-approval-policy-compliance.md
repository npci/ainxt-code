# ADR-003 — The Approval / Policy / Compliance Seam (compliance + authorization + audit as required trait objects the turn pipeline cannot be built without)

**Status:** Accepted (P0 — Phase 0 foundation, load-bearing on every turn). Design only (no code).
**Decision class:** Architecture-defining and *safety-invariant*. It fixes the one seam that makes the runtime enterprise-grade by construction: three gates (Compliance, Authorization, Audit) are **required trait objects the turn pipeline is constructed from**, plus a blocking tri-state **Approval Gate**. You configure the *provider* of each gate; you can never configure the *gate itself out of the pipeline*. There is no build of the runtime without them.
**Relates to / extends:** ADR-001 (Runtime spine / strangler-fig — this is the seam the spine is built around), ADR-002 (Tool+MCP Runtime / one `CapabilityRegistry` — every capability dispatch passes this seam), ADR-004 (Config model "config-first, safety-invariant" — this ADR is the concrete discharge of A1's *mandatory-invariant* table), ADR-005 (Protocol — the Approval Gate is a versioned protocol event; the Renderer only renders it), ADR-006 (Provider/Model-Router — compliance runs on every model input and output regardless of provider), ADR-007 (Event Log / tamper-evident execution audit — the Audit trait's sink), ADR-008 (Guardrails — the Compliance Gate is *one rail*; this seam is where every rail mounts, §10), ADR-009 (Prompt-Injection Defense — this seam is the *action-side* containment injection defense actuates, §11), ADR-012 (data-class → model routing — a non-overridable Policy Engine exclusion, §7.5), ADR-013 (idempotency — the Side-Effect Ledger claim happens under this seam's authorization), ADR-016 (Agent-Payment Boundary — a grant the Policy Engine's vocabulary cannot spell, §7.6), ADR-022 (Agent Identity — the OBO context's *acting-as* identity), ADR-025 (Evidentiary Admissibility — the audit this seam emits is exportable as a certificate), ADR-026 (Control-Plane Git-Native — the Policy Engine reads the same manifest front-matter the reviewers approved; RBAC-on-**execute** vs RBAC-on-**author**, §7.4).
**Extended by (operational overlays that wire *onto* this seam, never re-implement it):** ADR-017 (Regulated-FI Compliance Ops — makes the gate also the write-path sink-guard and incident-detection source), ADR-019 (Liability chain), TOOLING §1.6 (OBO grants), §1.7 (egress DLP).
**Reconciles the standing rules:** `feedback_redact_dont_block.md` (compliance REDACTS and PROCEEDS — never a user-facing hard block) and the three sibling rules that look like they contradict it but govern *different sinks* (§6.2).

---

## 1. Context — why three separate concerns are one mandatory seam, not three optional features

The last platform (and every generic enterprise-AI platform) treats compliance, authorization, and audit as **features that individual code paths remember to call.** `agents/compliance_engine.py` is invoked "on all input and output" — *by convention*, by every author who remembers to. RBAC is a decorator someone must apply. Audit is a log line someone must write. The failure mode is structural and inevitable: the moment a new feature, a new tool, a hot-fix, or an SDLC pipeline forgets one of the three calls, that path is silently non-compliant, silently over-privileged, or silently un-audited — and nobody notices until a regulator does. A gate that a code path can *forget to call* is not a gate; it is a habit.

For India's payment switch this posture fails on first contact with an examiner, for the same reason `REGULATED_FI_COMPLIANCE_OPS.md` §0 names: **these are not documentation adjacent to the system; they are real-time control loops the runtime cannot be allowed to route around.** PCI-DSS requires that a PAN never reach a cloud model prompt or a durable store. DPDP requires that a user's PII be redacted and their authorization scoped. RBI treats every model call as governed IT outsourcing. The Bharatiya Sakshya Adhiniyam requires that "what the system did" be provable years later. None of these can rest on "the author remembered to call the function."

The three concerns look separate but share one property that makes them **one seam**: each must run at the *same points in the same pipeline*, on *every turn*, *without exception*, and each must be *impossible to skip*. That is not three cross-cutting habits — it is one architectural commitment: **the turn pipeline is constructed from these gates as required dependencies, so a feature cannot own the loop without owning the gates, and cannot skip a gate because the gate is the loop.** This is the `RUNTIME_FEATURE_FLOWS.md` thesis — "the 🔒 gates are in the pipeline, not the feature; a feature cannot forget them because it does not own the loop" — turned into the ADR that makes it a compile-time truth rather than a design aspiration.

The vendor study (`VENDOR_SYNTHESIS.md` §1.4) confirms the *approval* half of this shape is convergent — a decoupled blocking gate (opencode), tri-state approve/approve-for-session/reject-with-feedback (kimi-cli, grok-build) — but also names the gap: **not one studied vendor has a mandatory compliance gate wrapping every model input/output and tool result.** That is the AiNxt-specific, non-negotiable seam this ADR adds around the borrowed approval shape.

---

## 2. Decision

**Compliance, Authorization, and Audit are required trait objects the turn pipeline is constructed from; the Approval Gate is a blocking tri-state protocol event mounted in the loop. You configure each gate's provider; you cannot configure any gate out of existence.**

1. **Three mandatory traits, injected at construction (§4).** The runtime's turn-pipeline constructor takes `Box<dyn ComplianceGate>`, `Box<dyn AuthzProvider>`, and `Box<dyn AuditSink>` as **non-optional parameters** — the exact three `TurnPipeline` fields ADR-004 §6 declares (this ADR owns their *contracts*; ADR-004 owns *how config selects and hot-swaps a provider* for each). There is no default-`None`, no `Option<_>`, no builder path that yields a pipeline without all three. The OSS core ships generic default implementations of each so the runtime is usable out of the box; NPCI supplies its own (the PCI/DSS + PII engine, the AD/Keycloak RBAC provider, the tamper-evident Event-Log sink) as private plugins (ADR-007 licensing core/enterprise split). **Configurable = which impl. Non-configurable = whether it is present.** (Vocabulary: the **Policy Engine** is the authorization *subsystem*; `AuthzProvider` is the swappable identity/RBAC *backend trait* it holds — AD, Keycloak, or the OSS default. This ADR uses "Policy Engine" for the subsystem throughout and `AuthzProvider` only for the constructor-wired trait.)

2. **The Compliance Gate wraps every model I/O and every tool result, redact-and-proceed (§6).** It runs at four fixed 🔒 positions — input, tool-call args, tool result, final output (`RUNTIME_FEATURE_FLOWS.md` steps 3, 7a, 7d, 8) — plus, per ADR-017, the write-path (before any durable persist) and the egress boundary (before any outbound send, TOOLING §1.7). For the *user-facing* sinks the action is **redact and proceed, never hard-block** (`feedback_redact_dont_block.md`); three sibling sinks take a different action for a principled reason stated once in §6.2.

3. **The Policy Engine authorizes every capability dispatch on-behalf-of the human, three layers, all must pass (§7).** No agent ever executes under its own ambient identity. Every dispatch carries a resolved **OBO context** threaded from the turn's JWT and inherited by sub-agents; the Policy Engine answers *"can this user, via this capability, do this action on this resource, right now?"* against three independent layers (declared grant, issued scope, resource-level ABAC), and a missing grant is a **hard structured denial** — never a substitution of the agent's broader credential (the confused-deputy fix, TOOLING §1.6). It reads the *same* manifest front-matter the reviewers approved in git (ADR-026), enforcing RBAC-on-**execute** as an orthogonal, per-turn decision distinct from RBAC-on-**author**.

4. **The Audit Sink records every gate decision to the tamper-evident Event Log (§8).** Every compliance redaction, every OBO grant/deny, every approval decision, and every model/tool action is appended to the hash-chained, NTP-sourced Event Log (ADR-007) as the **execution-audit trail**, complementary to git-history's **authoring-audit** trail (ADR-026 §9's two-trail model). Audit *emission* is not configurable off — you configure the sink and format, never whether the decision is recorded.

5. **The Approval Gate is a decoupled, blocking, tri-state protocol event (§9).** For any dispatch the Policy Engine *permits* but the autonomy policy marks as requiring confirmation, execution **blocks** on a tri-state decision — **approve / approve-for-session / reject-with-feedback** — surfaced over the protocol to whoever the surface designates: a human via a Desktop/Web dialog or a degraded CLI prompt, an SDLC HITL checkpoint, or a pre-declared auto-policy in non-interactive contexts. Rejection feedback becomes model-visible tool output. **This is the single seam SDLC design/solution approval, Long-Horizon Program checkpoints, and every "risky tool" confirmation all reuse** — one Approval Gate, not per-feature HITL machinery.

6. **This seam is where guardrails (ADR-008) mount and where injection defense (ADR-009) actuates.** The Compliance Gate is *one rail* in the guardrails framework; the seam is the mount point every rail plugs into with a fail-closed discipline (§10). Injection defense supplies *detection and instruction/data separation*; this seam supplies the *action-side containment* those decisions actuate — trust-context-narrowed capabilities, untrusted-triggered-action forced approval, and egress DLP (§11).

---

## 3. The invariant, stated once

> **The turn pipeline cannot be instantiated without a Compliance Gate, a Policy Engine, and an Audit Sink. Every model input, model output, and tool result passes the Compliance Gate. Every capability dispatch passes the Policy Engine on-behalf-of the requesting human. Every gate decision is recorded to the tamper-evident Event Log. What is configurable is *which provider* implements each gate; what is not configurable is *whether the gate runs*.**

This is the discharge of `IMPLEMENTATION_PLAN.md` A1's mandatory-invariant table (ADR-004), made structural rather than documented:

| Gate | You configure (the trait impl / sink / provider) | You cannot |
|---|---|---|
| **Compliance** | which ruleset/engine (PCI/DSS+PII, or the OSS default), which detectors, per-namespace policy | remove the gate from the pipeline, or make a user-facing sink hard-block instead of redact |
| **Authorization / RBAC-ABAC** | which provider (AD, Keycloak, the default), the grant vocabulary, ABAC attribute sources | skip the authz check, substitute ambient credentials on a missing grant, or spell a `PaymentInitiating` grant |
| **Audit** | the sink, the format, the retention (subject to statutory floors, ADR-017 §6) | disable audit emission, or record a decision without its OBO context and control-plane SHA |
| **Approval** | the autonomy dial (auto/assisted/escalate per task), the risk-tier thresholds, the auto-policy for non-interactive contexts | make a `PaymentInitiating` action approvable, or let a high confidence score bypass a Tier-3 HITL gate |

**Enforced structurally, not by review.** The mechanism is the type system: a pipeline value cannot be built without the three traits (they are constructor parameters, not fields set later), so "a feature that forgot to call compliance" is not a bug that can occur — such a feature cannot obtain a runnable pipeline. This is the exact discipline ADR-016 §3 uses for the payment boundary (a denial is a *match arm the dispatcher is built with*, not a check someone adds) generalized to the whole safety seam.

---

## 4. The three traits — contracts, not implementations

The seam is defined by three trait contracts. The OSS core owns the traits and generic defaults; enterprises own the impls. What follows is the *contract each impl must satisfy*, in prose (the schemas are versioned per ADR-004; the Rust signatures are illustrative of shape, not code to be copied).

### 4.1 `ComplianceGate` — the redaction/classification trait
- **Input:** a `ScanContext { text, sink, data_class_hint, namespace, provenance }` where `sink ∈ {ModelInput, ToolArgs, ToolResult, ModelOutput, DurableWrite, Egress}` and `provenance` marks whether the text is *user-authored*, *retrieved/untrusted*, or *model-generated* (the trust tag ADR-009 sets, §11).
- **Output:** a `Verdict { transformed_text, findings: [ {class, span, action_taken, confidence} ], escalate: bool }` — the transformed text is what proceeds; `findings` is what the Audit Sink records; `escalate` raises an `IncidentCandidate` (ADR-017 §2.1) when a class egressed where policy forbids.
- **Contract:** the *action per finding is a property of the `sink`, not of the caller* (§6.2). Detectors are **RE2-class linear-time with hard size caps** — the gate is the one un-skippable component, so it is hardened as an availability boundary, not only a correctness one (TOOLING §1.8, ADR-017 §1.2.3). The gate **never silently passes** a text it could not fully scan (timeout/oversize ⇒ fail-closed to the safe action for that sink).

### 4.2 The Policy Engine and its `AuthzProvider` backend trait — the authorization contract
The **Policy Engine** is the authorization *subsystem* (it owns the three-layer evaluation, reads the manifest front-matter, applies the data-class exclusion, and threads the OBO context); the constructor-wired required trait ADR-004 §6 names is `AuthzProvider` — the **swappable identity/RBAC backend** the Policy Engine calls for layer-1 role/grant resolution (AD, Keycloak, or the OSS default). One is the fixed subsystem, the other is the pluggable provider inside it.
- **Input:** an `AuthQuery { obo_ctx, capability_id, resource_key, action, constraints, trust_context, control_commit_sha }` — the OBO context (§7.1), the resolved capability + resource, the argument-level `trust_context` (§11), and the control-plane SHA the turn pinned at start (ADR-026 §6.2) so the manifest read is reproducible.
- **Output:** a `Decision { Permit | Deny(reason) | RequiresApproval(risk_tier, scope_options) }` — a three-valued result: an allowed call, a hard structured denial (fed back to the model, never an ambient-credential substitution), or an allowed-but-must-confirm call that hands off to the Approval Gate (§9).
- **Contract:** all three authorization layers (§7.2) must pass for a `Permit`; the grant vocabulary has **no term for `PaymentInitiating`** (ADR-016 §3.3); the data-class exclusion (ADR-012) is evaluated **before** any ranking or failover and cannot be reached by user selection (§7.5). Every decision is emitted to the Audit Sink beside the call. The `AuthzProvider` backend is swappable (which directory/IdP resolves roles and departments); *that* the three-layer check runs, and that a missing grant is a hard denial, is not.

### 4.3 `AuditSink` — the execution-audit trait
- **Input:** a typed `GateDecision` event (a compliance verdict, an OBO decision, an approval outcome, or an action/observation) carrying `{ actor (the full agent-workload identity, ADR-022 §14), obo_ctx, control_commit_sha, t_ntp, correlation_id }`.
- **Output:** a durable, ordered, **hash-chained** append (ADR-007) — position-independent correlation by id so parallel/branched tool calls survive (`VENDOR_SYNTHESIS.md` §1.6), NTP-sourced timestamps (ADR-017 §8.2) so `t0` and every decision are later admissible (ADR-025).
- **Contract:** emission is **mandatory and synchronous-to-durability for gate decisions** (an approval or an OBO deny is not "best-effort logged" — it is part of the decision's commit). The sink is pluggable (the format, the store, the export path); *that* a decision is recorded is not.

**Why traits and not concrete engines:** the OSS core cannot ship NPCI's PCI/DSS ruleset or AD integration (they embed NPCI IP and would poison the open-source tree, ADR-007). Traits let the core be genuinely open and genuinely safe — the *seam* (mandatory, un-skippable) is OSS; the *NPCI ruleset* (the specific PANs/AADHAARs/IFSCs it detects, the AD org tree it reads) is a private plugin. A downstream adopter who supplies no impl still gets the generic defaults; they cannot get *no gate*.

---

## 5. Where the seam mounts in the turn pipeline

Every request from every Renderer flows through the canonical pipeline (`RUNTIME_FEATURE_FLOWS.md` §1). This ADR owns the 🔒 positions:

```
 2. Identity + Policy 🔒   validate JWT → build OBO context; turn-admission RBAC + dept scope;
                          budget check; rate-limit/backpressure (503 if over)   ← PolicyEngine (turn scope)
 3. Compliance IN    🔒   scan input (sink=ModelInput; provenance=user)          ← ComplianceGate
 …
 7. Agent Loop (per tool call):
    7a. Compliance   🔒   scan tool-call args (sink=ToolArgs)                     ← ComplianceGate
    7b. Authorize + Approve 🔒
          (i)  PolicyEngine.decide(AuthQuery)  → Permit | Deny | RequiresApproval ← PolicyEngine (call scope)
          (ii) if Deny        → structured denial fed back to model (no substitution)
          (iii)if RequiresApproval → BLOCK on the tri-state Approval Gate         ← ApprovalGate
    7c. Tool Runtime      dispatch (native/MCP/plugin — indistinguishable); Side-Effect Ledger claim (ADR-013)
    7d. Compliance   🔒   scan tool result (sink=ToolResult; provenance=untrusted if remote)  ← ComplianceGate
          (+ Egress DLP 🔒 if the effect leaves the boundary: sink=Egress, pre-send, TOOLING §1.7)
    7e. append (action, observation, gate decisions) to Event Log                 ← AuditSink
 8. Compliance OUT   🔒   scan final response (sink=ModelOutput)                  ← ComplianceGate
10. Persist + Audit  🔒   durable hash-chained append; OTel trace; budget updated ← AuditSink
       (+ write-path sink-guard 🔒 before any durable store: sink=DurableWrite, ADR-017 §5)
```

Two authorization scopes, deliberately distinct: **turn-admission** (step 2 — may this human start this turn on this profile at all?) and **per-capability** (step 7b — may this human do this specific action on this specific resource?). Conflating them is a common mistake; the first is coarse (JWT valid, department in scope, budget available), the second is fine-grained (the three-layer OBO check, §7.2). Both are the Policy Engine; they answer different questions at different granularities.

---

## 6. Compliance Gate — redact-and-proceed, four regimes, hardened as an availability boundary

### 6.1 Redact-and-proceed is the default and the point
The load-bearing rule is `feedback_redact_dont_block.md`: **compliance must REDACT and PROCEED, never hard-block the user.** A hard block on a false positive is Day-1 abandonment; the user asked a legitimate question and got a wall. So at the user-facing sinks (`ModelInput`, `ModelOutput`, `ToolResult` returned to the user), a detected regulated class is **redacted in place** (tokenized to a typed placeholder the model and the user both see) and the turn **continues**. The finding is recorded (§8) and, if the class *egressed where policy forbids* (e.g., a PAN was about to reach a cloud model against the ADR-012 data-class exclusion), an `IncidentCandidate` is raised (ADR-017 §2.1) — but the *user* is never abandoned.

### 6.2 The four redaction regimes (reconciling the corpus rules, stated once)
The corpus carries four rules that look like they conflict about redaction. They do not: **the action is a property of the sink, declared once, driven by the same detector set** (this is the `ComplianceGate` contract, §4.1). Restated from `REGULATED_FI_COMPLIANCE_OPS.md` §1.3 as the canonical table for this seam:

| Sink | Action | Why | Source rule |
|---|---|---|---|
| **User-facing content** (model I/O, tool result to user) | **REDACT and PROCEED** | never abandon the user on a false positive; the model works on the redacted text | `feedback_redact_dont_block.md` |
| **Durable data-plane store** (Event Log, memory, vectors, traces, exports) | **REDACT/tokenize *before the write*** | so the store is structurally PCI/PII-light — DPDP erasability and PCI no-CDE-persistence hold by construction | ADR-017 §5, §6.6 |
| **A definition entering git** (control plane) | **BLOCK at commit-entry** | redacting a definition would corrupt it (a role's SOP with a redacted clause is a broken role); a definition never needs PII, so refuse entry | ADR-026 §10 |
| **Code** (a PAN-shaped literal in source) | **FLAG as a SAST finding**, never redact | redaction corrupts syntax; the fix is a code change, not a mutation | `feedback_doc_build_audit_not_block.md`, `CODE_REVIEW_PIPELINE.md` §5 |

There is no contradiction: **block a definition (it never needs PII), flag code (redaction corrupts it), redact user output (never abandon the user), redact-before-persist for durable stores (so the store is structurally clean).** One detector set, four sink-declared actions.

### 6.3 The gate is the one un-skippable component, so it is the one hardened attack surface
Making compliance central makes it the single point every turn depends on — which makes its own performance a denial-of-service surface (Pass-5 gap [20]). A crafted string that triggers catastrophic regex backtracking (ReDoS) or an unbounded input can pin a worker at 100% CPU and stall every turn sharing the pool. The gate is therefore **RE2-class linear-time on every detector, with hard input size caps**, and **fail-closed on a scan it cannot complete** (timeout/oversize ⇒ the safe action for that sink, never a silent pass). Detector *recall* is the honest residual (§16.1): the gate can only redact what it detects, so recall is a top-priority continuously-evaluated component (`RUNTIME_SCORECARD.md` systemic risk 2), and defense-in-depth (write-path sink-guard §6.2, store-sweep ADR-017 §5.4, egress DLP §11) catches misses at the next boundary.

---

## 7. Authorization — on-behalf-of, three layers, ABAC, and the two orthogonal RBAC questions

### 7.1 The OBO context — the agent never acts as itself
The agent never executes under its own ambient identity. Every dispatch carries a resolved **OBO context** — `{ user_id, role, department, ad_level, can_approve, granted_permissions, acting_as (the ADR-022 agent-workload identity), trust_context }` — threaded from the turn's JWT through the entire call chain, **including sub-agent invocation**: a sub-agent inherits the parent's OBO context and can never present broader credentials than the human who started the turn actually holds (TOOLING §1.6, acceptance test 6 there). The JWT claims are exactly the auth model in `CLAUDE.md` (`role ∈ {user, admin}`, `ad_level` 0–6, `department`, `can_approve = ad_level ≤ 3`) — this ADR does not invent a new identity model; it *threads the existing one through every dispatch and makes it un-substitutable.*

### 7.2 Three independent layers — RBAC × ABAC — all must pass
The Policy Engine answers one question per call — *can this user, via this capability, do this action on this resource, now?* — against three layers, **all** of which must return allow (TOOLING §1.6):

1. **Declared grant (RBAC).** A scoped tuple `{capability, resource_pattern, action, constraints}` on the definition's manifest front-matter (ADR-026 §5) — e.g. `connector.postgres.query: read-only, table=settlement_batches`, never a blanket `connector.postgres.*`. Least-privilege by default.
2. **Issued scope.** The user's *actually-issued* connector scope / OAuth grant (data plane, encrypted, keyed by `jwt.sub`) — a manifest may *declare* a grant the user has not been *issued*; the call needs both.
3. **Resource-level ABAC.** Attribute-based: the *resource's* attributes (department, data-class, `resource_key`, sensitivity) evaluated against the *caller's* attributes (`department`, `ad_level`, `data_class` clearance). This is what stops a user in Dept A reading Dept B's repo/thread even when they hold the capability (the data-scoping rule in `CLAUDE.md`, `SCENARIO_MATRIX.md` line 36).

RBAC answers "does this principal hold this permission"; ABAC answers "do the caller's and the resource's attributes permit this specific access." The seam runs both because either alone leaks: pure RBAC can't express "same capability, different department"; pure ABAC loses the named, reviewable grant. Both, always.

### 7.3 A missing grant is a hard denial — the confused-deputy fix
A missing grant is a **hard, structured denial** — the runtime **never** substitutes the agent's broader ambient service credential to "help" the call succeed. That substitution *is* the confused-deputy failure mode (a poisoned document tells the agent to query a ledger table the *user* can't see, and the agent's own broad credential quietly succeeds); refusing it is the fix (TOOLING §1.6, acceptance test 4). The denial reason is fed back to the model as an ordinary tool result (so the loop can adapt or ask the user), and the decision — granted or denied — is written to the Event Log beside the call, reconstructable years later.

### 7.4 RBAC-on-author vs RBAC-on-execute — the orthogonality this seam enforces at run time
ADR-026 §8 establishes two different questions answered by two different systems at two different times. This ADR owns the *execute-time* half:

| | **RBAC-on-AUTHOR** (ADR-026, git) | **RBAC-on-EXECUTE** (this ADR, run time) |
|---|---|---|
| Question | *Who may change this definition?* | *Who may run it, now, on this resource?* |
| Source of truth | CODEOWNERS + branch protection | the manifest's `execute_rbac` + `capabilities` front-matter |
| Enforced by | the git host, at PR/merge/promote | the **Policy Engine**, per turn, at dispatch |
| Failure it prevents | a junior ships a payment role | an unauthorized caller runs an approved role; over-privilege / confused-deputy |

**Approval-in-git is necessary but not sufficient for execution.** A role can be merged, tagged, and live in `env/prod` and still be **denied at run time** because the caller's role/`ad_level`/department/issued-scope don't satisfy the manifest's `execute_rbac`. The Policy Engine reads the *same* front-matter the reviewers approved, evaluated against the *caller's* live OBO context. Git governs authoring; this seam governs execution; neither substitutes for the other (ADR-026 acceptance test 3; `RUNTIME_FEATURE_FLOWS.md` §2.7–2.8 acceptance tests).

### 7.5 Data-class routing is a Policy Engine exclusion, not a router optimization
The Model Router is read as **a compliance component that happens to also optimize cost/latency/quality**, not the reverse (TOOLING §4, ADR-012). The data-class → model-eligibility exclusion runs **before ranking and before failover** and cannot be reached by user model-selection or a failover fallback: regulated-payment data is structurally excluded from cloud models and confined to in-house OSS models, as a hard filter the Policy Engine owns. This ADR records that the exclusion is *authorization*, not *ranking* — it lives on the un-skippable seam, so "the user picked GPT-5.4" or "the primary failed over" can never route regulated data off-shore.

### 7.6 The payment boundary is a grant the vocabulary cannot spell
Per ADR-016 §3.3, the Policy Engine's grant vocabulary has **no term** for a `PaymentInitiating` capability. This is stronger than "denied": the authority is *not representable*, so even a fully-privileged human's OBO context cannot carry it to the agent. Confused-deputy for the apex class is closed here specifically — there is nothing to be confused *into* (§4 layer 3 of ADR-016). The Approval Gate (§9) inherits this: a `PaymentInitiating` action is not "approvable with enough sign-off"; it never reaches the gate because it can never be granted.

---

## 8. Audit — the execution trail, and the two-trail model completed

### 8.1 Every gate decision is an audited event
The Audit Sink records, to the hash-chained Event Log (ADR-007), **every decision this seam makes** — not just actions, but the *governance* of actions:
- each **compliance verdict** (what class, which sink, what action taken) — so a redaction is provable;
- each **OBO decision** (grant/deny, which of the three layers, under which OBO context) — so "who was allowed to do what" is reconstructable;
- each **approval outcome** (approve / approve-for-session / reject, by which human, with what feedback, after how long) — feeding the oversight-health metrics (`WORKFORCE_AND_OS.md` §111: approve-latency and override-rate → complacency detection);
- each **action/observation**, correlated by id (position-independent, so parallel tool calls survive) with the **actor** = the full agent-workload identity (ADR-022 §14) and the **control-plane commit SHA** the turn pinned (ADR-026 §6.2).

### 8.2 The two-trail model, completed
ADR-026 §9 defines two complementary, non-substitutable audit trails; this seam supplies the second:
- **git history = the *authoring* audit** — who wrote/approved a definition (ADR-026).
- **the Event Log = the *execution* audit** — what the runtime *did* with a definition, under whose OBO context, at which SHA, with which gate decisions along the way.

A regulator's two questions — *"who authorized this behavior?"* and *"what did the system actually do, and can you prove it?"* — map to these two trails. The execution trail is NTP-sourced (ADR-017 §8.2) and exportable as a Bharatiya Sakshya Adhiniyam §63 certificate (ADR-025), so it is not merely tamper-evident but court-admissible. **Audit emission is not configurable off** (the A1 invariant, §3): you configure the sink, the format, the retention (subject to statutory floors and legal-hold, ADR-017 §6), never whether a decision is recorded.

---

## 9. The Approval Gate — blocking, tri-state, decoupled, one seam for every HITL

### 9.1 Decoupled blocking gate
The Approval Gate follows the convergent vendor shape (`VENDOR_SYNTHESIS.md` §1.4, opencode/kimi-cli/grok-build), re-implemented in AiNxt's own vocabulary: the dispatch that needs approval **requests permission and blocks on a response channel**; a separate mechanism publishes an **Approval Gate protocol event** (ADR-005) that the Renderer subscribes to; whoever answers (a human, an SDLC HITL step, a policy auto-decision) resolves it, unblocking the dispatch. The gate is **tool-agnostic of who answers it** — the *same* protocol event is answered by a Desktop rich dialog (diff preview + scope + "always allow"), a Web dialog, a CLI blocking prompt, an SDLC design-approval checkpoint, or a pre-declared auto-policy. The tool blocking on approval never knows or cares which.

### 9.2 The tri-state decision — never binary allow/deny
The decision is **three-valued** (never binary), because binary allow/deny loses the two states that make approval usable at scale:
- **approve** — this one call proceeds;
- **approve-for-session** — this call *and* semantically-equivalent calls for the rest of the session proceed without re-prompting (a "graduated always-allow scope" — for a parsed bash command, the scope is token-aware: "always allow `git status`", not "always allow anything", `VENDOR_SYNTHESIS.md` §1.4 token-aware approval);
- **reject-with-feedback** — the call is denied **and the rejection text becomes model-visible tool output**, so the loop learns *why* and can adapt (kimi-cli/grok-build) rather than blindly retrying.

Rejection-as-feedback is the property that makes the gate a *steering* instrument, not just a veto: "no, use the staging DB not prod" redirects the agent; a bare "denied" would just make it retry.

### 9.3 The autonomy dial decides *whether* the gate fires
Whether a permitted call fires the gate is governed by the **per-task autonomy dial** (`AINXT_OS.md` §4 step 4; `HARNESS_SDK.md`) — autonomy is *per-task, not per-role*:
- **auto** — the Policy Engine `Permit` proceeds with no gate (e.g. read-only KB search);
- **assisted (HITL)** — a `Permit` becomes `RequiresApproval`; the gate blocks for a human (e.g. a connector *write*);
- **escalate** — anything unrecognized, or where the uncertainty/abstention signal (gap U) crosses a threshold, escalates to a human regardless.

The autonomy dial is a *definition* (control-plane, git, ADR-026), reviewed and versioned; it configures *whether* a gate fires, never *whether the gate exists*. And it is bounded from below by hard rules the dial cannot lower: a **Tier-3 critical-path edit (settlement module) forces the Approval Gate regardless of a 100 Confidence Score** (`CODE_REVIEW_PIPELINE.md` Tier-3 rule §209/§277, `LONG_HORIZON_PROGRAMS.md` §208) — a high score can never buy its way past HITL on the money path.

### 9.4 One seam for SDLC HITL, Programs, and every risky action
The Approval Gate is deliberately the **only** HITL mechanism in the runtime — everything reuses it, nothing re-implements it:
- **SDLC** design-approval (gate #1) and solution-approval (gate #2) are Approval Gate events (`SUBSYSTEM_DEEP_DIVES.md` §SDLC steps 3/8, `RUNTIME_FEATURE_FLOWS.md` §2.4); on resume after approval, `repo` is read from `run.context`, never reconstructed (the known-bug guard in `CLAUDE.md`).
- **Long-Horizon Programs** (ADR-027) gate on staged checkpoints (start / phase-boundary / budget / critical-path / anomaly) via **this same seam** — "no new HITL machinery" (`LONG_HORIZON_PROGRAMS.md` §191).
- **Serving-Ops** P0 rollback below the auto-threshold blocks on this seam (`SERVING_OPS.md` §128).
- **Separation of Duties** is enforced *at the gate*: the Policy Engine refuses an approval action from the actor whose agent-workload identity *produced* the artifact (ADR-022 §18) — even the same model running as two Runs cannot self-approve, because the SoD check keys on identity.

### 9.5 Non-interactive and degraded surfaces — no human, no deadlock
The gate must never deadlock a context with no human to answer it:
- **CI / cron / headless** — a **pre-declared auto-approve/deny policy** answers the event (there is no human to prompt anyway); an action outside the policy's allow-list is *denied*, not hung (`INTERACTION_REPL_COMMANDS.md` §1.3, C1/C2 acceptance tests).
- **SSH / bare terminal, no GUI** — the one honestly-residual interactive case: `ainxt run --interactive-approvals` surfaces a **single blocking `y/n/feedback` readline** per Approval Gate event — the same protocol event a Desktop dialog answers, not a TUI, zero new rendering engine (`INTERACTION_REPL_COMMANDS.md` §1.3, N2; `ainxt_runtime_solution.md` §Clients/CLI).
- **Notification class.** An Approval Gate awaiting a live human is emitted with notification class `immediate` (bypasses digest and quiet hours — attention budget never overrides a live approval need, `INTERACTION_REPL_COMMANDS.md` §8), set by the *emitter*, never the channel.

---

## 10. Composition with Guardrails (ADR-008) — the Compliance Gate is one rail; this seam is the mount

ADR-008 is the **framework**; ADR-003 is the **mandatory seam it mounts on**. The relationship, stated precisely so neither ADR duplicates the other:

- **The Compliance Gate is one rail among many.** The guardrails framework runs a configurable set of rails at the same input/output positions this seam already owns (§5): jailbreak/injection-signature detection, toxicity/harmful-content, topic/scope restriction, **groundedness/hallucination** (the OUT-position rail that gates whether an answer is supported by its retrieved sources), format/schema validation, system-prompt-leak detection (`GAP_ANALYSIS_VS_AI_PLATFORMS.md` A/B). The `ComplianceGate` trait (§4.1) is the shape *every* rail implements — a `ScanContext → Verdict` — so a rail is just a compliance-gate-shaped component registered at a pipeline position.
- **One rail is non-removable; the rest are config-driven.** The PCI/DSS+PII compliance rail is the mandatory invariant (§3) — it cannot be turned off. The other rails are configurable *on/off/threshold* per A1 (`IMPLEMENTATION_PLAN.md`) — an enterprise tunes its toxicity threshold; it can never tune its PAN detector off. This is the exact "configure the provider, never the gate" rule applied within the rail set: the *compliance* rail is the floor, additional rails are additive.
- **Rails run in a defined order with a fail-closed discipline.** At each position rails run in a declared order; a rail may **redact** (transform-and-proceed), **annotate** (attach a finding for audit/UX, e.g. a groundedness score), **block** (only where policy for that sink permits a block — never a user-facing hard block, §6.1), or **feed back** (return a structured result to the loop, e.g. "this violated topic scope, rephrase"). A rail that errors or times out fails **closed** to its safe action, exactly as the compliance gate does (§6.3) — a broken guardrail is never a silent open door.
- **The groundedness rail composes with retrieval/citations.** The OUT-position groundedness rail (ADR-008, gap AA) is where "verify the citation actually supports the claim" is enforced; it consumes the same retrieved-source set the Context Engine assembled and the same Audit Sink records its verdict — so "the answer was grounded" is provable, not asserted.

The clean division: **ADR-008 decides *which rails exist and how they're configured*; ADR-003 guarantees *the mount is mandatory, the compliance rail is non-removable, and the whole set is un-skippable and fail-closed*.** Without ADR-003, ADR-008's rails would be optional features a code path could forget; with it, they are pipeline-owned.

---

## 11. Composition with Injection Defense (ADR-009) — this seam is the action-side containment

Prompt injection (especially *indirect* — a malicious instruction smuggled in via a retrieved document or a remote MCP tool result) is defended in two halves, and this ADR owns the *action* half. **ADR-009 adds no new gate** — it explicitly wires into *this* seam (ADR-009 §2, §6.3). ADR-009 owns **provenance, the trust lattice, taint propagation, and the injection classifier** (the *detection/separation* layer); ADR-003 owns the **Policy Engine and Approval Gate those decisions actuate** (the *action* layer). The division is exact and the composition is stated as the attack chain and where each mechanism cuts it:

1. **Instruction authority is a property of provenance, not position (ADR-009 §3).** Every context span carries a **trust class** (two authority levels — instruction vs data — and, within data, a taint tier), assigned at ingestion and **monotonically inherited** by anything derived from it (a summary of a poisoned doc stays tainted). *This ADR's part:* the resulting `provenance`/`trust_context` rides in the `ScanContext` (§4.1) and the `AuthQuery` (§4.2) — specifically the **argument-level taint** of *this* call — so the run-time gates *know* whether the specific action's parameters were influenced by untrusted bytes.
2. **Tool allow-listing per trust context is a Policy Engine decision (ADR-009 §6, the core mechanism).** The effective set of dispatchable capabilities is the intersection `base_profile ∩ OBO_grants ∩ trust_context_policy(taint, sensitivity, data_class)` — the third term is the taint axis, a **versioned control-plane policy definition** (ADR-026), evaluated by the **Policy Engine at dispatch (7b)** in the very place OBO/RBAC already run (ADR-009 §6.3), so native/MCP/plugin capabilities all get it via the one-registry path with no per-capability work. Crucially it is **argument-level, not turn-level**: a turn that read a poisoned document may still freely run a read-only lookup whose arguments came from the *user*, and trips the gate only on the *specific* call whose arguments the poison touched — precise, not blanket friction (`feedback_redact_dont_block.md` in spirit). A missing entry is a structured denial, never an ambient-credential substitution (the confused-deputy fix on the taint axis).
3. **Taint-gated confirmation reuses this Approval Gate, unchanged (ADR-009 §7).** When the trust-context policy says *confirm*, the runtime forces the call through the **same** tri-state Approval Gate (§9) — no new modal. What ADR-009 adds is *what the human is shown*: the **tainted provenance** ("this action's recipient/body was influenced by an external web page fetched this turn") and the **egress redaction preview**. This ADR's contribution is that the gate already exists, is blocking and tri-state, and that a `trust_context` marking argument-level taint on a sensitive call turns the Policy Engine's `Permit` into a `RequiresApproval` regardless of the autonomy dial.
4. **OBO constrains *who* (§7).** Even if injection gets the agent to *attempt* an exfiltrating or over-privileged action, the agent can only ever act as the requesting human — the confused-deputy fix means the injected instruction cannot reach data the *user* couldn't (§7.3).
5. **Egress DLP inspects *what* leaves (§5, TOOLING §1.7, ADR-009 §9).** The exfiltration half: any capability whose effect leaves the boundary routes its **outbound payload** through the Compliance Gate (`sink=Egress`) *before* the network call fires — a PAN in a summary the agent was tricked into emailing is redacted or the send is blocked; an unknown external destination soft-blocks pending approval (TOOLING acceptance test 7).
6. **The categorical backstop (ADR-016).** Above all of these, a `PaymentInitiating` action is unreachable regardless of how perfect the injection is — there is no dispatch arm and no grant to be steered into (§7.6). ADR-009's escalation to a **risk-triggered dual-LLM quarantine** (§8 there — a capability-less quarantined pass feeding a privileged pass that never sees raw untrusted bytes) is ADR-009's own mechanism *above* this seam; this ADR simply notes that even its output dispatches through the same Policy Engine + Approval Gate, so the quarantine narrows *what the model proposes* while this seam still governs *what actually runs*.

The chain closes because the two halves compose: **injection defense lowers the *probability* the agent attempts a malicious action; this seam lowers the *impact* to near-zero** — argument-level narrowed capabilities, taint-gated confirmation, un-substitutable identity, payload inspection on the way out, and an unreachable payment apex. Neither half alone suffices (detection has false negatives; action-gating alone can't tell trusted from untrusted intent); together, and only together, they are the full injection→exfiltration defense (ADR-009 §2: "no single link is trusted to hold alone").

---

## 12. Config-first, safety-invariant (ADR-004) — the exact boundary

This ADR is the concrete face of ADR-004's principle. The config layering (`built-in defaults → deployment → tenant/org → surface profile → per-request`, most-specific-wins) applies to *everything about how the gates behave* — and **nothing about whether they run**:

- **Configurable (declarative, schema-validated, versioned, hot-reload where safe):** which compliance engine + which detectors + per-namespace policy; which RBAC/ABAC provider + the grant vocabulary + ABAC attribute sources; which audit sink + format + retention; the autonomy dial per task; the risk-tier thresholds; the guardrail rail set + per-rail thresholds; the non-interactive auto-approve/deny policy.
- **Architecturally mandatory (no config path can reach):** the presence of all three traits in the pipeline; that compliance runs at all four model-I/O positions plus write-path and egress; that authorization is OBO and three-layer; that audit emits every gate decision; that a user-facing sink redacts rather than blocks; that a `PaymentInitiating` grant is unspellable; that a Tier-3 critical-path action forces HITL; that the data-class exclusion runs before ranking.

Per-request overrides are the sharpest edge: a request can *raise* strictness (a stricter tenant policy wins) but a per-request override can **never lower a mandatory invariant** — the merge is not "most-specific wins" for the invariants; they are floors the layering cannot descend below. This is enforced the same way the payment boundary is (§3): the invariant is structural, not a config default that a lower layer could shadow.

---

## 13. Control-plane / data-plane placement (ADR-026)

The seam's *policy* is control-plane (git); its *decisions and instances* are data-plane (stores) — the ADR-026 §3 split applied exactly:

| Artifact | Plane | Store | Erasable? |
|---|---|---|---|
| Grant vocabulary, `execute_rbac` front-matter, ABAC rules, autonomy dials, guardrail config, detector rulesets, SoD action-pairs | Control | git | No (reviewed, versioned, signed) |
| An **OBO decision** (grant/deny, for a specific call) | Data | Event Log | Per ADR-017 §6 (+ legal-hold) |
| A **compliance verdict** (what was redacted, where) | Data | Event Log | Per ADR-017 §6 |
| An **approval outcome** (who approved, feedback, latency) | Data | Event Log + `oversight_health` | Per ADR-017 §6 |
| The **issued connector scope** (OAuth token, per user) | Data | Postgres, encrypted | Yes (on disconnect) |
| A **Payment-Adjacent Mandate** instance (ADR-016 §6) | Data | Event Log | Non-repudiable; per hold |

The Policy Engine reads the *policy* from a fast, hot-reload-synced, **in-memory projection** of the control-plane registry (never a git read on the dispatch hot path — the same materialized-projection discipline ADR-022 §15 uses for renewal, `SERVING_OPS.md` §1 for placement, `PROMPT_ENGINEERING.md` §3 for the prompt registry), pinned to the turn's `control_commit_sha` so every decision is attributable to a specific, verifiable git state. **Fail-closed on staleness:** if the projection's sync lag exceeds a bounded freshness threshold, affected definitions are treated as deny-by-default, never fail-open on a stale cache.

---

## 14. Acceptance / scenario tests

| # | Scenario | Setup | Expected | Proves |
|---|---|---|---|---|
| 1 | Pipeline cannot be built gate-less | Attempt to construct the turn pipeline with a missing Compliance/Policy/Audit trait | Construction is impossible — the trait is a required constructor parameter; there is no build without it | The invariant is structural, not conventional (§3) |
| 2 | Redact-and-proceed, not block | A user pastes a Luhn-valid PAN into a chat question | The PAN is redacted in place; the turn **continues** and answers; the finding is audited; no user-facing hard block | Redact-and-proceed at user-facing sinks (§6.1) |
| 3 | Sink-driven action differs | The *same* PAN string appears in: chat input, a durable memory write, a definition PR, and a source file | Redacted (chat), tokenized-before-write (store), push **blocked** (git), **flagged as SAST** (code) — four actions, one detector set | The four redaction regimes (§6.2) |
| 4 | Confused-deputy denial | User has no grant for `connector.postgres.query` on `ledger_accounts`; asks the agent (which holds a broad service credential) to query it | Hard structured denial; the agent's broad credential is **never** substituted; denial fed back to the model; audited | OBO three-layer authz + no ambient substitution (§7.2–7.3) |
| 5 | Sub-agent inherits, cannot escalate | A parent turn's OBO context has a scoped grant; it delegates to a sub-agent | The sub-agent's calls evaluate under the **same** OBO context; it cannot exercise a broader grant than the parent | OBO propagation across delegation (§7.1) |
| 6 | ABAC department scope | User in Dept A, holding `kb.search`, targets Dept B's repo | Permitted by RBAC (holds the capability) but **denied by ABAC** (resource dept ≠ caller dept); no cross-scope leak in the Event-Log projection | RBAC × ABAC both required (§7.2) |
| 7 | Approve ≠ execute | A role merged, tagged, live in `env/prod`; a caller whose `ad_level`/dept fails `execute_rbac` invokes it | Policy Engine denies at run time despite full git approval | RBAC-on-author ⊥ RBAC-on-execute (§7.4) |
| 8 | Data-class exclusion beats user selection | User explicitly selects a cloud model; the turn carries regulated-payment data | The router excludes the cloud model **before ranking**; routes to in-house OSS; selection cannot override | Data-class routing is authorization, not ranking (§7.5) |
| 9 | Payment grant is unspellable | An author tries to write a manifest grant authorizing a `PaymentInitiating` capability | CI/pre-receive rejects it (ADR-016 §4 layer 4); the grant vocabulary has no term; the Approval Gate never even sees it | The apex boundary is non-representable, not "approvable" (§7.6) |
| 10 | Tri-state reject steers | An agent proposes writing to the prod DB; a human rejects with "use staging" | The call is denied; the rejection text becomes model-visible tool output; the agent redirects to staging | Reject-with-feedback is a steering instrument (§9.2) |
| 11 | approve-for-session scope | A human picks "approve-for-session" for `git status` | Subsequent semantically-equivalent `git status` calls proceed without re-prompt; `git push` still prompts | Token-aware graduated always-allow scope (§9.2) |
| 12 | Autonomy dial gates | `password_reset: auto`, `access_request: assisted` on one role | The reset proceeds silently; the access request **blocks** on the Approval Gate | Per-task autonomy dial drives whether the gate fires (§9.3) |
| 13 | Tier-3 forces HITL at score 100 | A settlement-module edit passes every deterministic gate at Confidence Score 100 | The Approval Gate **still** blocks (Tier-3 rule); a high score cannot bypass HITL | Critical-path floor the dial cannot lower (§9.3) |
| 14 | One seam for SDLC HITL | An SDLC design-approval checkpoint and a chat risky-tool confirmation | Both resolve via the **same** Approval Gate protocol event; no separate HITL machinery | Single approval seam (§9.4) |
| 15 | SoD self-approval refused | The agent-workload identity that produced an artifact attempts to approve/merge it | Refused — the SoD check keys on identity; even the same model as two Runs cannot self-approve | Separation of Duties at the gate (§9.4) |
| 16 | Non-interactive no-deadlock | A cron/CI run hits an Approval Gate event with no human present | The pre-declared auto-policy answers; an out-of-policy action is **denied**, never hung | Non-interactive coverage (§9.5) |
| 17 | SSH degraded approval | A human on a bare SSH terminal (no GUI) hits an Approval Gate event | `--interactive-approvals` surfaces a single blocking `y/n/feedback` prompt over the same protocol event; no TUI | The one honestly-residual case, covered minimally (§9.5) |
| 18 | Every gate decision is audited | Run a turn with a redaction, an OBO deny, and an approval | All three appear in the hash-chained Event Log with actor, OBO context, and `control_commit_sha`; none is omittable | Audit emission is mandatory (§8) |
| 19 | Two-trail audit answers a regulator | "Who authorized this behavior?" and "What did the system do?" | git history answers the first (signed PR + diff); the Event Log answers the second (OBO + SHA + gate decisions) | Complementary, non-substitutable trails (§8.2) |
| 20 | ReDoS on the gate is absorbed | A crafted catastrophic-backtracking string is fed to the input | RE2-class linear-time matching + size cap complete in bounded time; no worker pinned; oversize input fails **closed** | The un-skippable gate hardened as an availability boundary (§6.3) |
| 21 | Guardrail fails closed | A configured toxicity rail throws/times out mid-turn | The rail fails **closed** to its safe action; the turn does not proceed as if the rail passed; audited | Guardrail composition fail-closed discipline (§10) |
| 22 | Compliance rail cannot be configured off | A tenant config attempts to disable the PAN detector while lowering the toxicity threshold | The toxicity threshold change applies; the PAN detector **cannot** be disabled — the compliance rail is the floor | "Configure the provider, never the gate," within the rail set (§10, §12) |
| 23 | Injection → argument-level narrowing | A poisoned retrieved doc steers a sensitive tool call; the same turn also runs a read-only lookup whose args came from the user | The Policy Engine's `base ∩ OBO ∩ trust_context_policy` intersection gates the *tainted* call only; the user-sourced read-only lookup proceeds — argument-level, not blanket turn-level friction | Tool allow-listing per trust context, argument-level (§11.2, ADR-009 §6) |
| 24 | Taint-gated confirmation | A sensitive action's parameters are tainted by untrusted content | The Policy Engine's `Permit` becomes `RequiresApproval`; the Approval Gate blocks regardless of the autonomy dial, showing the tainted provenance + egress redaction preview | Taint-gated confirmation reuses the one Approval Gate (§11.3, ADR-009 §7) |
| 25 | Injection → exfiltration blocked at egress | A poisoned doc gets the agent to email a PAN-containing summary externally | Egress DLP inspects the outbound payload pre-send; PAN redacted or send blocked; unknown domain soft-blocks | The exfiltration half of the chain (§11.5) |
| 26 | Per-request override cannot lower a floor | A per-request override attempts to disable output compliance | The override is rejected for the invariant; strictness can only be raised, never lowered below the floor | Config-first, safety-invariant merge (§12) |
| 27 | Stale projection fails closed | The control-plane projection's sync lag exceeds the freshness threshold | Affected definitions are treated as deny-by-default; no fail-open on a stale policy cache | Fail-closed on staleness (§13) |
| 28 | Default impls, never no-gate | A downstream OSS adopter supplies no compliance/RBAC plugin | The generic OSS default gates run; the adopter gets *default* gates, never *no* gates | Traits + defaults keep the core open and safe (§4) |

---

## 15. Consequences

**Positive**
- Safety is enforced *by construction* — a feature cannot forget compliance/authz/audit because it does not own the loop and cannot obtain a pipeline without the gates. The `RUNTIME_FEATURE_FLOWS.md` "gates in the pipeline, not the feature" thesis becomes a compile-time truth.
- One approval seam for chat, SDLC HITL, Programs, Serving-Ops rollback, and SoD — built and hardened once, inherited everywhere.
- The core is genuinely open-source *and* genuinely safe: the seam is OSS (mandatory), the NPCI ruleset is a private plugin (ADR-007 core/enterprise split) — no NPCI IP in the OSS tree, no way to ship a gate-less runtime.
- The injection→exfiltration chain is closed by composition (§11), and guardrails (§10) mount without duplicating the seam — one safety architecture, not three parallel ones.
- Audit is admissible by construction (§8.2, ADR-025), and the two-trail model answers the regulator's two questions end-to-end.

**Negative / cost**
- Every turn pays the gate cost on every model I/O and tool result. Mitigated by RE2-class linear-time detectors + size caps (§6.3), the in-memory policy projection (§13), and prompt-cache-friendly positioning — but it is a real per-turn tax, deliberately paid.
- The seam is the one un-skippable component, so its *own* availability and *detector recall* become top-priority (residuals §16.1–16.2). Centralizing safety centralizes the blast radius of a bug in it.
- Legal/DPO/security must author policy (grants, ABAC, autonomy dials, detector rulesets) through git PR review (ADR-026) — a UX obligation on the Studio, inherited here.
- Non-engineers meet the Approval Gate constantly; a poorly-tuned autonomy dial produces either approval fatigue (too many prompts → rubber-stamping, which `WORKFORCE_AND_OS.md` §111 measures) or over-automation (too few → unreviewed risk). The dial must be tuned on real override-rate data.

**Neutral**
- This ADR removes nothing; it wires the existing identity model (`CLAUDE.md` JWT claims), the existing compliance detectors, and the existing Event Log into one mandatory seam, and gives ADR-008/009 a mount.

---

## 16. Residual risks (honest, not deferred silently)

1. **Detector recall is the ceiling on compliance.** The gate can only redact/authorize what it detects; a novel PAN/PII format the classifier misses passes user-facing sinks and is only caught (if at all) at the next defense-in-depth boundary. Mitigation: recall is a continuously-evaluated, top-priority component (`RUNTIME_SCORECARD.md` risk 2); the write-path sink-guard, store-sweep, and egress DLP are the belt-and-suspenders. The residual is real and named — a design cannot prove recall it hasn't measured on real NPCI data.
2. **The un-skippable gate is a single availability surface.** RE2-class matching + size caps + fail-closed bound the *known* DoS class (ReDoS, §6.3), but a subtler pathological input or a bug in the one component every turn depends on degrades or stalls every turn. Mitigation: the gate is the most-fuzzed, most-load-tested component (A3 security testing); the residual is that "the safety gate is also the chokepoint" is inherent to making it un-skippable.
3. **Autonomy-dial calibration is unproven until real load.** The auto/assisted/escalate thresholds and risk tiers are illustrative until tuned against real approve-latency and override-rate (`RUNTIME_SCORECARD.md` risk 4, `WORKFORCE_AND_OS.md` §111). A mis-tuned dial is either fatigue or over-automation; the mechanism is correct but the numbers are not yet fixed.
4. **Trust-context accuracy bounds injection defense.** §11's action-side containment is only as good as ADR-009's provenance tagging: if untrusted content is mis-tagged trusted, the capability set is not narrowed and the forced-approval rule does not fire. This seam actuates the trust decision; it does not *make* it — so a false-trusted tag is a hole this ADR cannot close alone. Named as a shared boundary with ADR-009.
5. **Approval-fatigue → rubber-stamping is a human residual, not a mechanism gap.** The gate can force a decision; it cannot force *attention*. The override-rate→0 complacency detector (§8.1, `WORKFORCE_AND_OS.md`) surfaces it but does not prevent it. An honest residual of any HITL system.
6. **Policy-projection freshness vs staleness fail-closed is a tuning trade.** Fail-closed on staleness (§13) prevents a stale-cache security hole but can deny legitimate calls during a control-plane propagation lag or a projection outage. The freshness threshold is a git-controlled knob balancing availability against safety; its value is not yet sized from production.

---

## 17. Self-score (honest)

**Design ceiling: 9.5 / 10.** Every clause of the decision has a concrete enforcement mechanism — three required constructor traits (§4), four fixed compliance positions with sink-declared actions (§6.2), three-layer OBO authz with no ambient substitution (§7), a tamper-evident two-trail audit (§8), a decoupled tri-state blocking gate with an autonomy dial bounded by hard floors (§9), and clean, non-duplicating composition with guardrails (§10) and injection defense (§11) — each with an acceptance test that exercises exactly the property that matters (28 tests, §14). The seam is the structural discharge of ADR-004's mandatory-invariant table, consistent with ADR-026's author-vs-execute orthogonality, ADR-016's non-representable payment grant, and ADR-012's pre-ranking exclusion. It reconciles the four apparently-conflicting redaction rules into one sink-driven table (§6.2) and gives ADR-008/009 a mount without absorbing their scope.

The missing half-point is honest and lives in the residuals: the whole seam's *effectiveness* (not its *presence*, which is structural and proven) rests on detector recall (16.1) and trust-context accuracy (16.4) — two things this design *specifies the enforcement for* but cannot itself prove until built and measured on real NPCI data; and the human half of approval (16.3, 16.5) is a calibration-and-attention problem no mechanism fully closes. **Build maturity: 0 / 10** — no code exists, consistent with every artifact in this corpus. The ceiling is set correctly so implementation can only descend from a real 10-shaped target: the *architecture* of the seam is complete and un-skippable; what remains genuinely open is the recall, the calibration, and the trust-tagging that determine how well the complete architecture performs.
