# ADR-004 — Configuration Model: "Config-First, Safety-Invariant"

**Status:** Accepted — Design only (no code).
**Decision class:** Foundation-defining, Phase 0. Fixes the *one* knob/tuning system every other document's "Config:" line in this corpus is written against (`IMPLEMENTATION_PLAN.md` per-phase "Config surface" rows, `SERVING_OPS.md` §QoS policy, `TOOLING_MCP_PLUGINS_ROUTING.md` tenant/enable sets, `ADR-026` §14 per-kind `authority` flag). Nothing built after this ADR may invent a second, parallel way to make a runtime behavior tunable.
**Relates to / extends:** ADR-001 (strangler-fig sidecar — the config loader is a Phase-0 deliverable of the sidecar itself, per `IMPLEMENTATION_PLAN.md` §Phase 0 "Config model spec"), ADR-002 (Tool+MCP Runtime — this ADR reuses ADR-002's schema-from-struct mechanism for every config domain, §4; a capability's *identity* — `effect_class`/`risk_tier`/schema — is a control-plane manifest, while its per-tenant *enable/disable* is config, §9), ADR-003 (Approval/Policy/Compliance seam — the three mandatory gates this ADR wires as non-optional constructor arguments, §6), ADR-006 (Provider/Model Router — which providers are *reachable at all* from a deployment is config, §9; router *eligibility* policy is control-plane per ADR-012/ADR-018), ADR-007 (execution Event Log — the audit sink every config change and every gate decision writes to, non-optional, §11), ADR-009 (Agentic Security & Prompt-Injection Defense — §10 of this ADR is the request-layer defense against a crafted input widening a safety ceiling through the last, most-specific config layer), ADR-012 (Data Residency/Sovereignty/Data-Class routing — the eligibility matrix is control-plane, not config; endpoint/credential wiring for a deployment's reachable providers is config, §9), ADR-013 (Action Idempotency & Transactionality — ledger TTLs and reconciler sweep intervals are hot-reloadable config, §7), ADR-016 (Agent-Payment-Initiation Boundary — has **no** config knob at all; §6 draws the line between "non-configurable-off" and "not present to configure"), ADR-018 (Model Governance — the License/Origin Registers are control-plane, not config, §9), ADR-024 (microVM Sandbox — this ADR's resource-ceiling fields are floors the sandbox's own hard limits may never be configured looser than, §5), **ADR-026 (Control-Plane Git-Native — the central reconciliation this ADR performs: ADR-026 owns *definitions*; this ADR owns everything `IMPLEMENTATION_PLAN.md` §A1 called "configurable" that is not a definition, §9)**.
**Supersedes:** `IMPLEMENTATION_PLAN.md` §A1's informal single list of "configurable" things. That list is not repealed — it is disambiguated by §9 below, exactly as ADR-026 §13 disambiguated (never repealed) `feedback_db_source_of_truth.md`.

---

## 1. Context — a good principle, an underspecified mechanism, and a vocabulary collision with ADR-026

`IMPLEMENTATION_PLAN.md` §A1 states the platform's founding configuration principle correctly: **almost everything is declarative and schema-validated; a small, named set of safety gates are architecturally mandatory and cannot be turned off.** That principle is right and this ADR does not revisit it. What §A1 left as a one-line sketch — a single bullet list of "configurable" nouns and a single arrow-chain of five layer names — is not yet a mechanism. Three questions have no answer in §A1's eighteen lines:

1. **What actually happens when two layers disagree?** §A1 says "most-specific wins," which is the right default for an ordinary setting (a tenant's preferred telemetry sink) and the **wrong** default for a safety-relevant ceiling (a tenant asking for a *higher* autonomy dial or a *larger* sandbox memory limit than the deployment allows must not win just because "tenant" is more specific than "deployment"). §A1 names no exception to its own rule, so as written it would let a more-specific layer *loosen* a less-specific layer's safety ceiling — the opposite of "safety-invariant."
2. **What is actually a config *value*, versus a reviewable *artifact*?** §A1's list — "models & providers, routing rules, capabilities/tools, skills, agents, connectors, surface profiles, context/retrieval strategy, autonomy levels, prompts, sandbox limits, budgets, rate limits, telemetry sinks" — was written before `ADR-026` existed. ADR-026 (a later, Q2-decision, architecture-defining ADR) subsequently declared that **skills, agents, roles, prompts, workflows, and policies are control-plane *definitions*** — versioned files in a git-backed repo, governed by PR review and CODEOWNERS, never a merge-at-boot config value. Several nouns on §A1's list are now, literally, the thing ADR-026 calls a definition. Read together, unreconciled, the two documents contradict each other about where a prompt or an agent spec lives. This ADR performs that reconciliation (§9) rather than leaving two authoritative documents in silent conflict.
3. **How is "hot-reload where safe" actually decided, and what happens to a turn already in flight when a value it is using changes underneath it?** §A1 states the qualifier ("where safe") without defining safety's boundary.

This ADR answers all three, reusing mechanisms this corpus already trusts (ADR-002's schema-from-struct, ADR-026's atomic-swap-with-in-flight-pin) rather than inventing new ones — the same "one mechanism, not two" discipline `TOOLING_MCP_PLUGINS_ROUTING.md` §0 applies to capability dispatch.

---

## 2. Decision

**Configuration is a five-layer, deterministically-merged, schema-validated value graph, with one structural exception carved out for safety-relevant fields, and it governs only what ADR-026 does not.**

- **The merge is deterministic and total-order.** `built-in defaults → deployment config → tenant/org config → surface profile → per-request overrides`. For an ordinary field, the most-specific layer that sets a value wins (last-write-wins along the chain, §5.1).
- **Safety-relevant fields are the one structural exception.** A field tagged `merge_policy: narrow_only` in its schema (autonomy ceiling, sandbox resource limits, egress allow-lists, budget/rate ceilings, and the three mandatory-gate toggles themselves, were a toggle for them to exist) merges by **MEET** — the most restrictive value across every layer that sets it wins, never the most specific (§5.2). A layer can only ever *tighten*, never loosen, what an upper layer already restricted.
- **The three mandatory gates — Compliance, Authorization/RBAC, Audit — are not merge-graph values at all.** They are required constructor arguments on the turn pipeline's type; there is no schema key whose value is "off," because there is no code path that reads one (§6). You configure *which provider implements the gate*; you cannot configure the gate's absence.
- **Every config domain is schema-validated using the same schema-from-struct mechanism ADR-002 uses for tool argument schemas** — one schema system for the whole runtime, not a config-specific second one (§4).
- **Hot-reload is an atomic, content-addressed, all-or-nothing swap, scoped to the smallest layer that changed, with every in-flight turn pinned to the config snapshot it started with** — the same mechanism ADR-026 §6 uses for the control plane, applied to a different subject (§7).
- **This ADR governs only what ADR-026 does not.** Anything with a reviewable *body* (a prompt's text, a skill's SOP, a policy's rule, a workflow's DAG) is a control-plane definition, governed by ADR-026, never a config value under this ADR — regardless of what `IMPLEMENTATION_PLAN.md` §A1's original list called it (§9).

---

## 3. The split, stated as an invariant (parallel to ADR-026 §3)

ADR-026 splits the platform along **control plane vs. data plane**, on the axis of erasability/mutability/change-shape. This ADR splits a *third* thing — **configuration** — out of both, on a different axis: **does the value have review-worthy *content*, or is it a *knob*?**

> **If a setting has substantive content that itself expresses privilege, behavior, or instructions — a persona, an SOP, a policy rule, a DAG — it is a *definition* and it lives in git, under ADR-026, regardless of how often or by whom it changes.**
> **If a setting is a scalar or small structured *value* with no independent content to review — an endpoint URL, a ceiling number, a feature flag, an enabled-set, a sink address — it is *configuration* and it lives in this ADR's layered merge graph, regardless of how safety-critical the number is.**

The second axis is orthogonal to ADR-026's first. A value can be safety-critical (an autonomy ceiling, a sandbox memory cap) and still be *configuration* — because a number has no body to review, only a value to bound, and bounding a number is exactly what the `narrow_only` MEET mechanism (§5.2) is for. A value can be operationally mundane and still be a *definition* (an internal-only, rarely-touched persona prompt) — because it has a body, and a body needs review, not a ceiling.

| Field on §A1's original list | Has reviewable content? | Plane / model |
|---|---|---|
| Skill body, agent spec, role persona, prompt text, workflow DAG, policy rule text | **Yes** — instructions/behavior in prose or DAG form | Control-plane **definition** (ADR-026) |
| Autonomy ceiling, sandbox CPU/mem cap, budget/rate limit, telemetry sink address, feature flag, enabled-capability set, provider endpoint/credential, retrieval top-k/rerank threshold | **No** — a number, address, or boolean | **Configuration** (this ADR) |

§9 works this table through every noun on §A1's original list explicitly.

---

## 4. Schema mechanism — one system, reused

Every config domain (`deployment`, `tenant`, `profile`, `request`) is a **Rust struct**, and its JSON-Schema is derived from that struct by the **same schema-from-struct macro** `IMPLEMENTATION_PLAN.md` §Phase 1 lists for the Tool Runtime (`registry, schema-from-struct, core tools`). This is deliberate reuse, not incidental resemblance — a config value and a tool argument are the same *shape* of problem (a typed, boundable, machine-checkable value supplied by something less trusted than the runtime itself), and giving them two different schema engines would mean fixing every schema bug twice.

Each field in a config struct carries schema metadata beyond type/range:

```
pub struct AutonomyConfig {
    #[config(merge_policy = "narrow_only", order = "auto > assisted > escalate")]
    pub ceiling: AutonomyLevel,
}

pub struct SandboxLimits {
    #[config(merge_policy = "narrow_only", op = "min")]
    pub memory_mb: u32,
    #[config(merge_policy = "narrow_only", op = "min")]
    pub cpu_percent: u8,
    #[config(merge_policy = "narrow_only", op = "and_of_false")]  // network can only ever be disabled, never enabled
    pub network_enabled: bool,
}

pub struct TelemetryConfig {
    #[config(merge_policy = "override")]   // ordinary — most-specific layer wins
    pub otel_endpoint: String,
}
```

**`merge_policy` has no default.** A field author must write `override` or `narrow_only` explicitly — the schema-derivation macro fails to compile (design-time, not run-time) a struct field with neither. This is the mechanical answer to residual risk §16.2: it does not guarantee a human picks the *right* policy, but it makes forgetting to pick one impossible, exactly as ADR-026 §5 makes a missing `execute_rbac` a hard CI failure rather than a silent default.

**A second, structural check runs at schema-registration time, not merge time:** any field whose type is a long freeform string (over a configurable length threshold, heuristically prose-shaped) is **rejected by the schema loader** with an error naming ADR-026 and pointing the author at the control repo. This does not catch every misclassification (§16.1 names the residual honestly) but it catches the concrete, recurring failure mode this ADR exists to prevent: someone adding a `"default_prompt_text": String` field to a config struct because it was faster than opening a PR against `ainxt-control`.

---

## 5. Layering and merge semantics

### 5.1 Ordinary fields — most-specific wins, deterministic

`resolved = defaults.merge(deployment).merge(tenant).merge(profile).merge(request)`, applied key-path by key-path (a deep merge over the struct's field tree, not whole-document replacement — setting one field in `tenant` does not blank out siblings left at their `deployment` value). Arrays and sets use an explicit verb (`set`, `add`, `remove`) per key rather than bare replace-or-concat, so a profile that wants to add one capability to a deployment's enabled set does not have to restate the whole set (and cannot accidentally shrink it by omission).

### 5.2 Safety-relevant fields — MEET, not override

For any field tagged `narrow_only`, the resolved value is the **most restrictive** value among every layer that sets it — computed once, over the whole chain, not "the most specific layer that happens to mention it." Three concrete restriction orders, because "most restrictive" is not the same comparison for every type:

| Field class | Restriction order | Example |
|---|---|---|
| Enum with a declared total order | `min()` along the declared order | `autonomy.ceiling`: `auto > assisted > escalate` (least autonomous wins) — a tenant configured at `assisted` who tries a per-request `auto` still resolves to `assisted`. |
| Numeric ceiling | `min()` | `sandbox.memory_mb`: deployment ceiling 512, tenant asks 768 → resolves to 512, per ADR-024's own hard floor, which this config ceiling may never exceed either. |
| Boolean gate | `AND` of `false` wins | `sandbox.network_enabled`: any layer setting `false` makes the resolved value `false`, permanently, for that request — no later layer can flip it back to `true`. |
| Allow-list (egress domains, capability enable-set) | **intersection**, never union | A tenant's egress allow-list can only be a subset of the deployment's; a profile cannot add a domain the deployment never allowed. |

**This is the mechanical form of the safety-invariant half of this ADR's name.** §A1's "most-specific wins" default is correct for `override` fields and actively wrong for `narrow_only` fields; naming the exception and giving it its own comparison semantics is what makes "config-first" and "safety-invariant" simultaneously true instead of in tension.

### 5.3 Validation happens before merge, not after

Every layer's raw value is schema-validated **in isolation** before it enters the merge. A malformed `tenant` layer never reaches the merge step at all — the resolver falls back to the last-good resolved value for that tenant and pages an operator (the same "all-or-nothing, last-good" discipline ADR-026 §6.1 applies to the control plane, scoped here to the smallest affected layer rather than the whole config graph, per §7.2).

---

## 6. The three mandatory gates — structurally present, not configured off

Per `IMPLEMENTATION_PLAN.md` §A1, Compliance, Authorization/RBAC, and Audit are **configurable provider, never configurable off**. This ADR fixes the mechanism, not just the rule:

| Gate | What is a config value | What is not a config value |
|---|---|---|
| Compliance | which ruleset/engine implementation loads (`compliance.provider: "npci-pci-dss-v2"` vs. the OSS default) | any key whose value would skip the call |
| Authorization/RBAC | which provider (`authz.provider: "ad" \| "keycloak" \| "default"`) | any key whose value would bypass the check |
| Audit | which sink/format (`audit.sink: "postgres" \| "kafka" \| "otel"`) | any key whose value would suppress emission |

**The turn pipeline's constructor takes these as required, non-`Option` trait objects:**

```
pub struct TurnPipeline {
    compliance: Box<dyn ComplianceGate>,   // required — no Default, no None variant
    authz:      Box<dyn AuthzProvider>,    // required
    audit:      Box<dyn AuditSink>,        // required
    // ... session manager, prompt engine, model router, etc.
}
```

There is no build of the runtime that produces a `TurnPipeline` value without all three — the type system, not a runtime `if config.compliance_enabled`, is what makes "off" impossible. The **provider selection** for each — which of possibly several implementations loads — *is* an ordinary config value (`override` merge policy, resolved like any other setting) and *is* hot-reloadable, but the wiring that calls the gate at all is compiled into the pipeline's shape, never conditional on a config key's presence. Defaults ship in the OSS core (a permissive default `ComplianceGate`, a default AD/`user`-role `AuthzProvider`, a stdout/Postgres `AuditSink`); NPCI supplies its PCI/DSS engine and AD-RBAC provider as the private enterprise plugin, per ADR-007's core/enterprise split — the *interface* is OSS, the *NPCI-specific implementation* is not, and neither fact changes whether the call happens.

**Swapping a gate's provider is not a bare file-touch.** Because the blast radius of a bad compliance or authz provider swap is the whole platform, gate-provider changes go through a **promotion path** distinct from an ordinary hot-reload: the new provider is instantiated and run against a fixed synthetic probe set (known PAN/PII/secret samples for Compliance; known allow/deny decision fixtures for Authz) *before* it is eligible for the atomic swap (§7.2); a provider that fails any probe is never adopted, and the last-good provider keeps serving. This is the same "shadow-validate before adopting" discipline `PROMPT_ENGINEERING.md`'s canary rollout uses for prompt-layer changes, applied here to gate providers specifically because they are the one config domain where "wrong" is silent and platform-wide rather than loud and scoped.

**ADR-016 note, for completeness, not overlap:** the agent-payment-initiation boundary is *not* an instance of this section's pattern. There is no `payment.enabled` config key to guard, because there is no code path to payment dispatch at all — "non-configurable-off" presumes a switch exists and is wired shut; ADR-016's boundary is the stronger case of a switch that was never built. This ADR's mandatory-gate mechanism and ADR-016's structural absence are two different, complementary answers to "how do you guarantee X always happens / never happens" — this ADR should not be read as claiming ADR-016's guarantee, and ADR-016 should not be read as needing this ADR's constructor-argument trick, because it needs no constructor argument at all.

---

## 7. Hot-reload mechanics

### 7.1 What "safe" means, precisely

A config change is hot-reloadable if and only if: (a) the new value passes schema validation in isolation (§5.3); (b) applying it does not require tearing down a live resource the running process holds open in a way that would break an in-flight turn (a connection-pool *size* can grow live; a connection-pool's *target host* cannot be swapped without draining first); and (c) for `narrow_only` fields, the MEET computation is well-defined for the new value (a schema-invalid enum value has no place in the declared order and is rejected, not coerced). Fields that fail (b) — listen ports, DB DSNs, sandbox kernel image paths — are **deploy-config-restart-only**, and are marked as such in their schema (`#[config(hot_reload = false)]`); attempting to hot-reload one is rejected with an explicit error, not silently ignored.

### 7.2 The reload itself — atomic swap, scoped, content-addressed

The mechanics are ADR-026 §6's, applied to a different registry:

1. A change lands in one layer's store (a deployment file edit, a tenant-config row update, a profile row update — never the built-in-defaults layer, which is compiled into the binary and changes only on a binary release).
2. The changed layer is re-validated in isolation (§5.3); on failure, only *that layer's* contribution is rejected — the resolver keeps the last-good value for that specific tenant/profile, other tenants/profiles are unaffected. This bounds blast radius to the layer that actually changed, the same way ADR-026 §6.2's incremental validation bounds cost to the changed set rather than the whole control plane.
3. The resolved config for every `{tenant, profile}` pair whose inputs changed is recomputed and hashed (`config_hash = sha256` over the resolved value tree) and swapped in atomically (an `arc-swap`-style pointer flip) — the previous resolved value remains reachable by its own hash until no in-flight turn references it.
4. **In-flight turns are pinned.** Every turn captures its `config_hash` at turn start, exactly as it captures the control-plane `commit_sha` (ADR-026 §6.2), and reads that snapshot for its whole duration. A budget or rate-limit tightened mid-turn does not retroactively cancel a turn already admitted under the prior ceiling; it takes effect for the *next* admission decision. The one deliberately-named exception is a small, explicit **live-tunable set** — a global kill-switch and emergency-zero-budget — which a turn re-checks at each step boundary rather than only at admission, because an emergency stop that waits for the current turn to finish on its own is not an emergency stop.

### 7.3 Reload-latency budget

Because the resolver scopes recomputation to the changed layer and the `{tenant, profile}` pairs it feeds (§7.2 step 2–3), reload cost tracks the size of the *change*, not the size of the *tenant base* — the same shape of commitment ADR-026 §6.3 makes for the control plane, restated here for config: a single tenant's rate-limit edit does not force recomputation of every other tenant's resolved config.

---

## 8. Storage per layer

| Layer | Store | Who writes it | Governance |
|---|---|---|---|
| Built-in defaults | Compiled into the binary (embedded TOML / `Default` impls), ships with the OSS core | Runtime engineers, via a normal code PR to the OSS repo | Ordinary code review — this layer is code, not data, and changes on a binary release |
| Deployment config | A file (TOML/YAML) + environment-variable overlay at a deploy-pinned path, read at boot (the direct successor of today's flat env-var model, `CLAUDE.md` §Required Environment Variables) | Ops/SRE, via the org's existing infra change-management (Ansible/Helm/whatever NPCI already runs) | **Not git-native control-plane** (deliberately — see §9); an ops team may keep its own infra-repo hygiene, but this ADR does not require it, and does not require a CODEOWNERS-gated PR for an ops config bump the way ADR-026 requires one for a definition |
| Tenant/org config | Postgres, a `tenant_config` table keyed by `{tenant_id, domain}`, data-plane per ADR-026 §3 | Admin-role users only (`require_admin_flag()`), through an admin UI/API | Every write is captured by the mandatory Audit gate (§6) — RBAC + audit, not PR review; this is the data-plane governance model, not the control-plane one, by design |
| Surface profile | Postgres, a `surface_profile_config` table keyed by `{profile_id}` (`cli`, `desktop`, `slack`, `teams`, `voice`) | Admin-role users | Same as tenant config — RBAC + audit |
| Per-request overrides | Never persisted — read once from the request/JWT claim/header for that turn, validated against a **strict allow-list schema** (§10), discarded after the turn | The caller (end user or calling surface) | Not a governed layer at all; it is the most-specific, least-trusted, most-restricted input in the whole graph |

Note what is deliberately absent from this table: **no layer here is a git-backed control-plane repo.** That is the point of §9 — this ADR's five layers are exactly the residue left after ADR-026 took the reviewable-content nouns out of §A1's original list.

---

## 9. Reconciling with ADR-026 — disambiguating `IMPLEMENTATION_PLAN.md` §A1's list

ADR-026 is later and architecture-defining; it does not conflict with this ADR so much as **narrow the set of nouns this ADR actually governs.** Read side by side with §3's invariant, here is every noun from §A1's original "Configurable" list, resolved:

| §A1 noun | Resolution | Why |
|---|---|---|
| **Skills, agents** | **Control-plane definition (ADR-026)** | Body-bearing — a skill's SOP or an agent's spec is reviewable content, not a knob |
| **Prompts** | **Control-plane definition (ADR-026)** | Prompt text is exactly ADR-026 §5's "body IS the compiled layer text" |
| **Policies** (data-class routing, egress allow-list templates, autonomy *defaults*) | **Control-plane definition (ADR-026)** for the rule/template itself | A policy's *rule text* is reviewable; see next row for the numeric ceiling this ADR still owns |
| **Autonomy levels** | **Split.** The per-task autonomy *value* declared for a specific role lives in that role's front-matter (control-plane, ADR-026 §5). An org-wide autonomy *ceiling* — "no dial in this deployment may exceed `assisted` during a regulatory probation window" — is a `narrow_only` config value under this ADR (§5.2), which can only tighten what a role's front-matter declares, never loosen it |
| **Connectors** | **Split.** A connector's capability manifest (schema, `effect_class`, `risk_tier`) and its org/department allow-deny *policy* are control-plane (ADR-026, TOOLING §3.3). Whether a connector is *enabled at all in this deployment*, and its OAuth app ID / redirect URI / air-gap-proxy routing, are config (this ADR) |
| **Models & providers, routing rules** | **Split.** *Eligibility* — which model may ever see which data class (ADR-012), and the License/Origin Registers (ADR-018) — is control-plane. Which providers are *reachable at all* from this deployment (endpoint URL, credential binding, `LLM_PROXY_URL` dev-vs-prod per `CLAUDE.md`) is config |
| **Capabilities/tools** | **Split.** A tool's identity/schema/`risk_tier` (ADR-002) is control-plane (or code, for native tools). The tenant/deployment *enabled set* is config (an `override`-policy allow-list, intersected downward by `narrow_only` at the deployment layer per §5.2) |
| **Surface profiles** | **Configuration (this ADR), §8.** A profile is a bundle of override *values* (which capabilities are on for Slack vs. CLI, a model-tier ceiling, an autonomy ceiling) — it has no body of its own; it composes references to control-plane definitions and config ceilings, it does not author new content |
| **Context/retrieval strategy** | **Configuration.** Retrieval source toggles, top-k, rerank thresholds — tuning parameters, no reviewable body |
| **Sandbox limits** | **Configuration, `narrow_only`.** CPU/memory/network ceilings — numeric, MEET-merged, floor set by ADR-024's own hard limits |
| **Budgets, rate limits** | **Configuration, `narrow_only`.** Numeric ceilings, MEET-merged |
| **Telemetry sinks** | **Configuration, `override`.** An address/format, no body |

**The refined rule, stated once, mirroring ADR-026 §13's own summary sentence:** *A setting with reviewable content is a definition and lives in git under ADR-026, however often it changes and however safety-critical it is; a setting that is a bounded value with no independent content is configuration and lives in this ADR's layered merge graph, however safety-critical the number is. Neither plane is ever the informal dumping ground the other one already has a better answer for.*

**Nothing on §A1's original list is un-owned.** Every noun resolves to exactly one of the two systems (or splits cleanly into one piece of each) — there is no third, ungoverned category this reconciliation leaves behind.

---

## 10. Request-layer safety — the last, least-trusted layer cannot widen a ceiling

The per-request layer is attacker-adjacent by construction: a crafted prompt (indirect injection, per ADR-009) or a malicious client can attempt to smuggle an override through any parameter the surface exposes. Two independent mechanisms close this, deliberately redundant:

1. **Strict allow-list schema.** The request-layer schema is not "the deployment schema, minus nothing" — it is a small, explicitly-enumerated **subset** of fields a request is permitted to vary at all (model hint, temperature/top-p, a few UX toggles). `compliance.provider`, `authz.provider`, autonomy, and every `narrow_only` field are **not members of the request-layer schema** — a request payload containing `"compliance_enabled": false` or `"autonomy": "auto"` is rejected at the schema boundary before it ever reaches the merge step, the same fail-closed posture the egress/data-class detectors use (`TOOLING` §1.7/§4.2).
2. **MEET semantics as defense-in-depth.** Even for the handful of `narrow_only` fields a request layer is, in some deployment, permitted to touch, §5.2's MEET computation means a request cannot widen what an upper layer restricted — it can only ask for something *within* the already-narrowed envelope. Two independent controls (an allow-list a malicious payload cannot even reach, and a merge rule that would neutralize it if it somehow did) is the same "belt-and-suspenders" posture ADR-026 §10 uses for its PII-at-commit-entry gate.

**Acceptance test 9 (§14) exercises exactly this: a request attempting to disable compliance or widen autonomy above the tenant ceiling is provably rejected, twice over.**

---

## 11. Reproducibility and audit

Every turn's Event Log record (ADR-007) carries **both** identifiers needed to reproduce its exact behavior: the control-plane `commit_sha` it ran under (ADR-026 §6.2, "in-flight pin") and the resolved-config `config_hash` it ran under (§7.2 step 4, this ADR's own pin). "What did the system do, and could you prove exactly what settings it was running under" — a regulator's second question, per ADR-026 §9 — is answered completely only when both are present; recording one without the other leaves a reproducibility gap this ADR names as a residual (§16.5) rather than assumes away. Every **write** to a tenant/profile config row (§8) is itself an audited event through the mandatory Audit gate (§6) — config changes are never a silent, unaudited side channel, closing the same class of gap ADR-026 §9 closes for authoring changes to definitions.

---

## 12. Air-gap

A sovereign/air-gapped deployment's config graph is entirely local by construction: the deployment-config file/env-overlay is provisioned at build/ship time, the tenant/profile Postgres tables are in-zone, and per-request overrides never touch a network boundary at all. Nothing in this ADR requires an outbound call to resolve a config value — unlike ADR-026's control plane, which needs a signed bundle transfer to cross the air-gap boundary (ADR-026 §12), the config model has no cross-boundary transfer step to design, because none of its layers are ever meant to be shared across deployments in the first place. The one thing worth naming: gate-provider promotion (§6) still requires the probe-fixture set to be provisioned in-zone (no different from any other in-zone artifact) — there is no live-network dependency introduced by this ADR that an air-gapped deployment does not already have to solve for everything else.

---

## 13. Alternatives considered

- **A single flat config file per environment, no layering.** Rejected: cannot express tenant- or profile-scoped granularity without duplicating whole files per tenant, and gives no natural home for a merge-time safety rule — "most restrictive wins" has nothing to compare against if there is only one file per environment to begin with.
- **Put configuration in the same git control-plane repo as definitions — one governance system for everything.** Rejected, deliberately, as the mirror image of ADR-026's own reasoning: configuration is high-write, per-tenant, and sometimes must change *instantly* (an emergency budget-zero, a kill-switch) — exactly ADR-026 §3's "operational-state" column, not its "definitions" column. Forcing every tenant rate-limit bump through a PR would recreate, for ops changes, the exact "Studio-as-git-client latency pressure to add a quick-publish side door" ADR-026 §17.4 already names as a residual risk for *authored content* — applying that same pressure to routine ops tuning is a worse trade, not a safer one.
- **Environment variables only, no schema, no layered merge.** Rejected as the *whole* model — it is exactly today's Python platform's flat env-var approach (`CLAUDE.md` §Required Environment Variables), which has no per-tenant/per-profile granularity and no schema validation. It survives inside this design as **one config source within the deployment layer** (the env-var overlay, §8), not as the entire mechanism.
- **A fully dynamic, unschematized feature-flag service (LaunchDarkly-style boolean flags with no type system).** Rejected as the general model: unschematized flags decay into an unreviewable, undocumented maze (classic feature-flag debt) and provide no place to hang `narrow_only` MEET semantics. A feature flag is welcome as *one config domain* inside this schema-typed model (a `bool` field with `merge_policy: override` or `and_of_false`), never as a parallel, ungoverned second system living beside it.
- **A "test/lower-environment" escape hatch that allows Compliance/Authz/Audit to be disabled for local dev.** Rejected outright, matching §A1's non-negotiable table exactly: even in the lowest environment, the OSS default provider for each gate still runs — "off" is not an environment-scoped exception, because a scenario matrix (`IMPLEMENTATION_PLAN.md` §A3) run against a dev build with gates disabled would prove nothing about the build that actually ships.

---

## 14. Acceptance / scenario tests

| # | Scenario | Setup | Expected | Proves |
|---|---|---|---|---|
| 1 | Deterministic merge | Same five-layer input set resolved twice, in-process and after a cold restart | Byte-identical resolved config both times | The merge is a pure function of its inputs, not order/timing-dependent |
| 2 | Ordinary field, most-specific wins | `telemetry.otel_endpoint` set at deployment and tenant layers | Resolved value is the tenant layer's | §5.1 override semantics hold |
| 3 | Autonomy MEET | Tenant ceiling `assisted`; a per-request override attempts `auto` (in a deployment where autonomy happens to be request-schema-visible) | Resolved value is `assisted` | §5.2 MEET on an ordered enum |
| 4 | Sandbox memory MEET | Deployment ceiling 512MB; tenant config requests 768MB | Resolved value is 512MB | §5.2 MEET (`min`) on a numeric ceiling |
| 5 | Egress allow-list intersection | Deployment allows `{*.npci.org.in}`; tenant config attempts to add `evil.example.com` | Resolved allow-list excludes the added domain | §5.2 MEET (intersection) on an allow-list |
| 6 | Missing `merge_policy` fails at schema-derivation time | A new config struct field is added with no `merge_policy` attribute | Build/schema-derivation fails, not a silent default | §4's "no default" rule is enforced mechanically |
| 7 | Prose-shaped field rejected | A config struct field is a long freeform string above the heuristic length threshold | Schema loader rejects it, error names ADR-026 | §4's structural nudge against config/definition misclassification |
| 8 | Mandatory gate cannot be omitted | An attempt to construct `TurnPipeline` with no `AuditSink` | Does not compile / cannot be constructed | §6 — gates are required trait objects, not config-gated calls |
| 9 | Request-layer widening attempt, twice-blocked | A request payload includes `"compliance_enabled": false` and `"autonomy": "auto"` above the tenant ceiling | Payload rejected at the request-schema allow-list boundary (mechanism 1); even if it somehow reached merge, MEET would still resolve to the ceiling (mechanism 2) | §10 — defense-in-depth against a prompt-injection-driven or malicious-client override |
| 10 | Malformed tenant layer, isolated blast radius | One tenant's config row is schema-invalid | That tenant resolves to its last-good config; every other tenant's resolution is unaffected | §5.3 + §7.2 — per-layer validation, scoped blast radius |
| 11 | Hot-reload atomic swap | A deployment config file is edited while turns are running | New value takes effect for new admissions after validation; no in-flight turn observes a torn/partial read | §7.2 atomic swap |
| 12 | In-flight pin | A tenant's rate limit is tightened mid-turn | The running turn completes under the ceiling it was admitted under; the *next* turn sees the new ceiling | §7.2 step 4 |
| 13 | Kill-switch is the named exception | A global kill-switch is flipped mid-turn | The in-flight turn observes it at its next step boundary and halts, unlike an ordinary `narrow_only` field | §7.2 step 4's explicit live-tunable carve-out |
| 14 | Restart-only field rejects hot-reload | An attempt to hot-reload a DB DSN | Rejected with an explicit "requires restart" error, not silently ignored and not silently applied | §7.1(b) |
| 15 | Gate-provider promotion probe | A new Compliance provider fails one fixture in the synthetic probe set | The provider is never adopted; last-good provider keeps serving; operator is notified | §6's promotion path, distinct from an ordinary hot-reload |
| 16 | Reproducibility from both hashes | A two-year-old Event-Log record with `commit_sha` + `config_hash` | The exact control-plane definitions *and* the exact resolved config that ran are both recoverable | §11 |
| 17 | Config-change audit | An admin edits a tenant's rate limit | The Audit gate records the change (who, when, old/new value); the write path cannot bypass it | §11 |
| 18 | Air-gap resolution with no egress | A fully offline deployment resolves its config graph at boot and on every tenant-row edit | No outbound call occurs anywhere in the resolution path | §12 |

---

## 15. Consequences

**Positive**
- One merge/schema mechanism reused across every config domain and shared (schema-from-struct) with the Tool Runtime — not a bespoke config engine bolted on beside it.
- The safety-invariant half of the ADR's name is a concrete, testable comparison rule (MEET on a declared order), not an aspiration — a config layer structurally cannot loosen what a stricter layer above it set.
- The reconciliation in §9 removes a live contradiction between `IMPLEMENTATION_PLAN.md` §A1 and ADR-026 that would otherwise leave two authoritative documents disagreeing about where a prompt lives.
- Reproducibility is complete (control-plane SHA + config hash together), not partial.
- Request-layer safety is redundant by design (allow-list + MEET), consistent with this corpus's general "two independent controls, not one" posture (ADR-026 §10, TOOLING §1.7/§1.9).

**Negative / cost**
- Every new config field's author must make an explicit, judged `merge_policy` choice — a real design burden per field, not a checkbox, and the correctness of the *choice* (not just its presence) is unenforced by any machine (§16.2).
- Tenant/profile config writes route through an admin-RBAC + audit path this ADR specifies but that still needs its own admin UI/API surface built — an operational deliverable, not a free side effect of this decision.
- Gate-provider promotion (§6) requires maintaining a synthetic probe-fixture set per gate, which itself needs upkeep as detector rules evolve — a new maintenance surface.
- The §4 prose-length heuristic is a blunt instrument; it will both over-flag (a long but legitimate description field) and under-flag (a short but still-reviewable instruction) at the margins.

**Neutral**
- Deployment config remains free-standing infra config (files + env vars); this ADR does not mandate that ops teams adopt git-PR governance for it, though nothing prevents an ops team from doing so as their own operational hygiene.

---

## 16. Residual risks (honest, not deferred silently)

1. **Config/definition misclassification is not machine-enforced beyond a length heuristic.** A future field could still be added to a config struct when it should have been authored as an ADR-026 definition, and the §4 prose-length check will miss anything shorter than its threshold that is nonetheless reviewable content (a short but privileged instruction string). The mitigation is the documented checklist in §9's table plus ordinary code review, not a hard gate — unlike ADR-026 §10's PII detector, there is no reliable automatic detector for "this value has content that should be reviewed."
2. **`merge_policy` correctness is a human judgment call, only its *presence* is enforced.** §4/§14 test 6 guarantees a field author must choose `override` or `narrow_only`; nothing guarantees they chose the *right* one. A safety-relevant field mistakenly tagged `override` would silently lose its MEET protection and no test in §14 catches a field that was mis-tagged at authoring time rather than left untagged.
3. **Tenant-config admin write path is a single RBAC gate.** An over-privileged or compromised admin account can widen ceilings across many tenants in one session; audit (§11) makes this discoverable after the fact, not preventable in the moment — the same class of exposure any admin-write surface carries, not something this ADR's mechanism specifically closes.
4. **The atomic-swap-plus-in-flight-pin mechanism is borrowed from ADR-026 but is a distinct implementation for a distinct registry.** Its correctness for *this* subject must be independently proven by the scenario matrix (§14 tests 11–13), not assumed inherited just because ADR-026's version is trusted.
5. **Reproducibility depends on every gate/router decision consistently threading `config_hash` into the Event Log.** A code path that consults the resolved config without recording which hash it read breaks replay fidelity silently — the same class of cross-cutting instrumentation debt as any "every call site must remember to do X" requirement, and one this design names rather than hides.
6. **The synthetic probe-fixture set for gate-provider promotion (§6) is only as good as its own coverage.** A new provider that passes every known fixture but fails on a case the fixture set never anticipated is adopted anyway — probe-based promotion narrows this risk, it does not eliminate it.

---

## 17. Self-score (honest)

**Design ceiling: 9.5 / 10.** Every claim has a concrete mechanism and an acceptance test that exercises the exact property that matters: the merge algorithm is total-order and specified per field class (§5), the safety-invariant half of the name is a testable MEET comparison rather than a slogan (§5.2, tests 3–5), the mandatory gates are a type-system fact rather than a runtime `if` (§6, test 8), hot-reload reuses a mechanism this corpus already trusts and is honest about its own scope limits (restart-only fields, §7.1), and the collision with ADR-026 — a real, unreconciled contradiction between two authoritative documents — is resolved noun-by-noun rather than papered over with a general statement (§9's full table). Request-layer safety is deliberately redundant (§10) rather than resting on a single control.

The missing half-point is honest: misclassification between "config" and "definition" is checked by a blunt heuristic and human review, not a hard gate the way ADR-026 §10 gates PII (residual 1); the correctness of a `merge_policy` choice, not just its presence, is unenforced (residual 2); and the atomic-swap/in-flight-pin mechanism, while proven in ADR-026's subject, is a fresh implementation here whose correctness this design specifies but cannot itself demonstrate until built (residual 4). **Build maturity: 0/10** — no code exists, consistent with every other design-only artifact in this corpus. The ceiling is set so that implementation can only descend from a real 9.5-shaped target, never inflate a lower one.
