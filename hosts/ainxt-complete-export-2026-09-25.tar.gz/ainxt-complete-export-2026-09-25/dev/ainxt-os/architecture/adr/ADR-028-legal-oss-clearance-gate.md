# ADR-028 — Legal / OSS Clearance Gate (Gate #0)

**Status:** Accepted (design). **Date:** 2026-07-18. **Owners:** platform eng + NPCI legal + AppSec.
**Related:** ADR-007 (license), ADR-018 (model weights), ADR-019 (liability), `feedback_legal_first_oss`, `IMPLEMENTATION_PLAN.md` P0.

## Context
The project's #1 rule (`feedback_legal_first_oss`): the code must **never carry a single legal issue when open-sourced**, and legal terms come **before** implementation. A one-off legal review is not enough — legal cleanliness must be **continuously enforced in CI**, because a single tainted dependency, copied identifier, license breach, or leaked NPCI-proprietary path can poison the whole OSS release.

## Decision
Establish **Gate #0 — the Legal/OSS Clearance Gate** as the first P0 deliverable and a **standing CI gate**. **No subsystem may be implemented, and no PR may merge, until it passes.** The gate has two parts: a one-time **clearance checklist** (foundational artifacts must exist) and **automated CI checks** (every PR).

### Part A — One-time clearance checklist (must exist before any subsystem code)
- [ ] License locked (Apache-2.0) — `runtime/LICENSE`, `runtime/NOTICE` (copyright entity set by legal) — ADR-007.
- [ ] OSS file set present — `README`, `SECURITY.md`, `CONTRIBUTING.md` (DCO), `CODE_OF_CONDUCT.md`, `THIRD_PARTY_INVENTORY.yaml`, `THIRD_PARTY_NOTICES.md`, `MODEL_WEIGHTS_REGISTER.md`, `deny.toml`, `docs/architecture/adr/`.
- [ ] Core/enterprise split defined — OSS boundary = `runtime/`; NPCI IP in a separate private repo.
- [ ] Model-weight licensing/origin register reviewed by legal — ADR-018.
- [ ] Liability/indemnity/insurance stance recorded — ADR-019.
- [ ] Trademark strategy for "AiNxt" decided.

### Part B — Automated CI checks (every PR, blocking)
1. **Dependency-license gate** — `cargo deny check` against `deny.toml`: permissive-only; **fail on copyleft / source-available / unknown license**; fail on known RUSTSEC advisories / yanked crates / disallowed sources. Inventory (`THIRD_PARTY_INVENTORY.yaml`) is cross-checked against the lockfile — a dep not in both fails.
2. **DCO check** — every commit has a valid `Signed-off-by`; else block.
3. **Clean-room lint** — a denylist scan for forbidden vendor tokens/identifiers/terminology (e.g., vendor project names, "yolo mode", "doom loop", "tengu", "gboom", copied prompt fingerprints) across code, comments, prompts, and docs; a hit blocks and requires review. New reference material used in a PR must be declared in the PR template.
4. **Core/enterprise boundary check** — CI fails if any file matching the private-plugin path patterns (NPCI PCI/DSS rule packs, AD/RBAC internals, IP-bearing connectors) lands in the OSS tree.
5. **Secret scan** — no secrets/keys/tokens in the OSS tree (gitleaks-class).
6. **License-header check** — required source files carry the Apache-2.0 header per ADR-007 appendix.
7. **NOTICE integrity** — placeholder copyright ("The AiNxt Authors") triggers a *release-blocking* (not merge-blocking) check so it can't reach a public tag.

## Alternatives considered
- **One-time legal review, no CI enforcement** — rejected: legal cleanliness drifts on every dependency/PR; a payments regulator (and any downstream adopter) needs *continuous* provable cleanliness.
- **Allow copyleft with careful segregation** — rejected: raises adoption + compliance risk and complicates the split; shell-out is simpler and safer.
- **CLA instead of DCO** — deferred: DCO is lighter-weight and sufficient; CLA can be added later.

## Consequences
- Slightly higher contribution friction (DCO sign-off, license discipline) — accepted; it is the price of a legally clean OSS release.
- Requires the CI tooling (cargo-deny, DCO bot, clean-room denylist linter, path-guard, secret scanner) to be stood up as part of P0 **before** feature code.
- The gate is **cheap to keep green and expensive to retrofit** — which is exactly why it is Gate #0.

## Acceptance tests
- A PR adding a GPL/unknown-license crate **fails CI**. A PR without `Signed-off-by` **fails**. A PR adding a file on a private-plugin path **fails**. A PR containing a forbidden vendor token **fails**. A release attempt with the placeholder copyright **is blocked**. A clean PR passes all checks.
