# ADR-002 — Tool + MCP Runtime: One Capability Trait, One Name-Keyed Registry

**Status:** Accepted — Design only (no code).
**Decision class:** Foundation-defining. Every side-effecting action anywhere in the runtime — native, MCP-discovered, or (Phase 5) plugin-exposed — dispatches through the mechanism this ADR fixes. Nothing built after this ADR may open a second, weaker dispatch path.
**Deep design / mechanism detail (authoritative for "how"):** `TOOLING_MCP_PLUGINS_ROUTING.md` §0–§3. This ADR is the decision record — Context, Decision, Alternatives, Consequences — and states *what is binding and why*; the referenced document specifies the concrete algorithms, field-level schemas, and 25 acceptance/scenario tests that exercise them. Where the two would ever appear to disagree, the deep design document's mechanism detail governs and this ADR should be corrected to match — this ADR does not fork a second version of the mechanism.
**Closes:** Pass-5 gaps **AB** (tool/capability selection degrades at hundreds-of-tools scale), **AI** (confused-deputy / on-behalf-of authorization), **R + S** (exactly-once + compensation for side-effecting actions), **[2]** (MCP tool-manifest trust / supply-chain).
**Relates to / extends:** ADR-001 (strangler-fig Rust sidecar — the registry is a Rust-native component of it), ADR-003 (Policy/Approval/Compliance seam — the OBO grant check in §1.6 below is an extension of it, not a parallel authz system), ADR-009 (prompt-injection defense — paired with the egress-DLP half of the exfiltration chain, `TOOLING §1.7`), ADR-012 (data-class → model routing — a distinct decision, but the same "exclude before rank" pattern this ADR's registry dispatch does not itself implement), ADR-013 (Action Idempotency & Transactionality — this ADR's Side-Effect Ledger, §1.2, is the concrete runtime mechanism that ADR-013 requires to exist), ADR-016 (Agent-Payment-Initiation Boundary — reads `effect_class` from this ADR's capability manifest as the type-system home of its non-overridable denial; see `AGENT_IDENTITY_AND_PAYMENT_BOUNDARY.md` §67 row 1), ADR-024 (microVM sandbox — every sandboxed exec is dispatched as a `SideEffecting`, `risk_tier`-bearing capability through this registry, never a side channel), ADR-026 (Control-Plane Git-Native — the plugin lifecycle in §3.3–§3.4 of the deep design is git-native per that ADR; MCP server manifests are pinned the same TOFU way ADR-026 §11 pins marketplace dependencies).
**Supersedes:** any capability dispatch that previously branched on origin (a hypothetical "native tools go through function X, MCP tools go through function Y" split). No such split may exist after this ADR; the registry is name-keyed and origin-blind by construction (§1 below).

---

## 1. Context

### 1.1 The problem this ADR exists to prevent
An agentic runtime accumulates capabilities from at least three sources over its life: capabilities the platform team writes natively, capabilities a connected MCP server exposes, and (from Phase 5) capabilities a third-party WASM plugin exposes. The default failure mode — observed across the vendor studies this program read for reference (codex, grok-build, opencode, aider, OpenHands, kimi-cli) and independently reasoned about here — is that these three sources accrete **separate dispatch paths**, each retrofitted with its own (partial, inconsistent) approval check, its own (often absent) retry-safety story, and its own idempotency behavior, because each source was bolted on at a different point in the codebase's history. The result is a platform where "is this action authorized, exactly-once, and audited?" has a different, unauditable answer depending on *where the tool happened to come from* — which is precisely the wrong axis to vary on for a PCI/DSS-scoped payment-switch platform, where the answer must be **the same regardless of origin, provably.**

A second, compounding problem is scale: once a runtime is connected to more than a handful of MCP servers, the naive approach — dump every discovered tool's schema into every prompt — measurably degrades the model's tool-choice accuracy and burns context budget (gap **AB**). A registry design that solves the dispatch-safety problem but not the selection-at-scale problem is only half of what "Tool + MCP Runtime" has to mean.

A third problem is trust: an MCP server's tool manifest is untrusted network input that steers what the model believes it can do. A design that merges a remote manifest into the planner's candidate set without a trust mechanism has built an unreviewed injection surface directly into tool selection (gap **[2]**).

### 1.2 Why this must be one decision, not three
Native tools, MCP tools, and plugin tools are not three different problems needing three different registries — they are the **same problem** (accept a described capability, decide if this call is authorized, dispatch it exactly-once, record what happened) with three different **origins** for the capability's *description*. Treating them as three registries means every future safety property (a new idempotency rule, a new OBO check, a new locking discipline) has to be implemented three times, audited three times, and can silently drift out of sync three ways. Treating them as one registry with three *adapters* means every safety property is implemented once and applies uniformly, permanently, to every future capability source — including sources that don't exist yet.

---

## 2. Decision

**One `Capability` trait. One name-keyed `CapabilityRegistry`. Native, MCP-discovered, and plugin-exposed capabilities are three *adapters* into the same registry, and the dispatcher does not know or care which adapter produced any given entry.**

- **Schema-from-struct, not hand-maintained JSON.** Every capability's arguments are one typed Rust struct that derives both the deserializer used to parse the model's tool-call JSON and the schema generator that produces the model-facing JSON Schema. Schema and parser compile from the same source and cannot drift apart. (`TOOLING §1.1`)
- **The manifest, not developer discipline, is what the runtime enforces against.** Every capability declares `effect_class` (`Pure | Idempotent | SideEffecting`), `resource_key` (for locking), `idempotency_key` (mandatory if `SideEffecting`), an optional `compensate` (for saga participation), and `risk_tier` (`Low | Elevated | HighRisk`, drives approval + two-phase-commit requirement). Registration is **rejected** for a `SideEffecting` capability with no idempotency-key function — this is a load-time gate, not a code-review reminder. (`TOOLING §1.1`)
- **Every side-effecting call is exactly-once, enforced by a Side-Effect Ledger, not by the capability author.** A Postgres-backed ledger, keyed by a hash over the *semantic* request (`{user, capability, resource_key, args}` — never wall-clock time or a nonce), claims a slot before dispatch; a retry that hits an existing `COMMITTED` row returns the stored result without re-invoking the capability; a `PENDING` collision blocks briefly on the in-flight call rather than racing it. This is the concrete mechanism ADR-013 requires to exist. (`TOOLING §1.2`)
- **Multi-step side effects are sagas with honest partial failure.** A composite action is an ordered list of ledger-tracked steps, each with its own `compensate` if declared; a non-compensable step that fails after prior steps committed is reported as `FAILED_PARTIAL` with an incident note — never silently claimed as a clean rollback. (`TOOLING §1.3`)
- **`HighRisk` actions require a two-phase commit.** `dry_run` returns a preview and computes the idempotency key with no side effect; `commit` requires the exact key from a prior `dry_run` within a TTL. The dispatcher rejects a `commit` with no matching prior `dry_run` — an agent cannot skip the preview step for the actions that most need one. (`TOOLING §1.4`)
- **Per-resource locking covers the concurrent axis the ledger doesn't.** Calls sharing a `resource_key` serialize; calls on disjoint resources run fully in parallel; locks are held only for the dispatch-and-claim window, never across a slow external call. (`TOOLING §1.5`)
- **Every dispatch carries an OBO (on-behalf-of) context, never the agent's own ambient identity, threaded through sub-agent delegation.** The Policy Engine (ADR-003) evaluates three independent layers that must all pass — declared grant, issued connector scope, resource-level ABAC — before any call proceeds. A missing grant is a hard, structured denial; the runtime never substitutes a broader ambient credential to "help" a call succeed. This is the structural fix for confused-deputy (gap **AI**). (`TOOLING §1.6`)
- **Any capability whose effect crosses the security boundary routes its outbound payload through the Compliance Gate before the network call fires** — the exfiltration half of the injection/exfiltration attack chain, closing the loop ADR-009 alone cannot. (`TOOLING §1.7`)
- **MCP servers are an adapter, not a special case.** Lazy, parallel, per-server connection at turn start with independent failure isolation; per-`(user_id, server_url)` OAuth decoupled from model-provider auth; two-phase discovery (manifest fetch once per connection, cheap per-turn planning); retrieval-based top-K tool ranking (with an always-visible core set and a `capability.search()` escape valve) as the concrete answer to gap **AB**. (`TOOLING §2.1–2.4`)
- **MCP manifest trust is TOFU-pinned, not implicitly trusted.** On first connection, the runtime computes a content hash over the full normalized manifest and pins it, with explicit human approval. Every reconnect re-hashes and diffs against the pin; any diff — an added tool, a changed schema, even a reworded description (a model-facing injection vector) — freezes the changed/added tools out of planning until a human re-approves the exact diff. Every server's tools register under a per-server namespace that cannot collide with native capabilities or another server's tools. This is the concrete fix for gap **[2]**. (`TOOLING §2.5`)
- **Plugins (Phase 5) extend the same registry, inside an additional inner boundary.** A plugin registers capabilities into the identical `CapabilityRegistry`, so approval, idempotency, OBO authz, locking, and egress DLP already apply without plugin-specific work; the WASI sandbox (no ambient host access, every host capability an explicit declared import) is an additional boundary, not a substitute for the outer one. The plugin lifecycle is git-native per ADR-026. (`TOOLING §3`)

```
Capability sources                 Dispatch (identical path for all)
──────────────────                 ──────────────────────────────────
native Rust fn        ──┐
MCP server tool        ──┼─▶ CapabilityRegistry ─▶ Policy(OBO+grant) ─▶ Idempotency Ledger
WASM plugin export     ──┘        (name-keyed)      check              (dedupe/commit)
                                                        │                    │
                                                        ▼                    ▼
                                              Resource Lock            Egress DLP (if
                                              (per resource_key)        effect crosses
                                                        │               the boundary)
                                                        ▼
                                                  Execute + record
                                                  side-effect receipt
```

**Non-negotiable corollary:** no future capability source (a fourth adapter, an internal microservice-as-tool bridge, anything) may bypass this dispatch path. If a new source cannot be expressed as an adapter into this registry, that is a defect in the proposal, not a justification for a parallel path.

---

## 3. Alternatives considered

### 3.1 Separate dispatch paths per origin (native / MCP / plugin each with its own approval + idempotency code)
Rejected. This is the status quo failure mode named in §1.1: three code paths mean three places a safety property can be implemented inconsistently or forgotten entirely on one path when it's added to another. It also means the OBO/idempotency/locking guarantees this ADR makes cannot be stated as platform-wide invariants — they would be per-origin claims requiring per-origin proof, which does not hold up under audit for a payments platform.

### 3.2 Hand-maintained JSON Schema per tool, decoupled from the handler's argument type
Rejected. This is the single most common source of "the model sent valid-looking JSON that the handler rejects" bugs across the vendor studies reviewed for this program — the schema and the parser are two artifacts a developer must remember to keep in sync, and they drift. Deriving both from one struct makes that class of bug structurally impossible rather than a code-review checklist item.

### 3.3 Idempotency as a per-capability convention ("just check if it already ran")
Rejected. Idempotency-by-convention means every capability author re-derives the same tricky exactly-once logic, with predictably inconsistent quality, and — critically — it gives the payment-critical guarantee ("an agent that retries 'initiate settlement' must never execute twice") no single place where it is provably enforced. A runtime-owned ledger with a load-time gate ("no idempotency key, no registration as `SideEffecting`") makes the guarantee structural, verifiable once, and impossible to skip per-capability.

### 3.4 Trust an MCP server's manifest implicitly on every connection (no pinning)
Rejected outright as the design that reopens gap **[2]**: a server that changes its tool set between connections — or names a tool to shadow/impersonate a native one — would silently steer the planner without any human ever reviewing the change. TOFU pinning with reconnect-diff re-approval and per-server namespacing (§2 above) is the minimum bar for treating a remote manifest as the untrusted network input it actually is.

### 3.5 Skip retrieval-based ranking; expose the full tool list every turn and let the model figure it out
Rejected on the evidence gap **AB** names directly: measured tool-choice degradation and token burn at hundreds-of-tools scale is not a hypothetical, it is the documented failure mode this decision exists to avoid. An always-visible core set plus a `capability.search()` escape valve exists specifically so ranking-at-scale never becomes "the tool exists but the model was never shown it and has no way to find it."

### 3.6 Defer the Side-Effect Ledger to Phase 5 (ship native tools first, add exactly-once later)
Rejected. Retrofitting exactly-once semantics onto an already-shipped dispatch path used by real callers is strictly harder and riskier than building the ledger into the registry's foundation from the first capability that registers — and "native tools shipped without it" is exactly the kind of origin-dependent safety gap §1.1 names as the problem to prevent. The ledger is P0, not a follow-on.

---

## 4. Acceptance / scenario tests (representative subset — full 25-test matrix in `TOOLING_MCP_PLUGINS_ROUTING.md` §5)

| # | Scenario | Expected | Proves |
|---|---|---|---|
| 1 | Agent retries a `SideEffecting` "create MR" call after a lost ack | Exactly one MR exists; retry returns the ledger's `COMMITTED` result without re-invoking the capability | Idempotency ledger is a runtime guarantee, not author discipline |
| 4 | User with no grant on `connector.postgres.query` for `ledger_accounts` asks the agent (which holds a broader service credential) to query it | Call denied with a structured OBO failure; the agent's own broader credential is never substituted | Confused-deputy prevention is structural (gap AI) |
| 9 | 5 MCP servers in scope, 1 unreachable at turn start | Turn proceeds with the other 4's capabilities; no turn-wide stall | Per-server connection isolation — one dead server never blocks the rest |
| 11 | Registry holds 400+ capabilities; a common task is asked | Top-K retrieval surfaces the correct capability; the always-visible core set is present regardless of ranking | Retrieval-based selection at scale (gap AB) |
| 20 | A pinned MCP server adds a tool and rewords an existing description on reconnect | Changed/added tools frozen out of planning; structured re-approval prompt shows the exact diff; unchanged pinned tools keep working | TOFU pin + reconnect-diff re-approval (gap [2]) |
| 21 | An MCP server registers a tool named `bash` | The native capability is unaffected; resolution is namespace-qualified; the remote tool cannot capture calls meant for the real one | Per-server namespace isolation (gap [2]) |

The full matrix (25 tests, including saga partial failure, scoped grant boundaries, sub-agent OBO inheritance, plugin sandbox escape/resource-exhaustion, supply-chain tamper, detector DoS hardening, and lost-ack reconciliation) lives in `TOOLING_MCP_PLUGINS_ROUTING.md` §5 and is authoritative; this table is a representative excerpt for this ADR's own review, not a duplicate source.

---

## 5. Consequences

**Positive**
- Every safety property (approval, idempotency, locking, OBO, egress DLP) is implemented and audited **once**, at the registry, and applies to every capability regardless of origin — including capability sources that don't exist yet.
- Schema-from-struct eliminates an entire bug class ("model sent valid JSON the handler rejects") by construction rather than by test coverage.
- The exactly-once guarantee is provable at the ledger, not asserted per-capability — the single property a payments-adjacent platform most needs to be able to state under audit.
- Tool-choice quality at scale (gap AB) and MCP supply-chain trust (gap [2]) are solved by mechanism, not by hoping the model handles hundreds of tools gracefully or that a remote server stays honest.
- Native, MCP, and (Phase 5) plugin capabilities are permanently interchangeable from the dispatcher's point of view — adding a fourth capability source later is an adapter, not a re-architecture.

**Negative / cost**
- The ledger, per-resource locking, and OBO threading are load-bearing infrastructure that must exist correctly before the *first* `SideEffecting` capability ships — there is no "add safety later" path without violating §3.6's rejected alternative.
- TOFU pinning and reconnect-diff re-approval put a human in the loop on every MCP server's tool-set change — correct, but a real operational tax on MCP-server-heavy deployments, and its own residual (a reviewer who rubber-stamps every diff) is named honestly in the deep design, not hidden.
- Retrieval-based ranking is itself a small model that can regress like any retrieval system and needs its own eval set — this is new operational surface, not free.

**Neutral**
- The plugin adapter (Phase 5) is fully specified now but not yet load-bearing until the WASM/WASI runtime ships; native and MCP adapters carry the full weight of this ADR from Phase 1.

---

## 6. Residual risks (honest, not deferred silently)

Restated from `TOOLING_MCP_PLUGINS_ROUTING.md` §6 because they are binding on this decision, not optional caveats:

1. **Idempotency-key derivation is only as strong as it being truly semantic.** A poorly chosen key (one that includes a timestamp, for instance) silently reopens the exact double-execution hole the ledger exists to close. This is an implementation-discipline risk this ADR cannot itself close by design alone — it requires a lint/review rule when Phase 1 code lands.
2. **TOFU manifest re-approval still routes through a human.** A reviewer who rubber-stamps every reconnect diff reopens the hole the pin exists to close; the mechanism bounds the *opportunity* for silent tool-set mutation, not the diligence of the approver.
3. **Retrieval-based tool ranking (§2.4 of the deep design) is a model in miniature and can regress like any retrieval system** — it needs its own eval set and its own regression gate, not an assumption that semantic similarity is always right for tool selection.
4. **The reconciler for lost acknowledgements (`TOOLING §1.8`) is only as strong as the downstream `reconcile` probes it calls.** A capability with no probe degrades to human manual-reconciliation, whose throughput — not the code — becomes the bound on how fast an ambiguous settlement-adjacent row is resolved.
5. **WASM/WASI plugin isolation is Phase 5.** Until it ships, "programmatic custom capabilities" have no sandbox to land in — scope creep into native code before the sandbox ships is the one path that would defeat the plugin half of this ADR entirely, and must be refused as a shortcut when the pressure to ship a plugin early inevitably arrives.

---

## 7. Self-score (honest)

**Design ceiling: 9.5 / 10.** The core claim — one trait, one registry, three origin-blind adapters — is not a slogan here; it is backed by a concrete dispatch pipeline (schema-from-struct, ledger, locks, OBO, egress DLP) where every stage has a load-time or run-time enforcement mechanism, not a convention, and the deep design document backs every mechanism with a scenario test that exercises exactly the property claimed. The three hardest gaps in this space — confused-deputy authorization (AI), tool-choice degradation at scale (AB), and MCP manifest supply-chain trust ([2]) — each have a named, testable mechanism rather than a principle statement, which is the bar this program holds every ADR to.

The missing half-point is honest and matches the deep design's own accounting: idempotency-key derivation, TOFU re-approval diligence, and ranking-quality drift are all mechanisms this design specifies correctly but whose *ongoing correctness* depends on implementation discipline and human diligence this ADR cannot itself guarantee by structure alone (§6). **Build maturity: 0/10** — no code exists, consistent with every other artifact in this corpus. The ceiling is set so implementation can only descend from a real 10-shaped target, and the residuals are named, not hidden.
