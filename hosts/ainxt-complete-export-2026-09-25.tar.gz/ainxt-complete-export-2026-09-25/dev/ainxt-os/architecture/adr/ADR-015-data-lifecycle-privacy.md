# ADR-015 — Data Lifecycle: Retention, Erasure & Privacy (DPDP)

**Status:** Accepted — Design only (no code). Closes `IMPLEMENTATION_PLAN.md` §Phase 0 gap **[Q] data lifecycle** and Pass-5 gap **[13]** statutory-retention-vs-erasure + legal-hold override (`GAP_ANALYSIS_PASS5.md`). This is the canonical decision record for retention, right-to-erasure, and PII-minimized persistence across the whole runtime — the standalone ADR file the master index (`adr/README.md`) has carried as "to be written" since the Q2 control-plane split made it load-bearing.
**Decision class:** Architecture-defining, cross-cutting. Fixes the retention-class taxonomy, the one universal erasure cascade every durable store must implement, the deterministic legal-hold/statutory-retention precedence function that gates it, the write-path PII-minimization principle that dissolves the retention-vs-erasure conflict before it starts, and the governed user-facing memory-consent surface. Every other document that touches "can we keep this / must we delete this / who can see it" defers to this ADR for the decision and implements it for its own store.
**Relates to / extends:** ADR-003 (Policy/Approval/Compliance seam — the same detector set that gates model I/O is reused here as the write-path sink-guard), ADR-007 (execution Event Log / tamper-evident hash-chain — every retention/erasure/hold decision is a signed entry on it), ADR-012 (data-class → model routing — the data-class dimension the retention-class taxonomy is keyed on), ADR-016 (agent-payment boundary — a settlement-adjacent record is a categorically stricter retention/hold class), ADR-017 (Regulated-FI Compliance Ops — the CERT-In/RBI/PMLA statutory floors this ADR's precedence function reconciles against DPDP), ADR-019 (Liability/Indemnity chain — a loss-allocation instance is exactly the kind of PII-bearing, legal-hold-critical data-plane record this ADR governs), ADR-020/ADR-021 (Serving-Ops / Hardware-Trust — the GPU-residue purge hook this ADR's cascade must reach into live inference memory, not only Postgres), ADR-025 (evidentiary admissibility — an erasure/retention/hold decision must itself be admissible evidence), ADR-026 (Control-Plane Git-Native — the reason this ADR's *policy* lives in git and its *instances* never do), ADR-027 (Long-Horizon Programs — a cross-system remediation when PII slips a floor runs as a Program, not a script).
**Companion / authoritative-for-mechanism docs (this ADR does not duplicate their detail):** `ENTERPRISE_MEMORY_LEARNING.md` §3 (the four memory tiers this cascade must reach), §5 (the per-tier retention table and the consent/view/edit/delete/export surface — authoritative for memory-specific UX), §7 (lineage/forensic-replay of what memory a turn saw); `REGULATED_FI_COMPLIANCE_OPS.md` §1.3 (the four-sink redaction regime), §5 (the PCI write-path CHD sink-guard + store-sweep — authoritative for the CHD-specific mechanism), §6 (the legal-hold precedence function and its acceptance tests — authoritative for legal-hold mechanics, which this ADR elevates to a general-purpose decision applying beyond PCI/CERT-In to every regulated retention floor); `SERVING_OPS.md` §6/§8.4 (the GPU-residue purge hook registered into this cascade — authoritative for live-inference-memory erasure).

**One line:** DPDP's right-to-erasure, RBI/PMLA's statutory retention floors, and litigation legal-hold are three obligations that structurally collide unless a system decides — once, deterministically, and provably — which one wins for a given record at a given moment; this ADR is that decision (a control-plane retention taxonomy, one erasure cascade reaching every store including live GPU memory and fine-tune lineage, a legal-hold-first precedence function, write-path PII-minimization that makes "retain the log" and "erase the person" stop competing, and a first-class user memory-consent surface), reconciled end-to-end with ADR-026's control-plane-is-PII-free / data-plane-is-erasable split.

---

## 1. Context — why "the DB is erasable" is necessary but not sufficient

Every other document in this corpus that touches personal data has, correctly, treated "erasure is possible because it's a Postgres row" as good enough to defer the actual design to later. It is not good enough, for three independent, structural reasons this ADR exists to resolve:

### 1.1 A user's data is never in one store

A single user's footprint in AiNxt spans, at minimum: **Redis** (session working memory), **Postgres** (episodic run records, `MemoryFact` semantic-memory rows, connector OAuth tokens, DSAR/incident/legal-hold ledger rows), the **Knowledge Graph** (`MemoryFact`/OKI nodes and edges, `ENTERPRISE_MEMORY_LEARNING.md` §2–§3), **pgvector** (embeddings derived from anything the user wrote or that was written about them), an **optional fine-tune corpus** (if any of their curated feedback or approved org-knowledge was used to train an in-house adapter), the **Event Log** (ADR-007's append-only, hash-chained execution record — including traces, tool-call arguments, and model I/O), and — the store every DB-centric design misses — **live GPU inference memory** (KV-cache pages, prompt-prefix cache, coarse-answer cache resident on a Serving-Ops node, `SERVING_OPS.md` §6). "Delete the user row" touches one of seven-plus stores. A right-to-erasure design that isn't explicit about *all seven* isn't a design; it's a promise with a blind spot, and DPDP does not grade on the stores you remembered.

### 1.2 Erasure, retention, and legal-hold are not three independent features — they are one function with three inputs that can disagree on the same record

- **DPDP** gives a data principal the right to have their personal data erased on request (subject to legitimate-use exceptions).
- **RBI/PMLA/CERT-In** impose *statutory minimum retention floors* — some records (payment-adjacent transaction context, CERT-In's 180-day security-log floor, PMLA's multi-year AML-relevant retention) **must** be kept for a fixed duration regardless of what the person wants.
- **Legal-hold** is a litigation/investigation preservation duty that can require keeping *exactly the record* someone has asked to have erased, for as long as the matter is open — deleting a held record is spoliation, a separate and serious legal exposure.

A naive "forget everything" button that just deletes rows will, on a long enough timeline, either violate DPDP (retaining what must go), violate a statutory floor (erasing what RBI/PMLA requires kept), or commit spoliation (erasing what is under hold). These three obligations are not edge cases to patch around later — they are the *normal* operating condition of a payment-system-adjacent AI platform, and the correct behavior is a **deterministic function**, evaluated before any deletion, not a human remembering to check three systems.

### 1.3 Logs and traces are where PII goes to become impossible to erase without breaking evidentiary retention

The obligation that seems hardest to satisfy simultaneously — "keep the security log 180 days" and "erase this person's PII now" — turns out to be a false conflict *if and only if* the log never held raw PII in the first place. If it does, the two obligations are genuinely incompatible and one of them loses. This ADR's answer is **write-path PII-minimization** (§6): redact/tokenize before the durable write, so the artifact under the retention floor and the artifact subject to erasure are never the same bytes. Get this wrong and every subsequent section of this ADR is fighting an unwinnable battle between two lawful obligations that should never have been forced to collide.

### 1.4 This ADR's relationship to the docs that already describe pieces of this

`ENTERPRISE_MEMORY_LEARNING.md` §5 and `REGULATED_FI_COMPLIANCE_OPS.md` §6 already contain real, load-bearing design for the memory-tier cascade and the legal-hold precedence function respectively, written before this standalone ADR existed. **This ADR does not contradict or replace either — it is the canonical decision record they were always implementing, made explicit, generalized beyond their original scope, and given one taxonomy and one precedence function that every store (not only memory, not only PCI-adjacent records) must use.** Where this ADR states a mechanism identically to one of those docs, that doc remains authoritative for that mechanism's implementation detail (per the same "decision record + authoritative mechanism doc" pattern ADR-002/ADR-006/ADR-018 already use); where this ADR generalizes or extends — the taxonomy (§3), the full seven-store cascade (§4), the GPU-residue reach (§4.6), and the consent-surface decision (§7) — this file is authoritative.

---

## 2. Decision

Five commitments, each mechanized, none of which is allowed to be "a policy we'll enforce manually":

1. **A retention-class taxonomy is a control-plane (git) policy table**, keyed on `{data_class, store_tier}` → `{retention_duration | policy}`, reviewed by Legal/DPO CODEOWNERS, versioned, never a mutable DB column any engineer can edit unreviewed (§3).
2. **One universal erasure cascade** — a single job, triggered by DSAR erasure, account offboarding, or TTL expiry — that reaches every one of the seven-plus store classes named in §1.1, including live GPU inference memory and fine-tune lineage, and is **not** reported complete until every store has acked (§4).
3. **A deterministic Retention/Hold precedence function** sits at the head of every cascade run, evaluated per target record, before any deletion: **legal-hold > statutory-retention floor > erase.** No model, and no human in the moment, adjudicates this — it is a policy-table lookup against the record's classification (§5).
4. **Write-path PII-minimization**: every durable sink is fronted by a compliance sink-guard that redacts/tokenizes PAN/PII/secrets **before the bytes land**, so a store under a retention floor is structurally PII-light and erasing a person's PII never requires destroying the (already-minimized) evidentiary record (§6).
5. **A governed, first-class user memory-consent surface** (view / edit / delete / export), not a support ticket, with provenance on every item and RBAC/data-class filtering pre-rank (§7).

All five commitments are reconciled with ADR-026's control-plane/data-plane split as one axis running through the whole design (§8): the *rule* is always a PII-free, versioned git definition; the *instance* — the erasure job run, the legal-hold matter, the DSAR request, the actual data — is always data-plane, erasable-or-held.

---

## 3. Retention-class taxonomy (the control-plane policy table)

The taxonomy is a **versioned git definition** (`policies/data-lifecycle/retention-classes/definition.md`, per ADR-026 §4's directory convention), owned by Legal/DPO CODEOWNERS, keyed on `{data_class × store_tier}`. It is the *single* place "how long do we keep this" is answered — every store's erasure/purge job reads it; no store hardcodes its own retention duration.

| Store tier | Data class(es) it typically holds | Default retention | Basis |
|---|---|---|---|
| Session (Redis) | any | session lifetime | never durable — nothing survives past the live turn unless promoted |
| Episodic run record (Postgres) | internal, confidential, PII (user's own) | 90 days (config) | past 90d, only promoted `MemoryFact`/OKI candidates survive; raw episodic is minimized-and-purged, per `ENTERPRISE_MEMORY_LEARNING.md` §5 |
| Semantic `MemoryFact(user)` | PII (self-scope) | until user deletes, or account offboarding | offboarding = automatic erasure job, never a manual step (§7) |
| Semantic + org-knowledge (OKI) | internal, confidential | indefinite, but versioned + deprecatable | org knowledge is superseded/deprecated through governance, not aged out on a timer |
| Feedback events (raw) | internal, PII (quoted content) | 180 days (config) | curated derivatives (prompts/evals/OKIs) outlive the raw event |
| Vector embeddings (pgvector) | mirrors source record's class | tied to source record | rebuildable; erasable by source — an embedding has no independent retention life |
| Fine-tune corpus + lineage record | internal (curated only — never raw episodic) | corpus: governed/indefinite; **lineage record: never erasable** while the model version it trained is live | the lineage record is what proves what a model *was and wasn't trained on* — erasing the lineage record would defeat the one mechanism that lets a future run exclude a principal's data (§4.5) |
| Event Log / audit trail | PII-minimized at write (§6) | ≥ 180 days floor (CERT-In); no ceiling — append-only, hash-chained | a **floor**, not overridable downward by erasure, because the retained artifact is PII-light by construction |
| Incident / DSAR / legal-hold ledger | PII-bearing (names the principal/matter) | until matter closes + any statutory floor on the incident class | subject to hold itself — a ledger row about an open matter cannot be erased mid-matter |
| Connector OAuth tokens | credential | until disconnect | erased immediately on disconnect; never subject to a retention floor |
| GPU KV-cache / prompt-prefix / coarse-answer cache | mirrors the live turn's class | session/inference lifetime | zeroized on eviction and, additionally, on an erasure event (§4.6) |
| Control-plane git (skills/agents/roles/prompts/workflows/**policies including this table**) | none — structurally PII-free (ADR-026 §10) | never erasable — immutable versioned history | this is the taxonomy's own home: the rule about retention is itself retained forever, because it never contains the thing it governs |

**Design rule that makes this a taxonomy and not a spreadsheet:** every retention value is `config` (a versioned control-plane field), never a compiled-in constant, because DPDP Rules timelines and RBI/PMLA floor durations are externally set and can change — a regulator changing a number is a reviewed config change, never a code change (the same discipline `REGULATED_FI_COMPLIANCE_OPS.md` §2.3 applies to statutory clock budgets, reused here for retention durations).

---

## 4. The universal right-to-erasure cascade

**One job, one trigger set, seven-plus store handlers, one completion contract.**

### 4.1 Triggers
1. **DSAR erasure** — an explicit data-principal request via the §7 consent surface.
2. **Account offboarding** — automatic, not a manual step someone forgets (`ENTERPRISE_MEMORY_LEARNING.md` §5).
3. **TTL expiry** — a retention-class duration (§3) elapsing on a record with no active hold.

### 4.2 The cascade, store by store

For a given target principal (or, for TTL expiry, a given record), the cascade's **first** operation is always the §5 Retention/Hold decision function, evaluated per record. Only records that clear it proceed to the per-store handler below:

| # | Store | Handler | Verified by |
|---|---|---|---|
| 1 | Redis (session) | already ephemeral; any lingering keyed-to-principal entries are deleted immediately | key-scan returns zero |
| 2 | Postgres episodic rows | hard-delete (or tombstone if a `SUPERSEDES` audit chain requires it — `ENTERPRISE_MEMORY_LEARNING.md` §6) | row-count query returns zero live rows |
| 3 | `MemoryFact` / OKI nodes in the Knowledge Graph | node + incident edges removed; any OKI that was *promoted from* the principal's episodic data but is now organizationally load-bearing is **not** deleted outright — it is re-attributed to `provenance: anonymized` (the org-knowledge survives DPDP-safely; the personal link to its origin does not) | graph query for `scope=user:{id}` returns zero |
| 4 | pgvector embeddings derived from the principal's content | deleted; source index **re-indexed** to exclude them (never left as an orphaned vector with no live source row) | re-index diff confirms exclusion |
| 5 | Fine-tune corpus lineage | any lineage record tracing to the principal is **flagged excluded** for every *future* fine-tune run; the corpus entries themselves (if still identifiable to the principal, not already anonymized at curation) are removed from the *next* training set | lineage query shows `excluded: true`; the honest limit (§4.5) is named, not hidden |
| 6 | GPU KV-cache / prompt-prefix / coarse-answer cache (Serving-Ops) | the **GPU-residue purge hook** (`SERVING_OPS.md` §6) deletes all three cache tiers keyed to the principal's partition and explicitly **zeroizes** any currently-resident KV-cache pages before returning them to the free pool | Serving-Ops **acks** the purge — see §4.6 |
| 7 | Event Log / traces | the **row is never bulk-deleted** (append-only, hash-chained, under the CERT-In floor) — because it was PII-minimized at write (§6), there is no PII payload left to erase; the cascade verifies this by a targeted re-scan rather than deleting anything | re-scan of the principal's Event-Log slice returns zero PII hits |
| 8 | Connector OAuth tokens | deleted immediately (independent of the cascade's other timing — a token is always erasable, never held) | token-store lookup returns none |
| 9 | Control-plane git | **no-op by construction** — definitions never contain PII (ADR-026 §10); the cascade does not need to, and must not attempt to, touch git | n/a (nothing to erase) |

### 4.3 Completion contract

The cascade is **not** reported complete until **every** applicable store handler (rows 1–8; row 9 is trivially satisfied) has acked. This is the same discipline `SERVING_OPS.md` §6 states for the GPU tier specifically, generalized here to the whole cascade: **a DB-only sweep is structurally blind to data that only ever lived in GPU memory** (or, for that matter, in a vector index or a fine-tune lineage table it never queried) — "erasure complete" is a conjunction over every store class that could have held the principal's data, not a single Postgres `DELETE` returning success.

### 4.4 The erasure event itself is provable, not just performed

Every cascade run produces one signed, hash-chained Event-Log entry (`ADR-007`): `{principal_id, trigger, t0, per-store outcomes[erased | deferred-legal-hold | deferred-retention-floor], stores_acked[], completed_at}`. An auditor asking "prove this person's data is gone" gets a reproducible answer, not a claim.

### 4.5 The honest limit on fine-tune lineage — named, not hidden

A past fine-tune run is **not retroactively un-trained** by an erasure request — you cannot subtract one person's gradient contribution from an already-trained adapter's weights after the fact. What the lineage record (`ENTERPRISE_MEMORY_LEARNING.md` §7) *does* buy is exactly the two things that are achievable: (a) **proof** of what a specific model version was and was not trained on, for any point in time, and (b) **exclusion from every future training run**. This ADR states the limit explicitly rather than implying erasure reaches backward into already-trained weights — a claim this design cannot make truthfully, and does not make (§13 residual 2).

### 4.6 GPU-residue purge is a first-class cascade participant, not an afterthought

`SERVING_OPS.md` §6/§8.4 registers its purge hook *into* this cascade (not a parallel mechanism) precisely so §4.3's completion contract holds. Confidential computing (ADR-021) gives confidentiality-in-use against the operator/hypervisor; explicit zeroization on erasure (and on ordinary cache eviction) is defense-in-depth against a future software bug in that stack, and — the reason it belongs in *this* ADR and not only in Serving-Ops — it is the one erasure-reaching mechanism that has no equivalent in a database-shaped design at all.

---

## 5. Legal-hold override — the deterministic precedence function

### 5.1 The rule, stated once, applied everywhere

On any erasure trigger, before any per-store handler in §4.2 runs, every target record passes through this function:

1. **Legal-hold (highest precedence).** If the record falls within an **active legal-hold matter's scope**, it is **preserved, not erased.** The erasure is **deferred and recorded**: an auditable "honored to the extent legally permissible; retained under matter #X until release" entry. A "forget everything" request **cannot** delete a held record — legal-hold is explicit, authorized, reason-coded, and never silently swallows an erasure; it produces a legible deferral, never a silent no-op.
2. **Statutory-retention floor.** A record inside a statutory minimum-retention window (the §3 taxonomy's floor durations — RBI/PMLA/CERT-In) is **retained until the floor elapses**, and the erasure request is **queued to fire automatically at floor-expiry** — dropped from neither the record nor the person's request.
3. **Otherwise → erase now** — the §4.2 cascade runs unmodified.

**Precedence is deterministic — no model adjudicates whether to keep regulated data.** A model may *classify* a record (which data class, which incident it relates to); the keep/erase/defer decision is a policy-table function over that classification, exactly the pattern `REGULATED_FI_COMPLIANCE_OPS.md` §2.2 uses for statutory-clock arming: the LLM does the messy natural-language work, a deterministic table makes the load-bearing call, so a sycophantic or confused model can never talk its way into disarming a hold or forcing an erasure it shouldn't.

### 5.2 Where the rule lives vs where the matter lives (the Q2 split, applied at its sharpest point)

- **Control-plane (git):** the retention-policy table (§3) and the legal-hold **scope-rule predicate** — the reviewable, PII-free rule that defines what a matter *covers* (e.g., "all records touching account X between dates D1–D2"). Legal/DPO-owned, CODEOWNERS-reviewed, versioned.
- **Data-plane (Postgres + Event Log):** the legal-hold **matter instances** — matter #X's custodian, date range, and the concrete record-sets it currently holds. A matter *names* a data principal and specific records — it is PII-bearing, and it **must never** live in git (git cannot erase; a matter must be closeable when released). This is the single sharpest edge of ADR-026's split applied to this ADR: **the rule is git; the matter is a store, on purpose, because only a store can be closed.**

### 5.3 Release and deferred-erasure

Releasing a matter (an authorized, reason-coded action, itself a signed Event-Log entry) fires the **deferred-erasure queue** for every now-unheld record — and, in the same pass, for any record whose statutory floor has *also* since elapsed. Nothing is dropped from either queue silently; every fire is the same §4.4 signed cascade-completion entry.

### 5.4 Reconciling "retain the log" with "erase the person" (the false conflict, resolved)

The CERT-In 180-day log floor cannot be overridden by a DPDP erasure — a security log may not be taken below 180 days. This reconciles cleanly, and only, because of §6: **security/audit logs are PII-light at write.** Erasure erases the PII *payload*; retention keeps the redacted *record*. The two obligations stop competing because the retained artifact never held the erasable PII to begin with — this is the mechanism, not a hoped-for outcome, and it is why §6 is not a nice-to-have appended to this ADR but the precondition that makes §5's precedence function resolvable at all for the log/trace tier specifically.

### 5.5 Break-glass, honestly

If a detector miss (§13 residual 1) lands erasable PII inside a record under a floor or a hold, remediation is a **controlled program** — a scoped, authorized redaction of just the PII payload while preserving the record's evidentiary hash-chain (redaction-with-attestation, logged), or, for the impossible case of PII in git, the ADR-026 §10 history-rewrite + credential-rotation incident. Because such a remediation can span systems and time, it runs as a **Long-Horizon Program** (ADR-027) with checkpoints and partial completion, never a one-shot script — the same discipline `REGULATED_FI_COMPLIANCE_OPS.md` §6.5 already specifies, generalized here as this ADR's standing break-glass path for *any* store, not only PCI-adjacent ones.

---

## 6. PII-minimized logging — the write-path mechanism that makes §5.4 possible

### 6.1 The sink-guard

Every durable sink — Event Log, memory (every tier), vector index, trace/observability store, DSAR/incident exports — is fronted by a **write-path sink-guard**: the same deterministic detector set the compliance engine already runs on model input/output (regex + Luhn validation + entropy analysis for PAN/CVV/AADHAAR/ACCOUNT_NUMBER/SECRET/API_KEY/EMAIL/MOBILE/UPI, per `CLAUDE.md`'s compliance-engine blocking-type list) runs **again, on the write path**, and a detected regulated class is **redacted or tokenized to a non-reversible placeholder before the bytes land.** This is a distinct regime from the other three the same detector set already drives (`REGULATED_FI_COMPLIANCE_OPS.md` §1.3): block a control-plane definition at commit-entry (ADR-026 §10), flag-don't-redact generated code (redaction corrupts syntax), redact-and-proceed for user-facing output (`feedback_redact_dont_block.md`) — and now **redact-before-persist** for every durable data-plane sink, so the store is structurally PII-light *by construction*, not by later audit.

### 6.2 Why this is not "block" and not "redact-and-proceed" — a fourth, distinct regime

The user-facing rule (`feedback_redact_dont_block.md`) says compliance must redact and proceed, never block the user — that rule is about the *live turn*, and it is untouched here. The write-path sink-guard operates **after** the turn has already been answered (or in parallel, on the durable-persistence path); it never blocks the user's response, it only decides what durable bytes are allowed to exist. A PAN the user typed is answered normally (redacted-and-proceeded, per the existing rule) **and separately** never lands in the Event Log, memory, or a trace in raw form. The two rules operate on two different surfaces (response vs. durable store) and do not conflict.

### 6.3 Continuous verification, not audit-by-luck

A periodic **store-sweep** re-scans every durable store for any regulated pattern, proving the write-path redaction held rather than merely asserting it. Any hit is treated as a control failure: the offending record is quarantined and remediated (§5.5's break-glass path), and — because a CHD/PII hit in a store is itself evidence the sink-guard was bypassed — it **raises an incident** through the statutory breach engine (`REGULATED_FI_COMPLIANCE_OPS.md` §2), turning "we believe the stores are clean" into "we continuously prove it, and a miss auto-arms a clock."

### 6.4 Retroactive re-redaction

When the detector rules change (a new PAN format, a newly regulated field), a scheduled job re-scans **already-stored** records across every tier and re-redacts — write-path minimization is applied once at write time but re-applied continuously as the definition of "regulated" evolves, so a record written under an older, narrower rule set doesn't sit indefinitely under-protected.

### 6.5 Traces and observability specifically

Trace spans (the `TracePanel.jsx` surface, and any OpenTelemetry-shaped export) are a durable sink like any other and pass through the same sink-guard: tool-call arguments, retrieved-chunk previews, and model I/O previews rendered into a trace are redacted-before-persist identically to the Event Log. A trace is not a "debug-only, doesn't count" exception — it is exactly the kind of high-fan-out, easily-forgotten sink where a raw PAN or token would otherwise leak widest.

---

## 7. Memory consent & user control — a first-class surface, not a support ticket

Every user gets a governed memory surface (API + UI), consistent with and extending `ENTERPRISE_MEMORY_LEARNING.md` §5:

- **View** — every `MemoryFact`/episodic-derived record scoped to them, grouped by tier, with **provenance** (when learned, from which turn, confidence) — no memory item exists without provenance, which is what makes "why does it think that about me" answerable at all.
- **Edit** — correct a fact directly; this creates a **new version**, the old one tombstoned (not silently overwritten), so the user's own edit history is auditable and undoable — the same versioning discipline this ADR applies to every other store.
- **Delete** — remove any individual item, or invoke "forget everything," which triggers the §4 cascade (through the §5 precedence function — a user's own delete request is subject to legal-hold/retention-floor deferral exactly like a DSAR erasure, and is told so, not silently ignored).
- **Export** — a machine-readable dump of everything remembered about them (DPDP data-portability), produced through the same evidentiary-export path other regulated exports use (`REGULATED_FI_COMPLIANCE_OPS.md` §7), so an export carries the same chain-of-custody guarantees a DSAR fulfillment does.

**Consent boundaries on what may be written, not only what may be read:** an explicit `remember` call from user U can only ever write `MemoryFact(scope=user:U)` — there is no code path from "a user said so" directly to org-scope memory; promotion to org scope requires the governed promotion pipeline (`ENTERPRISE_MEMORY_LEARNING.md` §4/§6), never a single user's unilateral say-so. This is a consent boundary as much as a governance one: a user consenting to AiNxt remembering something about *them* has not consented to it becoming an organizational rule everyone else's turns are influenced by.

**RBAC/data-class on every tier:** a `MemoryFact` or episodic record carries `data_class` and `rbac_scope`; reads are filtered **pre-rank** (identical discipline to chunk-level ACL for docs) so a record the requester isn't cleared for is excluded before it can occupy a context slot or leak its existence. A user's own PII-classed facts about themselves are visible to themselves and to admins **only with a logged justification** — break-glass, itself audited.

**Offboarding is automatic, not a manual step someone forgets** — an account-offboarding event is one of the three cascade triggers (§4.1), fired by the identity/HR system integration, never a checklist item a departing engineer's manager has to remember.

---

## 8. Reconciliation with ADR-026 — the split applied to every artifact this ADR introduces

ADR-026 draws one axis: **if an artifact must be reviewed, versioned, rolled back like code, and must never contain PII, and must never be erased — it is a definition, and it lives in git. If an artifact is high-write, per-user, queried by key, and must be erasable on request — it is operational state, and it lives in a store.** This ADR is, in one sense, ADR-026's data-plane half made concrete for the specific case of personal data — and every artifact this ADR introduces classifies cleanly against that axis:

| Artifact this ADR introduces | Plane | Store | Erasable? |
|---|---|---|---|
| Retention-class taxonomy (§3) | Control | git | No — the rule about retention is never itself the thing retained |
| Legal-hold scope-rule predicate (§5.2) | Control | git | No — a PII-free rule ("what a matter covers"), reviewed by Legal/DPO |
| Write-path sink-guard detector config (§6) | Control | git | No |
| A specific legal-hold **matter** (custodian, date range, held record-set) | Data | Postgres + Event Log | Yes, on release — it names a principal, so it must be closeable |
| A DSAR erasure/access/correction/export **request** | Data | Postgres + Event Log | Per its own retention class (§3) once fulfilled |
| An erasure-job **run record** (§4.4) | Data | Event Log | Per §3's Event Log floor — PII-minimized at write, so this is not a contradiction |
| `MemoryFact` / OKI / episodic instances | Data | Postgres + KG | Yes, per §4 |
| Fine-tune lineage record | Data | Postgres | **Never erased** while the trained version is live (§3) — this is the one data-plane artifact whose non-erasability is deliberate, and is the exception that proves the rule is about *principled* placement, not "data-plane always erasable, no exceptions" |
| GPU KV-cache / prompt-prefix / coarse-answer cache entries | Data (ephemeral) | Serving-Ops node memory | Yes, immediately, and additionally on erasure (§4.6) |

**The one subtle line, restated for this ADR specifically (mirroring ADR-026 §3/§10):** `data_class_ceiling: regulated-payment` on a *definition* is authorization-to-operate-on regulated data — a policy label, not data, and it passes ADR-026's pre-receive gate cleanly. A legal-hold matter naming "Account X, records between D1–D2" is not a label — it is a reference to actual regulated instances, and it **fails** that gate correctly, which is exactly why it belongs in the data plane (§5.2) and not, however administratively convenient it might seem, alongside the scope-rule predicate that defines matters *in general*.

**What ADR-026 gets, in return, from this ADR:** ADR-026 §10 states definitions must never contain PII "because git cannot erase" but does not itself specify *how* erasure works for the data that does need to be erasable — this ADR is that specification, and closes ADR-026's own forward reference (its §5, §17 residual 1) with a complete, cross-store mechanism rather than a promise.

---

## 9. Ties to `ENTERPRISE_MEMORY_LEARNING.md` and `REGULATED_FI_COMPLIANCE_OPS.md` — division of authority, stated explicitly

To prevent the exact drift ADR-026's whole design exists to prevent (two documents each thinking they're authoritative for the same mechanism), authority is divided as follows, and this ADR is the reconciling record:

- **This ADR (`adr/ADR-015-...`) is authoritative for:** the retention-class taxonomy (§3) as a cross-store table (not only memory tiers); the seven-plus-store erasure cascade including GPU residue and fine-tune lineage (§4); the general-purpose legal-hold/statutory-floor precedence function (§5), stated once for reuse by *any* regulated retention floor, not only PCI/CERT-In; the write-path PII-minimization principle as a cross-cutting design rule (§6); and the reconciliation with ADR-026 (§8).
- **`ENTERPRISE_MEMORY_LEARNING.md` §3/§5 remains authoritative for:** the four memory tiers' specific schemas, the promotion pipeline, the per-tier retention durations feeding the §3 taxonomy, and the user-facing consent UX's exact interaction design (§7 here restates the decision; that doc owns the interface detail).
- **`REGULATED_FI_COMPLIANCE_OPS.md` §5/§6 remains authoritative for:** the PCI-specific CHD write-path sink-guard's exact detector wiring and store-sweep cadence, and the legal-hold precedence function's original worked examples and acceptance tests (§5 here generalizes the same function; that doc's tests remain valid instances of it, not superseded).
- **`SERVING_OPS.md` §6/§8.4 remains authoritative for:** the GPU-residue purge hook's exact mechanism (cache-tier partitioning, zeroization timing, interaction with confidential computing) — §4.6 here states the decision that it is a first-class cascade participant; that doc owns how the purge itself works.

None of these four documents duplicates another's mechanism detail going forward; each cross-references this ADR for the decision and is read for its own domain's "how."

---

## 10. Alternatives considered

1. **Per-store bespoke erasure jobs, no single cascade.** Rejected — the failure mode is exactly the one that motivates §4.3's completion contract: a store nobody remembered to wire in (historically, GPU memory) silently fails to erase, and there is no single place that can even ask "did every store finish." A unified cascade with an explicit store list and a signed completion record is the only design that can be *audited* for completeness.
2. **Full anonymization instead of deletion, as the universal answer.** Considered for org-knowledge (§4.2 row 3 actually uses it) but rejected as the *universal* mechanism — DPDP's erasure right is not satisfied by "we can no longer easily identify you" when re-identification remains feasible by combining datasets (a real risk with embeddings and fine-tune corpora specifically). Anonymization is used where it is the *correct* answer (surviving org knowledge whose personal attribution is no longer needed) and deletion is used everywhere the personal link itself is the thing DPDP protects.
3. **Crypto-erasure (encrypt-per-principal, discard the key) as the universal erasure mechanism.** Attractive for its instant, computationally-cheap "erasure," but rejected as the *general* answer because it does not fit every store: the Event Log's hash-chain integrity depends on record content, and per-principal envelope encryption of individual chain entries would either break chain verification or require a design as complex as what this ADR already specifies. Crypto-erasure remains a legitimate *tier-specific* technique (e.g., for connector-token-adjacent blobs) but is not adopted as the one mechanism replacing §4's cascade.
4. **No legal-hold override — always honor an erasure request immediately.** Rejected outright: this is spoliation exposure the moment litigation or a regulatory investigation is live, and is not a legally available choice, not merely an unwise one.
5. **Retention as a mutable DB column, set per-record by an engineer or ops script.** Rejected for the same reason ADR-026 rejects a mutable `status:` field on a definition — a retention duration a single actor can silently edit is exactly the "who approved this policy" gap this whole corpus exists to close. Retention durations are a reviewed, versioned control-plane table (§3), read-only from every runtime code path.
6. **A single global retention duration ("keep everything N days"), no per-class taxonomy.** Rejected — the actual obligations range from "erase on request" to "never erase while a model trained on it is live" to "must be kept ≥180 days regardless of request," and collapsing that range into one number either under-retains (violating RBI/PMLA/CERT-In) or over-retains (violating DPDP). The taxonomy exists because the range is real, not because granularity is an aesthetic preference.

---

## 11. Acceptance / scenario tests

| # | Scenario | Setup | Expected | Proves |
|---|---|---|---|---|
| 1 | Write-path redaction | A chat turn contains a Luhn-valid PAN | The PAN is redacted/tokenized before it reaches the Event Log, memory, vector index, or a trace; a post-write scan of all four returns zero raw-PAN hits | §6.1 sink-guard holds at write time |
| 2 | Cascade reaches every tier | A DSAR erasure is filed for a principal with data in Redis, Postgres episodic, KG `MemoryFact`, pgvector, an active fine-tune lineage record, and a resident GPU KV-cache page | All seven-plus stores ack; a post-erasure query across every tier returns zero live records except the (excluded-for-future-training) lineage flag; one signed Event-Log entry records the run | §4.2/§4.3 completeness, not a DB-only sweep |
| 3 | GPU residue purge is load-bearing | An erasure request lands while the principal's KV-cache pages are resident on a Serving-Ops node | All three cache tiers purge; resident pages are explicitly zeroized before returning to the free pool; the cascade does **not** report complete until Serving-Ops acks | §4.6 — the DB-only blind spot is closed |
| 4 | Legal-hold defers, never drops | A "forget everything" request targets records inside an active legal-hold matter | Those records are deferred-with-record, not deleted; a signed deferral event states "honored to the extent legally permissible... retained under matter #X"; the request itself is not silently discarded | §5.1 step 1 — legal-hold highest precedence, legible not silent |
| 5 | Matter release fires the queue | The matter from test 4 is released (authorized, reason-coded) | The deferred-erasure queue fires for the now-unheld records; a follow-up query shows them gone; a signed erasure event exists | §5.3 |
| 6 | Statutory-floor deferral | An erasure request targets a record inside an RBI/PMLA retention floor | The record is retained; the request is queued to fire automatically at floor-expiry, not now; at expiry it fires without a human re-triggering it | §5.1 step 2 |
| 7 | CERT-In floor survives erasure | An erasure request is filed for a principal whose activity appears in a security log inside the 180-day floor | The log entry is **not** deleted (floor is not overridden); a check confirms the log entry held no raw PII to begin with (it was redacted at write) — the principal's PII is confirmed gone even though the log row remains | §5.4 — the false conflict resolved, not ignored |
| 8 | Consent round-trip | A user views, edits, and deletes one `MemoryFact` via the §7 surface | View returns the item with provenance; edit creates a new tombstoned-old version; delete removes it from active retrieval immediately and is logged | §7 |
| 9 | Offboarding is automatic | An account-offboarding event fires from the identity system, with no manual erasure request filed | The full §4 cascade runs unprompted, exactly as a DSAR erasure would | §7 — "not a manual step someone forgets" |
| 10 | Consent-scope boundary on writes | User U issues an explicit `remember` call | Only `MemoryFact(scope=user:U)` is written; no code path promotes it to org scope without the governed pipeline | §7, `ENTERPRISE_MEMORY_LEARNING.md` §4/§6 |
| 11 | Break-glass admin read | An admin reads a user's PII-classed `MemoryFact` without a logged justification | Access is denied; the same read with a justification succeeds and is itself audited | §7 |
| 12 | Retroactive re-redaction | The compliance detector rules are updated to catch a previously-missed pattern | A scheduled sweep re-scans already-stored records across tiers and re-redacts matches on the next pass | §6.4 |
| 13 | Fine-tune future-run exclusion, honestly bounded | A principal requests erasure after a fine-tune run already used their curated data | The lineage record is flagged excluded for the *next* training run; the *already-trained* adapter is not claimed to be retroactively altered — the response states this limit explicitly | §4.5 — the honest limit, verified as stated, not overclaimed |
| 14 | Control-plane never receives an instance | An attempt is made to store a legal-hold matter (naming a principal) as a git-tracked control-plane definition | Rejected by the ADR-026 §10 pre-receive compliance gate — a matter is data-plane only | §8 — the split holds at its sharpest point |
| 15 | Store-sweep catches a bypass | A synthetic PAN is injected directly into a durable store, out-of-band, bypassing the sink-guard | The periodic sweep detects it, quarantines the record, and raises a statutory incident | §6.3 |
| 16 | Cross-tenant isolation | An erasure/consent query scoped to principal A never surfaces or affects principal B's records | Verified by a scoped query returning only A's records | shared with `ENTERPRISE_MEMORY_LEARNING.md` §9, restated here for the cascade specifically |
| 17 | Forensic replay of an erasure decision | Given a two-year-old signed cascade-completion entry | The exact per-store outcome (erased / deferred-hold / deferred-floor) for each record is reconstructable from the Event Log | §4.4, ties ADR-025 |

---

## 12. Consequences

**Positive**
- Retention, erasure, and legal-hold stop being three separately-owned, occasionally-conflicting features and become one deterministic function with a single, auditable precedence — an auditor asking "why does this record still exist" or "prove this person's data is gone" gets a mechanism, not a claim.
- Write-path PII-minimization dissolves the retention-vs-erasure conflict *structurally*, for every current and future statutory floor, rather than requiring a bespoke reconciliation each time a new floor is added.
- The cascade's explicit reach into GPU inference memory and fine-tune lineage closes two blind spots a DB-centric erasure design would never even think to check.
- The taxonomy and the precedence function are both control-plane (git), so a change to a retention duration or a hold scope-rule is reviewed, diffed, versioned, and rolled-back-by-pointer — exactly the governance bar ADR-026 sets for everything definition-shaped.
- One canonical decision record ends the risk of `ENTERPRISE_MEMORY_LEARNING.md` and `REGULATED_FI_COMPLIANCE_OPS.md` drifting into two different erasure mechanisms over time.

**Negative / cost**
- Every new durable store the platform adds (a future cache tier, a new analytics sink) must be explicitly wired into both the §6 sink-guard and the §4 cascade — this is an ongoing engineering discipline, not a one-time build; a store added without that wiring silently reopens the exact blind spot §4.3 exists to close.
- The completion contract (§4.3) makes erasure *slower and more cross-service-coupled* than a single `DELETE` — an erasure isn't "done" until Serving-Ops, the vector re-indexer, and the KG all ack, which is a real latency and reliability surface (§13 residual 5).
- Legal/DPO must own and actively maintain the retention taxonomy and legal-hold scope-rule predicates as reviewed git artifacts — a UX and process obligation on non-engineering functions, inherited from ADR-026.

**Neutral**
- Nothing here weakens or duplicates ADR-003's compliance gate — the write-path sink-guard reuses the same detector set on a different sink, not a second detection stack.

---

## 13. Residual risks (honest, not deferred silently)

1. **Detector recall is the floor under §6 and §5.4.** Write-path PII-minimization, and the false-conflict resolution it enables, both assume the compliance detectors actually catch the PAN/PII on the write path. A miss lands raw PII under a retention floor or a hold, forcing the §5.5 break-glass remediation — real, and not eliminated by this design, only bounded by defense-in-depth (sink-guard + periodic sweep + break-glass Program).
2. **Fine-tune lineage cannot un-train a past model.** §4.5 states this honestly rather than implying otherwise: erasure reaches every store's *data*, and reaches *future* training runs via exclusion flags, but an already-trained adapter is not retroactively altered. This is an external limit of how model training works, not a gap this design could close by trying harder.
3. **Legal-hold scope-predicate correctness is a human/Legal judgment the mechanism enforces faithfully but cannot author correctly.** A too-narrow predicate could let a record that should be held slip through and be erased (spoliation risk); a too-broad one over-retains and creates its own DPDP exposure. The predicate is reviewed and versioned (§5.2), but a wrong predicate is a wrong outcome the mechanism will execute precisely.
4. **Retroactive re-redaction (§6.4) runs on a scheduled cadence, not in real time.** A record written under an older, narrower detector rule set carries residual exposure for the window between the rule change and the next sweep — bounded, not zero.
5. **The completion contract (§4.3) is a cross-service coupling.** "Erasure complete" now depends on Serving-Ops, the KG, and the vector re-indexer all acking; an outage or bug in any one of them can leave an erasure request legitimately stuck in a partially-complete state. The alternative (report "complete" without every ack) would silently reopen the exact blind spot this ADR exists to close, so this coupling is accepted as the correct cost, not an oversight — but it is a real operational surface that needs its own monitoring and alerting once built.
6. **DPDP Rules' exact erasure-response timelines are still settling**, mirrored from `REGULATED_FI_COMPLIANCE_OPS.md` §2's residual — the §3 taxonomy's durations are config precisely so a final Rule text is a re-pin, not a code change, but until the Rules finalize, some values are provisional best-estimates.

---

## 14. Self-score (honest)

**Design ceiling: 9.5 / 10.** Every claim in this decision has a concrete mechanism and an acceptance test that exercises exactly the property that matters: the taxonomy is a versioned control-plane table, not a claim (§3, tests 1/7); the cascade names every store including the two a DB-centric design would miss — GPU residue and fine-tune lineage — and is gated on a signed completion contract rather than a single `DELETE` (§4, tests 2–3, 13); the legal-hold/statutory-floor precedence is a deterministic policy-table function, generalized beyond its original PCI-specific home into a reusable, cross-cutting decision (§5, tests 4–6); the hardest constraint — "retain the log" vs. "erase the person" — is resolved structurally by write-path minimization rather than argued around (§6, §5.4, test 7); the consent surface is complete (view/edit/delete/export) and consent-scoped on writes, not only reads (§7, tests 8–11); and the reconciliation with ADR-026 is stated at its sharpest point (the matter-vs-rule split, §8, test 14) rather than left as a general principle. The division of authority with `ENTERPRISE_MEMORY_LEARNING.md` and `REGULATED_FI_COMPLIANCE_OPS.md` (§9) is explicit, closing the exact "which doc is right" drift risk ADR-026's own governance model exists to prevent elsewhere.

The missing half-point is honest and concentrated in three places this design *specifies* but cannot itself *prove or guarantee*: **detector recall** is the floor under the entire write-path-minimization strategy (residual 1) — the same recurring residual as every compliance-adjacent ADR in this corpus, named here rather than assumed away; the **fine-tune-lineage limit** is a genuine, external constraint on what erasure can mean for a trained model, stated plainly rather than glossed (residual 2); and the **cross-service completion contract** (residual 5) trades erasure latency/coupling for correctness — the right trade, but a real operational surface with no build yet to prove it holds under failure. **Build maturity: 0/10** — no code exists, consistent with every other artifact in this corpus. The ceiling is set so implementation can only descend from a real, go-live-blocker-clearing target.
