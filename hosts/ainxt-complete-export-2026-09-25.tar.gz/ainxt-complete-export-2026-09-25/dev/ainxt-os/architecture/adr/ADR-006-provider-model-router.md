# ADR-006 — Provider Gateway & Model Router: Event-Enum Normalization Seam + Tiered, Compliance-Gated Selection

**Status:** Accepted — Design only (no code). Formalizes into a standalone, citable ADR the design already load-bearing across the corpus: the Provider Gateway's event-enum seam (`AINXT_OS.md` §1 "event-enum streaming", `VENDOR_SYNTHESIS.md` §1.1, `RUNTIME_FEATURE_FLOWS.md` §1 step 6, `PROMPT_ENGINEERING.md` §4/§?) and the Model Router's selection pipeline (`TOOLING_MCP_PLUGINS_ROUTING.md` §4, whose mechanism — candidate-selection ordering, data-class gate, quality scoreboard, failover chains, prompt caching, live circuit-breaker — is incorporated here **verbatim as this ADR's baseline** and extended with the two pieces this ADR adds: (a) the Provider Gateway layer underneath it, and (b) complexity classification + native-JSON/constrained-decoding capability gating inside candidate selection). `TOOLING_MCP_PLUGINS_ROUTING.md` §4 is not deleted or contradicted — every claim in it remains true — but this file is the authoritative ADR-006 record the README index (`adr/README.md`) points to going forward.
**Decision class:** Architecture-defining, P0 foundational. Per `IMPLEMENTATION_PLAN.md` §Phase 0, ADR-006 is one of the six load-bearing ADRs (001–005, 007) that must be frozen before Phase 1 code — every other subsystem that calls a model (Prompt Engine, Agent Loop, SDLC, doc-gen, evals, skill/agent authoring) calls it through this seam. **This is the single narrowest point in the entire runtime through which every LLM call — cloud or self-hosted — must pass; there is no second path to a model.**
**Relates to / extends:** ADR-001 (strangler-fig Rust sidecar — the Provider Gateway + Model Router are Rust-native control-plane/runtime components the sidecar owns), ADR-002 (Tool+MCP Runtime — native tool calls the router requires are dispatched through the one `CapabilityRegistry`; schema-from-struct so the model-facing tool schema and the Rust argument type never drift), ADR-003 (Policy/Approval/Compliance seam — every call this ADR routes is wrapped in Compliance-IN/OUT per the canonical turn pipeline, `RUNTIME_FEATURE_FLOWS.md` §1 steps 3/7d/8; this ADR does not touch that wrapping, it is the thing being wrapped), ADR-004 (config-first, safety-invariant — the model registry, tier table, and failover chains are declarative config; the *gates* are the non-configurable-off invariant), ADR-005 (Protocol — the `ProviderEvent` enum this ADR defines is the model-stream vocabulary the versioned commands/events contract carries end-to-end to the renderer), ADR-009 (prompt-injection defense — data/instruction separation is enforced in the Prompt Engine and Context Fabric, upstream of this ADR; the Provider Gateway is provider-agnostic to that defense, not a second place it is implemented), **ADR-012 (data-class → model-eligibility — the router's non-overridable exclusion gate consulted FIRST, §5)**, **ADR-018 (Model Governance: license + nation-of-origin gates — the router's next two non-overridable exclusions, consulted immediately after ADR-012 and before ranking, §5)**, ADR-013 (idempotency/Side-Effect Ledger — mid-stream provider failover must never cause a tool call to double-fire; §3.4/test 11 relies on it), ADR-020/021 (Serving-Ops / Hardware Root-of-Trust — the self-hosted OSS fleet this router selects among is served there; session-affinity hints and `weight_digest` resolution cross this boundary, §4.5/§4.8), ADR-026 (Control-Plane Git-Native — the model registry, tier table, and failover-chain config are versioned control-plane definitions, not hardcoded Rust match arms, §4.8), ADR-027 (Long-Horizon Programs — a model-registry update that changes a tier's eligible set is authored the same way any control-plane change is, but is not itself a Program; re-validation-on-version-bump for a *specific weight's* governance is ADR-018 §7's Program, referenced not re-specified here).
**Python-platform analog preserved (strangler-fig):** `models/model_router.py` (routing), `models/classifier.py` (complexity classification), `models/hybrid_retriever.py`/`hybrid_search.py` (upstream of this ADR, not in scope), `gateway_claude.py` / `gateway_openai.py` / `gateway_gemini.py` (today's per-provider bespoke gateways), `core/model_registry.py` (tier table + `BLOCKED_MODELS`), `core/prompt_sanitizer.py::sanitize()` (must run before every outbound call — CLAUDE.md: *"Any new gateway must call it"*; this ADR's clean-room Rust analog inherits that invariant structurally, §3.6). CLAUDE.md's binding rule — **"Every model call must go through a gateway. Never call LLM APIs directly."** — is exactly this ADR's thesis, generalized to a typed, event-normalizing Rust seam instead of three parallel Python modules that can independently drift.

---

## 1. Context — two different problems get one seam, and conflating them is the risk

A model-agnostic, multi-cloud-plus-self-hosted runtime has two genuinely different jobs that are easy to smear into one god-module if not separated deliberately:

**(a) Talking to a model at all — the wire-protocol problem.** Anthropic, OpenAI, Google Gemini, and an in-house vLLM-served OSS fleet (Qwen/GLM/Gemma/Kimi, per ADR-018) each have their own auth scheme, request/response JSON shape, streaming event vocabulary, tool-call format, and error taxonomy. `VENDOR_SYNTHESIS.md` §1.1 names the convergent fix, independently rediscovered by three studied vendors: **a provider-neutral typed streaming event enum as the ONLY seam between core and any vendor.** Get this wrong — let any vendor's wire shape leak past the boundary — and every downstream consumer (Agent Loop, Prompt Engine's per-model compilation, the Compliance Gate, the Event Log, every renderer) either grows vendor-conditional branches or silently only works for the first vendor it was tested against. This is a **transport-and-normalization** problem: it does not decide *which* model to call, only *how* to talk to whichever one was chosen.

**(b) Deciding which model to call — the selection problem.** Given a turn's task type, data classification, license/origin constraints on self-hosted weights, live quality signal, cost, latency, and the user's own preference, exactly one candidate (plus an ordered fallback chain) must be chosen **before** any wire call happens. `TOOLING_MCP_PLUGINS_ROUTING.md` §4 already designed this rigorously as "exclude what is not allowed, then rank what remains," and `GAP_ANALYSIS_VS_AI_PLATFORMS.md` names the reason it cannot be a preference-only ranking for NPCI: *"Our design happily routes to Claude/GPT/Gemini in the cloud... For NPCI that may be illegal for sensitive payment/customer data... the Model Router becomes a compliance component."* This is a **policy-and-ranking** problem: it does not know or care how to actually speak to the chosen model.

**Why one ADR, not two.** They compose in one direction only — the Model Router's output (a chosen candidate, plus its ordered failover chain) is the Provider Gateway's input — and every subsystem downstream of model selection (Prompt Engine per-model compilation, the Event Log, the renderer) needs both halves to already agree on one shared vocabulary (the tier table's model identifiers must resolve to something the gateway can actually dial). Splitting them into two ADRs risks exactly the drift this document exists to prevent: a router decision that names a model the gateway has no adapter for, or a gateway adapter added without a corresponding registry/tier entry making it selectable. One ADR, two clearly bounded halves (§3 Provider Gateway, §4 Model Router), one seam.

**What this ADR deliberately does not decide.** The data-class → model-eligibility matrix (which classes may reach which models at all) is ADR-012's content. The OSS-weight license and nation-of-origin exclusion registers are ADR-018's content. This ADR fixes **where those two gates slot into the selection pipeline, that they are non-overridable, and that the router consults them before any ranking or user-preference weighting ever runs** (§5) — it does not re-litigate or duplicate their substantive matrices/registers. This mirrors the exact discipline ADR-026 established for definitions generally: one source of truth per fact, referenced not restated.

---

## 2. Decision

**Split the model-facing surface into two layers, both mandatory, both non-bypassable:**

- **The Provider Gateway** (§3) is the runtime's only wire-protocol boundary. It normalizes every provider's streaming wire format into one shared `ProviderEvent` enum. It ships as **one generic, config-driven implementation covering the entire OpenAI-schema-compatible family** (OpenAI, Azure OpenAI, and — the load-bearing case for NPCI — the in-house vLLM-served OSS fleet, since vLLM exposes an OpenAI-compatible endpoint) — adding a new such provider is a **config change, not a code change**. **Bespoke implementations exist only for providers whose auth or wire shape is incompatible with that schema** (Anthropic, Google Gemini today) — and even a bespoke implementation still emits the same shared enum; nothing downstream of the Provider Gateway ever branches on vendor.
- **The Model Router** (§4) is the runtime's only selection policy. It resolves a turn's task-type + complexity into a policy tier, then runs an ordered exclusion-then-ranking pipeline: policy tier → **ADR-012 data-class gate** → **ADR-018 license gate** → **ADR-018 origin gate** → live quality floor → rank by (quality, cost, latency, cache-warmth) → select, with a pre-filtered ordered failover chain on any transport, quality, or denylist failure. Tool calls are always native structured JSON, never freeform-text parsed. Self-hosted OSS candidates that cannot reliably produce native structured output are made reliable via **constrained/grammar decoding at the serving layer**, not a prompted-JSON hope. Provider-native prompt caching is structural and feeds back into ranking as a cache-warmth signal.
- **Both non-overridable exclusion gates (ADR-012, ADR-018) are consulted by the Model Router before ranking, before failover-chain construction, and before any user-facing model selection is applied** (§5). A user's explicit pick is a preference weight inside the eligible set, never a re-admission of an excluded candidate — the same invariant ADR-012/018 already state, restated here as the seam's binding contract with them.

---

## 3. Provider Gateway — the event-enum normalization seam

### 3.1 Three layers, one shared enum
```
Layer 1 — Raw transport         HTTP/1.1 or HTTP/2 request; response body is SSE
                                 (OpenAI-schema family, Anthropic) or a chunked
                                 streaming RPC (Gemini). One transport client,
                                 shared connection pool, shared timeout/retry
                                 policy — providers never each own their own
                                 HTTP stack.

Layer 2 — Per-provider          Parses that provider's specific chunk shape
           normalization        (SSE `data:` JSON lines / streaming JSON objects)
                                 into the shared enum below. This is the ONLY
                                 layer that knows any vendor's wire format exists.

Layer 3 — Shared ProviderEvent  ContentDelta{text}
           enum (the seam)      ReasoningDelta{text}            (extended-thinking /
                                                                  reasoning-token
                                                                  providers only —
                                                                  absent, never faked,
                                                                  for providers with
                                                                  no such concept)
                                ToolCallStart{id, name}
                                ToolCallArgsDelta{id, partial_json}
                                ToolCallStop{id}
                                Usage{input, output, cache_read, cache_write}
                                Error{taxonomy, retryable: bool, retry_after}
                                Done{stop_reason}
```
Everything above Layer 3 — the Agent Loop, the Prompt Engine's per-model compiled prompt dispatch, the Compliance Gate, the Event Log, every renderer — consumes **only** `ProviderEvent`. This is the concrete mechanism behind `VENDOR_SYNTHESIS.md` §1.1's convergent finding: *"the agent loop never sees a vendor wire format."*

### 3.2 One generic, config-driven implementation for the OpenAI-schema family
A single `OpenAiSchemaAdapter` covers **every** provider whose auth is a bearer/API-key header and whose request/response/streaming shape matches the OpenAI Chat/Responses API family: OpenAI itself, Azure OpenAI (base-URL + deployment-name swap), and — the case that matters most for this platform — **every self-hosted OSS weight served behind vLLM's OpenAI-compatible endpoint** (Qwen, GLM, Gemma, Kimi, and any future in-house fleet member). The adapter is parameterized entirely by config: `{base_url, auth_header_name, auth_secret_ref, model_id_map, extra_headers}`. **Onboarding a new OpenAI-schema-compatible provider — including a new internal vLLM cluster hosting a new OSS family — is a registry config entry, not a line of new Rust.** This is the direct payoff for ADR-012/018's mandate that regulated data have a real in-house-eligible set: the entire self-hosted fleet gets Provider Gateway support for free, with zero bespoke maintenance burden, because it speaks the same schema the generic adapter already covers.

### 3.3 Bespoke implementations — narrowly, and only where the schema genuinely differs
Two providers ship bespoke adapters today, each still emitting the identical `ProviderEvent` enum:
- **Anthropic** — `x-api-key` header (not bearer), the Messages API's `content_block_start/delta/stop` streaming shape, `cache_control` blocks for prompt caching (§4.6), and a distinct tool-use JSON shape.
- **Google Gemini** — API-key-as-query-param-or-header, the `generateContent`/streaming-RPC shape, a distinct function-declaration format, and provider-specific safety-setting fields.

**The boundary is enforced, not just documented** (test 3, §7): a provider config entry declares which adapter kind it requires (`schema: openai_compatible | anthropic | gemini`), and attempting to route an incompatible-schema provider through the generic adapter fails config validation at load — there is no code path where a misconfigured provider silently gets the wrong client and produces garbled or half-normalized events.

### 3.4 Streaming, cancellation, backpressure, and mid-stream failure
- **Shared cancellation token.** Per `VENDOR_SYNTHESIS.md` §1.2, one cancellation token is shared by the provider stream and every concurrent tool future for a turn; cancel (ESC / turn-abort / iteration-cap trip) tears down the wire connection and any in-flight tool calls together, cleanly, with no orphaned work.
- **Backpressure.** The Provider Gateway never buffers an unbounded stream; the bounded per-session inbox (actor-per-session, `VENDOR_SYNTHESIS.md` §1.2) is the only queue, and a slow renderer applies backpressure up through the same channel rather than the gateway growing an unbounded buffer — this is the 2,000-concurrent-session mandate applied to the model-stream path specifically.
- **Mid-stream provider fault — failover, never splice.** If the wire connection drops or the provider emits a terminal `Error{retryable: true}` before the current model-call step completes: **no side-effecting tool call has fired yet** → the router's failover chain (§5) selects the next eligible candidate and the iteration restarts cleanly; the renderer receives an explicit **stream-superseded boundary event** and the partial content already streamed is marked discarded, never silently appended to the fallback model's continuation. Splicing two different models' partial outputs into one answer is rejected as a design (alternative 7, §6) precisely because it can produce an incoherent, half-one-model, half-another answer that is harder to catch than an honest restart. **If a tool call already committed** (its `(action, observation)` pair is already in the Event Log, per `RUNTIME_FEATURE_FLOWS.md` §1 step 7e) before the fault: failover resumes the *next* iteration on the fallback model over the existing history — the committed tool call is never re-invoked (idempotency ledger, ADR-013, makes a retry safe regardless, but the design goal is to avoid even needing that safety net where possible).
- **Reconnect is bounded, not unbounded.** A transient disconnect gets exactly one immediate reconnect attempt if the provider's protocol supports mid-stream resume (rare in practice across the studied providers); any further fault is treated as a candidate-level failure and handed to the failover chain — the gateway never retries silently forever.

### 3.5 Error taxonomy normalization
Every provider's distinct error shape (OpenAI's typed error object, Anthropic's `error.type`, Gemini's RPC status codes, vLLM's HTTP status + body) normalizes at Layer 2 into one shared taxonomy: `RateLimited | AuthFailure | ContextLengthExceeded | ContentFiltered | Timeout | ServerError | InvalidRequest`. The Model Router's circuit breaker (§4.6) and failover logic consult **only** this taxonomy — a rate-limit from Anthropic and a rate-limit from a self-hosted vLLM cluster trip the identical breaker path. This is what keeps circuit-breaker/failover code from growing an if-vendor branch per provider added.

### 3.6 The Prompt Sanitizer seam is structural, not optional
Per the standing platform rule (`core/prompt_sanitizer.py::sanitize()` must run in **all** gateways before every LLM API call), the Provider Gateway's clean-room Rust design makes sanitization a **required stage every adapter passes through before Layer 1 transport** — both the generic OpenAI-schema adapter and every bespoke adapter call the same sanitizer trait object; there is no adapter construction path that skips it. This closes the exact failure mode the standing rule exists to prevent: a new provider added later (bespoke or config-driven) that forgets to sanitize outbound content.

### 3.7 Auth / secret handling
Per-provider credentials are resolved via config-declared secret references (`auth_secret_ref`), never hardcoded, and scoped per-provider — consistent with ADR-004's config-first model and the platform's existing discipline of never mutating process-wide credential state for per-request resolution (the same principle `tools/gitlab_tools.py`'s thread-local token pattern embodies for a different integration). A self-hosted vLLM cluster's internal service token and a cloud provider's API key are both just `auth_secret_ref` values to the generic adapter — it does not need to know which kind of secret it is.

---

## 4. Model Router — tiered, compliance-gated selection

### 4.1 The full candidate-selection pipeline (the ordering is the design)
```
0. classify         = a lightweight complexity classifier (clean-room Rust analog
                       of `models/classifier.py`) scores the turn simple/medium/
                       complex; the harness/Surface Profile's declared policy tier
                       is a FLOOR the classifier's suggestion can raise but never
                       undercut (test 15) — a harness that always requires ≥complex
                       (e.g. SDLC) is never silently downgraded by a misclassified
                       turn.
1. tier_eligible    = {models matching the resolved policy tier} ∩ {models whose
                       registry capability flags satisfy this turn's REQUIRED
                       flags — native_tool_calls, vision, structured_output,
                       extended_thinking} — a model incapable of a task's hard
                       requirement is excluded HERE, never left to fail at
                       generation time (test 7).
2. class_eligible   = tier_eligible ∩ {allowed for this turn's data class}      ← ADR-012, N/O
3. license_eligible = class_eligible ∩ {license permits this use}              ← ADR-018 Gate A, N/O
4. origin_eligible  = license_eligible ∩ {origin-trusted for this path}        ← ADR-018 Gate B, N/O
5. not_regressed    = origin_eligible ∩ {not currently quality-flagged}        — §4.7
6. rank(not_regressed) by (quality_score, -cost, -latency, +cache_warmth);
   user's explicit selection is a PREFERENCE WEIGHT applied here — it can
   reorder step 6's input, never re-admit anything excluded at steps 2–4
7. select top; on failure walk the FAILOVER CHAIN — pre-filtered to steps 2–4
   at construction time, never re-checked ad hoc during failover (§4.6)
```
Steps 2–4 are **identical to the pipeline ADR-018 §3 already specified** for its own two gates layered under ADR-012's — this ADR does not re-derive that ordering, it adopts it as the canonical seam and adds step 0 (complexity classification) ahead of it and steps 1/5/6/7's extensions (capability-flag gating, cache-warmth ranking, failover pre-filter restated for this ADR's ownership) around it.

### 4.2 Complexity classification and the tier table
The task-type → policy tier mapping is the clean-room Rust analog of the existing NPCI policy (`core/model_registry.py`'s tiers: simple/medium-coding/complex/haiku/deep/solution/vision, and the `BLOCKED_MODELS` denylist) — preserved semantically across the strangler-fig migration, not copied as vendor IP (it is NPCI's own operational policy, not a third party's). Per ADR-026, the **tier table, the failover chains, and the model registry are versioned control-plane definitions** (`policies/model-routing/definition.md` et al.), CODEOWNERS-governed, not hardcoded Rust match arms — the same "definitions live in git, never in a code constant" discipline ADR-026 established generally, applied here to routing policy specifically. `BLOCKED_MODELS` survives as the fast coarse denylist beneath the conditional gates, exactly as ADR-018 §9 already composes it.

### 4.3 Native-JSON tool calls
Per `VENDOR_SYNTHESIS.md` §1.1, tool calls are **always** native structured JSON emitted by the provider's own tool-calling mechanism (OpenAI/Azure/vLLM function-calling, Anthropic tool-use, Gemini function-declarations) — never freeform-text parsed out of a content delta. The `ToolCallStart/ArgsDelta/Stop` `ProviderEvent` variants (§3.1) exist specifically so the Agent Loop's tool-dispatch step (`RUNTIME_FEATURE_FLOWS.md` §1 step 7) has one shape to consume regardless of provider. The JSON schema offered to the model for each capability is derived from the **same typed struct** the `CapabilityRegistry` deserializes arguments into (ADR-002's schema-from-struct discipline) — the model-facing contract and the Rust parser cannot drift apart.

### 4.4 Constrained decoding — the reliability mechanism for self-hosted OSS models
Frontier cloud models have strong native structured-output/tool-calling out of the box; self-hosted OSS models vary widely (`PROMPT_ENGINEERING.md` §4). The router treats **structured-output reliability as a routing-relevant capability flag**, not a generation-time hope:
- A model family whose registry entry sets `grammar_constrained: true` has its structured-output calls (tool-call arguments, and any task requiring `structured_output`) attached a JSON-schema/GBNF grammar the serving layer (vLLM/Outlines/lm-format-enforcer) enforces **at the token-sampling level** — the model literally cannot emit a token that violates the schema. This is strictly stronger than "ask nicely and validate after," and is the mechanism `PROMPT_ENGINEERING.md` §4 already names as load-bearing.
- A model family with **neither** native structured output **nor** grammar-constrained serving is excluded from `tier_eligible` (step 1) for any task whose `structured_output` flag is required — it is never silently routed there to fail at generation time, and never left to the weaker prompted-JSON-plus-repair-loop fallback for a *hard* requirement (that fallback remains available for soft/best-effort structured asks elsewhere in the platform, per `PROMPT_ENGINEERING.md` §4, but is not this router's answer to a hard capability requirement).
- This is a **serving-stack dependency** (ties ADR-020): grammar-constrained decoding must actually be enabled on every self-hosted OSS family the router might select for a structured-output-required task, or that family's `grammar_constrained` flag must honestly read `false` — a flag that lies about serving-layer support reopens exactly the reliability gap this mechanism exists to close (named residual, §8).

### 4.5 Prompt caching
Structural, provider-native prompt caching applies to the **stable prefix** of every assembled prompt (persona, behavioral skills, guard prompts, large static context) per the Context Engine's deliberate stable-prefix-first assembly order — leaving only the volatile tail uncached. Cache state feeds back into step 6's ranking: a cache-warm candidate is cheaper/faster than the same model cold, so the router **prefers cache-warm candidates among otherwise-tied options** — sessions are not bounced across models for a marginal gain that then loses cache warmth. For self-hosted models, the analogous mechanism is **session-pinned KV-cache reuse** across turns, coordinated by a router-emitted session-affinity hint to the Serving-Ops disaggregated-prefill/decode layer (ADR-020). Cache invalidation is correctness-critical: a hot-reloaded prompt/skill (ADR-026 §6.2) must invalidate the affected stable prefix's cache key on its **very next** call (test 13).

### 4.6 Failover chains + the live quality circuit-breaker
Each tier declares an ordered fallback chain (e.g., a regulated-data complex tier: in-house-eligible primary → in-house-eligible fallback, zero cloud for that policy). Failover triggers on a normalized transport error (§3.5), an open circuit breaker (per `(provider, model)` pair, half-open probing to recover without a redeploy), a `BLOCKED_MODELS` hit, or a **live quality circuit-breaker** trip (the evaluation platform's judge-score stream dropping past threshold auto-quarantines a `(model, task_type)` route, pages on-call, and freezes the regressed turns into the eval platform as a permanent regression scenario — restated from `TOOLING_MCP_PLUGINS_ROUTING.md` §4.6, unchanged here). **The chain is filtered to steps 2–4's eligible set at construction time, not checked ad hoc during failover** — there is no code path where walking the chain can reach a data-class-excluded, license-prohibited, or origin-untrusted candidate (§5). An exhausted chain fails closed with an honest degraded response, never a silent escalation past step 2–4's boundary.

### 4.7 Quality as a live signal
Beyond the static tier table, the router consults a live per-model, per-task-type quality scoreboard fed by the evaluation platform. A model regressed on evals for a task type is deprioritized at step 5, or removed entirely below a floor — this is what keeps "capability tier" from silently going stale as models are updated upstream, and it is the same signal §4.6's circuit-breaker acts on when the drop is severe enough to demand an immediate pull rather than a ranking deprioritization.

### 4.8 The model registry is a control-plane definition, not a Rust match statement
Every routable model — cloud or self-hosted — has one registry entry: `{id, provider_adapter (§3.2/§3.3), wire_model_string, context_window, price, capability_flags (native_tool_calls, grammar_constrained, vision, extended_thinking, structured_output, prompt_cache_support)}`. Selection at every pipeline step is a **pure config lookup against this registry** — zero vendor-name branching in router logic, matching `VENDOR_SYNTHESIS.md` §1.1's convergent finding. Per ADR-026, the registry — like the tier table and failover chains — is a versioned, CODEOWNERS-reviewed control-plane file, so adding a model, changing its tier, or flipping a capability flag is a reviewable diff with an audit trail, never a runtime override.

---

## 5. Relationship to ADR-012 and ADR-018 — non-overridable, consulted first, by construction

This ADR does not define the data-class matrix (ADR-012) or the license/origin registers (ADR-018). It defines the **seam**, and binds itself to three invariants those two ADRs require and this ADR is the mechanism that must actually hold them:

1. **Ordering.** Steps 2–4 of §4.1 run **before** step 5 (quality) and step 6 (ranking, where user preference enters). A cost/latency/quality-optimal candidate that fails ADR-012 or ADR-018 is never reachable — it is removed from the *set*, not merely ranked low.
2. **Non-overridability.** A user's explicit model selection is a **preference input to step 6 only.** There is no code path — in the Provider Gateway, the Model Router, or any renderer-facing API — that re-admits a candidate excluded at steps 2–4. This is the same restated invariant `TOOLING_MCP_PLUGINS_ROUTING.md` test 16 and `ADR-018` test 14 already assert; this ADR is what makes that assertion mechanically true rather than a policy statement with no enforcement point.
3. **Failover cannot cross the boundary.** §4.6's failover chain is pre-filtered to steps 2–4's eligible set at construction. An exhausted chain fails closed (§4.6) rather than reaching for an excluded candidate — restated from `TOOLING_MCP_PLUGINS_ROUTING.md` test 17 / ADR-018 §6.4, now owned by this ADR's pipeline as the concrete mechanism.

Any future ADR that adds a **new** exclusion gate (a hypothetical ADR-0NN) slots in as another step between §4.1's step 1 and step 5, following this exact discipline — the seam is designed to be extended without renumbering the whole pipeline.

---

## 6. Alternatives considered

1. **A bespoke per-provider client for every provider, no shared enum.** Rejected — vendor wire-format leaks into the Agent Loop and every other downstream consumer, defeating the model-agnostic mandate structurally; N-times the surface to test and maintain; the exact anti-pattern `VENDOR_SYNTHESIS.md` §1.1 names as the thing three independent vendors converged on avoiding.
2. **Use each provider's own official SDK as the transport layer.** Rejected — reintroduces vendor-owned opinions on retry/backoff/timeout into a runtime that needs uniform circuit-breaker and cancellation semantics (§3.4/§4.6) regardless of provider; drags a vendor SDK dependency graph into a clean-room Rust core with its own OSS/IP hygiene requirements (ADR-007). Transport stays in-house behind the shared enum so retry/cancellation/circuit-breaker policy is ours, not three vendors' independently.
3. **Rank first, then filter out ineligible/prohibited candidates afterward.** Rejected — a cost/latency-optimal-but-excluded candidate could win the rank and require a second exclusion check on every call path that consumes the ranked list, which is easy to omit on exactly one path and reopens the ADR-012/018 leak this ADR exists to prevent structurally (§5). Exclusion must run before ranking, not after.
4. **Free-text tool-call extraction (regex/heuristic parsing of prose) as a provider-agnostic fallback.** Rejected per `VENDOR_SYNTHESIS.md` §1.1 — unreliable by construction, and it is the exact workaround constrained decoding (§4.4) exists to make unnecessary even for weaker self-hosted models.
5. **Rely on prompted-JSON-plus-validate-after for self-hosted OSS structured output, skip constrained decoding.** Rejected — this is precisely why self-hosted models "feel dumber" than they are (`PROMPT_ENGINEERING.md` §4); constrained decoding is strictly stronger (token-level enforcement, not post-hoc validation) and is made a first-class routing capability flag here rather than a per-prompt hack.
6. **Fold the ADR-012 data-class matrix and the ADR-018 license/origin registers into this ADR** rather than deferring to their own documents. Rejected per the task brief and for the same reason ADR-026 keeps one source of truth per fact: those matrices/registers carry their own legal-review, CODEOWNERS, and versioning workflows substantial enough to be their own ADRs; this ADR owns the **seam** (where they slot, that they are non-overridable, the ordering), not their **content** — folding them in would create two sources of truth for the same gate the moment either document is updated independently.
7. **Reconnect and splice a broken mid-stream response** rather than treating any provider-side fault as a candidate-level failure. Rejected (§3.4) — risks an incoherent answer stitched from two different models' partial outputs, which is a worse and harder-to-detect failure mode than an honest, explicitly-signaled restart on the failover chain's next candidate.

---

## 7. Acceptance / scenario tests

| # | Scenario | Setup | Expected | Proves |
|---|---|---|---|---|
| 1 | Vendor-agnostic Agent Loop | Swap the underlying provider (mock Anthropic ↔ mock OpenAI-schema ↔ mock Gemini) for an otherwise identical turn | Zero Agent Loop / Prompt Engine / Compliance Gate / Event Log code changes; only Provider Gateway config/adapter differs; the loop only ever observes `ProviderEvent` | The event-enum seam is real, not aspirational (§3.1) |
| 2 | Generic adapter covers the self-hosted fleet | Point the `OpenAiSchemaAdapter` at a self-hosted vLLM endpoint (Qwen) and at cloud OpenAI in the same test run, config-only difference | Identical adapter code path; correct wire calls and correctly normalized events for both | §3.2 — the fleet needs zero bespoke gateway code |
| 3 | Bespoke-adapter boundary is enforced | Config attempts to route Anthropic traffic (`x-api-key` auth, Messages API shape) through the generic OpenAI-schema adapter | Config validation rejects it at load, before any call is attempted | The "bespoke only for incompatible auth/shape" rule is mechanical, not documentation (§3.3) |
| 4 | Error taxonomy normalization | Three providers return their own distinct rate-limit error shapes for the same underlying condition | All three normalize to the shared `RateLimited` variant; the circuit breaker trips identically regardless of provider | §3.5 — one breaker discipline, not N vendor-specific ones |
| 5 | Native tool-call fidelity across providers | A tool call is emitted by each provider family for the same capability | Each roundtrips through the shared enum into the `CapabilityRegistry` dispatcher with byte-identical argument structure; no provider-specific tool-call parser exists anywhere in the Agent Loop | §4.3 — schema-from-struct + native JSON holds uniformly |
| 6 | Constrained-decoding validity | 100 consecutive structured-output calls (tool args, doc-gen payload) on a self-hosted, grammar-constrained model | 100 schema-valid outputs, zero parse failures, regardless of content quality | §4.4 — token-level enforcement is real (shared with `PROMPT_ENGINEERING.md` PE3) |
| 7 | Structured-output capability gating | A task requiring `structured_output: true` is a candidate turn; one registry model has neither `native_tool_calls` nor `grammar_constrained` | That model is excluded at step 1 (`tier_eligible`), never reached generation time to fail there | §4.1 step 1 — hard capability requirements are an exclusion, not a hope |
| 8 | Non-overridable gate ordering | A `regulated-payment`-classified turn; the user explicitly selects a cloud model | `class_eligible` excludes all cloud candidates regardless of the explicit selection (ADR-012); the selection is honored only among the eligible set | §5 — the seam makes ADR-012/018 non-overridability mechanical |
| 9 | Failover cannot cross the gate boundary | The in-house-eligible primary and fallback are both down for a regulated turn | Router fails closed with an honest degraded response; a cloud model is never attempted, even as a last resort | §4.6/§5 — failover chain pre-filtered to steps 2–4 |
| 10 | Mid-stream fault before any tool call commits | Provider connection is killed mid-generation, before any tool call has been dispatched | The next candidate in the failover chain restarts the iteration; the renderer receives an explicit stream-superseded boundary event; no spliced/stitched answer is ever produced | §3.4 — failover-restart, never splice |
| 11 | Mid-stream fault after a tool call commits | Provider connection is killed after a tool call's `(action, observation)` is already in the Event Log | Failover resumes the next iteration on the fallback model over the existing history; the already-committed tool call is never re-invoked | §3.4 + ADR-013 idempotency — no double-execution on failover |
| 12 | Cache-warmth ranking | Two otherwise-tied candidates at step 6; one has a warm session-scoped prompt cache | The router prefers the cache-warm candidate; a cold-but-marginally-cheaper candidate does not win against a warm-but-nominally-pricier one within the configured warmth-preference band | §4.5 — cache state is a real ranking input, not cosmetic |
| 13 | Cache invalidation on prompt change | A harness's system prompt hot-reloads mid-session (a skill is updated, ADR-026 §6.2) | The next call reflects the new stable prefix; no response is served against a stale cached prefix | §4.5 correctness (shared with `TOOLING_MCP_PLUGINS_ROUTING.md` test 19) |
| 14 | New provider by config only | A fourth OpenAI-schema-compatible provider (a new internal vLLM cluster hosting a fifth OSS family) is onboarded | Zero Provider Gateway crate source changes; a config-only PR (registry entry) passes the full scenario matrix | §3.2 — onboarding is a config change, structurally |
| 15 | Classifier cannot undercut a harness policy floor | A harness declares a hard minimum tier (e.g., SDLC ≥ complex); the complexity classifier scores a specific turn as `simple` | The harness-declared floor wins; the model actually selected is still at or above the declared minimum tier | §4.1 step 0 — the classifier can raise a tier, never lower a policy floor |
| 16 | Usage/cost accounting parity | Three providers with different native usage-accounting schemas (including cache-read/cache-write splits) serve turns in sequence | All three normalize into one shared `Usage` struct; per-turn budget/cost attribution (the budget middleware) produces consistent numbers regardless of provider | §3.1 `Usage` variant — one accounting model, not three |

---

## 8. Consequences

**Positive**
- Vendor wire formats never leak past the Provider Gateway — the Agent Loop, Prompt Engine, Compliance Gate, and Event Log are 100% provider-agnostic code, verified by test 1.
- The self-hosted OSS fleet — the mandatory in-house-eligible set ADR-012/018 depend on existing — needs **zero bespoke Provider Gateway code**: it is the same generic adapter, config-pointed at an internal vLLM base-URL. This is a direct, structural payoff for the "compliance-gated model-agnostic" story, not an incidental convenience.
- One error taxonomy and one circuit-breaker discipline cover every provider ever added, present or future.
- Native-JSON tool calls plus constrained decoding close the specific reliability gap that makes self-hosted models "feel dumber" than frontier cloud models — load-bearing for the model-agnostic mandate to be credible on exactly the paths (regulated/payment) where only self-hosted models are eligible at all.
- Onboarding a new OpenAI-schema-compatible provider — including new in-house OSS fleet members — is a reviewable config PR, consistent with ADR-004 (config-first) and ADR-026 (control-plane git-native), not a code change requiring a release.
- Cache-warmth as a ranking signal, tied to the Context Engine's deliberate stable-prefix ordering, is a direct, structural cost/latency win rather than an incidental one.

**Negative / cost**
- The two bespoke adapters (Anthropic, Gemini) must be hand-maintained and re-verified against the shared-enum contract whenever either vendor revises its wire schema (a new prompt-caching block format, a tool-call schema change, a new reasoning/thinking-block format) — a real, recurring maintenance event, not a config change.
- Constrained decoding requires the self-hosted serving layer (ADR-020) to actually support grammar/schema enforcement at the token level for every OSS family the router might select for a structured-output-required task — a serving-stack dependency this ADR assumes rather than provisions.
- Mid-stream failover-restart (rejecting splicing, alternative 7) is an honest UX cost: a user can see a visible "regenerating" moment on a provider hiccup mid-answer, traded deliberately for never risking an incoherent stitched answer.
- The complexity classifier (§4.1 step 0) is itself a fallible signal with the same class of dependency-on-freshness risk the quality scoreboard (§4.7) already carries — it is bounded by the harness-policy floor (test 15) but not eliminated as a source of misrouting within a tier band.

**Neutral**
- `BLOCKED_MODELS` is not removed; it remains the fast, coarse denylist beneath the conditional gates, exactly as ADR-018 §9 already composes it.
- Air-gap / sovereign deployment (ADR-018 §10, ADR-026 §12) requires no special-casing here: an air-gapped profile simply has an empty `tier_eligible` set for any cloud-schema adapter (no route to it exists at all, config-only), while the generic-adapter-served in-house fleet works identically in-zone — the Provider Gateway's design already makes "cloud excluded entirely" and "self-hosted fleet reachable" a config difference, not a code difference.

---

## 9. Residual risks (honest, not deferred silently)

1. **Vendor schema drift on bespoke adapters.** Anthropic/Gemini can change their wire shape (a new content-block type, a new tool-call format) with only their own release notes as warning; the bespoke adapter is only as current as whoever is watching for that. Mitigation: contract tests against each vendor's published schema, re-run on a fixed cadence — but a silent, undocumented vendor change between cadence runs is a real gap.
2. **`grammar_constrained` flag correctness is self-reported by the registry entry, not independently verified per call.** A flag that claims serving-layer grammar enforcement is present when the actual vLLM deployment for that model has it disabled reopens the exact reliability gap §4.4 exists to close, and the router has no independent runtime check that catches this — it trusts the config. Mitigation: this should be an ADR-020 Serving-Ops health-check surface, not assumed here; named as an open dependency, not solved.
3. **Complexity classifier misrouting within a tier band.** The harness-policy floor (test 15) bounds *how far down* a misclassification can route a turn, but a classifier that over-tiers (routes a genuinely simple turn to an expensive complex-tier model) has no symmetric floor — it is a cost inefficiency, not a correctness break, but it is real and unbudgeted here.
4. **Cache-warmth preference band is a tuning constant, not yet sized from production traffic.** §4.5's "prefer warm within a band" rule needs a real threshold; set too wide, it sacrifices genuine cost/quality gains for marginal cache retention; set too narrow, sessions thrash across models and lose the caching benefit entirely. This design specifies the mechanism, not the number.
5. **Mid-stream reconnect support varies by provider and was not verified against real production disconnect-rate telemetry** — §3.4's "one bounded reconnect attempt" is a reasonable default, not a number derived from NPCI's actual network-loss profile, because no production traffic exists yet at design time.

---

## 10. Self-score (honest)

**Design ceiling: 9.5 / 10.** Every clause of the brief has a concrete mechanism: the Provider Gateway is a **named three-layer seam** (§3.1) with the generic-vs-bespoke boundary **enforced at config validation**, not left to convention (§3.3/test 3); the self-hosted fleet's zero-bespoke-code payoff is a **direct, testable consequence** of the generic adapter's parameterization (§3.2/test 2), not an assertion; mid-stream failure handling is **decided explicitly** (failover-restart, never splice) with the harder case (a tool call already committed) reasoned through against the existing idempotency ledger rather than hand-waved (§3.4/tests 10–11); the Model Router's pipeline **adopts, rather than re-derives**, the exact ordering ADR-012/ADR-018 already require, and states the non-overridability invariant as a property of *this* seam's construction, not a restated hope (§5); native-JSON tool calls and constrained decoding are tied to the concrete reliability problem named in `PROMPT_ENGINEERING.md` and made a first-class routing capability flag rather than a per-prompt patch (§4.3–§4.4); and sixteen scenario tests exercise exactly the properties that decide correctness — vendor-agnosticism, the fleet's free-lunch config-only onboarding, gate non-overridability, failover-without-splicing, and cache-warmth as a real ranking input, not a cosmetic one.

The missing half-point is honest and named (§9): the bespoke adapters' correctness floor is *vendor schema stability the platform does not control* (residual 1), the constrained-decoding capability flag's correctness floor is *serving-layer truthfulness this ADR assumes but ADR-020 must actually guarantee* (residual 2), and the cache-warmth and reconnect-window constants are *mechanisms specified without production data to size them* (residuals 4–5) — enforcement surfaces this design specifies faithfully but whose inputs it cannot itself guarantee. **Build maturity: 0 / 10** — no code exists, consistent with every other artifact in this corpus. The ceiling is set so implementation can only descend from a real 10-shaped target.
