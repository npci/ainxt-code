# ADR-023 — Crypto Agility & Post-Quantum Readiness (an algorithm-rotation abstraction for every load-bearing cryptographic operation)

**Status:** Accepted (Pass-5 gap 42 — `GAP_ANALYSIS_PASS5.md` §B: *"all signing/audit-chain primitives lack rotation abstraction; harvest-now-decrypt-later"*). Design only — no code.
**Decision class:** Architecture-defining but deliberately **non-breaking**: it changes *how every caller reaches a cryptographic primitive*, not what any primitive currently is. No existing algorithm choice (Fernet/AES-128, HMAC-SHA256 hash-chaining, HS256/RS256 JWT, TLS 1.3, Ed25519/keyless signing) is replaced by this ADR. What changes is that **none of those choices may ever again be a hardcoded call site** — every one is rehosted behind a versioned indirection this ADR defines, so that changing the algorithm later is a registry entry, not a rewrite.
**Relates to / extends:** ADR-002 / `TOOLING_MCP_PLUGINS_ROUTING.md` §0 (the **one-registry principle** — this ADR is that same discipline applied to cryptographic primitives instead of tools), ADR-003 (Policy/Approval seam — crypto *policy* is authored through the identical git-review path), ADR-007 (execution Event Log / tamper-evident hash-chain — the primary consumer of the per-record algorithm identifier this ADR mandates), ADR-012 (data-class routing — long-retained regulated-payment data is the sharpest harvest-now-decrypt-later exposure), ADR-015 (retention — the multi-year retention floors that make HNDL a live threat, not a hypothetical one), ADR-016 / ADR-022 (`AGENT_IDENTITY_AND_PAYMENT_BOUNDARY.md` §16 already promises this ADR's `key_id` mechanism for AWC/attestation signatures — this ADR is where that promise is discharged), ADR-021 (Hardware-Trust / TEE — attestation-root keys rotate through this same abstraction), ADR-025 (evidentiary admissibility — a BSA §63 certificate signed years ago must remain verifiable after every rotation since), ADR-026 (Control-Plane Git-Native — crypto **policy** — allowed suites, rotation cadence, deprecation calendar — is a control-plane definition; crypto **material** — keys, HSM handles — is data-plane, §10), ADR-027 (Long-Horizon Programs — a Program's Event-Log hash-chain and AWC renewal chain can span a rotation event mid-run and must not break, §9). Companion docs: `TOOLING_MCP_PLUGINS_ROUTING.md` §3.4 (plugin/artifact signing — the first concrete caller of this abstraction), `CODE_REVIEW_PIPELINE.md` §9 (hash-chained pipeline events), `REGULATED_FI_COMPLIANCE_OPS.md` §7 (the BSA §63 admissibility certificate whose signature must outlive several rotations), `SUBSYSTEM_DEEP_DIVES.md` §2 (MultiFernet versioned-key rotation — the existing pattern this ADR generalizes to every other primitive).

---

## 0. Cross-cutting decisions honored (binding)

- **[Q2 — Control-Plane is Git-Native, ADR-026].** Everything in this ADR that is a **decision about crypto** — which algorithm suites are permitted, the rotation cadence per suite class, the deprecation calendar, which record types must use which suite, the PQC-migration phase gates — is a **versioned, reviewed, PII-free file in the git control plane** (`policies/crypto-agility/definition.md`, §7). Everything that is **crypto material** — actual key bytes, HSM/KMS handles, per-key status, wrapped secrets — is **data-plane**, living in an HSM/KMS + a Postgres Key Registry, **never in git, never in code, never hardcoded.** §7 states this split as a table, mirroring ADR-026 §3 exactly.
- **[Q1 — Long-Horizon Programs, ADR-027].** A Program's Event-Log hash-chain and its Runs' AWC-renewal chain can each span **weeks** — long enough to cross a scheduled or emergency key/algorithm rotation mid-flight. §9 states the concrete guarantee: a rotation event is invisible to an in-flight Program's verification path, because every record — old and new — carries its own algorithm identifier (§3) and the verifier is required to support every non-deprecated historical suite, not just the current one.

---

## 1. Context — why "add PQC later" is the wrong shape of plan

Six load-bearing cryptographic surfaces already exist in the platform, each added independently, by different subsystems, at different times, with no shared rotation story:

| # | Surface | Where it lives today | Primitive today | What breaks if the algorithm ever needs to change |
|---|---|---|---|---|
| 1 | Hash-chained audit / Event Log | ADR-007; `CODE_REVIEW_PIPELINE.md` §9; every subsystem's event stream | SHA-256 chaining, one hash function, no per-record tag | Every historical record becomes unverifiable the day the hash function changes, because nothing on a record says *which* function produced it |
| 2 | Artifact / plugin / model signing | `TOOLING_MCP_PLUGINS_ROUTING.md` §3.4 (WASM plugins), `control.lock` tag signatures (ADR-026 §9), OSS model-weight provenance (ADR-018) | keyless/transparency-log-style signing (Sigstore-shaped), Ed25519-class keys | A signature scheme swap invalidates every previously-signed artifact's *verifiability*, not just new signing — auditors lose the ability to re-verify a two-year-old release |
| 3 | Handoff / attestation signatures | `AGENT_IDENTITY_AND_PAYMENT_BOUNDARY.md` §13/§16/§18 (AWC issuance, TEE remote-attestation quotes, producer→approver signed handoffs) | Ed25519-class keys, already `key_id`-versioned in the AWC claim (§16 promises this ADR) | A rotated AIA root or TEE attestation root must not invalidate an already-issued, still-live AWC's *chain of custody* |
| 4 | JWT (human + service auth) | `core/config.py` `JWT_SECRET`, gateway auth middleware | one shared **symmetric** secret (HS256-shaped) | A single shared secret has no `kid`, no per-token algorithm tag, and no rotation path that doesn't invalidate every live session at once |
| 5 | MultiFernet secrets | `store/credential_vault.py`, `routers/profile_router.py`, `core/platform_credentials.py`, connector OAuth tokens (`SUBSYSTEM_DEEP_DIVES.md` §2) | Fernet = AES-128-CBC + HMAC-SHA256, **already versioned** (decrypt-with-any-key, encrypt-with-newest) | Nothing breaks *today* — this is the one surface that already has a rotation story. It is the template this ADR generalizes, and it is itself under-margined for a post-quantum symmetric-strength floor (§8) |
| 6 | Provider TLS | LLM Proxy (`services/llm_proxy/main.py`, web02:9301 Squid in prod) to Anthropic/OpenAI/Gemini/Jira | whatever TLS version/cipher the remote endpoint and the local TLS stack negotiate — **not policy-pinned** | NPCI has no declared, reviewed floor (TLS 1.3-only, approved cipher list) and no visibility into which regulated-data flows are exposed to harvest-now-decrypt-later while a provider hasn't yet turned on a PQC-hybrid key exchange |

**The shared defect is not "the algorithms are weak."** Every current choice (Ed25519, SHA-256, AES-128/256, TLS 1.3, Fernet) is cryptographically sound today. The defect is structural: **every one of the six surfaces calls its primitive directly, with no algorithm identifier traveling with the record it produces, and no registered path to run two algorithms side by side during a transition.** That is precisely what makes a rotation — whether forced by a compromise, a deprecation, or the eventual arrival of a cryptographically relevant quantum computer — an emergency rewrite instead of a config change. Pass-5 gap 42 names this exactly: *"all signing/audit-chain primitives lack rotation abstraction."*

**Why this cannot wait for an actual quantum computer.** The threat that matters *now*, for a payment-switch operator, is **harvest-now-decrypt-later (HNDL)**: an adversary who cannot break today's asymmetric cryptography can still **record today's ciphertext and signed/encrypted traffic and decrypt or forge it once a cryptographically relevant quantum computer exists** — a threat that is retroactive against anything encrypted or signed *today* and retained for years. NPCI's own retention floors make this concrete, not hypothetical: PMLA record-retention, RBI supervisory-record requirements, and DPDP's own multi-year holds (ADR-015) mean **regulated financial and KYC-adjacent data signed or transmitted today is expected to still be sensitive a decade from now** — squarely inside the window most public HNDL risk models treat as exposed. NIST finalized its post-quantum standards in August 2024 (FIPS 203 ML-KEM for key encapsulation, FIPS 204 ML-DSA for signatures, FIPS 205 SLH-DSA as a hash-based signature backstop), and global regulators and standards bodies — India's CERT-In and RBI among the institutions publicly tracking this space — are on a visible trajectory toward expecting crypto-agility and PQC migration planning from regulated financial infrastructure; NPCI has not (as of this design) published a binding PQC mandate, and this ADR does not assert one exists — it builds the abstraction *so that whichever mandate eventually lands is a configuration change, not a re-architecture* (§8, residual 1).

---

## 2. Decision

**Every load-bearing cryptographic operation in the runtime — hash, sign, verify, encrypt, decrypt, and TLS negotiation — is mediated by a single indirection layer, the Crypto Agility Layer (CAL), dispatched by a versioned Suite Identifier, never called against a concrete primitive directly.**

- **One trait, many suites — the same one-registry principle `TOOLING §0` already applies to tools.** A single `CryptoSuite` interface (§4) is implemented once per concrete algorithm family (Ed25519, ML-DSA-65, SHA-256, AES-256-GCM, a hybrid X25519+ML-KEM-768 TLS suite, …) and registered in the **Algorithm & Key Registry (AKR)** under a stable `suite_id`. No caller anywhere in the runtime — the Event Log writer, the AIA issuing an AWC, the control-plane tag verifier, the JWT issuer, the credential vault, the TLS client — ever imports or calls a concrete crypto library function. Every one calls the CAL with a `suite_id`, and the CAL resolves it.
- **Every signed or hashed record carries its algorithm identifier, permanently.** A record is never just `{value, signature}` — it is always `{value, suite_id, key_id, signature}` (§3). This is the mechanical answer to "algorithm identifiers on every signed/hashed record": the identifier travels with the *record*, not with the system's current configuration, so a record produced five suite-rotations ago is still self-describing.
- **Rotation is a Key Registry operation, never a code change.** Introducing a new algorithm, retiring an old one, or rotating a key is: add a row to the AKR (new `suite_id` or new `key_id`), flip the "active for new signing/encryption" pointer, and — after a soak period — mark the old key `retired` (verify-only) or, only on compromise, `revoked` (§6). No call site is touched.
- **The six surfaces of §1 are the first six consumers, not six bespoke solutions.** §5 maps each onto the CAL with its current suite and its PQC-migration path. Nothing about their current cryptographic soundness changes; what changes is that they now go through one door.
- **Crypto policy is git; crypto material is data-plane (Q2, §7).** Which suites are permitted, per record type, and the rotation/deprecation calendar are control-plane definitions. The keys themselves live in an HSM/KMS with wrapped-key metadata in Postgres — the same split ADR-026 §3 already mandates for every other definition-vs-state pair, applied here.

---

## 3. The abstraction, stated as an invariant

> **A record's cryptographic verifiability must never depend on the runtime's *current* algorithm configuration — only on the algorithm identifier the record itself carries, and on that identifier's suite still being in the verifier's supported set.**

This single sentence is what makes rotation non-breaking. It has two halves, and both are enforced structurally, not by convention:

1. **Forward half (new records):** the CAL always signs/hashes/encrypts *new* records with the suite marked `active` in the AKR for that record type — never a caller-chosen algorithm, never a default baked into the caller.
2. **Backward half (old records):** the CAL's verify/decrypt path dispatches on the `suite_id` **embedded in the record**, not on whatever suite is currently active. A verifier that still supports a suite (status `active` or `retired`) can always verify a record that suite produced, regardless of how many rotations have happened since. Only `revoked` suites (compromise, never routine deprecation) are refused (§6).

**Concretely, for a hash chain (the sharpest case, because a chain's integrity depends on *every* prior link):** each Event-Log entry's hash header is `{hash_alg: suite_id, prev_hash, this_hash}`. The chain-linking hash of record *N* is computed **over record N−1's own stated `{hash_alg, this_hash}` pair**, not over a re-derived value — so a chain that started on `hash.sha256.v1` and later introduces `hash.sha3-512.v1` for new records verifies end-to-end: each link is checked with the algorithm *that link declares*, and the chain of custody is unbroken because every verifier in the runtime is required to carry forward support for every non-revoked historical suite (§6). This is the direct mechanism behind CODE_REVIEW_PIPELINE §9's "a regulator reconstructing a settlement-path commit two years later gets a signed, ordered, un-editable trail" — it now holds *even across an algorithm rotation inside that two-year window*, which the current design does not yet guarantee.

---

## 4. Core objects

### 4.1 Suite taxonomy — `suite_id`

A `suite_id` is a stable, versioned, human-legible string, namespaced by crypto *function* so a hash suite can never be mistaken for a signature suite at the call site:

```
sig.ed25519.v1              # current default — artifact/plugin/AWC/handoff signing
sig.ml-dsa-65.v1            # NIST FIPS 204 — PQC signature candidate, Phase 1 (§8)
sig.hybrid-ed25519+mldsa65.v1   # dual-sign transition suite (§6) — both must verify
hash.sha256.v1               # current default — Event Log / pipeline hash-chaining
hash.sha3-512.v1             # wider-margin hash candidate, Phase 1
enc.fernet-aes128.v1         # current MultiFernet default — secrets/connector tokens
enc.aes256-gcm.v1            # PQC-symmetric-margin successor (§8) — Grover-resistant floor
kex.tls13-x25519.v1          # current default — provider egress TLS
kex.tls13-x25519+mlkem768.v1 # NIST FIPS 203 hybrid — PQC-hybrid TLS, Phase 1
jwt.hs256.v1                 # current default — legacy shared-secret JWT (deprecation target, §5)
jwt.eddsa.v1                 # asymmetric, kid-addressed JWT successor, Phase 0 target (§5)
```

Each `suite_id` also carries, in the AKR (not in code), a **PQC-vulnerability tier**, because the two families of primitive are not equally exposed:

- **Asymmetric (signature / key-exchange) suites — HNDL-vulnerable.** Broken retroactively by a sufficiently capable quantum computer running Shor's algorithm; this is the family the PQC roadmap (§8) targets first.
- **Symmetric / hash suites — Grover-margin, not HNDL-vulnerable in the same way.** Grover's algorithm only halves the effective search-space exponent, so AES-256 and SHA-384/SHA-3-512 retain a comfortable post-quantum security margin; AES-128 and SHA-256 do not have the same margin and are the reason Fernet (AES-128) and the current hash-chain default (SHA-256) are flagged as **Phase-1 upgrade targets, not Phase-0 emergencies** (§8).

### 4.2 The `CryptoSuite` interface (design contract, no code)

```
trait CryptoSuite {
    fn suite_id(&self) -> SuiteId;
    fn sign(&self, key: &KeyHandle, msg: &[u8]) -> Signature;          // sig.* suites
    fn verify(&self, key: &KeyHandle, msg: &[u8], sig: &Signature) -> bool;
    fn hash(&self, msg: &[u8]) -> Digest;                              // hash.* suites
    fn encrypt(&self, key: &KeyHandle, pt: &[u8]) -> Ciphertext;       // enc.* suites
    fn decrypt(&self, key: &KeyHandle, ct: &Ciphertext) -> Plaintext;
    fn negotiate_tls(&self, endpoint: &Endpoint) -> TlsSession;        // kex.* suites
}
```

Every one of the six §1 surfaces holds only a `suite_id` (or, for verify/decrypt, reads one off the record) and calls the CAL — `CAL::resolve(suite_id).sign(...)`. **No surface ever imports `ring`, `rustls`, `ed25519-dalek`, or an AES crate directly.** This is not a style preference; it is the enforcement mechanism: a code-review rule (backed by a lint/CI check, mirroring the pre-receive discipline of ADR-026 §10) rejects any diff that imports a concrete crypto primitive outside the CAL's own implementation modules.

### 4.3 Key Registry entry (data-plane, §7)

```
{ key_id, suite_id, status: active | retiring | retired | revoked,
  created_at, activated_at, retired_at,
  material_ref,        # HSM/KMS handle — never raw key bytes in this record
  rotation_policy_ref, # which control-plane policy (§7) governs this key's lifecycle
  predecessor_key_id }  # chain of custody across rotations, for audit (ADR-025)
```

---

## 5. Per-surface application

| Surface | Current suite | AKR-governed rotation | PQC path (§8) |
|---|---|---|---|
| Hash-chained Event Log (ADR-007) | `hash.sha256.v1` | New chain segments may switch `hash_alg` per §3's mixed-algorithm chain rule; no forced migration — SHA-256 is not HNDL-vulnerable | Phase 1 optional upgrade to `hash.sha3-512.v1` for wider margin on newly-opened chains (long-retained regulated logs first) |
| Artifact / plugin / model signing (`TOOLING §3.4`, ADR-026 §9 tags) | `sig.ed25519.v1` | Publisher/release keys rotate on the existing signed-tag cadence; verifiers keep every non-revoked historical `key_id` | Phase 1: dual-sign new releases with `sig.hybrid-ed25519+mldsa65.v1`; Phase 2: PQC-only for new releases; classical verify-only retained for history |
| Handoff / attestation signatures (AWC issuance, TEE quotes, producer→approver handoffs — `AGENT_IDENTITY §13/§16/§18`) | `sig.ed25519.v1`, already `key_id`-tagged in the AWC claim | AIA root and TEE attestation-root rotation exactly as `AGENT_IDENTITY §16` already promises, now backed by this ADR's AKR instead of a bespoke mechanism | Phase 1 hybrid signing for the AIA root first (it is the single standing agent-side secret, §1 of `AGENT_IDENTITY`) — highest blast-radius key gets PQC-readiness first |
| JWT (`core/config.py` `JWT_SECRET`) | `jwt.hs256.v1` — one shared symmetric secret, no `kid` | **Phase-0 change (this ADR), not deferred to §8:** migrate to `jwt.eddsa.v1`, asymmetric, `kid`-addressed, published verify-only JWKS with overlapping validity windows; reject any token whose `alg` is not on the per-verifier allow-list (closes the classic `alg:none` / algorithm-confusion downgrade attack as a side effect of adopting the CAL) | Not HNDL-urgent at typical session TTLs, but re-evaluated in Phase 2 if session/refresh-token retention windows lengthen |
| MultiFernet secrets (`store/credential_vault.py`, connector tokens, `SUBSYSTEM_DEEP_DIVES §2`) | `enc.fernet-aes128.v1`, **already** decrypt-with-any/encrypt-with-newest | Unchanged mechanically — this surface is the existing template the AKR formalizes; its `suite_id`/`key_id` pair is simply now AKR-registered instead of bespoke | Phase 1: new secrets default to `enc.aes256-gcm.v1` (Grover-margin floor); existing Fernet-encrypted rows remain decrypt-with-any until re-encrypted opportunistically on next write (no forced bulk re-encryption) |
| Provider TLS (LLM Proxy → Anthropic/OpenAI/Gemini/Jira, web02:9301 in prod) | Negotiated, **not policy-pinned today** | **Phase-0 change (this ADR):** a control-plane policy (§7) pins a minimum TLS 1.3, an approved cipher/KEX allow-list, and a per-provider record of which endpoints support a PQC-hybrid KEX yet — feeding the exposure register (§8) | Phase 1: enable `kex.tls13-x25519+mlkem768.v1` for any provider/web02-Squid pairing that supports it; providers that don't are logged as a named HNDL exposure, not silently accepted |

---

## 6. Historical verification without breaking rotation

Generalizing the MultiFernet pattern (`SUBSYSTEM_DEEP_DIVES §2`) to every suite in §4.1:

- **Encrypt/sign with the newest active key only.** The AKR exposes exactly one `active` key per `(record_type, suite_family)` at a time — never a caller choice, so there is no way to accidentally sign with a stale key.
- **Decrypt/verify with any non-revoked key.** `active` and `retired` keys are both valid for verification; only `revoked` keys (compromise, not routine aging) are refused. A record's own `key_id` tells the CAL exactly which key to try — there is no trial-and-error across the whole registry.
- **Dual-sign transition suites bridge an algorithm family change.** When moving from a classical to a PQC (or hybrid) signature family (§8 Phase 1), the AKR can mark a `sig.hybrid-*` suite `active` for a defined soak period: new records are signed by **both** the classical and the PQC key, and old verifiers (who don't yet understand the hybrid suite) still find and check the classical signature component while new verifiers check both. No verifier anywhere is ever presented with a record it cannot at least partially validate.
- **Revocation is the only breaking event, and it is rare and audited by design.** Marking a `key_id` `revoked` (compromise) removes it from the verify path — any record that depended solely on that key for its signature becomes unverifiable by that signature alone. This mirrors ADR-026 §10's break-glass: expensive and rare, run as a security incident with sign-off, re-signing/re-attestation as the remediation, never a routine rotation outcome.
- **The mixed-algorithm hash chain (§3) is the load-bearing special case:** because each link's hash is computed over the *previous link's own declared algorithm and value*, a chain never needs every link re-hashed under a new algorithm to remain verifiable — it needs every verifier to keep supporting every non-revoked historical `hash_alg`, which is a registry-support commitment, not a data migration.

---

## 7. Key material lifecycle & the Q2 split (policy in git, material in the data plane)

| Artifact | Plane | Store | Erasable? |
|---|---|---|---|
| Allowed suite list per record type; PQC-migration phase gate; rotation cadence per suite class; deprecation calendar | Control | git (`policies/crypto-agility/definition.md`, ADR-026) | No (versioned, reviewed) |
| Which record types require dual-signing during a transition window | Control | git | No |
| `alg` allow-list per JWT verifier context | Control | git | No |
| Key Registry entries (`key_id`, `suite_id`, `status`, timestamps, `predecessor_key_id`) | Data | Postgres (metadata only) | Rebuildable / retained per §8 |
| Actual key material | Data | HSM/KMS (in-zone for air-gap, per ADR-026 §12) | Rotatable/revocable — raw material never persisted outside the HSM/KMS |
| Signed/hashed record instances (Event-Log entries, AWCs, signatures on artifacts) | Data (append-only) | log store / Event Log | Per ADR-015 + legal-hold — the record is erasable-or-held per the *content* it protects, never per the algorithm that protected it |

**The subtle line, stated once (mirrors ADR-026 §3):** the *rules* about crypto — which algorithms are permitted, when they rotate, when PQC becomes mandatory — are reviewed, PII-free, versioned policy → git. The *keys themselves and their live status* are high-churn, sensitive, rotatable operational secrets → HSM/KMS + a Postgres metadata registry, **never git, never a code constant.** A crypto policy PR is reviewed by the same CODEOWNERS discipline as any other control-plane policy (ADR-026 §8); a key rotation is an operational action against the HSM/KMS, logged to the Event Log, never a diff to review.

---

## 8. Post-quantum readiness roadmap

Phased so that "PQC-ready" is a sequence of reviewable, reversible steps, not a single big-bang cutover — and so the roadmap can absorb whichever external mandate (RBI, CERT-In, or an NPCI-internal policy) eventually lands without a redesign:

| Phase | Trigger | Scope | Exit criterion |
|---|---|---|---|
| **Phase 0 — Abstraction + inventory (this ADR)** | Accepted now | Build the CAL + AKR (§2–§4); migrate JWT to `jwt.eddsa.v1` and pin provider-TLS policy (§5) — the two surfaces with no rotation story at all today; classify every existing signed/hashed record type by PQC-vulnerability tier (§4.1); stand up the **HNDL exposure register** — a control-plane-policy-driven, data-plane-populated list of `{data_class, retention_floor, current_suite, provider/endpoint, PQC-hybrid available: y/n}` | CAL/AKR live; every one of the six §1 surfaces dispatches through it; exposure register populated for every regulated-payment-class flow |
| **Phase 1 — Hybrid pilot** | NIST FIPS 203/204/205 tooling matures in NPCI's approved crypto libraries/HSMs; a non-regulated internal environment is available for soak testing | Dual-sign artifact/plugin releases and the AIA root with `sig.hybrid-ed25519+mldsa65.v1`; enable `kex.tls13-x25519+mlkem768.v1` for any provider/proxy pairing that supports it; migrate MultiFernet defaults to `enc.aes256-gcm.v1` for new secrets | Hybrid suites verified in production for ≥ one full soak period with zero verification regressions; exposure register shows a measurable drop in HNDL-exposed regulated flows |
| **Phase 2 — PQC-default for new records** | Phase 1 soak clean; FIPS-validated PQC modules available in NPCI-approved, India-deployable HSM/KMS hardware (a real procurement dependency, not assumed) | New signatures/records default to the PQC or hybrid suite; classical suites move to `retired` (verify-only) for their record types, never `revoked` (§6) — history stays verifiable | All *new* load-bearing signing/KEX activity is PQC or hybrid; classical suites carry zero new-record traffic |
| **Phase 3 — Regulatory-driven full migration** | An explicit RBI/CERT-In/NPCI-internal PQC mandate with a stated deadline (not asserted to exist today — this phase is the landing pad for one) | Deprecation calendar (a control-plane policy, §7) sets a hard date after which classical-only verification is dropped for record types the mandate covers; any record still needing classical-only verification past that date is re-signed/re-attested under the mandate's transition provisions | Compliance with the specific mandate's deadline, evidenced in the Event Log and the exposure register |

**What makes this a roadmap and not a promise:** every phase transition is gated on an external, checkable fact (library/HSM availability, soak-test results, a published mandate) rather than a calendar date this ADR invents, and every phase's *mechanism* (dual-signing, decrypt/verify-with-any, mixed-algorithm hash chains, §3/§6) is already fully specified and buildable in Phase 0 — later phases turn on AKR entries, not new architecture.

---

## 9. Interaction with Q1 — Long-Horizon Programs

A Program (ADR-027) can run for weeks; its Event-Log hash-chain and its Runs' AWC-renewal chain (`AGENT_IDENTITY §15`) are exactly the kind of long-lived, continuously-verified artifact a mid-flight rotation must not break:

- **Event-Log chain integrity survives a rotation mid-Program**, because §3's mixed-algorithm chain rule makes each link self-describing — a Program that opened its chain under `hash.sha256.v1` and crosses a platform-wide upgrade to `hash.sha3-512.v1` for new links verifies end-to-end without any retroactive rewrite of the Program's own history.
- **AWC renewal survives a rotation mid-Program**, exactly as `AGENT_IDENTITY §16` already specifies: a renewed AWC's `key_id` simply points at whichever key is `active` at renewal time; a still-live AWC signed by a now-`retired` key remains verifiable (§6) until its own short TTL expires — no Program is ever force-terminated by a routine rotation.
- **A rotation is never a soft path to weaken a long-lived Program's guarantees.** The AKR's `revoked` state (the only state that breaks verification) is reserved for compromise, gated by the same `ad_level<=3` + CODEOWNERS authority as any other high-blast-radius control-plane action (ADR-026 §8) — a Program cannot be quietly downgraded to a weaker suite by an unreviewed operational action.

---

## 10. Alternatives considered

1. **Do nothing; add PQC support to each surface independently when forced.** Rejected. This is the status quo Pass-5 flags as the gap: six surfaces, six bespoke rewrites, no shared rotation story, and — critically — no algorithm identifier on historical records, so a forced migration on any one surface either breaks historical verification or requires an expensive after-the-fact tagging project. The cost of the shared abstraction is paid once, now, while nothing is urgent; the cost of not having it is paid later, under a deadline, six times.
2. **Hardcode a single "current best" algorithm per surface and re-review each site by hand at rotation time.** Rejected for the same reason ADR-026 rejected the DB governance state machine: a hand-rolled, per-site rotation is unsigned, un-auditable, single-reviewer, and — worse for crypto specifically — a missed call site is a silent security regression, not a visible functional bug. A registry with a CI-enforced "no direct primitive import" rule makes a missed call site a build failure, not a production surprise.
3. **Go straight to PQC-only for every surface today.** Rejected. NIST's PQC standards are recent (finalized August 2024); FIPS-validated PQC modules in India-deployable, NPCI-approved HSM/KMS hardware are not yet an assumed procurement reality; and several of the six surfaces (JWT sessions, MultiFernet secrets under normal rotation) are not meaningfully HNDL-exposed at their actual retention windows. Migrating everything immediately would spend scarce crypto-engineering effort on the least-exposed surfaces first and introduce operational risk (unvalidated PQC tooling in production) for no corresponding reduction in the actual regulated-data exposure that motivates this ADR.
4. **Treat crypto-agility as purely an ops/runbook concern (rotate keys via a script, no architectural change).** Rejected. Key rotation alone (rotating *material* under a *fixed* algorithm) is necessary but not sufficient — it does nothing for an *algorithm* rotation (the actual PQC transition), and Pass-5 gap 42 names the missing piece as the *rotation abstraction*, not the absence of a key-rotation runbook (several surfaces, e.g. MultiFernet, already rotate keys fine; none can rotate *algorithms* without a rewrite).
5. **A single global "crypto version" flag the whole runtime reads.** Rejected. A single global version cannot express "this Event-Log chain has old-suite links and new-suite links" or "this artifact needs dual-sign but that JWT verifier only needs the new suite" — it collapses exactly the per-record, per-surface granularity §3's invariant depends on. The AKR's per-`(record_type, key_id)` granularity is the minimum granularity that supports mixed-algorithm history without a flag day.

---

## 11. Acceptance / scenario tests

| # | Scenario | Setup | Expected | Proves |
|---|---|---|---|---|
| 1 | No direct primitive import | A diff adds a call to a concrete crypto crate outside the CAL's own implementation modules | CI rejects the diff | The one-registry discipline is enforced, not conventional (§2/§4.2) |
| 2 | Record self-describes its algorithm | Inspect any Event-Log entry, AWC, or signed artifact produced today | It carries an explicit `suite_id`/`key_id`, not an implicit "whatever's current" | §3 forward half |
| 3 | Rotation is config, not code | A key is rotated (new `key_id` marked `active`) for a suite | No caller code changes; new records use the new key automatically | §2/§6 |
| 4 | Verify a record from before the rotation | A record signed under a now-`retired` key is verified after rotation | Verification succeeds via `key_id` dispatch (§6) | Backward half of §3's invariant |
| 5 | Mixed-algorithm hash chain | A chain has links under `hash.sha256.v1` followed by links under a newly-introduced `hash.sha3-512.v1` | The chain verifies end-to-end, each link checked under its own declared algorithm | §3's mixed-algorithm chain mechanism |
| 6 | Revocation breaks only what it must | A `key_id` is marked `revoked` after a compromise | Records depending solely on that key's signature fail verification; records under other keys are unaffected | §6 revocation is scoped, not global |
| 7 | Dual-sign transition | A `sig.hybrid-*` suite is `active` for a soak period | New records carry both classical and PQC signature components; an old verifier checks the classical component and accepts; a new verifier checks both | §6/§8 Phase 1 transition mechanism |
| 8 | JWT algorithm confusion blocked | A crafted token sets `alg: none` or an off-allow-list algorithm | The verifier rejects it — the allow-list is control-plane policy, not caller-trusted token content | §5 JWT migration side-effect |
| 9 | Program survives mid-flight rotation | A Program's Event-Log chain and AWC-renewal chain span a platform-wide key rotation | The Program's chain remains verifiable; in-flight AWC renewals succeed against the new active key; no forced Program termination | §9 (Q1 tie) |
| 10 | Policy in git, material in the vault | Inspect where the allowed-suite list vs. the actual key bytes live | Allowed-suite list + rotation cadence in git (reviewed); key material in HSM/KMS + Postgres metadata only | §7 (Q2 tie) |
| 11 | Exposure register reflects reality | A provider egress path has no PQC-hybrid KEX available | The HNDL exposure register lists that flow's data class, retention floor, and current suite as an open exposure — not silently accepted | §8 Phase 0 |
| 12 | Two-year-later admissibility survives a rotation | A BSA §63 evidentiary export (ADR-025) references a signature made under a since-`retired` key | The export's certificate re-verifies successfully against the retired key via `key_id` dispatch | §6 tie to ADR-025 |

---

## 12. Consequences

**Positive.** Every one of the six existing crypto surfaces gains a rotation story it did not have; the two surfaces with genuinely no story today (JWT, provider TLS) get one immediately (Phase 0) rather than waiting for a PQC deadline; the PQC transition, whenever it becomes mandatory, is a sequence of AKR entries and control-plane policy edits, not a rewrite of six subsystems under deadline pressure; the HNDL exposure register turns "are we exposed?" from a guess into a queryable, auditable list that directly feeds any future RBI/CERT-In quantum-readiness reporting obligation; historical verifiability — the property BSA §63 admissibility and two-year-later audit replay both depend on — is preserved *through* every future rotation, not just up to the next one.

**Negative / cost.** A real HSM/KMS integration and a Postgres Key Registry are new operational surface; the "no direct primitive import" CI rule requires discipline across every subsystem that currently touches crypto directly; dual-signing during Phase-1 transitions doubles signature size and verification cost for the transition window; the roadmap's later phases depend on external facts (FIPS-validated India-deployable PQC hardware, an eventual regulatory mandate) this design cannot itself accelerate.

**Neutral.** No existing algorithm choice is weakened or replaced by this ADR alone — MultiFernet, Ed25519 signing, SHA-256 chaining, and TLS 1.3 all continue exactly as they are; what changes is the door they are called through.

---

## 13. Residual risks (honest, not deferred silently)

1. **No confirmed external PQC mandate exists yet to size Phase 3 against.** The roadmap (§8) is deliberately gated on an external trigger rather than inventing a date; until RBI/CERT-In or an NPCI-internal policy publishes one, Phase 3 has no deadline, and this ADR cannot manufacture regulatory certainty it does not have.
2. **FIPS-validated, India-deployable PQC hardware/HSM support is a procurement dependency, not a design one.** Phase 1/2 cannot proceed faster than that market matures — a real external constraint, named rather than hidden.
3. **The "no direct primitive import" rule is a policy + CI check, not a physical impossibility.** A determined or careless contributor could still add a direct crypto call in a code path CI doesn't cover; this is the same class of enforcement-surface residual ADR-026 names for its own git-native guarantees (§17 residual 2 there) — it must be verified in the build pipeline's own test suite (acceptance test 1), not merely specified here.
4. **Dual-signing transition windows are a real operational cost with no fixed exit date until Phase 2's hardware dependency clears** — an organization under cost pressure may be tempted to skip the soak period; the design specifies the soak (§8) but cannot itself enforce patience.
5. **The HNDL exposure register is only as complete as the inventory that populates it.** A crypto surface this ADR's authors did not know about (a future connector, a new provider integration) starts unregistered until someone adds it — an onboarding checklist item, not a structural guarantee, and named as such.

---

## 14. Self-score (honest)

**Design ceiling: 9.5 / 10.** Every clause of the brief has a concrete mechanism: algorithm identifiers travel on every record by construction (§3), not by convention; rotation-without-breaking-history is a specific, testable dispatch rule (§6) generalized from a pattern already proven in production (MultiFernet, `SUBSYSTEM_DEEP_DIVES §2`); the PQC roadmap is phased against external, checkable triggers rather than invented dates, and is honest that no mandate is asserted to exist yet (§8, residual 1); it is wired into Q2 (policy-in-git/material-in-vault, §7) and Q1 (a Program's multi-week chains survive a mid-flight rotation, §9) exactly as both binding decisions require; and it closes a second, unrequested but structurally adjacent bug (JWT algorithm-confusion/`alg:none`) as a side effect of building the abstraction correctly (§5, test 8).

The missing half-point is honest and concentrated in what no design document can close by itself: **Phase 2/3 of the roadmap depend on external facts** — FIPS-validated India-deployable PQC hardware maturing, and a regulatory mandate actually landing (residuals 1–2) — that this ADR can plan for but not accelerate; and the **"no direct primitive import" enforcement is a policy + CI surface**, not a physical guarantee, which is the same class of honest residual ADR-026 carries for its own git-native invariants (residual 3). **Build maturity: 0/10** — no code exists, consistent with every other artifact in this corpus. The ceiling is set correctly so implementation can only descend from a real 10-shaped target.
