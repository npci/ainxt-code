# ADR-013 — Action Idempotency & Transactionality (exactly-once side effects, honest sagas, in-doubt reconciliation, and correctness under clock skew)

**Status:** Accepted (P0) — Design only (no code).
**Decision class:** Foundation-defining and payment-critical. It fixes the one property a national-switch operator's agent runtime cannot get wrong: **a side effect the runtime causes must happen exactly once with respect to its semantic request** — no double MR, no double email, no double ledger post, and above all **no double debit** — across retries, restarts, process death, lost acknowledgements, network non-determinism, and clock skew across a multi-node fleet.
**Relates to / extends:** ADR-002 (Tool+MCP Runtime — its **Side-Effect Ledger**, `TOOLING §1.2`, is the *primary concrete enforcement site* of this ADR's invariant; this ADR is the general principle that site instantiates, not a second mechanism — where the two would appear to disagree, ADR-002 / `TOOLING_MCP_PLUGINS_ROUTING.md §1.2–1.8` governs the ledger *mechanism* and this ADR is corrected to match), ADR-003 (Policy/Approval/Compliance seam + OBO — the idempotency key is derived from the OBO context, and every ledger transition is an audited decision), ADR-005 (Protocol — the client-minted `command_id` is the *envelope-layer* instance of this invariant; §10), ADR-016 (Agent-Payment-Initiation Boundary — the apex `PaymentInitiating` class sits *atop* this ledger's type system; this ADR governs everything *below* the boundary, ADR-016 governs the one class *above* it; §11), ADR-017 / `REGULATED_FI_COMPLIANCE_OPS.md §8.2` (NIC/NPL NTP + the clock-skew monitor — the *substrate + detector* this ADR's correct-under-skew design makes into defense-in-depth rather than the primary defense; §9), ADR-025 (evidentiary admissibility — a ledger row and its receipt are court-grade execution-audit records), ADR-026 (Control-Plane Git-Native — the downstream-idempotency policy, the semantic-key lint rule, and per-`effect_class` reconciler timeouts are versioned control-plane definitions, not buried constants), ADR-027 (Long-Horizon Programs — a Program's resume re-executing a committed node is deduplicated by this same ledger; §10).
**Closes:** Pass-5 gaps **[21]** (idempotency in-doubt reconciler — lost-ack `PENDING` has no resolution; *downstreams may not accept idempotency keys* → double debit / dropped settlement) and **[32]** (clock skew across the two-runtime fleet — skewed saga/idempotency timers can fire premature compensation = double-execution). Formalizes the standing **R + S** foundations (`IMPLEMENTATION_PLAN.md §Phase 0` — exactly-once + saga/compensation) that ADR-002 made concrete for the tool-dispatch site but that no document had yet stated as a *cross-cutting* runtime contract.
**Supersedes:** nothing. It *names and generalizes* an invariant that ADR-002 enforced at one site and ADR-005 enforced at another, so that no future side-effecting path (a connector webhook, a Program resume, a fourth capability adapter) can be built without inheriting it.

---

## 1. Context — why "exactly-once" is the property most easily faked and most catastrophic to get wrong

An agentic runtime causes side effects on almost every non-trivial turn, and it does so over an inherently unreliable substrate: models retry their own tool calls after a soft error; the agent loop retries after a stuck-detector trip; a network timeout leaves the caller unable to tell whether the downstream *succeeded and the ack was lost* or *never ran*; a worker dies mid-dispatch; a UI double-click and an internal retry race; a redelivered webhook re-enters a pipeline; a resumed Program replays to its last checkpoint. Every one of these is a *duplicate delivery* of the same intent. In a generic productivity tool a duplicate is an annoyance — two identical Slack messages. **In the runtime of India's payment switch, a duplicate side effect on anything settlement-adjacent is a double debit, a double NACH mandate execution, a double dispute credit — a systemic-integrity incident, not a UX blemish.**

The trap is that exactly-once is the property *easiest to appear to have and hardest to actually have.* A capability author can write "check if it already ran, and if so skip" and believe they have idempotency — until the check and the write are not atomic, or the key they dedup on includes a timestamp so no two attempts ever match, or the downstream they retry against has no way to recognize a duplicate. Each of these *looks* like exactly-once in a demo and *is* at-least-once in production. This ADR exists because a payments platform cannot rely on per-author belief for its single most consequential guarantee; the guarantee must be **structural, owned by the runtime, and provable at one place under audit** — and it must be honest about the boundary of what the runtime can promise when the downstream will not cooperate.

**Three facts frame the whole decision:**

1. **Exactly-once is an end-to-end property, not a local one.** The runtime can make *its own dispatch* exactly-once trivially (a ledger, §5). Whether the *effect at the downstream* is exactly-once depends on whether the downstream can recognize a retry — and many of NPCI's real downstreams (a legacy SOAP core-banking API, an SMTP relay, a fire-and-forget queue) cannot. Any design that claims exactly-once without confronting this is claiming a guarantee it does not hold (§6, gap [21]).
2. **"Don't-do-it-twice" and "undo-it-if-the-multi-step-fails" are two different problems.** The first is idempotency (the ledger, §5); the second is transactionality across steps a single lock can't span (sagas + compensation, §7). A design that solves one and calls it done leaves the other as an unowned seam.
3. **Timers are the quiet third failure axis.** Every timeout in this design — how long a `PENDING` waits before it is reconciled, how long a two-phase-commit key stays valid, how long a reconciler holds a row lease — is a *duration*, and a duration compared across nodes with unsynchronized wall-clocks is a latent double-execution: a fast clock declares a still-in-flight call "timed out" and fires premature compensation or a blind retry (gap [32]). Idempotency that is correct in a single process and wrong across a skewed fleet is not correct.

---

## 2. Decision

**Every side effect the runtime causes is governed by one transactionality contract, enforced structurally, at whichever layer the effect originates — with the Side-Effect Ledger (ADR-002) as its primary and canonical enforcement site.** The contract has five binding laws:

1. **Claim before dispatch, exactly-once by construction.** The runtime records an intent-to-act in a durable ledger, keyed by the *semantic* request, **inside the same transaction that reserves the right to proceed, and always before the side-effecting call fires** (§5). A retry that finds a `COMMITTED` claim returns the stored result and **never re-invokes** the capability; a `PENDING` claim is blocked-on, never raced. This is ADR-002's ledger, restated as the law it instantiates.
2. **The idempotency key is *purely semantic* — never wall-clock time, never a random nonce, never a per-attempt identifier.** A key must be identical for two deliveries of the *same intent* and different for two genuinely different intents. A key that embeds anything that varies per attempt silently converts exactly-once into at-least-once and is the single most common way this guarantee is faked; it is therefore a design law with a CI-enforced lint and a per-capability review gate, not a coding suggestion (§4).
3. **Exactly-once is pursued end-to-end, and the runtime is honest where it cannot reach.** Each capability declares its downstream's deduplication capability (`Native | NaturalKey | None`). Where the downstream can dedup, the runtime *passes the same semantic key through* so the effect is exactly-once at the downstream too. Where it cannot, the runtime **does not blind-retry** — it degrades to evidence-based reconciliation or human resolution, because a blind retry against a non-deduplicating settlement downstream *is* the double debit (§6).
4. **Multi-step side effects are sagas with honest partial failure.** A composite action is an ordered list of ledger-tracked steps, each with an optional `compensate`; a non-compensable step that fails after prior steps committed is reported as **`FAILED_PARTIAL`** with an incident note — never a silently-claimed clean rollback (§7).
5. **In-doubt is a first-class state, resolved by evidence and never by a clock.** A claim stuck `PENDING` beyond a bounded, per-`effect_class` timeout is not forgotten and not guessed — a reconciler **probes the downstream's actual state** and resolves the row to `COMMITTED` or `FAILED`, or escalates to `MANUAL_RECONCILIATION` when the truth is unknowable (§8). Every timeout in the design is a *monotonic duration evaluated against a single clock authority*, so clock skew can change *when* the runtime investigates but never *what verdict it reaches* (§9).

**Non-negotiable corollary:** no side-effecting path may exist that does not pass through this contract. A capability dispatch (ADR-002), a protocol command (ADR-005), a connector-triggered pipeline (a GitLab/Jira webhook), and a Program-node resume (ADR-027) are four *origins* of intent, all bound by the one contract — exactly as ADR-002's registry is origin-blind for capabilities. If a new side-effecting path cannot express its intent as a semantic-keyed ledger claim, that is a defect in the path, not a licence for an at-least-once side door.

---

## 3. The invariant, stated once

The axis is not "which tool" or "which subsystem." It is **the relationship between an intent and its effects on the world:**

> **A side effect is exactly-once with respect to its semantic request if, and only if, every duplicate delivery of that request — by retry, restart, race, redelivery, or resume — produces the effect at most one additional time it would have produced with a single delivery, and the caller observes the identical result. Where the runtime cannot guarantee this end-to-end (a non-deduplicating downstream with no way to check its state), it must surface the ambiguity as an in-doubt state for evidence-based resolution — never resolve it by assumption, and never re-attempt blindly.**

Two questions decide everything downstream, and conflating them is the most common way to get this wrong:

| Question | Answer lives in | Failure it prevents |
|---|---|---|
| *Did I already do this?* (single effect) | the **Side-Effect Ledger** keyed by the **semantic** idempotency key (§4–§5) | double-execution on retry/race/restart — the double debit |
| *Did the multi-step whole complete, and if not, what is the honest state?* | the **saga** + `compensate` + **`FAILED_PARTIAL`** (§7) | a false claim of clean rollback for an effect that can't be undone |
| *(the trap between them)* *The call fired but the ack was lost — did it happen?* | the **in-doubt reconciler**, resolved **by probe, never by clock** (§8–§9) | a permanently-ambiguous settlement row, or a blind retry = double debit |

---

## 4. The purely-semantic idempotency key — the law, and why a timestamp reopens the hole

The idempotency key is the load-bearing input to the entire guarantee, and its one required property is **semantic stability**: the same intent must always hash to the same key, and two different intents must never collide.

**Derivation (the canonical rule).** The key is a hash over the *business-meaningful* tuple only:

```
idempotency_key = H( obo_ctx.user_id, capability_id, resource_key, canonical(semantic_args) )
```

where `canonical()` strips every *volatile* field — timestamps, request UUIDs, retry counters, trace/span ids, session nonces, "generated at" markers — and normalizes the *meaningful* fields (ordering-independent, whitespace-normalized, unit-normalized) so that two deliveries of the same intent are byte-identical before hashing. `resource_key` (the file, ticket, ledger account, settlement batch the call touches) is part of the key precisely because "post ₹500 to account A" and "post ₹500 to account B" are different intents that must not collide.

**Why a timestamp (or a nonce) is catastrophic — stated as the rejected reflex it is.** The instinct that makes an idempotency key *unique per call* is exactly backwards. If the key includes `now()` or a fresh UUID, then **every delivery of the same intent produces a different key**, every ledger claim is a fresh row, no retry ever matches a prior `COMMITTED` row, and the ledger — the mechanism whose entire purpose is to collapse duplicates — dutifully records each duplicate as distinct and lets each one execute. The system *appears* to have a rigorous ledger and *is* at-least-once. This is not a hypothetical: it is the single most common real-world idempotency defect, and for a settlement-adjacent action it is a double debit dressed as diligence. **A timestamp does not make a key safe; it makes exactly-once impossible.**

**Enforcement — mechanism, not discipline.**
- **A CI lint over the control-plane capability manifests (ADR-026) rejects any `idempotency_key` derivation that references a clock source, a random/UUID generator, a per-attempt counter, or an un-canonicalized free-form field.** A capability whose key function reads wall-clock time fails the PR, the same way ADR-002 rejects a `SideEffecting` capability with *no* key function at all. Absence of a key and *wrongness* of a key are both structural rejections.
- **A per-capability review gate** (`RUNTIME_SCORECARD.md §review-gate 5`) requires the author to state, in the manifest, *what makes this key semantic* — which fields were stripped as volatile and why the remainder uniquely identifies the intent. This is a reviewed, versioned assertion, not a buried constant.
- **The key derivation is itself a versioned control-plane definition** (ADR-026): "how this capability's key is computed" is diff-reviewed and rolls back like any other definition, so a change that quietly de-semanticizes a key is caught at review and reproducible from SHA.

**Honest limit (residual §15).** The lint catches the *obvious* de-semanticizers (clock, nonce, UUID). It cannot, by static analysis alone, prove a key is *fully* semantic — an author could include a subtly per-request field the lint doesn't recognize. That residual is why the human review gate exists on top of the lint, and why it is named, not hidden.

---

## 5. Claim-before-dispatch: the Side-Effect Ledger as the primary enforcement site

The concrete ledger algorithm is ADR-002 / `TOOLING §1.2` and is authoritative there; this ADR does not fork it. What this ADR fixes is the *ordering law* the ledger exists to enforce, because the ordering is the whole correctness argument:

**The claim is inserted, durably, BEFORE the side-effecting call fires — never after, never concurrently.** The sequence is invariant:

```
1. compute semantic key (§4)
2. INSERT {key, status: PENDING, request_hash, obo, claimed_at} into the ledger
     (unique constraint on key; this INSERT is the atomic claim)
   ├─ conflict, existing status = COMMITTED → return stored result. DO NOT dispatch.
   ├─ conflict, existing status = PENDING   → block on the in-flight claim; return its result.
   └─ conflict, existing status = FAILED     → prior attempt cleanly failed, no effect occurred;
                                               issue a fresh PENDING claim, proceed.
3. ONLY NOW dispatch the capability (the side-effecting call)
4. on success → UPDATE status = COMMITTED, store result + receipt
   on clean failure (no effect) → UPDATE status = FAILED
   on lost ack / crash between 3 and 4 → row stays PENDING → §8 reconciler
```

**Why the order is the point.** If the claim were written *after* the call, a crash between the call and the write would leave no record that the effect happened — and the retry would fire it again with an empty ledger. Claiming *before* dispatch means the durable record of "I am about to do this" exists no matter where a crash lands, which is exactly what makes the in-doubt row (step 4's crash case) *recoverable* rather than *invisible*. This is the transactional-outbox discipline (the claim and the intent are one durable write) applied to side effects — it is why "claim before dispatch" is a law here and not an implementation detail.

Per-resource locking (`TOOLING §1.5`) covers the *concurrent* axis (two live calls on one `resource_key` serialize); the ledger covers the *temporal/cross-process* axis (retries, restarts, races across workers). Together they close both — one process cannot double-execute concurrently, and no set of processes can double-execute across time. Neither substitutes for the other, and this ADR requires both.

---

## 6. Downstreams that don't accept idempotency keys (gap [21] — the end-to-end problem)

The ledger makes *the runtime's own dispatch* exactly-once. It does **not**, by itself, make the *effect at the downstream* exactly-once — and this is the gap a naïve design hides. Consider the lost-ack case: the runtime claims the slot, fires the call, the downstream **succeeds**, and then the network drops the response. The ledger row is `PENDING`. A retry now depends entirely on whether the downstream can recognize that this is the *same* request it already processed:

- If the downstream is **idempotency-key-native** (it accepts a caller-supplied key and dedups on it — the pattern industry tools like Stripe expose, and the shape a UPI RRN or a NACH UMRN gives a rails message), the runtime passes **the same semantic key** as the downstream's dedup token, and the retry is a no-op at the downstream. **End-to-end exactly-once.**
- If the downstream has a **natural business key** the runtime can *read back* (an MR by source+target branch, a ticket by external-ref, a settlement instruction by batch-id) — not a dedup token, but a queryable identity — the runtime can *check whether the effect already exists* before re-attempting. **End-to-end exactly-once via read-before-write.**
- If the downstream is **neither** — a legacy SOAP core-banking endpoint that ignores extra headers, an SMTP send, a fire-and-forget queue — then **the runtime cannot unilaterally guarantee exactly-once end-to-end**, because a retry is indistinguishable, *to the downstream*, from a genuine second request. A blind retry here is precisely the double debit.

**Decision: the downstream's deduplication capability is a declared, reviewed manifest field, and it governs retry behavior — the runtime never assumes.**

```
downstream_idempotency:
    Native { key_field }          # runtime sends the semantic key AS the downstream's dedup token
  | NaturalKey { read_probe }     # runtime reads back by business key before re-attempting
  | None                          # downstream cannot recognize a duplicate — see the rule below
```

**The `None` rule (the honest core of gap [21]):**
1. **No blind retry, ever.** A `PENDING`/lost-ack row for a `None` downstream is **never** auto-retried. It goes straight to the in-doubt reconciler (§8), which, absent a probe, escalates to `MANUAL_RECONCILIATION` — a human resolves the ambiguity against the downstream's own records. Passive re-attempt is forbidden because it is the double-debit path.
2. **`HighRisk` + `None` + no `reconcile` probe = rejected at registration.** A settlement-adjacent (`risk_tier: HighRisk`) capability whose downstream can neither dedup nor be read back is *un-shippable*: the `CapabilityRegistry` refuses to register it (the same load-time gate ADR-002 uses to reject a keyless `SideEffecting` capability). "High-risk, non-deduplicating, and unverifiable" is not a capability the runtime will operate — it is a structural impossibility, so a double debit through this path cannot be authored, not merely discouraged.
3. **The author must make the effect naturally idempotent, or accept manual reconciliation.** For non-high-risk `None` downstreams (e.g., an internal notification), the honest guarantee the runtime offers is *at-most-once on our side + at-least-once delivery*; the capability author must design the effect to be intrinsically safe to repeat (e.g., an upsert, a set-to-value rather than an increment) or accept that a lost ack means a human reconciles. This is stated in the manifest and reviewed — the platform never *pretends* a `None` downstream is exactly-once.

**End-to-end exactly-once is therefore a property the runtime *achieves where the downstream cooperates* and *honestly degrades where it cannot* — never a blanket claim.** This is the difference between a design that solves gap [21] and one that hides it: the hard case (no key, no probe) is met with a refusal-to-guess and a structural registration gate for the class that matters, not a silent retry.

---

## 7. Saga / compensation with honest partial failure

The mechanism is ADR-002 / `TOOLING §1.3`; the law this ADR fixes is **honesty about what could not be undone.**

A composite action ("update the Jira ticket, then create the GitLab MR, then notify the channel") is an ordered list of ledger-tracked steps (§5 applies to each), each carrying an optional `compensate(receipt) -> Action`. On a step failure, the saga runs the declared `compensate` of each prior committed step in reverse. The decision that matters is what happens when a prior step **has no `compensate`** (an email already sent, a settlement-adjacent post that cannot be un-posted):

- The saga **never fabricates a clean rollback.** It marks the non-compensable step, files an incident note carrying the full request hash and receipt, and terminates the saga as **`FAILED_PARTIAL(list of non-compensable steps)`** — a first-class, honestly-reported outcome, distinct from `FAILED_COMPENSATED` (everything prior was undone) and from `COMMITTED` (the whole completed).
- `FAILED_PARTIAL` is the same "never claim done when it isn't" discipline the SDLC judge-loop uses for `capped` and the reconciler uses for `MANUAL_RECONCILIATION`. A human sees exactly which effects are live and which were reversed, because the alternative — a saga that swallows a non-reversible effect and reports "rolled back" — is a lie that a payments auditor would (correctly) treat as a control failure.

**Interaction with ADR-016.** The apex case — a completed inter-bank settlement, a released NACH debit — has *no* `compensate` that un-happens it, so for money-movement `FAILED_PARTIAL` would be "a catastrophe reported politely" (ADR-016 §1). That is precisely why ADR-016 removes payment initiation from this ledger's dispatchable classes entirely: the saga's honest partial-failure is the *right* behavior for a sent email and an *unacceptable* one for moved money, so money-movement is never allowed to become a saga step in the first place (§11).

---

## 8. The in-doubt (lost-ack) reconciler

The mechanism is ADR-002 / `TOOLING §1.8`; the law this ADR fixes is **in-doubt is a first-class state, resolved by evidence, never forgotten and never guessed.**

A row stuck `PENDING` past its per-`effect_class` timeout is the runtime's most dangerous state: the runtime claimed the slot, may or may not have fired the call, and cannot tell from its own records. Passive expiry (delete/fail the row after a timeout) is **forbidden** — a timed-out `PENDING` is exactly the row that must be *resolved*, because forgetting it either drops a settlement (if the effect never happened) or invites a blind retry into a double debit (if it did).

A background **reconciler** sweeps timed-out `PENDING` rows and resolves each *actively*:

- **Probe the downstream's real state.** For a capability exposing `reconcile(idempotency_key) -> { Committed(result) | NotFound | Ambiguous }` — **mandatory** for any `HighRisk SideEffecting` capability (and, per §6, the only way a `None`-downstream high-risk capability can register at all) — the reconciler queries the downstream keyed by the *same* semantic key that was sent, and moves the row to `COMMITTED` (effect confirmed, result back-filled) or `FAILED` (downstream has no record → safe to re-attempt). The verdict is the downstream's *actual* state, not an inference.
- **Never fabricate a verdict.** If the probe returns `Ambiguous`, or the capability declares no probe, the reconciler escalates the row to **`MANUAL_RECONCILIATION`**, files an incident with the full request hash and receipt, and pages the settlement on-call. A settlement-adjacent row is *never* left indefinitely ambiguous and *never* auto-resolved on a guess.
- **The reconciler is itself idempotent.** It claims each row under a short, **fenced** lease (§9) before probing, so it is safe to run on every node and survives the same restarts it exists to clean up after — two reconcilers cannot both act on one row.

**The reconciler's dependency, named honestly (residual §15):** it is only as strong as the `reconcile` probes it calls. A capability with a weak or missing probe degrades to human manual-reconciliation, whose *throughput* — not the runtime's code — becomes the bound on how fast an ambiguous settlement row is resolved.

---

## 9. Clock skew: the timers are correct *by construction*, not merely monitored (gap [32])

Every timeout in §5–§8 is a *duration* — "PENDING older than T," "dry-run key still within its TTL," "reconciler lease not yet expired." Across a multi-node fleet with unsynchronized wall-clocks, a duration computed as `my_node.now() − a_timestamp_another_node_wrote` is a latent double-execution: a node with a fast clock declares a *still-in-flight* call "timed out," and if the design then compensates or re-attempts on that basis, the effect fires twice (gap [32]). ADR-017 §8.2 provides the NIC/NPL NTP substrate and a skew *monitor* that raises a §2 incident on drift — but a monitor is a detector, not a correctness guarantee. This ADR makes the timers **correct under skew by construction**, so the monitor is defense-in-depth on top of a design that does not depend on it:

1. **All duration/timeout comparisons are evaluated against a single clock authority — the ledger datastore's own clock — never a cross-node wall-clock difference.** "Is this `PENDING` older than T?" and "is this two-phase-commit key still valid?" are evaluated *in the database* (`now() − claimed_at > interval`), where `now()` and `claimed_at` are read from **one** clock. No node ever compares its local wall-clock to a timestamp minted by a *different* node, so cross-node skew cannot enter a timeout verdict.
2. **Elapsed-time within a single process uses a monotonic clock, never wall-clock.** In-process waits (the `PENDING`-collision block of §5, per-call budgets) measure elapsed time with a monotonic source immune to wall-clock steps/NTP corrections — a wall-clock jump backward can neither shorten nor extend a live wait.
3. **Leases carry fencing tokens.** The reconciler's row-lease (§8) carries a monotonically increasing fence token; a write from a stale lease-holder (a node paused/GC'd long enough that another node took the lease) is rejected because its fence is lower than the current holder's. So even if a lease *appears* expired under skew and two workers act, only the highest-fence write commits — the classic lease-without-fencing split-brain is closed structurally.
4. **Timeouts are sized with an explicit skew + latency margin, and that assumption is the thing the monitor guards.** Each per-`effect_class` reconciler timeout is set to comfortably exceed `(max tolerated NTP skew bound) + (max expected downstream latency)`, and ADR-017 §8.2's monitor pages when skew approaches the bound — so the sizing assumption is enforced, not assumed. If skew ever exceeds the bound *and* the monitor is down, law 5 is still the backstop.
5. **The decisive structural property: a timer decides only *when to investigate*, never *what the verdict is*.** The reconciler *never* resolves a row by clock — a timeout only triggers a *probe* (§8), and the probe's verdict is the downstream's *actual* state. Therefore a *premature* sweep caused by skew can at worst cost a wasted probe query; it can **never** cause a double-execution or a premature compensation, because the runtime does not compensate-or-retry on "the timer says so" — it acts on "the downstream says so." This is what turns clock skew from a correctness bug into, at most, a transient efficiency cost. Laws 1–4 keep skew from even reaching the timers; law 5 guarantees that if it somehow did, the outcome is still correct.

This is the honest inversion of gap [32]: the gap warns that skewed timers → premature compensation → double-execution; this design breaks the chain at every link and, most importantly, at the last one — **compensation and retry are never a function of a timer alone.**

---

## 10. Where else the invariant binds — the cross-cutting scope (why this is a general ADR, not the ledger restated)

The Side-Effect Ledger (§5) is the *primary* enforcement site, but the invariant (§3) binds every origin of intent. Naming them is the point of a *general* transactionality ADR:

- **The protocol envelope (ADR-005 §7 / residual 5).** A client-minted `command_id` makes at-least-once *network* delivery into exactly-once *application*: a command redelivered because the client didn't see the ack is deduplicated at the runtime boundary before it ever reaches a capability. This is the same invariant one layer out; the `command_id` is the *transport-level* idempotency key, and this ADR's semantic-key discipline (§4) is why a well-formed client must not reuse a `command_id` across semantically different commands (ADR-005 residual 5's "key hygiene is a client obligation" is this ADR's law applied to the wire).
- **Connector-triggered ingress (webhooks).** A GitLab MR event or a Jira `issue_created` webhook is an *inbound* intent over an at-least-once channel — the provider *will* redeliver. The receiving pipeline claims a ledger slot keyed by the event's semantic identity (provider event-id + resource) before acting, so a redelivered webhook runs the pipeline once. (This is the runtime-native generalization of the existing platform's `gitlab_create_mr` 409-idempotency and "silently drop non-`issue_created`" disciplines — the same instinct, now a ledger law rather than a per-connector special case.)
- **Program / Run resume (ADR-027).** A Program resumes by replaying to its last checkpoint (`set of COMMITTED commit-SHAs`, `LONG_HORIZON_PROGRAMS.md §checkpoints`) and re-scheduling READY nodes. A node whose side effect *already committed* before the crash must not re-execute on resume — the ledger deduplicates it by the node's semantic key, so replay-to-checkpoint is safe *because* the side-effecting steps are idempotent. Long-horizon durability and this ADR are two halves of one guarantee: the checkpoint makes the *plan* resumable; the ledger makes the *effects* safe to re-drive.

Four origins — capability dispatch, protocol command, connector event, Program node — one contract. A fifth origin added later inherits it or is a defect (§2 corollary).

---

## 11. Relationship to the payment boundary (ADR-016) — this ADR governs *below* the line

ADR-016 and this ADR meet at the ledger's `effect_class` type system, and the division is exact:

- **This ADR governs every dispatchable side effect — `Pure | Idempotent | SideEffecting` — and makes each exactly-once, saga-safe, in-doubt-recoverable, and skew-correct.** For payment-*adjacent* actions (simulate a settlement, draft a dispute, post a non-settling status), double-execution is a real harm and this ADR's machinery is the whole defense.
- **ADR-016 reserves the apex `PaymentInitiating` class *above* this ADR's dispatchable set and builds the runtime with no dispatch arm for it.** It does this *because* §1's honest limits apply hardest to money: a completed settlement is non-compensable (§7 would report `FAILED_PARTIAL` — "a catastrophe reported politely"), and a `None`-downstream double-fire (§6) would be a literal double debit. Rather than trust the ledger to *never* let money move twice, ADR-016 removes money-movement from the ledger's reach entirely. **This ADR makes side effects safe; ADR-016 makes the one unsafe-at-any-guarantee side effect unrepresentable.** They compose: the strongest exactly-once machinery in the world is still the wrong tool for an irreversible national-settlement debit, so that class lives on the other side of a boundary this ADR's mechanisms never have to defend.

---

## 12. Alternatives considered

### 12.1 Idempotency as a per-capability convention ("just check if it already ran")
Rejected (restating ADR-002 §3.3 at the principle level). Convention means every author re-derives the same tricky exactly-once logic with inconsistent quality, and the check-then-act is rarely atomic in practice (a crash between check and write re-fires the effect). A runtime-owned ledger with claim-before-dispatch (§5) and a load-time gate makes the guarantee structural and provable at one place, which is the only form of it a payments auditor can accept.

### 12.2 Make the idempotency key unique per call (timestamp / nonce / UUID)
Rejected, and named as the *anti-pattern* because it is the intuitive-but-wrong reflex (§4). A per-call-unique key means no retry ever matches a prior claim, so the ledger records every duplicate as distinct and executes each — at-least-once wearing an exactly-once costume. It is a double debit dressed as diligence, and it is blocked by a CI lint, not left to reviewer memory.

### 12.3 Assume every downstream is idempotency-key-native
Rejected — this is the hidden face of gap [21]. Many real NPCI downstreams (legacy SOAP core-banking, SMTP, fire-and-forget queues) ignore a supplied key. A design that passes a key and *assumes* dedup silently reopens the double-execution hole for exactly the legacy, high-consequence integrations that matter most. The `downstream_idempotency` classification (§6) forces the capability to *declare* the truth and forces `HighRisk + None + no-probe` to be un-shippable, so the assumption can never be made silently.

### 12.4 Passive TTL expiry of stuck `PENDING` rows
Rejected. A timed-out `PENDING` is the *one* row that must be resolved by evidence (§8), because it is precisely the lost-ack in-doubt case. Expiring it either drops a real settlement or (worse) frees a retry to double-fire. Forgetting an ambiguous settlement row is not a cleanup; it is the incident.

### 12.5 Wall-clock timeouts / time-based distributed locks without fencing
Rejected — this reopens gap [32]. Comparing a local wall-clock to a timestamp another node wrote makes every timeout a skew-driven double-execution risk, and a lease that expires purely by time (no fence) lets a paused node and its replacement both act on one row. §9's single-clock-authority, monotonic durations, and fencing tokens are the minimum bar; the probe-not-guess property (§9 law 5) is the backstop that makes even a failure of the others non-catastrophic.

### 12.6 A distributed transaction (2PC / XA) spanning the runtime and the downstream
Rejected. Most of the runtime's downstreams — payment rails, SaaS connectors, SMTP, third-party MCP servers — do not speak XA, so a two-phase distributed transaction is not available for the integrations that matter, and a global transaction coordinator is a new single-point-of-failure and availability drag. The saga + ledger + reconcile model (§5–§8) is the correct pattern for *heterogeneous, non-transactional* downstreams: local atomicity at the ledger, honest compensation across steps, evidence-based resolution of in-doubt. (The runtime's own two-phase `dry_run`→`commit`, `TOOLING §1.4`, is a *different* thing — an intra-runtime propose-then-act gate for `HighRisk` actions, not a cross-system XA transaction.)

### 12.7 Transactional outbox / event-sourcing *instead of* a ledger
Not rejected — subsumed. "Claim before dispatch inside one durable transaction" (§5) *is* the transactional-outbox discipline: the intent record and the right-to-proceed are one atomic write, which is what makes the crash-in-between case recoverable. What a pure fire-and-forget outbox lacks — read-back deduplication of a `COMMITTED` result and an in-doubt reconciler — this design adds. The outbox is the enabling mechanism; the ledger + reconciler is the complete contract.

---

## 13. Acceptance / scenario tests

| # | Scenario | Setup | Expected | Proves |
|---|---|---|---|---|
| 1 | Lost-ack, key-native downstream | A `SideEffecting` call fires; the downstream (idempotency-key-native) succeeds; the ack is lost; the agent loop retries with identical semantic args | Retry carries the *same* semantic key as the downstream dedup token; downstream recognizes the duplicate; exactly one effect exists; retry returns the ledger's `COMMITTED` result without re-invoking | End-to-end exactly-once when the downstream cooperates (§5/§6) |
| 2 | Semantic-key stability | Two genuine retries of the same intent, minted seconds apart | Both derive the *identical* key (volatile fields stripped); the second hits the `COMMITTED` row and is a no-op | The key is semantic, not per-attempt (§4) |
| 3 | Timestamp-in-key rejected | A PR adds a capability whose `idempotency_key` derivation reads wall-clock time / a UUID | CI lint fails the PR; the capability never registers; review gate requires a stated semantic justification | The double-execution-via-unique-key hole is blocked structurally (§4) |
| 4 | Two different intents don't collide | "Post ₹500 to account A" and "post ₹500 to account B" in one turn | Distinct `resource_key` → distinct keys → both execute exactly once; neither dedups the other | Key uniqueness is by *intent*, including resource (§4) |
| 5 | HighRisk + None-downstream + no probe | Register a `HighRisk SideEffecting` capability whose downstream can neither dedup nor be read back and ships no `reconcile` probe | `CapabilityRegistry::register` rejects it at load time | A settlement-adjacent double-debit path is un-authorable, not merely discouraged (§6) |
| 6 | None-downstream, lost ack | A `downstream_idempotency: None` capability fires; ack is lost; row is `PENDING` | The runtime does **not** auto-retry; the reconciler escalates to `MANUAL_RECONCILIATION` and pages | No blind retry against a non-deduplicating downstream = no double debit (§6) |
| 7 | Read-before-write on NaturalKey | A `NaturalKey` capability (create-MR) retried after a lost ack | The reconciler/read-probe finds the existing MR by source+target branch and resolves `COMMITTED` without creating a second | Exactly-once via read-back where the downstream has a queryable identity (§6) |
| 8 | Concurrent duplicate retries | A UI double-click races an internal retry of the same action | The second blocks on the first's `PENDING` claim and returns its result; the capability is invoked once | Ledger `PENDING`-collision handling on the concurrent axis (§5) |
| 9 | Saga honest partial failure | A 3-step saga; step 3 fails after 1–2 committed; step 2 is non-compensable | Step 1 compensated; step 2 marked non-compensable; saga reports `FAILED_PARTIAL` with an incident note — never a clean-rollback claim | Saga honesty (§7) |
| 10 | In-doubt resolved by probe | A `HighRisk` call fires; the process dies before the row leaves `PENDING` | The reconciler sweeps the timed-out row, probes the downstream's *actual* state, resolves `COMMITTED` or `FAILED` | In-doubt is resolved by evidence, not forgotten or guessed (§8) |
| 11 | In-doubt ambiguous → manual | The `reconcile` probe returns `Ambiguous` (or none exists) | Row → `MANUAL_RECONCILIATION`; incident filed with request hash + receipt; on-call paged; never auto-resolved | The reconciler never fabricates a verdict (§8) |
| 12 | Clock skew → premature sweep, no double-exec | A reconciler node's clock is fast; it sweeps a row whose call is *still legitimately in-flight* | The sweep only triggers a *probe*; the probe (or the DB single-clock TTL re-check) shows the call in-flight/committed; no compensation, no re-attempt, no double effect | The decisive skew property: timers decide *when to investigate*, never the verdict (§9 law 5) |
| 13 | TTL evaluated on one clock | A two-phase `dry_run`→`commit` TTL is checked while two nodes' wall-clocks differ | The TTL is evaluated in the ledger datastore (`now() − claimed_at`), one clock; cross-node skew cannot expire-early or accept-stale | Single-clock-authority for all timeout verdicts (§9 laws 1–2) |
| 14 | Fenced lease, no split-brain | A reconciler node is paused past its lease; another takes the row; the paused node wakes and tries to write | The stale write is rejected by the fence token; only the current holder's write commits | Lease fencing closes the paused-node split-brain (§9 law 3) |
| 15 | Protocol envelope dedup | A client redelivers a command (missed ack) with the same `command_id` | The runtime deduplicates at the boundary; the command is applied once; the same result is returned | The invariant binds the transport layer too (§10, ADR-005) |
| 16 | Webhook redelivery | A GitLab/Jira provider redelivers the same event | The pipeline claims a ledger slot on the event's semantic identity; it runs exactly once | Connector ingress inherits the invariant (§10) |
| 17 | Program resume idempotency | A Program crashes after a node's side effect committed but before checkpoint; it resumes | Replay-to-checkpoint re-schedules the node; the ledger dedups its side effect; the node's effect does not re-fire | Long-horizon resume is safe because effects are idempotent (§10, ADR-027) |
| 18 | Payment-adjacent double-fire attempt | A payment-*adjacent* action (settlement *simulation*) is retried | Exactly-once holds via the ledger; the apex money-movement class remains non-dispatchable (ADR-016) regardless | This ADR governs below the line; ADR-016 governs the apex (§11) |

---

## 14. Consequences

**Positive**
- The single most consequential guarantee for a payment operator — no double debit — is **structural and provable at one place** (the ledger + its laws), not asserted per-capability. It can be stated under audit as a platform invariant, not a per-origin claim.
- The three ways exactly-once is usually *faked* are each blocked by mechanism: a non-atomic check-then-act (claim-before-dispatch, §5), a per-call-unique key (semantic-key lint, §4), and an assumed-cooperative downstream (the `downstream_idempotency` classification + the `HighRisk+None+no-probe` registration refusal, §6).
- Gap [21] (lost-ack, non-key-native downstreams) is met *honestly*: exactly-once end-to-end where the downstream cooperates, evidence-based reconciliation where it can be probed, and a structural refusal-to-guess (no blind retry, manual escalation) where it cannot — the hard case is designed, not hidden.
- Gap [32] (clock skew) is met *by construction*: single-clock TTL verdicts, monotonic in-process durations, fenced leases, and the decisive probe-not-guess property that makes even a skew-driven premature sweep non-catastrophic. The ADR-017 skew monitor becomes defense-in-depth, not the primary defense.
- The invariant is **cross-cutting and named** — capability dispatch, protocol envelope, connector ingress, and Program resume all inherit one contract, so a new side-effecting origin cannot be built at-least-once by accident.

**Negative / cost**
- The ledger, per-resource locking, fenced leases, and the reconciler are load-bearing infrastructure that must exist correctly *before the first `SideEffecting` capability ships* — there is no "add exactly-once later" path (ADR-002 §3.6).
- The `downstream_idempotency` classification is a real authoring obligation and, for `None` downstreams, forces either a naturally-idempotent effect design or acceptance of manual reconciliation — friction that is the intended cost of not faking the guarantee.
- The reconciler's manual-escalation path makes *human throughput* the bound on resolving ambiguous rows for capabilities with weak/absent probes — an operational tax on settlement on-call, named not hidden.

**Neutral**
- The concrete ledger/saga/reconciler algorithms remain authoritative in ADR-002 / `TOOLING §1.2–1.8`; this ADR is the principle and the cross-cutting scope, and is corrected to match that mechanism doc if they ever diverge — it deliberately does not fork a second copy of the mechanism.

---

## 15. Residual risks (honest, not deferred silently)

1. **Semantic-key correctness is bounded by review, not fully by static analysis.** The CI lint catches the obvious de-semanticizers (clock, nonce, UUID, per-attempt counter); it cannot *prove* a key is fully semantic — a subtly per-request field could slip past it. The human review gate (§4) is the belt to that suspenders, but "is this key truly semantic" remains partly an author-discipline property this ADR bounds but cannot fully close by structure alone.
2. **The `downstream_idempotency` declaration is author-asserted.** A capability that declares `Native` while its downstream actually *ignores* the key reopens the hole for that integration. The `reconcile` probe is the belt (a lost-ack still gets probed rather than blind-retried), but a downstream that silently violates its own documented dedup contract is a residual the runtime detects only via reconciliation, not prevention.
3. **The reconciler is only as strong as its probes** (restating ADR-002 §6.4). A weak/missing `reconcile` degrades to manual reconciliation, whose throughput — not the code — bounds how fast an ambiguous settlement row is resolved.
4. **The clock-skew design is correct under a *bounded* skew assumption.** Laws 1–4 (§9) keep skew out of the timers; the ADR-017 monitor guards the bound. If skew exceeds the bound *and* the monitor is simultaneously down, the probe-not-guess property (law 5) still prevents double-execution, but availability degrades (premature-investigation churn). The margin sizing (`max skew + max downstream latency`) is a policy knob this design specifies but has not yet sized from production load data.
5. **Exactly-once is end-to-end only where the downstream cooperates or can be probed.** For a non-high-risk `None` downstream with no probe, the honest ceiling the runtime offers is *at-most-once on our side + at-least-once delivery* — the author must make the effect naturally idempotent or accept manual reconciliation. This is a real limit of the physical world (you cannot make a system dedup that has no way to recognize a duplicate), named as the honest boundary rather than papered over.
6. **Ledger durability is itself an assumption.** Exactly-once at the ledger is only as strong as the ledger store's own durability and availability; a ledger that loses a `COMMITTED` row after acking it would reopen the hole. This inherits the data-plane durability posture (Postgres) and is a dependency, not a property this ADR proves.

---

## 16. Self-score (honest)

**Design ceiling: 9.5 / 10.** Every clause the brief named has a concrete enforcement mechanism and an acceptance test that exercises exactly the property that matters — the house bar. Claim-before-dispatch is an ordering *law* with the crash-recovery argument spelled out (§5); the purely-semantic key is a *law with a CI lint and a named anti-pattern* (§4), not a coding suggestion; the downstream-without-keys problem (gap [21]) is met with a declared classification and a structural `HighRisk+None+no-probe` registration refusal plus a no-blind-retry rule, i.e. an *honest* end-to-end story rather than a blanket exactly-once claim (§6); the saga reports `FAILED_PARTIAL` rather than a false rollback (§7); the in-doubt reconciler resolves by *probe, never by clock* (§8); and the clock-skew hazard (gap [32]) is broken at every link — single-clock TTL verdicts, monotonic durations, fenced leases, and the decisive property that a timer decides only *when to investigate*, never the *verdict* (§9). It is positioned cleanly against its neighbors: it is the principle ADR-002's ledger instantiates, the invariant ADR-005's envelope carries, the safe-resume ADR-027 depends on, and the class-below-the-line that ADR-016's payment boundary sits atop.

The missing half-point is honest and structural: semantic-key correctness and the `downstream_idempotency` declaration are partly author-assertions this ADR bounds with lint + review + probe but cannot make *fully* static (residuals 1–2); the reconciler and the manual-escalation path make human throughput and probe quality the real bound in the hardest cases (residual 3); the skew margin is a not-yet-field-sized knob (residual 4); and exactly-once past a non-cooperating downstream with no probe is a limit of physics, not of design (residual 5). Those are enforcement surfaces this design specifies precisely but cannot itself prove hold until built. **Build maturity: 0 / 10** — no code exists, consistent with every artifact in this corpus. The ceiling is set so implementation can only descend from a real 10-shaped target, and the residuals are named, not hidden.
