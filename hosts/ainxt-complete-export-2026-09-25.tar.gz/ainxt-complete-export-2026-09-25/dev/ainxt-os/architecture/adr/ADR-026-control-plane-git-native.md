# ADR-026 — Control Plane is Git-Native (definitions as versioned files, not a database)

**Status:** Accepted — Q2 decision. Design only (no code).
**Decision class:** Architecture-defining. Splits the platform along a new axis (control plane vs data plane) and changes the source of truth for *definitions*.
**Relates to / extends:** ADR-001 (AiNxt Runtime, strangler-fig), ADR-002 (Tool+MCP Runtime / one CapabilityRegistry), ADR-003 (Policy/Approval/Compliance seam — the runtime authz engine this ADR reads front-matter into), ADR-007 (execution Event-Log / tamper-evident audit), ADR-012 (data-class → model routing — the `data_class_ceiling` field feeds it), ADR-015 (retention / DPDP erasure — the reason definitions must be PII-free), ADR-016 (agent-payment boundary — the one class git-native review must not weaken), ADR-025 (evidentiary admissibility — git history as an authoring audit trail). Reconciles the standing **"DB is the source of truth"** rule (`feedback_db_source_of_truth.md`) and the **"no durable state in localStorage / all persistence server-side"** rule (`feedback_no_localstorage.md`).
**Supersedes for definitions only:** the DB-backed governance state machine (`DRAFT → PENDING_APPROVAL → APPROVED → PRODUCTION → DEPRECATED`) described in `SUBSYSTEM_DEEP_DIVES.md` §skills and `AINXT_OS.md` §4. That lifecycle is not deleted — it is *re-hosted* on git primitives (§7). It remains fully in force for the existing Python platform until each definition kind is migrated (§14).

---

## 1. Context — why the DB-source-of-truth rule needs refining, not repealing

The platform's load-bearing rule is `feedback_db_source_of_truth.md`: **the DB is the only source of truth for agent prompts, skill code, and workflow steps — never hardcode them as a Python/Rust runtime override.** That rule exists to kill a specific, real failure mode: a "prompt" or "skill" that lives half in Postgres and half in a constant string in `model_router.py`, so nobody can tell which one actually ran, and a governance approval in the DB is silently overridden by code. The rule is correct and non-negotiable in *spirit*: **externalize definitions, single source, never a code override.**

But "put it in Postgres" was a *storage* answer to a *governance* problem, and it conflates two things that have opposite requirements:

| | **Definitions** (skills, agents, roles, prompts, workflows, policies) | **Operational state** (sessions, memory, event log, budgets, tokens, vectors) |
|---|---|---|
| Contains PII? | **Never** (an authorization *to touch* regulated data is not the data itself) | **Yes** — user memory, transcripts, PII are its whole job |
| DPDP erasability | Must **never** be erasable — they are the audit record of what the org authorized | Must be **erasable on request** (DPDP right-to-erasure, ADR-015) |
| Change shape | Reviewed, diffed, versioned, rolled back — **exactly like code** | High-write, mutable, queried by key, scoped per user |
| Who changes it | A small set of accountable authors, through review | The runtime, thousands of times a second, on behalf of users |
| What "correct" means | The right *reviewers approved the right diff* | The right *user sees the right row under RBAC* |

The moment you write these two lists side by side, the DB governance state machine we hand-rolled (`AgentRecord.status`, a versions table, an approvals table, an audit table) is revealed as a **reimplementation of git** — worse, an unsigned, un-diffable, single-reviewer reimplementation, sitting inside a store whose defining property (mutability, erasability) is *actively wrong* for an audit-of-record.

Git already solves definition-shaped governance to a higher bar than we can hand-roll in a DB, and it is the bar a payment regulator already understands: **PR review is a maker-checker approval workflow; CODEOWNERS is authoring RBAC; branch protection + signed commits are integrity; git history is a tamper-evident, attributable audit trail; semver tags are versioning and instant rollback.** None of that is PII, none of it must ever be erased, all of it must be reviewed and versioned. That is exactly the definitions column above.

Meanwhile the operational-state column is exactly what git is *bad* at (mutable, high-write, per-user, must be erasable) — and exactly what Postgres/Redis/pgvector/object-store are *for*.

**So the DB-source-of-truth rule was solving the right problem in the wrong store for one of the two things it was applied to.** This ADR keeps the rule's spirit intact and splits its subject.

---

## 2. Decision

**Separate the control plane from the data plane.**

- **CONTROL PLANE = definitions.** Skills, agents, roles, prompts, workflows, and policies are stored as **versioned files in a git-backed repository** — a directory tree of Markdown-with-front-matter definition files (§4–§5). Governance is **git-native** (§7): the PR review workflow *is* the approval lifecycle, CODEOWNERS *is* authoring RBAC, branch protection + signed commits *are* integrity/audit, git history *is* the audit trail, semver tags *are* versioning and rollback. Definitions are loaded into the runtime at startup and **hot-reloaded** on change via webhook/file-watch (§6). **Definitions contain no PII, ever** — enforced at commit-entry, because git cannot erase (§10).
- **DATA PLANE = operational state.** Sessions, the event log, **user memory and PII (must be erasable per DPDP → NEVER git)**, vector indexes, telemetry, budgets, run history, and connector tokens stay in their stores (Postgres / Redis / pgvector / object-store), governed by ADR-015 retention/erasure.
- **Runtime execution authorization is enforced by the Policy Engine (ADR-003) reading each definition's manifest front-matter (§8). Git governs *authoring* only.** Approval-in-git means "this definition is correct and safe to exist in production"; it says nothing about *who may run it now* — that is a separate, per-turn decision made by the runtime against the front-matter's `execute_rbac` + the caller's OBO context. These are two different questions, enforced at two different layers, at two different times.
- **The existing Python platform keeps its DB source of truth until each definition kind is migrated** (strangler-fig, ADR-001). There is never a moment where both git and the DB are authoritative for the same kind (§14).

---

## 3. The split, stated as an invariant

The axis of the split is not "new vs old" or "Rust vs Python." It is **erasability + mutability + change-shape**:

> **If an artifact must be reviewed, versioned, and rolled back like code, and must never contain PII, and must never be erased — it is a definition and it lives in git.**
> **If an artifact is high-write, per-user, queried by key, and must be erasable on request — it is operational state and it lives in a store.**

| Artifact | Plane | Store | Erasable? |
|---|---|---|---|
| Skill (behavioral SOP / execution code) | Control | git | No (versioned, immutable history) |
| Agent / Role / Team spec | Control | git | No |
| Prompt-layer artifacts (L1–L5, per-model variants) | Control | git | No |
| Workflow definition (the DAG spec, not a run) | Control | git | No |
| Policy (data-class matrix, egress allow-list, autonomy dials, CODEOWNERS) | Control | git | No |
| **Which version is deployed to an env** | Control | git ref (`env/prod`) | No (the deploy history is the audit) |
| Session / conversation transcript | Data | Postgres + Event Log | Per ADR-015 |
| User memory / personalization (PII) | Data | Postgres (`cowork_user_memory` et al.) | **Yes — on request** |
| Vector indexes / embeddings | Data | pgvector | Rebuildable; erasable by source |
| Budgets / usage / telemetry | Data | Redis db=4 / Postgres | Per retention |
| Connector tokens (OAuth) | Data | Postgres, encrypted | Yes (on disconnect) |
| Run history / event log | Data | Postgres / Event Log | Per ADR-015 + legal-hold |

**The one subtle line (§10):** a definition may be *authorized to operate on* regulated data (`data_class_ceiling: regulated-payment`) without *containing* any. The authorization-to-touch is git-safe; the data-touched is data-plane-only. Conflating the two is the mistake this ADR most has to prevent, and the compliance-gate-at-commit-entry (§10) is what prevents it mechanically.

---

## 4. Repository & folder layout

One git repository is the **control repo** (`ainxt-control`). It contains only definitions and their governance metadata — no runtime code, no data.

```
ainxt-control/
├─ ainxt.control.yaml            # repo config: control-schema version, signing keyring ref,
│                                #   marketplace source list, per-kind cutover flags (§14)
├─ CODEOWNERS                    # authoring RBAC: path → required reviewers (§8)
├─ control.lock                  # pinned {id, version, content_hash, commit_sha, source} for
│                                #   every definition incl. marketplace deps — verified at load (§9)
├─ policies/
│   ├─ data-class-routing/definition.md      # feeds ADR-012 router eligibility matrix
│   ├─ egress-allow-lists/definition.md      # feeds TOOLING §1.7 egress DLP
│   └─ autonomy-defaults/definition.md
├─ prompts/
│   ├─ persona-npci-core/definition.md       # L1 persona; per-model variants as sibling files
│   └─ guard-injection-defense/definition.md
├─ skills/
│   ├─ behavioral/triage-sop/definition.md   # body IS the injected SOP (full instructional authority)
│   └─ execution/release-notes/
│       ├─ definition.md                      # manifest + human description
│       └─ run.py | run.wasm                  # the executed code, versioned beside its manifest
├─ agents/
│   └─ release-notes-drafter/definition.md
├─ roles/
│   └─ l1-support-engineer/definition.md
├─ teams/
│   └─ sdlc-delivery/definition.md
├─ workflows/
│   └─ nightly-compliance-report/definition.md
└─ .ainxt/
    ├─ schema/                    # JSON-Schema per kind — CI *and* the loader validate against these
    └─ hooks/                     # pre-receive compliance-gate + schema-gate (§10), CI equivalents
```

**Design choices that matter:**
- **One definition = one directory** containing `definition.md` (the manifest + human-readable body) plus any attachments (execution code, prompt variants, templates). A directory, not a single file, so an *execution* skill's code sits under review beside its manifest and shares its version and its PR — code and its governance can never drift into different reviews.
- **The body is the definition's substance, not decoration.** For a behavioral skill the Markdown body *is* the SOP injected into the system prompt with full instructional authority (per `CLAUDE.md` skill semantics); for a prompt artifact it is the compiled layer text; for a role it is the persona/instructions. Front-matter governs; the body *is* the definition.
- **Clean-room format.** Markdown + YAML front-matter is a ubiquitous, vendor-neutral convention (used by every static-site generator). The file name (`definition.md`), the front-matter key vocabulary (§5), and the directory taxonomy are AiNxt's own — no vendor file layout, identifier, or prompt is reproduced.
- **The runtime never reads a raw file path.** It reads the parsed, schema-validated, signature-verified **Definition Registry** built at load (§6). A file on disk that isn't in the verified lockfile is invisible to the runtime — there is no "drop a file in a folder and it runs" path.

---

## 5. Front-matter (manifest) schema

Every `definition.md` opens with a YAML front-matter block. The schema is versioned (`ainxt.control.yaml: control_schema`) and enforced twice — by CI (can't merge a malformed manifest) and by the loader (can't deploy one). Example (a role):

```yaml
---
kind: role                        # skill | agent | role | team | workflow | policy | prompt
id: role.l1-support-engineer      # globally-unique, kind-prefixed, immutable slug
version: 2.3.0                    # semver; the git tag on main IS this release (§7)
title: L1 Support Engineer
summary: Triage L1 tickets, resolve password/access requests, escalate the rest.
owner: platform-support           # accountable git group; must match a CODEOWNERS entry (§8)

# ── RUNTIME EXECUTION AUTHZ — read by the Policy Engine (ADR-003) at run time, per turn ──
execute_rbac:
  min_role: user                  # user | admin  (aligns with the two-role model)
  max_ad_level: 6                 # AD-seniority ceiling permitted to INVOKE (0=senior..6=junior)
  requires_approval: false        # can_approve gate for invocation, if true
  departments: [support, ops]     # dept scoping (empty ⇒ all); data-scoping per JWT dept
  visibility: public              # public | private

data_class_ceiling: internal      # MAX data class this def may OPERATE ON at runtime → ADR-012.
                                  #   (Authorization to touch; NOT data contained here — see §10)

capabilities:                     # scoped OBO grants (ADR-003 / TOOLING §1.6) — least-privilege
  - id: connector.ticketing.read
    resource: "queue=L1"
    action: read
  - id: connector.email.send
    resource: "domain=*.npci.org.in"   # egress allow-list (TOOLING §1.7)
    action: write
    risk_tier: Elevated

model_policy:
  tier: medium                    # CLAUDE.md tier; router still applies non-overridable
  failover: [in-house-primary, in-house-fallback]   #   data-class exclusion (ADR-012)

autonomy:                         # per-TASK autonomy dial (AINXT_OS §4 step 4)
  password_reset: auto
  access_request: hitl
  default: escalate

payment_boundary: none            # none | initiates-settlement — a non-'none' value forces the
                                  #   ADR-016 hard-class review path (§8); default-deny

depends_on:                       # composition graph, semver-ranged, resolved at load
  - { id: skill.behavioral.triage-sop, version: "^1.4.0" }
  - { id: prompt.persona-npci-core,    version: "~3.0.0" }
---

# L1 Support Engineer — operating instructions
(Markdown body: the persona + SOP the runtime injects. This is the substance, governed above.)
```

**The one deliberate absence: there is no `status:` field.** A definition never carries `DRAFT`/`APPROVED`/`PRODUCTION` in its front-matter, because **status is not a property of the file — it is the file's position in git** (§7). Encoding status in the file would recreate the exact DB failure mode this ADR removes: a mutable field a single actor can flip without review. The status of a definition is *derived*, not *declared*.

**Schema rules enforced by CI + loader (not convention):**
- `kind`, `id`, `version`, `owner`, `execute_rbac`, `data_class_ceiling` are **required**; a missing required field fails CI and fails load.
- `id` is immutable across versions — renaming an `id` is a delete + create (two reviewable diffs), never a silent rewrite, so cross-references (`depends_on`, run history, Event-Log records) never dangle.
- An `execution` skill **must** ship a sibling `run.*` and declare `effect_class`/`risk_tier`/`idempotency_key` per TOOLING §1.1 — the loader rejects a `SideEffecting` skill with no idempotency-key function, exactly as the CapabilityRegistry does.
- `payment_boundary != none` is a **default-deny hard class**: it requires the ADR-016 CODEOWNERS group's approval *and* a signed commit from an `ad_level <= 3` author (§8). Git-native governance must never become the soft path around the payment boundary.
- `owner` must resolve to a CODEOWNERS-recognized group whose path covers this file — an orphaned definition (owner with no CODEOWNERS coverage) fails CI, closing the "author leaves, nobody owns it" decay gap (Pass-5 gap 28).

---

## 6. Load + hot-reload mechanics

### 6.1 Startup load (all-or-nothing, content-addressed)
1. The runtime resolves the deploy ref for its environment — the `env/prod` (or `env/staging`) git ref (§7.2), a signed, fast-forward-only branch that points at a signed semver tag.
2. It fetches that ref to a pinned **commit SHA**, verifies the tag signature against the environment's provisioned keyring, and verifies that `control.lock` matches the tree (every `{id, version, content_hash}` re-hashed from the checked-out files; any mismatch = hard fail, §9).
3. It parses and schema-validates **every** manifest, resolves the `depends_on` graph (rejecting version-range conflicts and cycles), and runs the per-kind loader checks (§5).
4. Only if **all** of the above pass does it build the in-memory **Definition Registry** and mark itself ready.

**All-or-nothing is the point.** If any single manifest fails validation, signature, or lockfile check, the *entire* load is rejected — the runtime boots on the **last-good** snapshot (or refuses to serve on cold boot) and pages an operator. It never boots on a partially-valid control plane, because "half the roles loaded" is a silent-degradation failure mode, not a graceful one. The loaded snapshot is identified by its git commit SHA — the control plane is **content-addressed**, so "which definitions were live" is always a specific, reproducible SHA, never "whatever was in the DB at the time."

### 6.2 Hot-reload (atomic swap, in-flight-safe)
- **Trigger:** a git post-receive webhook to the runtime on a change to the deploy ref (online), or a file-watch on the in-zone mirror (air-gap, §12). Debounced; coalesces a burst of commits into one reload.
- **Reload-triggering rate-limit / cooldown (beyond commit debounce).** Debounce only coalesces commits that land inside one short window; it does not, by itself, bound how often the runtime will *attempt a rebuild* if commits keep landing in successive windows. A separate **cooldown floor** (a hard minimum interval, e.g. 5s, between successive reload *builds*, independent of trigger volume) sits in front of the build path: at most one "reload pending" flag is queued at a time, and any trigger that arrives while a build is in-flight or inside the cooldown window sets that flag (idempotent) rather than enqueuing more work. A high-frequency but legitimate commit burst — a busy merge day, a bulk CI-driven update touching many definitions across several PRs in quick succession — therefore coalesces into the *next* cooldown tick and is picked up as one build, rather than driving one rebuild per commit (acceptance test 19, §15).
- **Validation is incremental from the second reload onward, not full-tree.** Cold start (§6.1) validates every manifest because there is no prior snapshot to diff against. Every reload thereafter diffs the new tree against the **last-good snapshot** by `{id, content_hash}` and re-runs the expensive per-definition checks — live schema introspection, signature/attestation-list checks, secret/compliance scanning (§10) — only on the **changed set** (definitions added, modified, or removed by the push) plus the **transitive dependents** of any changed `id` (a `depends_on` version-range binding can be invalidated by an upstream change even when the dependent's own bytes are untouched). Every definition outside that set carries forward its cached validation result and content-hash from the last-good snapshot unexecuted. This is the mechanism that keeps reload cost bounded by the size of a *push*, not the size of the *repo* — the concrete latency budget this buys is stated in §6.3, and its own cost/DoS exposure is named as a residual (§17.7).
- **Mechanism:** the new snapshot is fetched, verified, and built **fully** (§6.1 steps 2–4, scoped to the changed set per the incremental-validation rule above) *before* it becomes live. The live registry is then swapped atomically (an `arc-swap`-style pointer flip). A failed build never touches the live pointer — a bad push cannot take production down; it is simply not adopted, and the pusher is notified (the same "regression auto-rolls-back, a human is notified not paged" discipline as PROMPT_ENGINEERING canary).
- **In-flight turns are pinned.** Every turn captures the registry snapshot's commit SHA **at turn start** and reads that snapshot for its whole duration. A definition being edited mid-run never changes underneath a running turn — the turn completes on the version it started with, and the Event Log records that exact SHA (ties to PROMPT_ENGINEERING PE1 and ADR-007 replay: a turn's behavior is reproducible against the precise control-plane version it ran under).
- **Rollback = a git operation, not a redeploy.** Resetting `env/prod` to a prior signed tag (a fast-forward-only, CODEOWNERS-gated, signed reset) triggers the same hot-reload path; the next-turn snapshot is the prior version. This is the "rollback is a pointer flip, instant and exact" property PROMPT_ENGINEERING §3 describes, now backed by an immutable, content-addressed store instead of a DB version table.

*(Implementation note, not a control-plane authority: an optional data-plane `control_plane_deployment` row `{env, commit_sha, tag, actor, ts}` may cache the current pointer for sub-second rollback without a git round-trip and for an operational deploy dashboard. The **authority** for "what is deployed" remains the signed `env/*` ref in git; the row is a derived cache and an operational log, never a second source of truth.)*

### 6.3 Reload-latency SLA / budget

Cold load and hot-reload scale on different axes, so each gets its own explicit budget rather than one number that quietly assumes repo size stays small:

| Operation | Scales with | P99 budget |
|---|---|---|
| Cold/full load (§6.1) — first boot, or any reload the runtime cannot diff against a last-good snapshot (e.g. a control-schema version bump that invalidates the cache) | **total** definition count in the control repo | ≤ 30s for a synthetic control plane of ~10,000 definitions across 20 tenants |
| Hot-reload (§6.2) — the steady-state path, a push against an already-loaded snapshot | **size of the changed set** (added/modified/removed definitions + their transitive dependents), not total repo size | ≤ 2s + 15ms × \|changed set\|, independent of total registry size |

**This is a commitment to incremental/partial reload, not "full reload, made faster."** A design that re-validated all 10,000 definitions on every single-definition edit would make the hot-reload budget scale with total repo size, which defeats the purpose of the atomic-swap design (§6.2) as the control plane grows from pilot to platform-wide scale — that is exactly the failure mode the incremental-validation rule (§6.2) exists to prevent. Acceptance test 20 (§15) is the mechanical proof that the budget holds at 10,000 definitions / 20 tenants and that hot-reload latency tracks the changed set, not the repo.

---

## 7. Git-native governance mapping

### 7.1 The lifecycle, re-hosted on git primitives

| DB governance (superseded for definitions) | Git-native mechanism | Enforced by (mechanism, not convention) |
|---|---|---|
| `DRAFT` | a feature branch (`feat/l1-role-escalation`) | branch namespace; nothing on a feature branch is ever loaded by a prod runtime |
| `PENDING_APPROVAL` | an open PR/MR against `main` | the git host; CI (schema + compliance §10 + Breaker dry-run) runs on the PR |
| *authoring RBAC* (who may change it) | **CODEOWNERS** path rules | **branch protection**: merge blocked without required CODEOWNERS approval (§8) |
| `APPROVED` | PR **merged to `main`** | branch protection: N approvals + green CI + **signed commits only** + linear history |
| `PRODUCTION` | a **signed semver tag** promoted onto the env ref (`env/prod`) | release job (fast-forward-only, signed); the runtime pins to `env/prod` (§6) |
| `DEPRECATED` | `deprecated: true` note + move to `deprecated/`, or removal (still reachable by tag) | PR + CODEOWNERS; a tombstone keeps `id` references honest |
| *versioning* | **git tags (semver)** | one tag = one immutable version; `control.lock` pins content hashes |
| *rollback* | reset `env/prod` to a prior signed tag | pointer flip → hot-reload (§6.2); instant, exact, audited |
| *audit trail* (who/when/what/why) | **git history**: signed commits + PR record (reviewers, discussion, linked ticket) + diff | protected, signed, non-rewritable history (§9) — a court-relevant authoring record (ADR-025) |

Nothing in the lifecycle is *lost* — the maker-checker approval, the accountable owner, the immutable versioning, the instant rollback, the audit — every property the DB state machine gave us is preserved, and several (multi-reviewer, signed, diffable, per-line-blame) are **strengthened** because git does them natively and to a bar auditors already accept.

### 7.2 Environment refs — the deploy pointer
`env/staging` and `env/prod` are **protected, fast-forward-only branches** that may only advance to a **signed semver tag** and only via the promotion job (which itself requires a promotion approval from the release CODEOWNERS group). The runtime pins to its environment's ref. This keeps the entire "what is live where, and who promoted it" record inside git history — no out-of-band deploy tool, air-gap-clean (§12), and admissible as an authoring+deploy audit trail.

---

## 8. RBAC-on-author vs RBAC-on-execute — the orthogonality that makes this safe

These are **two different questions, answered by two different systems, at two different times.** Conflating them is the single most likely way to get this ADR wrong, so it is stated as a hard separation:

| | **RBAC-on-AUTHOR** | **RBAC-on-EXECUTE** |
|---|---|---|
| Question | *Who may change this definition?* | *Who may run this definition, now, on this resource?* |
| Source of truth | **CODEOWNERS + branch protection** (git) | the definition's **`execute_rbac` + `capabilities`** front-matter (§5) |
| Enforced by | the **git host**, at PR/merge/promote time | the **Policy Engine** (ADR-003), **per turn**, at dispatch time |
| Enforced when | authoring (once, before it exists in prod) | execution (every single invocation) |
| Failure mode it prevents | a junior silently ships a payment role | an unauthorized user runs an approved role, or over-privilege / confused-deputy (TOOLING §1.6) |
| Answer to "it's approved, so…" | "…it may exist in production" | **not** "…anyone may run it" |

**Approval-in-git is necessary but not sufficient for execution.** A role can be merged, tagged, and live in `env/prod` (fully author-approved) and still be **denied at runtime** to a specific caller because that caller's role/ad_level/department/OBO grants don't satisfy the manifest's `execute_rbac` + `capabilities`. The Policy Engine reads the *same* front-matter the reviewers approved, and evaluates it against the *caller's* live OBO context (`{user_id, role, department, ad_level, can_approve, granted_permissions}` threaded from the JWT, inherited by sub-agents per TOOLING §1.6). Three independent execute-time layers must all pass (unchanged from ADR-003 / TOOLING §1.6): the manifest's declared grant, the user's issued connector scope, and resource-level ABAC.

**Git governs authoring only.** The runtime never asks git "may this user run this?" — git has no idea who the runtime's users are. Git answered "is this definition correct and safe to exist" at review time; the runtime answers "may this caller invoke it now" at run time. Each system does exactly one job.

**CODEOWNERS granularity (authoring RBAC), examples:**
```
/roles/                       @platform-leads
/policies/                    @security-council @platform-leads      # 2 groups required
/skills/execution/            @platform-leads @appsec                # code review + security
/**/*payment*                 @payments-council                      # ADR-016 hard class
* payment_boundary != none    → additionally requires an ad_level<=3 signed commit (CI check)
```
Branch protection makes CODEOWNERS approval a *merge precondition*, so authoring RBAC is enforced by the host, not by reviewer goodwill.

---

## 9. Integrity & audit

- **Signed commits + protected branches.** `main` and `env/*` accept **signed commits only**, linear history, no force-push, no history rewrite. Merges require green CI (§10) + CODEOWNERS approval (§8). The result is a tamper-evident, attributable authoring log: every change to what the AI is allowed to do carries a cryptographic author identity, a reviewer set, a timestamp, a diff, and a linked justification.
- **Signed release tags.** A `PRODUCTION` version is a semver tag signed by an allow-listed release key. The runtime verifies the tag signature at load (§6.1) — an unsigned or wrong-key tag is never loaded.
- **The lockfile (`control.lock`).** Pins `{id, version, content_hash (sha256 of the definition dir), commit_sha, source}` for every definition, including marketplace dependencies (§11). The loader re-hashes the checked-out tree and rejects any mismatch — the runtime never executes a definition whose bytes differ from what was reviewed and approved. This is the exact discipline TOOLING §3.4 applies to WASM plugins, applied to the whole control plane.
- **Two complementary audit trails, by design:**
  - **git history = the *authoring* audit** — who changed the definition, who approved it, when, why (ADR-025 admissibility: signed, attributable, non-rewritable).
  - **the Event Log (ADR-007) = the *execution* audit** — what the runtime *did* with a definition, under which caller's OBO context, at which control-plane commit SHA.
  A regulator's two questions — "who authorized this behavior?" and "what did it actually do, and could you prove it?" — map to these two trails respectively. Neither substitutes for the other.

---

## 10. The DPDP / no-PII invariant — enforced at entry, because git cannot erase

Git's immutability is a feature for audit and a hazard for DPDP: **you cannot honor a right-to-erasure request against git history.** The design's answer is not "erase from git later" (impossible without a history rewrite) — it is **"never let PII in."** Definitions are structurally PII-free (§3), and that structure is *enforced at commit-entry*, in three layers:

1. **Pre-receive hook (server-side, blocking).** The git host runs the platform Compliance Gate (the same PCI/DSS + PII/PAN detectors as `agents/compliance_engine.py`, ADR-003) over every changed file in a push to a protected branch. A detected regulated class (`PAN`, `AADHAAR`, `INDIA_PAN`, `ACCOUNT_NUMBER`, `SECRET`, `API_KEY`, `EMAIL`, `MOBILE`, `UPI`, …) **rejects the push**. This is the one place the "redact-and-proceed" rule (`feedback_redact_dont_block.md`) is deliberately inverted to **block**: redacting inside a definition would silently corrupt it (a role's SOP with a redacted clause is a broken role), and a definition never *needs* PII, so the correct action is to refuse entry, not to mutilate. This is not a user-facing runtime block (which the rule forbids) — it is an authoring-time integrity gate on a code-like artifact.
2. **CI gate on the PR.** The same scan re-runs in CI so the failure is visible in the PR before merge (belt-and-suspenders; the pre-receive hook is the hard stop, CI is the fast feedback).
3. **Secret-specific scanning.** A dedicated secret scanner (high-entropy strings, key formats, credential patterns) runs alongside — a leaked token in a workflow definition is caught here, and connector *tokens* live in the data plane encrypted (§3), never in a manifest.

**The authorization-vs-data distinction (§3), enforced:** `data_class_ceiling: regulated-payment` is *authorization to operate on* regulated data at runtime — it is a policy label, not data, and passes the gate. An actual PAN pasted into a definition body is *data* — it fails the gate. The detectors already distinguish "the string is a real PAN (Luhn-valid, entropy)" from "the string names a data class," so the ceiling label and a real PAN are not confused.

**Break-glass (honest residual, §18):** if a detector *misses* PII and it lands in history, remediation is a controlled history-rewrite (BFG/filter-repo) + forced key/credential rotation + re-signing, run as a security incident with sign-off — expensive and rare by design, which is exactly why entry is gated hard rather than relying on later erasure. The residual risk is real and named, not hidden.

---

## 11. Marketplace-as-repos

The Marketplace (`AINXT_OS.md` §4 step 9; `MCPMarketplace.jsx`) becomes a **federation of git repositories**, not a DB table of blobs:

- **A curated internal "blessed" repo** (`ainxt-control` itself, or a first-party marketplace repo) + **department repos** + **optionally vetted external definition repos**.
- **Sources are declared and pinned** in `ainxt.control.yaml` and materialized as `depends_on` entries resolved from a specific `repo@tag@content_hash` recorded in `control.lock` — **TOFU hash-pin** (trust-on-first-use, then pin), the exact supply-chain discipline TOOLING §2 (MCP) and §3.4 (plugins) apply. A marketplace dependency whose upstream tag content changes under the same tag (a rug-pull) fails the lockfile hash check at load (§9).
- **Publishing = opening a PR** to the target repo → the same CODEOWNERS review + compliance gate + Breaker dry-run + signing. There is no "upload a definition" side door; publishing *is* review.
- **Installing = adding a pinned dependency** (a PR to your control repo's lockfile) → subject to *your* org's review and *your* data-class/compliance gate, so an external definition can't enter your runtime without your reviewers approving the exact pinned version. Adoption is a diff, revocation is a diff, and both are audited.
- **Diff-and-re-approve on update** (Pass-5 gap 2 / TOOLING MCP supply chain): bumping a marketplace dep to a new tag is a reviewable diff, not a silent auto-upgrade — the reviewer sees exactly what changed in the definition they're re-trusting.

This makes the marketplace's trust model *identical* to the plugin/MCP supply-chain model already designed — one supply-chain discipline, not a second bespoke one.

---

## 12. Air-gap

A sovereign / air-gapped NPCI deployment has **no live git host reachable from the inference zone**. Git-native governance still holds, because git is designed for disconnected operation:

- **Transfer as a signed bundle.** The approved control repo (at a signed tag) is exported as a **`git bundle`** — a single, self-contained, verifiable file — and moved across the air-gap boundary through the existing controlled-transfer process. A bundle carries full history + tags + signatures, so the in-zone side can verify authoring provenance without ever contacting the outside host.
- **In-zone mirror + in-zone keyring.** An in-zone git mirror imports the bundle; signatures are verified against a **keyring provisioned inside the zone** (not fetched over the wire). The runtime pulls from the in-zone mirror exactly as it would from a live host (§6).
- **Hot-reload via file-watch.** With no outbound webhook path, the runtime watches the in-zone mirror's ref (or the pre-receive hook on the in-zone host fires an in-zone notification). Same atomic-swap, all-or-nothing reload (§6.2).
- **Only PII-free bytes cross the boundary.** Because definitions are structurally PII-free (§10), the control plane is *safe to move across a sovereignty boundary* — this is a direct payoff of the §3 split. The data plane (sessions, memory, PII) **never** crosses; it stays in-zone in its stores. The thing that must move (definitions) is exactly the thing that is safe to move.

---

## 13. Reconciling the "DB source of truth" rule

The standing rule (`feedback_db_source_of_truth.md`) has four commitments. This ADR keeps three verbatim and refines the fourth:

| Commitment of the DB rule | Under ADR-026 |
|---|---|
| **Never hardcode** definitions as a Python/Rust runtime override | **Preserved, strengthened.** Definitions live *outside the binary entirely* — in a separate git repo, loaded at runtime. There is even less room for a code-constant override than with a DB. The loader reads only the verified registry; no code path substitutes a hardcoded definition. |
| **Externalize** definitions from code | **Preserved, strengthened.** Files in a repo are the canonical externalization. |
| **Single source of truth** — one authoritative place | **Preserved.** Git is the single source of truth for definitions; the DB is the single source of truth for operational state. One source *each*, split on a principled axis (§3). Never two sources for the same thing (§14 guarantees no split-brain during migration). |
| **The store is Postgres** | **Refined.** For *definitions*, the store becomes git — because definitions are code-shaped, PII-free, review-governed, and must never be erased, which is precisely what git does better than a DB and what a DB does *wrong* (mutable, erasable, single-reviewer). For *operational state*, the store stays Postgres/Redis/pgvector/object-store — exactly as the rule intends, because that data is mutable, per-user, and must be erasable. |

**The refined rule, stated once:** *Definitions are source-of-truth in git; operational state is source-of-truth in the stores; neither is ever hardcoded, and nothing is authoritative in two places at once.* The spirit of `feedback_db_source_of_truth.md` — externalize, single-source, never-a-code-override — is fully honored. What changed is a *storage choice for one of the two subjects*, made because git is the strictly better store for that subject's requirements. `feedback_no_localstorage.md` is untouched: no durable state moves to the client; the control plane is server/git-side, the data plane is server-DB-side.

---

## 14. Strangler-fig — the Python platform keeps the DB until migrated

Per ADR-001, the Rust runtime lands as a sidecar the existing Python gateway calls; the Python platform is not disturbed. Applied to the control plane:

- **Per-kind cutover, one authority at a time.** `ainxt.control.yaml` carries a per-kind flag: `authority: db | git` for each of `{skill, agent, role, prompt, workflow, policy}`. **Exactly one** store is authoritative for a kind at any moment — this is the mechanical guarantee against split-brain (which would violate "single source of truth"). The Rust runtime **refuses to read a kind from git** until that kind's flag is `git`; until then it defers to the Python DB path.
- **Order of cutover:** low-risk, low-write kinds first (prompts, behavioral skills), then agents/roles, then policies/workflows — each kind gets its own migration PR, exporter run, and soak period, never a big-bang.
- **Migration exporter.** A one-time, one-way tool reads the DB records for a kind (`AgentRecord`, `SkillRecord`, prompt/workflow rows), emits `definition.md` manifests + attachments, opens them as a PR (so the *migration itself* goes through review + the compliance gate §10), and — on merge + cutover — flips `authority` to `git`. Export is one-way; there is no DB↔git two-way sync (two-way sync *is* split-brain).
- **Optional read-through projection after cutover.** Legacy Python code paths that still `SELECT ... FROM agents_pg` need not be rewritten on day one: after a kind's cutover, a **git→DB projector** materializes the git definitions into the old DB tables as a **read cache** (git is the sole writer/authority; the DB table becomes a derived mirror, never edited directly). This lets the Python surface keep working unchanged while git is authoritative — the strangler-fig's whole point. Direct writes to a cut-over kind's DB table are revoked at the DB grant level so the "never edit the mirror" rule is enforced, not trusted.
- **The existing DB governance state machine stays fully in force for any not-yet-migrated kind.** Nothing about ADR-026 changes how the Python platform governs a kind still on `authority: db`.

---

## 15. Acceptance / scenario tests

| # | Scenario | Setup | Expected | Proves |
|---|---|---|---|---|
| 1 | PII cannot enter git | Author commits a role whose body contains a Luhn-valid PAN | Pre-receive hook (§10) rejects the push; CI on any bypass also fails; nothing lands in history | The DPDP no-PII-in-git invariant is enforced at entry, not hoped for |
| 2 | Data-class label ≠ data | A definition sets `data_class_ceiling: regulated-payment` but contains no actual PAN | Push accepted — the label is authorization, not data (§3/§10) | Authorization-to-touch vs data-touched is distinguished mechanically |
| 3 | Approve ≠ execute | A role is merged, tagged, live in `env/prod`; a user whose `ad_level`/dept fails `execute_rbac` invokes it | Policy Engine denies at run time despite full git approval (§8) | RBAC-on-author and RBAC-on-execute are orthogonal |
| 4 | Authoring RBAC | A junior (no CODEOWNERS for `/roles/`) opens a PR changing a role | Merge blocked until a CODEOWNERS approver signs off (§8) | CODEOWNERS + branch protection = authoring RBAC, host-enforced |
| 5 | Payment hard-class | A PR sets `payment_boundary: initiates-settlement` | Requires the payments-council CODEOWNERS group **and** an `ad_level<=3` signed commit; CI blocks otherwise (§5/§8) | Git-native governance does not weaken the ADR-016 payment boundary |
| 6 | Signed-tag load | A definition tree is tagged with an unsigned / wrong-key tag and pushed to `env/prod` | Runtime load refuses the tag signature check; keeps last-good snapshot (§6/§9) | Integrity via signed tags, verified at load |
| 7 | Lockfile tamper | A file's bytes are changed but `control.lock`'s hash is not updated | Loader re-hash mismatch = hard fail; the changed definition never runs (§9) | Content-hash lockfile catches drift from what was reviewed |
| 8 | All-or-nothing reload | One of 50 manifests in a new push is schema-invalid | The *entire* reload is rejected; the runtime stays on the last-good snapshot; pusher notified (§6.2) | No partial/silently-degraded control plane |
| 9 | In-flight pin | A role is edited and hot-reloaded while a turn using it is mid-run | The running turn completes on the snapshot SHA it captured at turn start; the Event Log records that SHA (§6.2) | A definition never changes underneath a live turn; execution is reproducible |
| 10 | Instant rollback | A bad-but-valid role reaches prod; operators reset `env/prod` to the prior signed tag | Next-turn snapshot is the prior version; rollback is a signed, audited pointer flip, no redeploy (§6.2/§7.2) | Rollback = pointer flip, instant and exact |
| 11 | Marketplace rug-pull | An installed external dep's upstream re-publishes different bytes under the same tag | Lockfile hash check fails at load; the changed dep is not adopted (§9/§11) | TOFU hash-pin defeats supply-chain tamper |
| 12 | Marketplace install is review | A team adds an external definition dependency | It enters only via a PR to their lockfile, through their CODEOWNERS + compliance gate; no upload side door (§11) | Publishing/installing *is* review, not a bypass |
| 13 | Air-gap load | Control repo delivered to an air-gapped zone as a signed `git bundle` | In-zone mirror verifies signatures against the in-zone keyring; runtime loads + file-watch hot-reloads; no egress (§12) | Git-native governance works fully disconnected; only PII-free bytes cross |
| 14 | No split-brain during migration | `agent` kind has `authority: db`; a `definition.md` for an agent exists in git | The Rust runtime ignores git for `agent` and defers to the Python DB path until the flag flips (§14) | Exactly one authoritative store per kind at all times |
| 15 | Read-through mirror integrity | After `skill` cutover to git, a process attempts a direct write to `skills_pg` | The write is refused at the DB grant level; the table is a git-fed read cache only (§14) | Post-cutover DB is a derived mirror, never a second source of truth |
| 16 | Orphan prevention | A definition names an `owner` group with no CODEOWNERS path coverage | CI fails the PR (§5) | Ownership succession is structural — no orphaned definitions (Pass-5 gap 28) |
| 17 | Reproduce-from-SHA | Given a two-year-old Event-Log turn recording a control-plane commit SHA | The exact definitions that ran are recoverable by checking out that SHA; behavior is replayable (§6/§9) | Content-addressed control plane + Event Log = full authoring+execution reproducibility |
| 18 | Execution audit vs authoring audit | Regulator asks "who authorized this behavior?" and "what did the system do?" | git history answers the first (signed PR + diff); the Event Log answers the second (OBO context + SHA) (§9) | Two complementary, non-substitutable audit trails |
| 19 | High-frequency legitimate commit burst | 50 legitimate commits land against `env/prod` within 10s (a busy merge day / a bulk CI-driven update spanning several PRs) | Debounce + the cooldown floor (§6.2) coalesce the burst into a single reload build, not one build per commit; at most one build runs per cooldown window; the resulting registry reflects the cumulative state of all 50 commits; no update is dropped and no build storm is triggered | Reload rate-limiting absorbs legitimate burst load without the runtime DoS-ing its own validation path |
| 20 | Large-scale incremental reload SLA | A synthetic control repo seeded with ~10,000 definitions across 20 tenants; cold load is timed, then a single-definition edit is pushed and the resulting hot-reload is timed | Cold load completes within the §6.3 budget (≤30s); the single-definition hot-reload completes within ≤2s + 15ms×\|changed set\| and does **not** scale with the 10,000-definition total | Incremental validation + the reload-latency SLA (§6.3) hold at production-representative scale, not only at demo scale |

---

## 16. Consequences

**Positive**
- Governance is done by a system built for it, to a bar auditors already accept (signed, attributable, diffable, non-rewritable), instead of a hand-rolled DB state machine.
- One supply-chain discipline for definitions, plugins, and MCP (TOFU hash-pin, signed artifacts, diff-and-re-approve) — not three.
- Definitions become *portable and air-gap-safe by construction* because they are PII-free — the sovereignty story falls out of the split for free.
- Reproducibility: "what ran two years ago" is a git SHA + an Event-Log record, not a forensic DB archaeology exercise.
- Rollback is instant and exact (pointer flip), and disaster-recovery of the control plane is `git clone`.

**Negative / cost**
- Requires a git host with enforceable branch protection, signed commits, CODEOWNERS, and server-side pre-receive hooks (NPCI's self-hosted GitLab supplies all of these — consistent with `feedback_gitlab.md`; GitLab, never GitHub).
- Non-engineers author definitions through the conversational Studio flow (AINXT_OS §4), which must now *emit a PR* rather than a DB row — the Studio becomes a git client. This is a UX obligation on the Studio, called out so it isn't discovered late.
- The DPDP no-PII invariant is only as strong as the compliance detectors at commit-entry; a miss is expensive to remediate (§10 break-glass).
- A migration project (§14), per kind, with soak periods — not a flip-a-switch change.

**Neutral**
- The DB is not removed; it keeps the entire data plane and (via read-through projection) can keep serving legacy Python reads of migrated kinds indefinitely.

---

## 17. Residual risks (honest, not deferred silently)

1. **Immutability vs erasure edge case.** If PII ever slips past the entry gate (§10), git's strength becomes a liability — remediation is a controlled history-rewrite + rotation incident. Mitigation is prevention-at-entry + defense-in-depth scanning; the residual is real and named.
2. **Split-brain during migration** is prevented *by policy* (`authority` flag, revoked DB grants §14). A bug that lets both stores be written for one kind reintroduces the exact multi-source problem this ADR exists to kill — the per-kind grant revocation is what makes it mechanical rather than trusted, and must be verified in the migration acceptance suite (test 15).
3. **Hot-reload trust surface.** The webhook/file-watch path must itself be authenticated and the reload must re-verify signatures + lockfile every time (§6.2) — a reload that trusts the trigger instead of re-verifying the bytes would be a soft path around §9.
4. **Studio-as-git-client latency.** Authoring-by-conversation must produce a real PR through real review; if that feels slow, teams will pressure for a "quick publish" side door — which must be refused (it is the DB failure mode returning). The mitigation is fast CI + a good PR-authoring UX, not a bypass.
5. **CODEOWNERS drift.** Authoring RBAC is only as correct as CODEOWNERS is maintained; a stale CODEOWNERS file is stale authoring RBAC. It should itself be a reviewed, owned definition (it is — it lives in the control repo under review).
6. **Large binary attachments.** Execution-skill `run.wasm` blobs and prompt-attachment binaries bloat git; large artifacts should use git-LFS or an object-store-by-hash reference pinned in `control.lock`, not raw git blobs — a build-maturity concern flagged now.
7. **Reload-validation cost as a DoS surface.** Incremental validation (§6.2) bounds reload cost to the changed set in the common case, but a push whose changed set is made artificially large — a fanned-out PR touching thousands of definitions, or a script generating many distinct tiny diffs in rapid succession — can still drive repeated expensive per-definition checks (live schema introspection, attestation-list lookups) faster than legitimate authoring ever would. The cooldown floor (§6.2) bounds *how often* a build runs, not *how expensive one build can be* if a single push's changed set is unusually large; a determined internal actor with push access to a feature branch is a distinct risk from the external-attacker case CODEOWNERS/branch-protection already cover. Mitigation is the cooldown plus a hard cap on changed-set size per single reload (an oversized push is rejected and must be split across multiple PRs, itself a CI-enforced, reviewable check) — the residual is that this cap is a policy knob this design specifies but has not yet been sized from production load data (acceptance test 19, §15, exercises the legitimate-burst case; the cap itself is a follow-on sizing exercise, not yet numerically fixed).

---

## 18. Self-score (honest)

**Design ceiling: 9.5 / 10.** Every claim in the decision has a concrete enforcement mechanism (a hook, a schema gate, a signature check, a lockfile hash, an atomic swap, a per-kind authority flag) and an acceptance test that exercises exactly the property that matters — the house bar. The split is principled (an invariant, §3), the governance mapping is complete (§7), author-vs-execute RBAC is cleanly orthogonal (§8), and the hardest constraint (DPDP erasure vs git immutability) is met head-on by gating entry rather than pretending erasure is possible (§10). It reconciles the DB-source-of-truth rule without violating its spirit (§13) and stages the strangler-fig migration without split-brain (§14).

The missing half-point is honest: the DPDP invariant leans on detector recall at commit-entry (residual 1), and the anti-split-brain and anti-side-door guarantees are *policy + grant* mechanisms that a determined implementer could still subvert (residuals 2, 4) — those are enforcement surfaces this design specifies but cannot itself prove hold until built. **Build maturity: 0 / 10** — no code exists, consistent with every other artifact in this corpus. The ceiling is set correctly so implementation can only descend from a real 10-shaped target.
