# ADR-018 — Model Governance: OSS-Weight Licensing/Field-of-Use + Nation-of-Origin Sovereignty Gates in the Model Router

**Status:** Accepted — Design only (no code). Closes Pass-5 gaps **[5] OSS weight licensing / field-of-use** and **[14] nation-of-origin / sovereignty routing gate** (`GAP_ANALYSIS_PASS5.md`). Consolidates the two provenance gaps the gap analysis tagged loosely (5 → "ADR-007 ext", 14 → "ADR-006 ext"; `REGULATED_FI_COMPLIANCE_OPS.md` §4.2 calls the latter "the sovereignty gate ADR-006-ext") into **one** Model-Governance decision, because both are properties of a **weight**, not of a data path, and both enforce at the **same** router seam.

**Decision class:** Architecture-defining, additive. Adds **two non-overridable exclusion gates** into the Model Router's candidate-selection pipeline (ADR-012 / `TOOLING_MCP_PLUGINS_ROUTING.md` §4.1), sitting **underneath** the existing data-class → model-eligibility gate — it never replaces or relaxes that gate, only adds two further preconditions a route must also clear. It is the self-hosted-weight complement to the external-provider Outsourcing Register (ADR-017 / `REGULATED_FI_COMPLIANCE_OPS.md` §3): the register governs providers that data *leaves the boundary* to reach; this ADR governs the weights we *self-host*, which ship no data out and are therefore invisible to that register yet carry license and origin risk it was never designed to catch.

**Relates to / extends:** ADR-001 (strangler-fig Rust sidecar — the Model Router is a Rust-native control-plane component the sidecar owns), ADR-002 (Tool+MCP Runtime — `model.infer` is a governed capability in the one `CapabilityRegistry`), ADR-003 (Policy/Approval/Compliance seam — the per-turn authz engine these gates run inside), ADR-007 (execution Event-Log — where the governing license id + weight digest of every inference are recorded), **ADR-012 (data-class → model routing — the router this ADR plugs two new exclusion steps into; ADR-018 never weakens it)**, ADR-015 (retention/erasure — the reason both registers must be PII-free), ADR-016 (agent-payment boundary — the class the origin gate keys on: an untrusted-origin weight is structurally `payment_boundary_eligible: false`), ADR-017 / `REGULATED_FI_COMPLIANCE_OPS.md` §3 (the Outsourcing Register — the external-provider analogue this complements without overlap), ADR-020 / `SERVING_OPS.md` §5 (weight rollout + signed weight manifest — the source of the `weight_digest` these gates key on), ADR-021 (Hardware-Trust/TEE — the node-level attestation gate that composes beneath these two), ADR-025 (evidentiary admissibility — the procurement/trusted-source dossier must be court-grade), **ADR-026 (Control-Plane Git-Native, Q2 — both registers are versioned control-plane definitions, never DB rows)**, **ADR-027 (Long-Horizon Programs, Q1 — re-validation-on-version-bump, trusted-source procurement onboarding, and a forced model-exit are Programs, not single Runs)**. Reconciles the standing **model-agnostic mandate** (`feedback_model_agnostic.md`) with the reality that "agnostic where safe" is not "unconditional," and layers a conditional, versioned governance tier above the coarse `BLOCKED_MODELS` denylist (`core/model_registry.py`).

**The two binding cross-cutting decisions, honored explicitly:**
- **[Q2 — ADR-026, Control-Plane Git-Native]:** the **License Register** and the **Origin Register** are **control-plane definitions** — Markdown-with-front-matter files in `ainxt-control`, CODEOWNERS-governed, signed, content-addressed, all-or-nothing loaded, air-gap-clean by construction (§4). A license determination and a trusted-source designation are review-governed, versioned, PII-free, never-erased legal facts — precisely ADR-026's "definition" column. Every live routing number (platform MAU, per-route counts) is data-plane state (§5). One source each, split on ADR-026's exact axis.
- **[Q1 — ADR-027, Long-Horizon Programs]:** onboarding a new weight through legal + security re-validation, procuring a trusted-source designation, and executing a **forced model-exit** on a sovereignty veto are all **Programs** — checkpointed, restart-safe, able to ship a partial cutover (§7). A version bump is never a "flip a flag" moment; it is a scheduled Program whose completion is the precondition for the new digest becoming routable.

---

## 1. Context — self-hosting OSS weights solved data residency and created two new risks that live on the weight, not the data path

ADR-012 made the Model Router a **compliance component**: regulated-payment and PII data may route **only** to in-house-hosted OSS models (Qwen / GLM / Kimi / Gemma / Llama fleet), because the eligible set for those data classes is empty without self-hosting (`TOOLING` §4.2). That decision is correct and load-bearing — it is *why* the OSS fleet exists. But it solved a **data-residency** problem and, in doing so, created two problems that are properties of **the weight itself**, and that no existing gate owns:

**(a) Licensing / field-of-use — an OSS weight is not "free to do anything."** "Open weights" is not "public domain." The fleet's licenses are a patchwork of custom, conditional, and version-varying terms with **zero indemnity** — no vendor stands behind an OSS weight the way a negotiated cloud contract (governed by the §3 Outsourcing Register) stands behind a hosted API:
- **Gemma** ships under Google's custom *Gemma Terms of Use* (not OSI-approved), which incorporate an **updatable Prohibited-Use Policy by reference**, impose **downstream pass-through** of the use restrictions, require attribution, and reach **hosted/remote-access** uses — the exact deployment mode this platform is.
- **Llama** ships under the custom *Llama Community License*: an **acceptable-use policy**, a naming/attribution obligation, and a **700M-MAU commercial trigger** above which a separate license from the licensor is required.
- **Qwen / GLM / Kimi** carry **custom or version-varying** terms (some sizes/versions permissive-OSI, others source-available-with-conditions; some carry their own MAU/revenue attribution triggers) — the terms are **not stable across versions**, so a determination made for one checkpoint does not carry to the next.
- **Bundling many such weights under one AiNxt brand** can silently breach attribution and field-of-use terms (gap 5) — one un-propagated NOTICE, one hosted-use clause missed, one MAU trigger crossed.

**(b) Nation-of-origin / sovereignty — a signed weight is still an untrusted-origin weight.** Qwen (Alibaba), GLM (Zhipu AI), and Kimi (Moonshot AI) are **PRC-origin**. For the runtime of **India's national payment switch**, running an adversary-jurisdiction-origin model in the **cardholder / settlement path** is a national-security exposure that is **independent of the weight's technical quality and even of its cryptographic signature** (gap 14). RBI/MeitY hold a plausible national-security veto over such a route. The subtle, load-bearing point: **cryptographic signing proves byte-integrity and publisher-provenance; it does not change the nation that trained the bytes.** A perfectly signed Qwen weight is still a PRC weight.

**Why no existing gate closes this:**

| Existing gate | What it governs | Why it misses gaps 5 & 14 |
|---|---|---|
| **Data-class gate (ADR-012 §4.2)** | *May this data-class reach this model-identity?* | Has no notion of a weight's **license** or **nation-of-origin**. It correctly routes regulated data to the in-house fleet — and then has nothing to say about *which* in-house weight's license permits the use, or whether its origin is trusted for a payment path. |
| **Outsourcing Register (ADR-017 §3)** | *External* providers, because data **leaves the boundary** | A self-hosted OSS weight ships **no data out**, so the Outsourcing Register never sees it — yet it carries license + origin risk. This ADR is the mirror-image register for the inbound-weight case. |
| **`BLOCKED_MODELS` (`core/model_registry.py`)** | A flat model-id **denylist** | Cannot express **conditional** field-of-use ("prohibited only above 700M MAU", "trusted only for internal traffic"), cannot **re-validate on a version bump**, and cannot distinguish "blocked for regulated-payment" from "blocked everywhere." |
| **Serving-Ops weight signing (ADR-020 §5)** | *Are these the exact bytes the publisher released, on trusted hardware?* | Proves integrity + provenance-of-bytes. Says nothing about license terms or nation-of-origin (§6.2). |

Two gaps, both properties of the weight, both enforceable at exactly one seam — the router's "exclude, then rank" phase. This ADR adds that missing model-provenance discipline.

---

## 2. Decision

**Add two non-overridable exclusion gates to the Model Router, each backed by a control-plane register.**

- **The License Register** — one control-plane definition per **weight-version** (`models/license/<family>@<version>/definition.md`, per ADR-026), capturing license family/text, field-of-use permits/denies, conditional usage triggers (MAU/revenue), hosted/remote-access clauses, attribution/NOTICE obligations, indemnity status, and a **`weight_digest` binding** to the exact bytes (§4).
- **The Origin Register** — one control-plane definition per weight-version (`models/origin/<family>@<version>/definition.md`), capturing developing entity, **nation-of-origin and ultimate corporate-control nation**, an origin-trust tier, and a **trusted-source procurement designation** modeled on India's NSDTS telecom "trusted-source" regime (§4, §6.3).
- **Gate A — Licensing / field-of-use.** At candidate selection, any self-hosted weight whose license **prohibits the current use** (deployment mode, output use, redistribution, or a crossed usage trigger) is **excluded before ranking and before failover**. Applies to **all** self-hosted weights. Non-overridable.
- **Gate B — Nation-of-origin / sovereignty.** For any request whose data-class ∈ {regulated-payment, PII, cardholder} **or** whose harness/task crosses the ADR-016 payment boundary, every candidate whose origin-trust tier is not `trusted` (or lacks a valid, unexpired trusted-source designation) is **excluded** — **regardless of the weight's signature validity** (§6.2). Untrusted-origin weights keep serving public/internal traffic. Non-overridable.
- Both gates slot into the router's exclusion phase (§3), both **pre-filter the failover chain**, both **fail closed** on an empty eligible set — identical discipline to ADR-012 §4.2. **A user's explicit model selection is a rank-preference input, never an override of an exclusion gate.**
- **NOTICE propagation** (§8) and **re-validation-on-version-bump** (§7) are enforced mechanisms — a build fails without the required NOTICE; a new digest is un-routable until its records land.

---

## 3. Where the two gates slot into the router pipeline — the ordering is the design

ADR-012 / `TOOLING` §4.1 defines the router as "exclude what is not allowed, then rank what remains." This ADR inserts two exclusion steps into that pipeline. The full, extended selection order:

```
1. tier_eligible    = models matching the task-type's policy tier (CLAUDE.md model table)
2. class_eligible   = tier_eligible ∩ {allowed for this turn's data class}       ← ADR-012 §4.2
                        (external routes additionally filtered by the Outsourcing Register, ADR-017 §3.2)
3. license_eligible = class_eligible ∩ {weights whose license permits this use}   ← GATE A, §5   [NEW]
4. origin_eligible  = license_eligible ∩ {origin-trusted for this path}           ← GATE B, §6   [NEW]
5. not_regressed    = origin_eligible ∩ {not currently quality-flagged}           ← quality scoreboard §4.3
6. rank(not_regressed) by (quality, -cost, -latency); user selection is a preference weight here
7. select top; on failure walk the FAILOVER CHAIN — itself pre-filtered to steps 2–4
```

**Why this order:**
- Gates A and B are **exclusions** (they narrow the allow-set), so they belong in the exclusion phase (steps 2–4), **before** ranking (step 6) and **before** the user-preference weight can touch anything. This is the same reason ADR-012's data-class gate is step 2, not a ranking tiebreak.
- Gate B runs **after** the data-class gate (step 2) because the origin gate's severity is a *function of the data-class already computed*: origin exclusion applies only on regulated/payment paths, which step 2 has already classified. Running Gate B against an unclassified request would be undefined.
- **The failover chain is pre-filtered to steps 2–4 at construction time**, not checked ad hoc during failover — there is no code path where walking the chain can reach a data-class-excluded, license-prohibited, or origin-untrusted model. Same guarantee ADR-012 §4.4 makes for the data-class line, extended to the two new lines.
- **Non-overridable, restated as a hard invariant:** there is no user-facing or harness-facing "use it anyway" path around steps 3 or 4. A user's explicit pick (`gpt-5-5`, `claude-opus-4-7`, or a specific OSS weight) is a **preference input to step 6** — it can reorder the eligible set, never re-admit an excluded one. A regulated-classified turn cannot select a license-prohibited or PRC-origin weight through any surface.

---

## 4. The two registers as control-plane git definitions (Q2 / ADR-026)

**Why git, not Postgres, not code.** A license determination and a trusted-source designation are **review-governed, versioned, PII-free legal facts that must never be erased** — the audit record of what the organization determined about a weight it runs. That is exactly ADR-026's "definition" column: they must be reviewed and diffed like code (a legal re-read of a new license is a diff), rolled back (a mistaken designation is a `git revert`), attributed (who signed off that a PRC weight is trusted, and on what evidence), and never erased (a regulator asks "why was this weight routable in March"). Storing them as mutable Postgres rows would reintroduce the exact single-reviewer, un-diffable, erasable failure mode ADR-026 exists to kill. So both registers inherit ADR-026 wholesale: CODEOWNERS authoring-RBAC, signed commits, all-or-nothing content-addressed load, and air-gap-clean bundle transfer (§10).

**CODEOWNERS (authoring RBAC per ADR-026 §8):**
```
/models/license/    @oss-counsel @platform-leads         # legal determination + eng review
/models/origin/     @security-council @board-delegate    # sovereignty is a board-level risk (2 groups)
```
An engineer cannot self-certify a weight's license or its nation-of-origin trust; the merge is blocked without the accountable group's signed approval. A weight can be *fetched and eval'd* on a feature branch, but it becomes *routable* only when both records are merged, tagged, and promoted onto `env/prod` — the same author-vs-execute orthogonality as ADR-026 §8.

### 4.1 License Register — front-matter schema

```yaml
---
kind: model-license
id: model-license.qwen3-32b@3.0.0        # kind-prefixed, immutable, version-pinned slug
weight_digest: "sha256:9f3c…"            # binds THIS record to THESE exact bytes (§7)
model_family: qwen3
model_version: "3.0.0"
license_name: "Apache-2.0"               # SPDX id if OSI; else the custom license's exact name
license_class: permissive-osi            # permissive-osi | source-available-conditional | research-only | proprietary
license_text_ref: licenses/qwen3-3.0.0.txt   # the verbatim license text, versioned beside this file
osi_approved: true
field_of_use:                            # the permit/deny predicates Gate A evaluates (§5)
  commercial_use: allow
  hosted_inference: allow                # Gemma's remote-access clause ⇒ conditional | deny here
  redistribution_of_weights: allow       # gates the air-gap-bundle / desktop-distribution path (§5)
  output_use_restrictions: []            # e.g. "outputs may not train a competing model" (distillation)
usage_triggers:                          # conditional terms that flip allow→deny/condition at a threshold
  - { metric: mau, threshold: 700000000, effect: requires_special_license }   # Llama-style
  - { metric: revenue_monthly_usd, threshold: 20000000, effect: attribution_required } # Kimi-style
attribution:                             # NOTICE-propagation obligations (§8)
  notice_required: true
  display_string: "Built with Qwen"
  aup_ref: "https://…/prohibited-use"    # incorporated-by-reference AUP (Gemma) — updatable upstream
  aup_pinned_hash: "sha256:1a2b…"        # TOFU-pin the AUP; a silent upstream change ⇒ diff-and-re-approve (§7)
indemnity: none                          # OSS weights carry ZERO indemnity — recorded, feeds Model-Risk (§9)
license_review_ref: "LEGAL-4821"         # the counsel determination this record encodes
reviewed_by: oss-counsel
---
# Qwen3-32B @ 3.0.0 — license determination (body: counsel's reasoning, the reviewed substance)
```

### 4.2 Origin Register — front-matter schema

```yaml
---
kind: model-origin
id: model-origin.qwen3-32b@3.0.0
weight_digest: "sha256:9f3c…"            # same binding — origin is a property of these exact bytes' provenance
model_family: qwen3
developing_entity: "Alibaba Cloud"
entity_nation: CN
corporate_control_nation: CN             # ULTIMATE beneficial control, not merely HQ/registration
training_provenance: partial             # known | partial | opaque
origin_trust_tier: untrusted             # trusted | conditional | untrusted   ← Gate B keys on THIS, never on signing
trusted_source_designation:              # RBI/MeitY 'trusted-source'-style procurement evidence (§6.3)
  status: none                           # designated | pending | none | denied
  authority: ""                          # e.g. NCSC/MeitY-designated — modeled on the NSDTS telecom regime
  evidence_ref: ""                       # procurement dossier id (ADR-025 court-grade)
  expires: ""
signing_status: signed                   # BYTE-integrity (ADR-020 §5) — ORTHOGONAL to origin trust (§6.2)
max_data_class_for_untrusted: internal   # untrusted/conditional origin ceiling: NEVER regulated-payment/PII/cardholder
payment_boundary_eligible: false         # structurally barred from ADR-016 payment-initiating paths
reviewed_by: security-council
board_delegate_ack: ""                   # required to promote an origin_trust_tier: trusted PRC-origin weight
---
# Qwen3-32B @ 3.0.0 — origin & sovereignty determination (body: the security-council reasoning)
```

**Schema rules enforced by CI + loader (not convention), per ADR-026 §5:**
- `weight_digest`, `model_family`, `model_version`, and (license) `license_class` / (origin) `origin_trust_tier` are **required**; a missing field fails CI and fails load.
- A weight whose Serving-Ops manifest digest (ADR-020 §5) has **no** matching `model-license` **and** `model-origin` record is **un-routable** — the loader marks it ineligible for every request (fail-closed; "no ungoverned weight," mirroring §3.2's "no ungoverned outsourcing").
- Promoting an `origin_trust_tier: trusted` record for a weight whose `corporate_control_nation` is a designated-adversary jurisdiction additionally requires a non-empty `trusted_source_designation.status: designated` **and** `board_delegate_ack` — CI blocks otherwise. Sovereignty trust cannot be quietly asserted by an engineer.

---

## 5. Gate A — Licensing / field-of-use (mechanism)

At candidate selection (step 3), for each self-hosted candidate weight the gate resolves the **actually-loaded weight's digest** from the Serving-Ops signed manifest (ADR-020 §5), looks up its `model-license` record **by digest** (§7), and evaluates the request context against `field_of_use` + `usage_triggers`:

1. **Deployment-mode check.** Is this a hosted-inference / remote-access use the license restricts? A weight whose `field_of_use.hosted_inference != allow` is excluded for served-inference traffic (this is the Gemma remote-access clause made mechanical).
2. **Output-use check.** Does the task's output use violate an `output_use_restrictions` clause? The load-bearing case is the **eval/distillation pipeline**: a weight whose license forbids using its outputs to train a competing model is excluded from any route whose *purpose* is synthetic-data or distillation generation — a restriction a data-class gate could never see because it is about *what the output is for*, not *what the input contained*.
3. **Usage-trigger check.** The gate compares each `usage_triggers` metric against a **live platform-scale signal** (data-plane: current platform MAU, per-route monthly revenue attribution) — so the platform cannot **silently cross** a 700M-MAU or a revenue threshold and keep routing a now-non-compliant weight. Crossing a `requires_special_license` trigger excludes the weight until a new license record (recording the special license) lands; crossing an `attribution_required` trigger flips on the per-output NOTICE obligation (§8) rather than excluding.
4. **Redistribution check.** If the route's effect **distributes** the weight (an air-gap bundle export §10, a bundled desktop artifact) rather than merely serving inference, the stricter `redistribution_of_weights` clause is evaluated — a weight that may be *served* but not *redistributed* is excluded from a distribution route while remaining eligible for served inference.

**Outcomes:** a weight with no license record → excluded (fail-closed). A prohibited field-of-use → excluded before ranking and removed from the failover chain. **No override path.** The governing `license.id` + `weight_digest` are written to the **Event Log (ADR-007)** beside the route decision, so "which license governed this exact inference, and on which bytes" is reconstructable for audit two years later.

---

## 6. Gate B — Nation-of-origin / sovereignty (mechanism)

### 6.1 The gate
For a request whose data-class ∈ {regulated-payment, PII, cardholder} **or** whose harness/task crosses the ADR-016 payment boundary, Gate B excludes every candidate whose `origin_trust_tier != trusted` **or** which lacks a valid, unexpired `trusted_source_designation`. Untrusted-origin weights are **not removed from the fleet** — they keep serving public/internal traffic (they are excellent models; this is a sovereignty judgment, not a quality one). A sovereignty exclusion **narrows the regulated-eligible set only**, never the whole fleet — the exact discipline ADR-021 §8.2 uses when a node's attestation lapses (it drains from the regulated pool, keeps serving public/internal).

### 6.2 Signing ≠ origin-trust — the orthogonality that makes this correct
This is the single most important correctness point in the ADR, and it is stated as a hard separation because conflating the two questions is precisely how gap 14 is reintroduced:

| | **Signature / attestation** (ADR-020 §5, ADR-021) | **Nation-of-origin trust** (this gate) |
|---|---|---|
| Question | *Are these the exact bytes the publisher released, loaded inside a currently-attested enclave?* | *Do we trust the **nation and ultimate corporate control** that trained these bytes, for a **regulated payment** path?* |
| Proves | integrity + byte-provenance + publisher identity + trusted hardware | a **sovereignty** judgment about the weight's origin — it proves *nothing* about integrity |
| A **signed PRC weight** | **passes** (the bytes are authentic and unaltered) | **still fails** — signing a PRC weight does not make it non-PRC |

The gate therefore keys **only** on `entity_nation` / `corporate_control_nation` / `origin_trust_tier` — **never** on `signing_status`. Signature verification remains **required** (ADR-020 §5 refuses an unsigned or tampered weight at load) but is **necessary-and-insufficient**: a weight must be signed *and* origin-trusted to reach a regulated path. A design that let a valid signature imply routing-trust would be the exact error the gap names — "a signed weight is still PRC-origin."

### 6.3 The trusted-source designation
`origin_trust_tier: trusted` for an adversary-jurisdiction weight is earned, not asserted. It is modeled on India's **National Security Directive on the Telecommunication Sector (NSDTS, 2021)** "trusted-source / trusted-product" regime administered by the National Cyber Security Coordinator — extended **by analogy** to model weights entering regulated payment paths (a formal MeitY/RBI regime for AI weights does not yet exist at design time; the design provisions for it and defaults conservative until it does). A weight becomes `trusted` only with a **procurement dossier** (`trusted_source_designation.evidence_ref`, court-grade per ADR-025) signed off by the designated authority (interim: security-council + board-delegate). **In-house-trained weights** and weights from **trusted jurisdictions** may be pre-designated `trusted`; **PRC-origin weights default to `untrusted`**, and a signature cannot upgrade them (§6.2). The designation carries an `expires` date — a lapsed designation reverts the weight to `untrusted` (fail-safe), draining it from regulated paths until re-designated (a Program, §7).

### 6.4 Fail-closed on an empty set
If Gates A+B leave the regulated-eligible set empty for a turn (e.g., the only in-house models strong at a task are all PRC-origin), the router **fails closed** exactly as ADR-012 §4.2: it returns the best trusted-in-house-eligible answer with an explicit low-confidence flag, queues, or refuses with a sovereignty reason — it **never** falls back to an untrusted-origin weight because that one is the only capable candidate. **Named residual (§13):** this can degrade regulated-path quality; the honest mitigation is investing in trusted-origin and in-house-trained weights, not relaxing the gate. A fleet whose only good models for a regulated task are adversary-origin is a **procurement problem to fix, not a gate to weaken.**

---

## 7. Weight-digest binding + re-validation on version bump (Q1 / ADR-027)

**The binding — the router never trusts a model-id string.** Both registers key on `weight_digest` (sha256 of the weight artifact). At selection the router resolves the digest of the **actually-loaded** weight from Serving-Ops's signed manifest (ADR-020 §5) and looks up license + origin **by digest**. A model-id string with no matching-digest records is un-routable. This defeats the "the id says `qwen3-32b` but the loaded bytes are a different, differently-licensed, or re-quantized checkpoint" substitution — the governance follows the **bytes**, not a mutable label.

**Re-validation on version bump — a Program, not a flag.** A new checkpoint (a version upgrade, a fine-tune, a re-quantization) has a **new digest** → **no** license/origin record → **un-routable** until a re-validation Program (ADR-027) completes:
1. Fetch the new weight; Serving-Ops verifies signature + computes digest (ADR-020 §5).
2. **Legal re-review** — a *license diff* against the prior version. This is not ceremony: license terms genuinely change across versions (GLM moved from a custom license to MIT between releases; a Qwen size that shipped custom-licensed became Apache in a later release; a Gemma Prohibited-Use-Policy revision). The new `model-license` record encodes the *current* terms, never the inherited ones.
3. **Security re-review** — origin unchanged? Any change in ultimate corporate control? Does an existing trusted-source designation still apply, or must it be re-procured?
4. **NOTICE regeneration** (§8) from the new records.
5. **Two PRs** (license + origin) through their CODEOWNERS gates; the Serving-Ops rollout (ADR-020 §5 canary) **additionally refuses to admit** the new digest to *user* traffic until both records are green — so a new weight can be **loaded for eval** but never **routed to users** until governed.

Because it is a Program, a fleet-wide re-validation across many co-hosted weights checkpoints, resumes, and can **ship partial** (the re-validated subset goes live; the rest stays on the prior digest) rather than an all-or-nothing scramble.

**AUP drift (the Gemma case).** A Prohibited-Use Policy incorporated by reference is **updatable by the publisher after the fact**. Its hash is **TOFU-pinned** (`aup_pinned_hash`) in the license record; a periodic re-fetch compares the live hash to the pin, and a mismatch raises a **diff-and-re-approve** PR — the same supply-chain discipline as the §3.3 sub-processor drift check and ADR-026 §11 marketplace rug-pull. A silently-tightened AUP that would prohibit a use we currently route is caught, not trusted.

---

## 8. NOTICE propagation (closing "bundling under one brand may breach terms")

Every routable weight's `attribution` obligations are aggregated — **generated from the License Register, so it can never drift from what is actually deployed** — into a versioned `THIRD_PARTY_MODEL_NOTICES` artifact that is enforced at three points:
- **Served surface:** the platform's about/legal surface renders the current NOTICE set (Built-with strings + retained license texts for every live weight).
- **Distribution build (hard gate):** any distributed artifact (desktop app, air-gap bundle §10) that **includes** a weight must include that weight's NOTICE and license text; the build **fails** otherwise. This is the mechanical answer to gap 5's "bundling under one AiNxt brand may breach terms" — you cannot ship a bundle that drops a required NOTICE.
- **Per-output attribution (conditional):** when a license's `usage_triggers` has flipped `attribution_required` on (Kimi-style UI-attribution-above-threshold), a response produced by that weight carries the attribution in its provenance metadata — driven by the same live-metric signal Gate A uses (§5 step 3), so the obligation switches on automatically at the threshold rather than relying on someone remembering.

---

## 9. Composition — one exclusion phase, one source per fact, no overlap

| Concern | Owned by | Relationship to ADR-018 |
|---|---|---|
| Data-class → model-identity eligibility | ADR-012 §4.2 | ADR-018's gates run **underneath** it (steps 3–4 after step 2); never relaxed. |
| **External-provider** governance (data egress) | Outsourcing Register, ADR-017 §3 | **Clean division of labor:** §3 governs providers data *leaves the boundary* to reach; ADR-018 governs *self-hosted weights* that ship no data out. A cloud route hits §3; a self-hosted OSS route hits ADR-018; **both feed the same router exclusion phase.** No overlap, no gap. |
| Weight **signature + attestation** | Serving-Ops, ADR-020 §5 / ADR-021 | Serving-Ops proves "right bytes, trusted hardware" and **exposes the digest**; ADR-018 consumes that digest to ask "may these bytes' license + nation serve this request." Necessary-and-complementary; §6.2 keeps them orthogonal. |
| **Model-Risk Record / algorithmic due-diligence** | `REGULATED_FI_COMPLIANCE_OPS.md` §4.2 (gap P) | The license `indemnity: none` and the origin `trust_tier` are **inputs** to the Model-Risk Record; ADR-018 is the *enforcement*, the Model-Risk Record is the *DPO-facing due-diligence narrative*. One source (the registers), two consumers. |
| **Payment boundary** | ADR-016 | An untrusted-origin weight is structurally `payment_boundary_eligible: false`; Gate B's regulated-path definition **includes** the payment boundary, so a PRC-origin weight can never sit behind a payment-initiating role even under a future misconfiguration. |
| Coarse operational denylist | `BLOCKED_MODELS` (`core/model_registry.py`) | Stays as a fast short-circuit (a `BLOCKED_MODELS` hit excludes as today); ADR-018's registers are the **conditional, versioned, field-of-use-aware** layer above it, expressing everything the flat list cannot. |

---

## 10. Air-gap / sovereign deployment

- **Both registers are PII-free control-plane definitions**, so they cross the air-gap boundary as a **signed `git bundle`** (ADR-026 §12) — a sovereign NPCI zone runs the **same** license + origin governance with **no** live connection. The trusted-source dossiers and the in-zone signing keyring travel in the bundle.
- **The origin gate matters *more* in a sovereign deployment, not less** — an air-gapped national-payment zone is precisely where a PRC-origin weight in the settlement path is the worst exposure, and precisely where "we already vetted it centrally" is least verifiable without the register present. Because the register is in the bundle, the in-zone router enforces Gate B identically.
- **The distribution NOTICE gate (§8) runs on the bundle build** — an air-gap export that includes weights fails unless every included weight's NOTICE + license text is present. Sovereignty and licensing compliance travel *with* the weights, by construction.

---

## 11. Alternatives considered

1. **Extend the flat `BLOCKED_MODELS` denylist.** Rejected: it cannot express **conditional** field-of-use (blocked only above 700M MAU; trusted only for internal traffic), cannot **re-validate on a version bump** (a new digest inherits nothing), and cannot distinguish "blocked for regulated-payment" from "blocked everywhere." A flat list is the wrong shape for conditional, versioned, path-scoped facts.
2. **Governance-by-binder — a legal spreadsheet + an out-of-band review checklist.** Rejected for the exact reason the Outsourcing Register (ADR-017 §3) rejects it: a register that is **not the router's input** is describable-after-the-fact, not preventive. If wiring a weight without a review is "a violation caught in audit" rather than "the weight cannot route," it will happen. Enforcement must be a **selection precondition**, not a document.
3. **Store the registers as Postgres rows.** Rejected per ADR-026 (Q2): a license determination and a trusted-source designation are review-governed, versioned, PII-free, never-erased legal facts = **definitions**, which belong in git with CODEOWNERS + signed history, not in a mutable, single-reviewer, erasable table.
4. **Trust cryptographic signing/attestation as sufficient for origin.** Rejected — this is the precise error gap 14 warns against (§6.2): signing proves the *bytes*, not the *nation*. A signed PRC weight is still PRC-origin. Signing is kept as a *necessary* precondition (ADR-020 §5) but is explicitly *insufficient* for a regulated path.
5. **Rely on the ADR-012 data-class gate alone.** Rejected: it governs data→model-identity and has no notion of license or origin; and because a self-hosted weight ships no data out, the ADR-017 outsourcing register never sees it either — leaving both gaps wholly unowned. The two gates exist to fill a seam **between** two already-designed gates.
6. **Block all PRC-origin weights fleet-wide.** Rejected: they are high-quality and legitimately usable for public/internal traffic; a blanket ban wastes capability and pushes engineers to shadow-AI (Pass-5 gap 29), undermining the model-agnostic mandate where it is *safe*. The gate is deliberately **path-scoped** (regulated/payment only) — sovereignty-strict where it must be, agnostic where it can be.

---

## 12. Acceptance / scenario tests

| # | Scenario | Setup | Expected | Proves |
|---|---|---|---|---|
| 1 | Ungoverned weight is un-routable | A weight is loaded whose digest has no `model-license` **or** `model-origin` record | The loader marks it ineligible for every request; the router never selects it | "No ungoverned weight" — fail-closed, mirroring §3.2 |
| 2 | License prohibits hosted use | Gemma-class weight with `hosted_inference: deny` is a candidate for served inference | Gate A excludes it before ranking and from the failover chain | Field-of-use (deployment mode) enforced at selection, not audited later |
| 3 | MAU trigger crossed | Platform MAU signal exceeds a weight's `usage_triggers` 700M `requires_special_license` threshold | The weight is excluded until a new license record recording the special license lands | Conditional triggers evaluated against a live signal; no silent crossing |
| 4 | Output-use / distillation restriction | A distillation route targets a weight whose license forbids training a competing model on its outputs | Gate A excludes it for that *purpose*, while the same weight stays eligible for ordinary inference | Output-use restriction — a class the data-class gate cannot see |
| 5 | Signed PRC weight on a regulated path | A cryptographically **valid, signed** Qwen weight is a candidate for a `regulated-payment` turn | Gate B excludes it **despite** the valid signature; routes to a trusted in-house weight or fails closed | §6.2 — signing ≠ origin-trust; the core of gap 14 |
| 6 | PRC weight on public traffic | The same Qwen weight is a candidate for a `public` turn | Gate B does **not** exclude it; it is eligible and rankable | The gate is path-scoped — agnostic where safe (alt. 6) |
| 7 | Trusted-source designation earns regulated eligibility | An origin record flips to `origin_trust_tier: trusted` with a valid dossier + `board_delegate_ack` | The weight becomes regulated-eligible; the promotion required the security-council + board-delegate CODEOWNERS + a non-empty dossier | §6.3 designation is earned via reviewed procurement evidence, not asserted |
| 8 | Designation expiry fails safe | A `trusted` designation passes its `expires` date | The weight reverts to `untrusted`, is drained from regulated paths, keeps serving public/internal | Lapsed trust fails safe, not open |
| 9 | Digest binding defeats id substitution | The loaded bytes differ from the record's `weight_digest` but the model-id string matches | The router treats it as ungoverned (test 1) — governance follows bytes, not the label | §7 digest binding |
| 10 | Version bump is un-routable until re-validated | A new checkpoint (new digest) is loaded with no new records | It may be loaded for eval but is never routed to users; the rollout canary refuses user admission until both records are green | §7 re-validation-on-version-bump as an ADR-027 Program |
| 11 | License change across versions | The new version's license differs from the prior (e.g., custom→MIT) | The new `model-license` record encodes the *current* terms; the old record's terms do not carry over | §7 — terms are re-determined per version, never inherited |
| 12 | AUP drift caught | An incorporated-by-reference Prohibited-Use Policy changes upstream | The pinned-hash re-fetch mismatches → a diff-and-re-approve PR; until re-approved the affected uses are restricted | §7 TOFU-pin on the AUP |
| 13 | NOTICE required in a distribution build | An air-gap bundle includes a weight but omits its required NOTICE/license text | The bundle build **fails** | §8 NOTICE propagation as a hard build gate; closes gap 5's bundling risk |
| 14 | No user override of an exclusion gate | A user explicitly selects a license-prohibited (or PRC-origin, on a regulated turn) weight | The router refuses; the selection is a rank preference (step 6), never a re-admit of an excluded model | §3 non-overridability |
| 15 | Empty regulated-eligible set fails closed | Every capable in-house model for a regulated task is PRC-origin | The router returns the best trusted-eligible answer with a low-confidence flag / queues / refuses — never falls to an untrusted-origin model | §6.4 fail-closed; the residual is a procurement problem, not a gate to weaken |
| 16 | Air-gap parity | The control repo is delivered to a sovereign zone as a signed `git bundle` | The in-zone router enforces Gates A + B identically against the in-zone keyring, no egress | §10 — governance is air-gap-clean because the registers are PII-free definitions |
| 17 | Audit reconstruction | A regulator asks "which license and which exact weight governed this inference two years ago" | The Event-Log record beside the route decision yields `license.id` + `weight_digest`; the git history yields who approved both records and why | §5 + §4 two-trail audit (authoring in git, execution in the Event Log) |
| 18 | Clean division with the outsourcing register | One turn routes to a cloud provider, another to a self-hosted OSS weight | The cloud turn is gated by ADR-017 §3; the OSS turn by ADR-018; both in the same exclusion phase, neither double-gated nor ungoverned | §9 no-overlap-no-gap composition |

---

## 13. Consequences

**Positive**
- The two provenance risks the OSS-hosting mandate created are closed **at the one seam that can enforce them** — a weight that is license-prohibited or origin-untrusted for a path **cannot be selected**, not "is a finding later."
- Governance follows **bytes, not labels** (`weight_digest` binding), so a version bump or a re-quantization cannot silently inherit an obsolete license/origin determination.
- **One exclusion phase** now governs data-class (ADR-012), external providers (ADR-017 §3), license (Gate A), and origin (Gate B) — a single, uniform "exclude, then rank" discipline instead of four bespoke checks.
- Sovereignty is **path-scoped**, so the model-agnostic mandate survives where it is safe (public/internal) while the payment path is sovereignty-strict — capability is not thrown away, and shadow-AI pressure (gap 29) is not created.
- Licensing compliance (NOTICE) travels **with** the weights into air-gapped and distributed artifacts, by build gate, not by memory.

**Negative / cost**
- Every self-hosted weight now needs **two reviewed records** and, for adversary-origin weights on regulated paths, a **procurement dossier** — a real legal + security workload, and a per-version-bump one (§7). This is the price of running foreign OSS weights in a national payment system honestly.
- A version bump is a **Program with a legal and a security re-review on its critical path** — slower than "pull the new checkpoint and serve it." The mitigation is that eval loading is unblocked; only *user routing* waits on governance.
- Gate B can leave a regulated task with a **weaker trusted-eligible model** than the best-available (PRC-origin) one (§6.4). Named, not hidden: the fix is trusted-origin/in-house investment.

**Neutral**
- `BLOCKED_MODELS` is not removed; it stays as the coarse fast-path denylist beneath the conditional register layer.

---

## 14. Residual risks (honest, not deferred silently)

1. **Origin attribution can be opaque.** `corporate_control_nation` and `training_provenance` rely on disclosed and inferable facts; a deliberately obscured ultimate-control chain, or an undisclosed training-data provenance, is a real limit. Mitigation: `training_provenance: opaque` **defaults to `untrusted`** — opacity fails safe. But the register is only as good as the diligence behind it; a well-hidden control chain is an accepted residual, named here.
2. **No formal MeitY/RBI "trusted-source for AI weights" regime exists yet.** The §6.3 designation is modeled by analogy on the telecom NSDTS precedent with an interim authority (security-council + board-delegate). If a formal regime arrives, the `authority`/`evidence_ref` fields must be re-pointed to it — provisioned for, not yet backed by, a statutory scheme.
3. **License determination is a legal judgment.** Gate A enforces the *recorded* determination faithfully; it cannot catch a *wrong* determination (counsel misreads a custom clause). Mitigation: two-group CODEOWNERS (counsel + eng) and a versioned, revertable record — a mistaken determination is diffable and rollback-able, but the residual (bad legal input) is real.
4. **Live-metric accuracy for usage triggers.** The MAU/revenue signal feeding §5 step 3 is a data-plane projection; a wrong or stale metric could delay a trigger firing. Mitigation: conservative rounding + the metric itself is an eval-monitored signal — but a mis-measured platform scale is a named residual.
5. **AUP re-fetch cadence.** The §7 TOFU-pin catches an AUP change only as often as the re-fetch runs; a change exploited within the window between fetches is a (bounded) gap. Mitigation: cadence tuned to the obligation's risk; the pin makes the change *detectable*, the cadence makes it *timely*.
6. **Fail-closed can degrade regulated quality.** §6.4 is honest about this: strict sovereignty on a thin trusted-model bench yields weaker regulated answers until the bench is invested in. This is a deliberate trade — correctness of *who* may run over marginal quality — and a procurement mandate, not a defect to code around.

---

## 15. Self-score (honest)

**Design ceiling: 9.5 / 10.** Every clause of the brief has a concrete enforcement mechanism, not a restated principle: the two gates are **two named exclusion steps in the router pipeline** (§3) with a stated ordering rationale and a failover-chain pre-filter that makes bypass structurally impossible; the registers are **content-addressed control-plane definitions** (§4) with CI+loader-enforced schemas, keyed on **`weight_digest`** so governance follows bytes not labels (§7); the hardest correctness point — that **a signed PRC weight is still PRC-origin** — is met head-on with an orthogonality table and a gate that keys on origin, never on signature (§6.2); NOTICE propagation is a **hard build gate** (§8); re-validation-on-version-bump is a real **ADR-027 Program** with legal + security re-review on the critical path (§7); and composition with the four neighbouring gates is a no-overlap-no-gap table (§9). It honors both binding cross-cutting decisions structurally (Q2 registers-as-definitions; Q1 re-validation/exit-as-Programs), is air-gap-clean by construction (§10), and considers six real alternatives (§11). Eighteen scenario tests exercise exactly the properties that decide correctness — the signed-PRC-weight case, the digest-substitution case, the version-bump license-change case, and the empty-set fail-closed case.

The missing half-point is honest and named (§14): the origin gate's floor is the *quality of origin attribution* (residual 1) and the *absence of a formal statutory trusted-source regime for AI weights* (residual 2) — enforcement surfaces this design specifies faithfully but whose *inputs* it cannot itself guarantee. **Build maturity: 0 / 10** — no code exists, consistent with every artifact in this corpus. The ceiling is set so implementation can only descend from a real 10-shaped target.
