# ADR-014 — Model Risk Management: RBI/SR-11-7-Style Independent Governance Layered Above the Generic Definition Lifecycle and the ADR-011 Card

**Status:** Accepted — Design only (no code). Closes Pass-5 / cross-platform gap **[P] Model Risk Management (RBI / SR 11-7 style)** (`GAP_ANALYSIS_VS_AI_PLATFORMS.md` §Part 2): a model inventory, independent model validation, challenger models, ongoing performance monitoring, and documented model risk.

**Decision class:** Institutional / regulatory-examination-relevant, additive. **Layers a third governance discipline on top of two already-decided gates, and duplicates neither.** ADR-026 answers *"was this change reviewed by an accountable owner and merged?"* for every control-plane definition alike. ADR-011 answers *"does this model route / Role have a current, approved documentation Card, a passing fairness suite, and wired explainability?"* — a Responsible-AI documentation gate, also layered on ADR-026, also same-domain-approved. This ADR answers a third, narrower, harder question that only SR-11-7-style model-risk governance asks, and that neither of the first two was designed to answer: **"has someone *organizationally independent* of this model's development benchmarked it against an alternative, blessed it as fit-for-purpose, and is it re-checked on a calendar regardless of whether it changed?"** That question requires a disjoint validator, a challenger, and a clock — three things this ADR adds without re-authoring anything ADR-011 or ADR-026 already owns.

**A terminology note, stated once, to prevent the exact drift this note exists to prevent:** `REGULATED_FI_COMPLIANCE_OPS.md` §4.2 named an artifact the **"Model-Risk Record"** and explicitly deferred its schema to *"ADR-014."* Since that deferral was written, **ADR-011 §3.1 has implemented and generalized that same artifact as the Model/System Card** — one per model route, one per production Role/agent/skill — beyond §4.2's original DPDP-SDF-only scope. **This ADR does not define a second, competing "Model-Risk Record" schema.** Every reference below to **"the Card"** is ADR-011 §3.1's object, referenced by `card_id`, never re-declared. What this ADR adds is the three things ADR-011's Card deliberately does not attempt (§1): a materiality-tiered **Inventory** entry per Card (§4), a structurally-**independent Validation** sign-off on top of the Card's own domain-owner approval (§5), and a mandatory **challenger-benchmark** discipline (§6) — plus a calendar-monitoring cadence (§7) that *tightens*, never loosens, ADR-011's own recertification clock. Read together, the Card (ADR-011) plus this ADR's three registers *are* the documented-model-risk artifact §4.2 asked for (§8).

**Relates to / extends:** ADR-001 (strangler-fig Rust sidecar — the Model Risk registers are control-plane components the sidecar's Policy Engine reads at routing time), ADR-003 (Approval/Policy/Compliance seam — the tri-state Approval Gate is reused for the independent-validator sign-off, §5), ADR-006 (Provider Gateway + Model Router — consults the Inventory's tier + validation status as a further eligibility input, alongside ADR-012/ADR-018), ADR-007 (Event Log — every validation decision, challenger benchmark, and calendar review is recorded there for two-year reconstruction), **ADR-010 (Evaluation Platform — the statistical evidence engine this ADR's mechanisms consume; ADR-010 §9/§11 already names this ADR as the consumer of its output: "an eval run *is* the independent-validation + challenger + ongoing-monitoring evidence RBI/SR-11-7 requires" — ADR-010 supplies the *how-to-measure*, this ADR supplies the *who-must-look, how-independently, and on what calendar*)**, **ADR-011 (Responsible-AI Governance — owns the per-subject Model/System Card, §3.1, that this ADR annotates rather than duplicates; this ADR is written as a fourth extension of ADR-011's base layer, sibling to ADR-017/019/025, adding the model-risk-specific axis — inventory tiering, disjoint independent validation, challenger benchmarking, materiality-tiered monitoring — that ADR-011 explicitly leaves to a same-domain CODEOWNERS approval, §5)**, ADR-012 (data-class → model routing — a data-class ceiling of regulated-payment/PII, already recorded on the Card as `permitted_data_class`, is read by this ADR as one of two automatic Tier-1 drivers, §3), ADR-016 (Agent-Payment-Initiation Boundary — the Card's `payment_boundary_class` field is the other automatic Tier-1 driver), ADR-017 / `REGULATED_FI_COMPLIANCE_OPS.md` §4.2 (the **Model-Risk Record** — the artifact this ADR resolves per the terminology note above, §8), **ADR-018 (Model Governance — the License + Origin Registers are a narrower, orthogonal risk axis: is this weight *legally and sovereignly eligible to run at all*, already reused by reference on the Card's `provenance` block. ADR-014 governs a different axis: *given that it is eligible, is it sound, independently validated, and still the best-justified choice*)**, ADR-020 (Serving-Ops — weight-digest binding, reused verbatim so Inventory entries key on bytes, not a mutable model-id string), ADR-025 (Evidentiary Admissibility — validation records, challenger benchmarks, and monitoring history are exported court-grade for an RBI examination), **ADR-026 (Control-Plane Git-Native — the generic promotion lifecycle both this ADR and ADR-011 layer above, and the storage substrate for every register this ADR defines)**, ADR-027 (Long-Horizon Programs — calendar-triggered revalidation, §7, and a fleet-wide re-validation sweep, run as Programs).

**The two binding cross-cutting decisions, honored explicitly:**
- **[Q2 — ADR-026, Control-Plane Git-Native]:** the **Model-Risk Inventory**, every **Independent Validation Record**, and every **Monitoring Plan** are **control-plane definitions** — reviewed, versioned, PII-free git files, never DB rows (§4, §5, §7), referencing the Card's `card_id` rather than re-declaring its fields. The **evidence** those records point to (eval scores, drift metrics, challenger benchmark runs) is **data-plane**, produced by ADR-010's eval platform and the Event Log. Same split ADR-011 and ADR-018 each already use for their own registers, applied to a third risk axis.
- **[Q1 — ADR-027, Long-Horizon Programs]:** calendar-triggered revalidation (§7) and a fleet-wide re-validation sweep after a corpus-wide model/prompt change are **Programs** — checkpointed, resumable, able to ship partial completion (the re-validated subset goes live; the rest stays under its prior, still-valid record) — never a big-bang all-at-once scramble.

---

## 1. Context — three gates now exist above ADR-026; this ADR is the one that asks "independent of whom, and how often regardless"

ADR-026 gives every control-plane definition — a prompt, a skill, an agent, a routing policy, a newly onboarded model — one uniform lifecycle: `branch = DRAFT → PR+CI = PENDING_APPROVAL → merge under CODEOWNERS = APPROVED → signed tag on env/prod = PRODUCTION`. ADR-011 correctly layers a Responsible-AI documentation gate on top of that (a Card must exist, be `approved`, pass the fairness suite, and wire explainability before `PRODUCTION`). Both are real, structural, git-native controls. `GAP_ANALYSIS_VS_AI_PLATFORMS.md` §P names the precise residue left after both: *"the DRAFT→PRODUCTION lifecycle question is already answered... but that answers how a model version gets promoted, not model-risk-specific content (inventory, independent validation, challenger models, performance monitoring)."*

That residue has a specific, testable shape once compared against what a payment regulator's model-risk-management (MRM) function — in the tradition of the US Fed/OCC SR 11-7 framework, the closest well-specified precedent RBI's own model-risk direction draws on — actually examines. Two structural gaps neither ADR-026 nor ADR-011 closes:

**(a) The approver is not independent of the builder.** Both ADR-026's CODEOWNERS review and ADR-011's Card `owner` sign-off are *domain-accountable-owner* review — the right control for "was this reviewed by someone who understands it and is on the hook for it." SR-11-7's central concept is **effective challenge**: a validation function with the authority, competence, and — critically — the **incentive independence** to say "no, this is not fit for purpose," exercised by people who did not build the thing and are not measured on its success. A platform-lead approving a Card for a model they co-designed satisfies both existing gates and fails SR-11-7's. Nothing in the corpus today enforces organizational disjointness between "who built/tuned this" and "who signed off that it is sound."

**(b) Neither existing gate has a *materiality-scaled*, model-risk-specific calendar.** ADR-011's Card does carry a `recert_after` cadence (§9 there) — a real, welcome step — but it is a **blanket freshness check on documentation content** (is the Card's provenance/limitations text still accurate), not a **risk-tiered soundness re-validation** that scales with how consequential the route is, nor does it require an independent 2nd-line sign-off or a challenger comparison on renewal. A Tier-1 payment-adjacent route and a Tier-3 internal tool renewing on the identical cadence, with the identical single-owner sign-off, is not proportionate model-risk governance.

Neither gap is closed by any other existing decision, and each genuinely-near neighbor solves a different problem:

| Existing mechanism | What it governs | Why it misses gap [P] |
|---|---|---|
| **ADR-026's promotion pipeline** | *Was this change reviewed by an accountable owner and merged?* | Same-domain review; no materiality-scaled calendar of its own. |
| **ADR-011's Model/System Card + promotion gate** | *Does this subject have current, approved documentation, a passing fairness suite, and wired explainability?* | The Card's `owner` sign-off is domain-approval, not independent challenge; `recert_after` is a blanket documentation-freshness clock, not a risk-tiered validation-and-challenger cadence. |
| **ADR-018's License + Origin Registers** | *Is this self-hosted weight legally licensed for this use, and is its nation-of-origin trusted for this path?* | An orthogonal legal/sovereignty axis, already reused by reference on the Card's `provenance` block. Says nothing about whether the model performs soundly, or whether anyone independent has benchmarked it. |
| **ADR-010's Evaluation Platform** | *Does a candidate's measured quality non-regress, with statistical rigor, against the version it replaces?* | The **evidence engine** — powered, corrected, judge-calibrated, canaried. Does not itself assert *who* must look at the result, whether that person is independent of the model's developers, or that a review must recur even absent a change. A green ADR-010 gate is necessary evidence for model-risk sign-off; it is not, by itself, the sign-off. |

This ADR closes the residue by adding four things, each cross-referencing rather than re-declaring the Card: (i) a materiality tiering function read off the Card's own fields (§3), (ii) a lightweight **Inventory** entry per Card that indexes tier + this ADR's three registers (§4), (iii) an **Independent Validation** gate structurally disjoint from the Card's own `owner` (§5), (iv) a mandatory **challenger-model** discipline for Tier-1 (§6), and a **materiality-tiered calendar cadence** that tightens ADR-011's blanket `recert_after` for the entries that carry the most risk (§7).

---

## 2. Decision

**Model Risk Management is a control-plane governance layer, organizationally independent of model development, that (a) indexes every in-scope Card at a risk tier, (b) requires an independent validation sign-off disjoint from the Card owner's approval before a Tier-1/Tier-2 subject reaches production, (c) mandates a benchmarked challenger for every Tier-1 route, and (d) forces a materiality-tiered calendar revalidation regardless of whether the subject changed — with the Card (ADR-011) plus this ADR's registers together forming the one documented-model-risk artifact `REGULATED_FI_COMPLIANCE_OPS.md` §4.2 asked for.**

Four commitments, each with a concrete mechanism, none of them re-declaring a Card field:

- **MR1 — Scope + tiering (§3).** A precise test for what is "a model" under this ADR (broader than "an LLM weight" — includes every subject ADR-011 already cards: prompts/skills/agents/workflows/classifiers whose output drives a decision without full human re-derivation), and a materiality/complexity tiering function **derived from the Card's own `payment_boundary_class`, `permitted_data_class`, and `autonomy_level` fields** — no new classification input is invented.
- **MR2 — Model-Risk Inventory (§4).** One control-plane register entry per Card, keyed on the Card's own `card_id` and the underlying `weight_digest`/definition-commit-SHA — never a mutable label — carrying only the fields the Card does not: tier, tier driver, and refs to this ADR's three registers. No entry → ineligible for Tier-1/Tier-2 traffic (fail-closed, the same discipline ADR-011/ADR-018 use for their own registers).
- **MR3 — Independent Validation (§5).** A second, structurally-disjoint sign-off — from a CODEOWNERS group with **zero membership overlap** with the Card's authoring/domain owner, enforced by CI — required before a Tier-1 entry (and periodically for Tier-2) reaches `env/prod`. Layered on top of, never instead of, the ADR-026 merge approval **and** the ADR-011 Card approval.
- **MR4 — Challenger models + materiality-tiered monitoring (§6, §7).** Every Tier-1 production route ("champion") has at least one continuously-benchmarked challenger, using ADR-010's canary/A-B statistical machinery for a **risk-evidence** purpose distinct from ADR-010's own engineering-optimization purpose; and a Monitoring Plan fires a mandatory revalidation on a **tier-scaled cadence that can only tighten, never loosen, ADR-011's own `recert_after`** — independent of any code/prompt/Card change.

---

## 3. Scope — the same subjects ADR-011 already cards, tiered off fields the Card already carries

**The scope test is identical to ADR-011's:** every subject that carries a Model/System Card (§3.1 there) is automatically in scope of this ADR's Inventory (§4) — this ADR invents no new scoping boundary, it consumes ADR-011's. That means: any self-hosted or cloud LLM weight admitted to the Model Router, any prompt/skill/agent/workflow composition whose behavior drives a decision, and any bespoke statistical/ML component (retriever, ranker, classifier, ML-backed PII detector) already carded under ADR-011 is in scope here.

**Materiality/complexity tiering, derived from fields the Card already declares — no new input is collected:**

| Tier | Trigger (read from the Card, any one is sufficient) | Mandatory controls |
|---|---|---|
| **Tier 1** | Card's `payment_boundary_class != none` (ADR-016), **or** `permitted_data_class` reaches regulated-payment/PII/cardholder (ADR-012), **or** `autonomy_level == fully_auto` with no human-in-the-loop before the output takes effect | MR2–MR4 all mandatory; Model Risk Committee review (§8.2) |
| **Tier 2** | `autonomy_level == assisted`/`supervised`; Tier-1-adjacent but human-gated | MR2 mandatory, MR3 periodic (not per-change), MR4 advisory |
| **Tier 3** | Low-materiality internal tooling, no customer or payment exposure | MR2 mandatory (inventory completeness); MR3/MR4 advisory, lightweight |

Tiering is itself recorded on the Inventory entry (§4) and reviewable — a subject cannot be silently downgraded to escape controls; a tier *decrease* additionally requires the same independent-validator sign-off as a promotion (closing the "reclassify it as Tier 3 to skip the gate" evasion), and any change to the *Card* fields the tier is derived from (§3 table) automatically re-derives the tier at the next Inventory sync, the same reactive discipline ADR-011 §8.2 already uses for its own diff-invalidation rule.

---

## 4. The Model-Risk Inventory — a thin, tier-indexed register over the Card, not a second Card

**Schema (git definition, `model-risk/inventory/<card_id>/definition.md`, per ADR-026) — deliberately carries no field the Card already owns:**

```yaml
---
kind: model-risk-inventory
id: model-risk-inventory.card.role.payment-triage@1.4.0
card_ref: card.role.payment-triage           # ADR-011 §3.1 — provenance, intended_use, permitted_data_class,
                                              # autonomy_level, payment_boundary_class, known_limitations
                                              # all live on the Card. This entry does not re-declare them.
weight_digest: "sha256:9f3c…"                 # if the Card's subject_type is a self-hosted weight (ADR-020 binding)
definition_commit_sha: "a1b2c3…"              # if the Card's subject_type is a prompt/skill/agent/workflow (ADR-026 binding)
tier: 1                                       # derived per §3's table from the CARD's own fields
tier_driver: payment_boundary                 # payment_boundary | data_class_regulated | no_hitl | internal
status: production | conditional | retired    # this ADR's own status, distinct from card_status (ADR-011)
validation_record_ref: ""                     # §5, populated on sign-off
challenger_refs: []                           # §6
monitoring_plan_ref: ""                       # §7
model_risk_rating: high                       # f(tier, complexity, control-effectiveness) — §8.1, new, not on the Card
next_scheduled_review: "2026-10-18"            # §7 — tighter than the Card's own recert_after for Tier 1/2
---
# Payment-triage Role — model-risk inventory entry (body: tiering rationale, not a restatement of the Card's content)
```

**Fail-closed loader rule, identical in spirit to ADR-018 §4.2's "no ungoverned weight" and ADR-011's card-gate:** a Tier-1 or Tier-2 subject with no matching Inventory entry, or whose `status` is not `production`/`conditional`, is **ineligible for that traffic** — the Model Router's exclusion phase (ADR-006/ADR-012/ADR-018) treats a missing or stale Inventory entry as an additional exclusion, checked alongside the license, origin, and Card gates. **Governance follows the digest or the commit SHA, never the model-id string** — the same anti-substitution discipline ADR-018 §7 uses, inherited here via the Card's own binding.

---

## 5. Independent Validation — the effective-challenge gate, structurally disjoint from both the ADR-026 merge approval and the ADR-011 Card owner

### 5.1 Organizational disjointness, enforced, not assumed

**CODEOWNERS (per ADR-026 §8), with a disjointness rule CI enforces:**

```
/model-risk/validation/    @model-risk-management     # independent 2nd-line function
```

`@model-risk-management`'s membership is checked **at CI time against the membership of both the Card's `owner` group (ADR-011 §3.1) and the underlying definition's ADR-026 authoring CODEOWNERS group.** **A person who is a member of either and of `@model-risk-management` cannot be recorded as that entry's validator** — the merge is blocked. This is the mechanical answer to "who validates the validator's independence": it is not a policy statement, it is a membership-set intersection check that fails the build, the same enforcement posture ADR-018 §4 uses for CODEOWNERS-as-authoring-RBAC, applied across two upstream owner sets instead of one.

### 5.2 The validation record

```yaml
---
kind: model-risk-validation
id: model-risk-validation.card.role.payment-triage@1.4.0
inventory_ref: model-risk-inventory.card.role.payment-triage@1.4.0
card_ref: card.role.payment-triage           # the Card this validation is *about*, never re-declared
validator: "@model-risk-management"           # disjoint from both the Card owner and the ADR-026 author (§5.1)
conceptual_soundness: |                        # is the approach fit for the stated purpose (Card's intended_use)
  ...
developer_testing_reviewed: eval-run-id-88231       # ADR-010 evidence — reviewed, not re-taken on faith
independent_replication: true                 # validator re-ran or spot-checked key eval cells itself (§5.3)
challenger_benchmark_ref: challenger-run-4471       # §6, mandatory for Tier 1
outcome: approved | approved_with_conditions | rejected
conditions: []                                 # e.g. "quarterly recheck of usage volume vs validated ceiling"
next_scheduled_review: "2026-10-18"            # feeds §7
reviewed_at: "2026-07-18"
---
```

### 5.3 Independent replication — the point where "trust the developer's eval" is explicitly rejected

The validator does not merely read the developer's ADR-010 Eval Delta (already consulted once by the Card's `quality_score` projection) and rubber-stamp it. For Tier-1, the validator's process requires **independently re-running or spot-checking a sample of the key watched cells** using the same sealed eval infrastructure (ADR-010 §5) — catching the case where a developer's local run diverged from the CI-recorded one, or where the developer selectively reported a favorable subset. This is the concrete meaning of "effective challenge": the validator has both the standing and the mechanism to disagree with the developer's own quality claim, not merely to audit that a claim was filed.

### 5.4 The gate — a third layer, on top of ADR-026 and ADR-011, never instead of either

Promotion of a Tier-1 subject to `env/prod` now requires **three distinct, separately-signed artifacts**: the ADR-026 CODEOWNERS merge approval ("this change is technically sound"), the ADR-011 Card approval + passing fairness suite + wired explainability ("this subject is responsibly documented and fair"), **and** a `outcome: approved` (or `approved_with_conditions`) Independent Validation record ("this model is fit-for-purpose and I, independent of both prior approvals, attest to that"). **Non-overridable for Tier-1:** there is no promotion path — no admin flag, no "hotfix" lane — that reaches `env/prod` with fewer than all three. Tier-2 requires MR3 periodically (at the calendar cadence, §7) rather than on every change; Tier-3 is advisory.

---

## 6. Challenger models — mandatory comparative benchmarking, and why this is a different concept from the Breaker

### 6.1 The mechanism

For every Tier-1 production route (the **champion**), `@model-risk-management` designates and continuously benchmarks **at least one challenger** — a different model, version, or vendor family capable of the same task type — using ADR-010's canary/A-B statistical machinery exactly as specified there: pre-registered metrics and non-inferiority margins, powered, multiple-comparison-corrected, always-valid online inference. The **purpose** is different from ADR-010's own default use of that machinery: ADR-010 runs A/B for **engineering optimization** ("is the new candidate better, so we should ship it"); this ADR runs the identical statistical rig for **risk evidence** — "is the currently-deployed champion still the best-justified choice, and if not, is there already a benchmarked, production-ready alternative on file" — a champion/challenger program is continuous, not a one-time promotion decision, and it runs whether or not anyone has proposed changing the champion.

### 6.2 Explicitly not the Breaker

`AGENT_TESTER.md`'s **Breaker** is an adversarial red-team engine that hunts for failures and mints regression cases (`ADR-010` §6); ADR-011's **Fairness & Bias Test Suite** (§5 there) is a metamorphic-oracle fairness check. A **challenger model**, by contrast, is not an attacker and is not looking for a specific defect — it is a comparative-quality benchmark answering "which of these two legitimate, capable models performs better on this task type, right now." All three feed the same eval-platform infrastructure; they answer categorically different questions, and none substitutes for another. This distinction is stated explicitly because the vocabulary collision ("challenger" vs "Breaker" vs "candidate") is exactly the kind of terminology drift that causes an engineer to think one satisfies the other.

### 6.3 What a challenger divergence does — and does not — trigger

If a challenger statistically and materially outperforms the champion (clears its pre-registered MDE, non-inferiority margin, and FDR correction — ADR-010 D3) on the watched cells for **two consecutive calendar review windows** (§7), `@model-risk-management` must open a re-justification item on the Inventory entry (§4): the entry's `status` flips to `conditional` pending review. **This does not auto-promote the challenger** — a champion swap on a Tier-1 payment-adjacent route is a deliberate, accountable, human decision (it may have cost, latency, license/origin, or contractual reasons to hold the champion despite a quality edge), and auto-promotion on a rolling statistical signal would reintroduce exactly the "flaps on noise" failure ADR-010 D3 was designed to prevent for ordinary shipping decisions — doubly so for a decision this consequential. The mechanism forces the conversation; it does not have the conversation for you.

---

## 7. Ongoing performance monitoring — materiality-tiered, calendar-triggered, tightening (never loosening) ADR-011's own cadence

### 7.1 Two triggers, layered on ADR-011's one

ADR-011 §9 already gives every Card a change-triggered eval gate and a blanket `recert_after` calendar clock (default 180 days) for documentation freshness. This ADR does not replace that clock — it **tightens** it for the tiers that carry the most risk, the identical `narrow_only` MEET-semantics discipline ADR-004 §6 uses for safety ceilings generally: a more-specific, higher-risk layer may only shorten the window a less-specific layer set, never lengthen it.

| Tier | This ADR's monitoring cadence | Relationship to the Card's `recert_after` |
|---|---|---|
| Tier 1 | Quarterly (90 days) | Overrides/tightens; the Card's own recert additionally re-runs at this shorter interval for a Tier-1 subject |
| Tier 2 | Semi-annual (180 days) | Equal to the Card's default — no tightening needed |
| Tier 3 | Annual (365 days), advisory | Looser than the Card's default is never permitted to apply here — the Card's own 180-day floor still governs documentation freshness; this ADR's slower cadence applies only to the *validation/challenger* content, not the Card |

A **Monitoring Plan** (control-plane, `model-risk/monitoring/<card_id>/definition.md`) records the tier-derived cadence, the watched metrics, and drift thresholds; it fires **whether or not the underlying model, prompt, or weight has changed at all** — a Tier-1 subject that is bit-for-bit unchanged for a full quarter still comes up for review, because usage volume, data drift, and the operating environment move independently of the artifact.

### 7.2 Mechanism — reusing, then extending, the live signal

The always-on signal is ADR-010's live quality circuit-breaker and drift monitor (`TOOLING` §4.6), and — for fairness specifically — ADR-011 §5.3's identical breaker discipline for a Fairness Score collapse. This ADR does not reinvent that telemetry. It adds the **scheduled, Program-checkpointed (ADR-027) review** that happens on the calendar regardless of whether the live signal ever tripped: a Model Risk reviewer examines the accumulated live-quality/fairness trend, the challenger comparison (§6), and any usage-volume growth against the validated ceiling, and either renews the entry's `next_scheduled_review` with a fresh sign-off or opens a re-validation item. A fleet-wide calendar sweep (many Tier-1 entries due the same quarter) runs as an ADR-027 Program: checkpointed, resumable, and able to ship **partial completion** — reviewed entries renew on schedule; a backlog on the rest does not silently roll every entry's deadline forward, it is a visible, tracked exception.

### 7.3 Failure of calendar-triggered review is handled by the same enforcement arm as a live trip

An Inventory entry whose calendar review lapses past its `next_scheduled_review` **without a renewed sign-off** is auto-demoted from Tier-1/Tier-2 eligibility by the Model Router's exclusion phase — the identical "auto-quarantine, fail over to the class-eligible chain" mechanism `TOOLING` §4.6 and ADR-011 §5.3 both use for a live judge-score or fairness-score collapse. **A stale review is treated with the same severity as a measured quality regression**, because from a regulator's chair, "nobody checked" and "it got worse" are both "the control did not hold."

---

## 8. Documented model risk — the Card plus this ADR's three registers, read together, is the artifact

`REGULATED_FI_COMPLIANCE_OPS.md` §4.2 asked for one artifact ("a Model-Risk Record per model route / per Role... provenance, permitted data-class, evaluation results, known limitations") and deferred it to "ADR-014." Per the terminology note (header), that artifact **already has an implementation** — ADR-011's Card — for the provenance/data-class/scores/limitations half. This ADR supplies the half the Card structurally does not: independence, benchmarking, and a risk-proportionate calendar. **The composed view an examiner reads is a join, not a new document:**

```
Model-Risk Record (as queried) =
    Card (ADR-011 §3.1)                         — provenance, intended use, permitted_data_class,
                                                    payment_boundary_class, known_limitations, live scores
  ⋈ Model-Risk Inventory entry (§4, this ADR)    — tier, tier_driver, model_risk_rating, status
  ⋈ Independent Validation Record (§5)           — validator identity, soundness finding, outcome
  ⋈ Challenger benchmark history (§6)            — comparative evidence
  ⋈ Monitoring Plan + review history (§7)        — cadence, renewals, lapses
    joined on card_id / weight_digest / definition_commit_sha
```

No field is stored twice; each register owns exactly the facts the others do not, and the join key is the same `card_id`/digest binding every register in §4–§7 already carries.

### 8.1 The model-risk rating

A function of **materiality** (tier, §3), **complexity** (self-hosted-fine-tuned vs off-the-shelf cloud call; single model vs multi-agent composition), and **control-effectiveness** (has an active challenger; is calendar-review current; has zero open conditions) — a three-input rating (`low`/`medium`/`high`), recorded on the Inventory entry (§4) because it is genuinely new content the Card does not carry, and reviewable in its own right — a `high`-rated entry is examined by the 3rd line more often than a `low`-rated one (§9), proportionate, not blanket.

### 8.2 The Model Risk Committee — the Tier-1 escalation path

For Tier-1 entries, in addition to the individual validator's sign-off (§5), a standing **Model Risk Committee** (named principals spanning `@model-risk-management`, a business-line delegate, and — mirroring ADR-018 §6.3's precedent for sovereignty-level decisions — a board-delegate for the highest-materiality entries) reviews the **aggregate** Tier-1 Inventory on a standing cadence and is the forum that resolves: an unresolved challenger divergence (§6.3) past its second window, a calendar review that surfaces a rating change to `high`, or any `rejected`/`approved_with_conditions` validation outcome the individual validator escalates rather than closes alone. The committee's decisions are themselves recorded (`committee_ack` id, on the Inventory entry) and feed back into the composed record — this is the point where a single validator's judgment is checked by more than one pair of eyes for the entries where it matters most, without requiring committee overhead for every Tier-2/3 entry.

### 8.3 Who reads this record

The India-resident DPO and the independent data auditor (`REGULATED_FI_COMPLIANCE_OPS.md` §4.3, read-only auditor evidence-access mode) query the composed Model-Risk view exactly as they query the outsourcing register, DPIA coverage, and the Card itself — no engineer in the loop, no new export mechanism (reusing ADR-011 §4.3's stated principle: "no new export path"). An RBI examiner's ask ("show me your model inventory, who validated this model, whether it has a challenger on file, and when it was last reviewed") is answered by the join in §8, exported court-grade per ADR-025.

---

## 9. Three lines of defense — the organizational structure §5.1's disjointness rule encodes

| Line | Who | Responsibility |
|---|---|---|
| **1st line** | Model/prompt/skill developers + the ADR-026 domain CODEOWNERS reviewer + the ADR-011 Card owner | Build, tune, self-test, document (the Card), and merge-approve the change (ADR-026/ADR-011's existing pipelines, unchanged). |
| **2nd line** | `@model-risk-management` — organizationally and CODEOWNERS-disjoint from every 1st-line group it validates (§5.1) | Independent validation sign-off (§5), the challenger program (§6), authoring Monitoring Plans and running calendar reviews (§7), maintaining the Inventory + rating (§4, §8.1), escalating to the Model Risk Committee (§8.2). |
| **3rd line** | Internal audit / the independent data auditor (`REGULATED_FI_COMPLIANCE_OPS.md` §4.3) | Periodically audits the **2nd line itself**, not the models: are validations genuinely independent (the disjointness check's history), are challenger benchmarks real and current, is the calendar cadence actually honored, is the rating (§8.1) accurate. Sampling depth scales with the rating (§8.1) — `high`-rated entries audited more often. Uses the same read-only auditor evidence-access mode as every other compliance register. |

The disjointness enforcement in §5.1 is what makes "three lines of defense" a structural property rather than an org-chart aspiration: a person cannot occupy the 1st and 2nd line for the same subject, because CI checks the set intersection and blocks the merge if they try.

---

## 10. Composition — one Model Risk layer, three neighbors, no overlap and no gap

| Concern | Owned by | Relationship to ADR-014 |
|---|---|---|
| Generic definition promotion (review + merge + tag) | ADR-026 | 1st-line gate for every control-plane definition alike; ADR-014 layers a 3rd, independent gate on top for Tier-1/2 subjects specifically — never a replacement. |
| Per-subject documentation, fairness testing, explainability, blanket recert cadence | ADR-011 (the Card) | The base object this ADR indexes and annotates (§4, §8); ADR-014 never re-declares a Card field and never redefines `recert_after` — it tightens the *effective* calendar for high-risk tiers (§7.1) via a separate Monitoring Plan. |
| License / field-of-use + nation-of-origin of a self-hosted weight | ADR-018 | Orthogonal legal/sovereignty axis; already reused by reference on the Card's `provenance` block (ADR-011 §3.1), and hence transitively visible to this ADR's §8 join — never re-collected here. |
| Statistical evidence engine (eval deltas, Judge calibration, canary, drift, Regression Vault) | ADR-010 | The **mechanism** §5's independent replication, §6's challenger benchmarking, and §7's monitoring all consume; ADR-014 defines *who* must use it, *how independently*, and *on what calendar* — ADR-010 itself names this ADR as the consumer of its output (ADR-010 §9/§11). |
| Live quality/fairness circuit-breaker / auto-quarantine | `TOOLING` §4.6 / ADR-011 §5.3 | The single enforcement arm for a change-triggered collapse **and** a calendar-review lapse (§7.3) — one quarantine discipline, multiple triggers. |
| Automatic Tier-1 driver — payment-initiation, data-class ceiling | ADR-016 / ADR-012, surfaced via the Card | The Card's own `payment_boundary_class`/`permitted_data_class` fields are the hard triggers in the §3 tiering table; a payment-adjacent route can never be tiered down to escape MR2–MR4. |
| Weight-digest / definition-SHA binding | ADR-020 / ADR-026 | Inventory entries (§4) key on bytes or commit SHA, not a mutable model-id string — the identical anti-substitution discipline ADR-018 §7 established, inherited via the Card's own binding. |

---

## 11. Air-gap / sovereign deployment

Every register this ADR defines (Inventory, Validation Records, Monitoring Plans) is a **PII-free control-plane definition** referencing the Card by id, so it crosses the air-gap boundary as a signed `git bundle` exactly as ADR-026 §12, ADR-011 §8.1, and ADR-018 §10 all specify. A sovereign zone's Model Risk function operates against the bundled register set with no live connection; the `@model-risk-management` disjointness check (§5.1) is enforced identically by the in-zone CI against the in-zone CODEOWNERS file. **The calendar-trigger obligation (§7) travels with the bundle** — a sovereign deployment does not get a lighter monitoring cadence merely because it is disconnected; the Program checkpoint (§7.2) resumes locally on reconnect or on an in-zone schedule if permanently air-gapped.

---

## 12. Alternatives considered

1. **Rely on ADR-026's and ADR-011's gates alone, with no separate model-risk layer.** Rejected (§1): a same-domain approval (ADR-026's CODEOWNERS or ADR-011's Card `owner`) is not independent challenge, and neither existing gate has a materiality-scaled soundness/challenger calendar. This was the exact residue named.
2. **Duplicate ADR-011's Card into a second, competing "Model-Risk Record" schema.** Rejected — this was this ADR's own first-draft mistake, corrected here (header terminology note): it would re-declare provenance/limitations/scores fields ADR-011 already owns, creating two sources of truth for the same facts and the exact "which document wins" ambiguity this corpus otherwise avoids everywhere else (`REGULATED_FI_COMPLIANCE_OPS.md` §0's own "one source per fact" discipline, applied to itself).
3. **Fold model risk into ADR-018.** Rejected: ADR-018 governs a self-hosted weight's legal licensing and sovereignty specifically — a narrower, different accountable group (`@oss-counsel`, `@security-council`) and a different failure mode. Conflating it with soundness/challenger/calendar validation would blur two teams' accountability and force every prompt/skill/agent (which ADR-018 was never designed to cover) through a weight-shaped register.
4. **Treat a green ADR-010 eval gate, or a green ADR-011 promotion gate, as sufficient model-risk sign-off.** Rejected: both are necessary evidence, neither asserts organizational independence, a challenger comparison, or a calendar obligation scaled to materiality. §5.3 exists precisely because "the developer's own CI check (or Card) passed" cannot be the same claim as "an independent function validated this."
5. **Continuous monitoring only, no periodic committee review.** Rejected: live metrics (drift, judge-score/fairness-score collapse — already covered by ADR-010/ADR-011) catch *quantitative* degradation; they do not force a *qualitative* "is this still the right model/approach for this purpose, given everything we've learned this quarter" reassessment — which is exactly what a calendar-triggered human review and the Model Risk Committee (§8.2) are for.
6. **A single flat "model-risk approved" rubber-stamp role for every subject, regardless of materiality.** Rejected: disproportionate for Tier-3 internal tooling and would either bottleneck the low-risk majority or get gamed into a rubber stamp for everything. The tiering table (§3) is deliberately risk-based and proportionate — the same posture SR-11-7 itself takes, and the same posture ADR-011 itself argues for its own fairness/quality signals (its alternative 4).
7. **Auto-promote a challenger that statistically beats the champion.** Rejected (§6.3): a Tier-1 champion swap has cost/latency/contractual/license dimensions a pure quality comparison cannot see, and auto-promotion on a rolling statistical signal reintroduces flapping risk for the platform's highest-consequence routing decisions. The mechanism forces the human decision; it does not make it.

---

## 13. Acceptance / scenario tests

| # | Scenario | Setup | Expected | Proves |
|---|---|---|---|---|
| 1 | Ungoverned model is ineligible | A Tier-1 route is live with an ADR-011 Card but no matching Model-Risk Inventory entry | The Model Router's exclusion phase treats it as ineligible for that traffic | §4 fail-closed, "no ungoverned model," layered on top of the Card gate |
| 2 | Same-team validator is blocked | A developer who is a member of the Card's `owner` group or the ADR-026 authoring group is proposed as the `@model-risk-management` validator | CI's membership-disjointness check blocks the merge | §5.1 — independence is enforced against *both* upstream owners |
| 3 | Tier-1 promotion needs three signatures | A Tier-1 subject has an ADR-026 merge approval and an ADR-011 approved Card, but no Independent Validation record | Promotion to `env/prod` is refused | §5.4 — non-overridable three-signature gate |
| 4 | Independent replication catches a selective report | A developer's filed Eval Delta omits an unfavorable watched cell the validator's own re-run surfaces | The validator's independent replication catches the discrepancy; `outcome: rejected` or `approved_with_conditions` | §5.3 — validation is not "trust the developer's claim" |
| 5 | Tier reclassification is gated | An engineer edits an Inventory entry's `tier` field to `3` while the Card's `payment_boundary_class` is still non-`none` | The tier-decrease requires the same independent-validator sign-off as a promotion, and the next Inventory sync re-derives Tier 1 from the Card regardless | §3 — tiering cannot be evaded by self-reclassification |
| 6 | Challenger designated for every Tier-1 champion | A new Tier-1 route reaches `production` with no challenger on file | The entry is flagged incomplete by `@model-risk-management`'s onboarding checklist before `status: production` is set | §6.1 — challenger is mandatory for Tier 1, not optional |
| 7 | Challenger divergence opens a re-justification item, does not auto-swap | A challenger clears its pre-registered MDE against the champion for two consecutive review windows | The Inventory entry's status flips to `conditional`; a re-justification item opens; the challenger is **not** auto-promoted | §6.3 — forces the conversation, preserves the human decision |
| 8 | Calendar review fires with zero code change, tighter than the Card's own clock | A Tier-1 entry's weight/definition is bit-for-bit unchanged, and its Card's `recert_after` has not yet lapsed | This ADR's quarterly Monitoring Plan still triggers a mandatory review ahead of the Card's own semi-annual clock | §7.1 — tightening, never loosening, the base cadence |
| 9 | Lapsed calendar review is auto-demoted | A Tier-1 entry's `next_scheduled_review` passes with no renewed sign-off | The Model Router auto-quarantines the route via the same mechanism as a live quality/fairness trip; traffic fails over to the class-eligible chain | §7.3 — a stale review is treated as a live regression |
| 10 | Fleet-wide calendar sweep ships partial | Many Tier-1 entries are due the same quarter and the review backlog cannot clear in time | The ADR-027 Program checkpoints; reviewed entries renew on schedule; the backlog is a visible tracked exception, not a silently-extended deadline for everyone | §7.2 — Program discipline, partial completion is a first-class outcome |
| 11 | The composed record answers an examiner's ask directly | An RBI-style examination asks "show inventory, validator, challenger status, and last review for this route" | The §8 join across the Card + Inventory + Validation + Monitoring registers answers all four fields without a new export mechanism | §8 — the join *is* the record `REGULATED_FI_COMPLIANCE_OPS.md` §4.2 asked for |
| 12 | Committee escalation on unresolved divergence | Test 7's re-justification item is still open past the committee's next standing review | The Model Risk Committee reviews it and records a `committee_ack` decision on the Inventory entry | §8.2 — the Tier-1 escalation path resolves what a single validator shouldn't close alone |
| 13 | 3rd line audits the 2nd line, not the model | The independent data auditor's periodic review targets `@model-risk-management`'s own practice | The auditor checks disjointness-check history, challenger-benchmark currency, and calendar-cadence adherence — via the read-only auditor mode, no engineer involved | §9 — three lines of defense, the 3rd line's actual scope |
| 14 | License-eligible weight still fails soundness validation | A weight passes ADR-018's license + origin gates cleanly (visible on the Card's `provenance` block) but has no Independent Validation record | It is license/origin-eligible **and** still ineligible for Tier-1 traffic under this ADR | §10 — ADR-018 and ADR-014 are orthogonal axes, neither substitutes for the other |
| 15 | Challenger benchmark is not mistaken for the Breaker or the Fairness Suite | An engineer proposes closing the challenger-model obligation by pointing at Breaker adversarial-test coverage or ADR-011's Fairness & Bias Test Suite results | Neither satisfies §6's champion/challenger comparative-benchmark requirement — the three answer different questions | §6.2 — the terminology distinction is load-bearing, not pedantic |
| 16 | Air-gap parity | The control repo ships to a sovereign zone as a signed git bundle | The in-zone Model Risk function enforces §5.1 disjointness and §7's calendar obligation identically, no egress required | §11 |
| 17 | Payment-boundary crossing forces Tier 1 regardless of self-assessment | A route's Card is authored with `payment_boundary_class: adjacent` but a self-assessment proposes Tier 2 | The tiering table's hard trigger, read directly off the Card field, overrides the self-assessment; it is Tier 1 | §3 — automatic drivers cannot be argued around |
| 18 | Audit reconstruction two years later | A regulator asks "who validated this exact model, on what evidence, and when was it last reviewed, as of 18 months ago" | The Event Log yields the routing decisions; the git history of the Card + Inventory + Validation + Monitoring registers yields who signed what and when, reconstructable from the tagged commit SHA | ADR-025/ADR-007 — the same two-trail audit discipline ADR-018 §12 test 17 and ADR-011 §11 test 13 establish, applied to model risk |

---

## 14. Consequences

**Positive**
- The residue `GAP_ANALYSIS_VS_AI_PLATFORMS.md` named precisely — "the lifecycle question is answered, the model-risk content is not" — is closed with a concrete, CI-enforced organizational-independence check (§5.1) layered cleanly on top of ADR-011's Card rather than duplicating it, fixing this ADR's own first-draft mistake before it shipped (§12 alt. 2).
- Model risk evidence stops being "we ran an eval once, and a Card exists" and becomes a standing, calendar-driven discipline (§7) that survives long after the model that prompted its creation has been forgotten about — closing the specific SR-11-7 failure mode of "validated at launch, never looked at again," while never contradicting ADR-011's own blanket recert clock (§7.1's tightening-only rule).
- One composed record (§8) — Card ⋈ Inventory ⋈ Validation ⋈ Monitoring — is the single view an examiner, the DPO, or the independent auditor needs, with each fact owned exactly once.
- The champion/challenger discipline (§6) turns "is this still the best model for this route" from an occasional ad hoc debate into continuously-available, statistically rigorous evidence, and produces a pre-vetted fallback as a side effect.
- Tiering (§3) keeps the heaviest controls proportionate to actual materiality, derived from fields the Card already carries — no new self-assessment surface for an engineer to game.

**Negative / cost**
- Every Tier-1/Tier-2 entry now needs a **genuinely disjoint** second reviewer function — a real staffing cost (a validation team that cannot simply be "whoever's free on the platform team this week"), and the CI disjointness check will, correctly, sometimes block a promotion because the org is too small to staff two disjoint groups for a niche route — a real operational friction named here, not hidden.
- Calendar-triggered review (§7) is ongoing work that recurs whether or not anything changed — a genuine standing cost, on top of the recurring cost ADR-011's own recert cadence already imposes.
- A Tier-1 champion swap now requires a deliberate committee-adjacent decision (§6.3, §8.2) even when the statistics are clear — slower than "just ship the better model," by design, because the decision has more dimensions than the eval score alone.

**Neutral**
- ADR-026's generic promotion pipeline and ADR-011's Card/documentation gate are both untouched and remain the 1st-line gates; this ADR adds a third, independent gate for a subset of subjects.
- ADR-010's evaluation infrastructure is reused verbatim as the evidence engine; no new statistical machinery is invented.

---

## 15. Residual risks (honest, not deferred silently)

1. **Disjointness at small scale.** §5.1's CI check is only as good as the org actually having enough people to staff two disjoint groups. A small platform team may be forced into an uncomfortable choice between under-resourcing 2nd-line validation or slowing Tier-1 promotions. Named, not hidden — this is a genuine staffing dependency, not a code defect to fix.
2. **"Independent" is a necessary, not sufficient, condition for competent.** Disjointness enforces that the validator is not the builder; it does not guarantee the validator is more skilled than the builder at judging soundness. Mitigation: the Model Risk Committee (§8.2) provides a second check for the highest-tier entries, but a systematically under-skilled 2nd-line function is a real residual this design cannot code around.
3. **Calendar cadence is a chosen parameter, not a proof of sufficiency.** Quarterly/semi-annual/annual reviews (§7.1) are a reasonable, risk-scaled default, not a guarantee that drift cannot do damage within the window. A fast-moving fraud pattern could invalidate a Tier-1 model faster than its quarterly cadence catches it — the always-on live circuit-breaker (§7.2) is the mitigating layer, but the residual — a genuinely novel failure mode that is both slow enough to avoid tripping live thresholds and fast enough to matter within a quarter — is real.
4. **Challenger availability.** §6.1 assumes a viable alternative model exists to benchmark against. For a niche, highly specialized Tier-1 task with genuinely no comparable second model, the challenger requirement degrades to "benchmarked against a weaker or synthetic alternative," which is honest but weaker evidence than a true champion/challenger comparison.
5. **The composed record's quality is bounded by the Card it joins against.** §8's join is only as trustworthy as ADR-011's Card content (provenance, known limitations) and ADR-010's eval evidence — this ADR mandates that the linkage exists and is independently reviewed (§5.3), but a wrong upstream input (an inaccurate Card, a mis-scored eval) propagates into the composed record, the same "garbage in" residual every downstream compliance artifact in this corpus carries and names honestly.

---

## 16. Self-score (honest)

**Design ceiling: 9.5 / 10.** Every clause of the brief has a concrete, CI-enforced mechanism, not a restated principle: the Model-Risk Inventory is a **fail-closed, digest/SHA-keyed register** (§4) that deliberately carries no field the Card already owns, resolving — explicitly, in the header's terminology note and again in §12 alt. 2 — a genuine artifact-naming collision this design discovered against a concurrently-written sibling ADR (ADR-011) rather than shipping two competing "Model-Risk Record" schemas; independent validation is a **structural, CI-checked membership-disjointness** requirement (§5.1) — the single hardest correctness point in SR-11-7's "effective challenge" concept, checked against *both* the ADR-026 author and the ADR-011 Card owner, and sharpened further by requiring **independent replication** (§5.3) rather than trust in the developer's own reported score; challenger models are a **mandatory, continuously-running statistical program** (§6) reusing ADR-010's rigor for a distinct purpose, with the terminology collision against both the Breaker and ADR-011's Fairness Suite resolved explicitly (§6.2) precisely because that kind of ambiguity is what quietly defeats a control; ongoing monitoring closes the change-vs-calendar gap head-on (§7) with an explicit **tighten-never-loosen** relationship to ADR-011's own blanket recert clock, the exact `narrow_only` discipline ADR-004 established for safety ceilings generally; and documented model risk is a **join, not a duplicate document** (§8) — the composed view three other artifacts in the corpus (`GAP_ANALYSIS_VS_AI_PLATFORMS.md`, `REGULATED_FI_COMPLIANCE_OPS.md` §4.2, ADR-010 §9/§11) already forward-referenced. The composition table (§10) draws a clean, no-overlap line against the three ADRs most likely to be confused with this one (026, 011, 018), and eighteen scenario tests exercise exactly the properties that decide correctness — the disjointness block against two upstream owners, the calendar-tightens-not-loosens case, the challenger-divergence-does-not-auto-swap case, and the license-eligible-but-unvalidated case that proves ADR-018 and ADR-014 are genuinely orthogonal.

The missing half-point is honest and named (§15): organizational independence is only as real as the org's staffing depth to support two disjoint functions (residual 1), disjointness proves independence but not competence (residual 2), and a chosen calendar cadence is a parameter, not a proof, against a sufficiently novel and sufficiently fast-moving failure mode (residual 3) — enforcement mechanisms this design specifies faithfully, whose *sufficiency* against a determined or unlucky failure it cannot itself guarantee. **Build maturity: 0/10** — no code exists, consistent with every artifact in this corpus. The ceiling is set so implementation can only descend from a real 10-shaped target.
