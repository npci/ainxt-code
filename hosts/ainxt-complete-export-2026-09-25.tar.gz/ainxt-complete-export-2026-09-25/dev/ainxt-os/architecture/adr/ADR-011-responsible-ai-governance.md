# ADR-011 — Responsible-AI Governance (Model/System Cards, Bias & Fairness Testing, Explainability, AI Incident Response, Human-Oversight Records)

**Status:** Accepted. Design only — no code. Closes `GAP_ANALYSIS_VS_AI_PLATFORMS.md` gap **D** (*"model cards/system cards, bias & fairness testing, explainability, AI decision audit trails, human-oversight records, and an AI incident-response process"*) and the **non-statutory** half of two Pass-5 gaps: **[3]** (*"agentic incident taxonomy"* — the statutory-clock half is `ADR-017`) and **[12]** (*"DPDP algorithmic due diligence"* — the model-risk-record half is generalized here from `REGULATED_FI_COMPLIANCE_OPS.md` §4.2, which today only fires for DPDP-SDF-relevant features).

**Decision class:** Architecture-defining, additive, cross-cutting. This ADR is deliberately written as a **base layer four later ADRs extend along four different axes, without any of the five re-implementing it**:

- **Extended by ADR-017** (`REGULATED_FI_COMPLIANCE_OPS.md` §2) — takes this ADR's general incident taxonomy and adds a second policy table that arms a *statutory* breach clock (CERT-In 6h / DPDP / RBI) for the subset of incident classes that are also legally reportable. Same `IncidentCandidate` object, same classification step, one more table.
- **Extended by ADR-019** (`adr/ADR-019-liability-indemnity-insurance.md` §4) — takes this ADR's before-the-fact Oversight Record and adds the after-the-fact Accountability Record, for the case where an AI-caused harm crystallizes into a financial loss requiring adjudication and recovery.
- **Extended by ADR-025** (`REGULATED_FI_COMPLIANCE_OPS.md` §7) — takes every artifact this ADR produces (cards, explainability records, incident entries, oversight records) and supplies the BSA §63 certificate that makes an export of any of them court-admissible, not merely tamper-evident.
- **Extended by ADR-014** (`adr/ADR-014-model-risk-management.md`) — takes this ADR's Model/System Card (§3.1) as given and adds the RBI/SR-11-7-specific axis this ADR deliberately leaves to a same-domain `owner` sign-off: a materiality-tiered inventory, a structurally-independent validation gate disjoint from the Card owner, a mandatory challenger-model benchmark for Tier-1 subjects, and a risk-tiered calendar that can only tighten — never loosen — this ADR's own `recert_after`. ADR-014 references every Card by `card_id` and declares no competing card schema.

Nothing in this ADR anticipates or duplicates those four extensions; each is named at the point in this document where its extension seam lives, so a reader of ADR-014/017/019/025 can find the exact clause it builds on.

**Relates to / extends (backward dependencies):** ADR-003 (Policy/Approval/Compliance seam — the runtime authz context every Oversight Record and Decision Explainability Record is anchored to), ADR-007 (Event Log — the durable, hash-chained substrate every object in this ADR lives on), ADR-010 (Evaluation & Experimentation Platform, design-only-to-be-written per `IMPLEMENTATION_PLAN.md` §Phase 0 — the Fairness & Bias Test Suite, §5, is a new scenario category inside it, not a parallel eval stack), ADR-012 (Data Residency/Classification → model routing, design-only-to-be-written — its candidate-selection pipeline, concretized in `TOOLING_MCP_PLUGINS_ROUTING.md` §4.1, is the decision this ADR's routing-explainability mechanism, §4.1, makes queryable), ADR-016 (Agent-Payment-Initiation Boundary — an autonomy-runaway or oversight-failure incident touching a payment-boundary-adjacent Role is the sharpest incident class in §6.1's taxonomy), ADR-018 (Model Governance — the license/origin/`weight_digest` provenance fields the Model Card, §3.1, reuses by reference rather than re-collecting), ADR-022 (Agent Identity — the attributable, revocable principal every explainability and oversight record names as `actor_of_record`), ADR-026 (Control-Plane Git-Native — cards, the incident taxonomy, the fairness-suite definitions, and the oversight policy are versioned git artifacts; the PRODUCTION-promotion gate this ADR adds, §8.2, is the DPIA-gate pattern of `REGULATED_FI_COMPLIANCE_OPS.md` §4.1 applied to responsible-AI artifacts), ADR-027 (Long-Horizon Programs — periodic card re-certification and fairness-drift remediation, §9, run as Programs, not ad hoc tasks). Companion docs: `WORKFORCE_AND_OS.md` §5, §7 (the human-accountability framing and the automation-complacency controls — `oversight_health`, decoy attention-checks, `competency_status` — this ADR formalizes into a governance artifact, §7), `AGENT_TESTER.md` §2 (the metamorphic oracle the Fairness & Bias Test Suite is built on, §5), `TOOLING_MCP_PLUGINS_ROUTING.md` §4 (the Model Router pipeline this ADR's routing-explainability mechanism instruments), `REGULATED_FI_COMPLIANCE_OPS.md` §2 (Statutory Clock machinery reused, never reimplemented, by ADR-017's extension), §4.2 (the Model-Risk Record this ADR's Model Card generalizes), §8 (the auditor evidence-access mode every card/record/register in this ADR is exposed through — no new export path).

---

## 0. Cross-cutting decisions honored (binding)

- **[Q2 — Control Plane is Git-Native, ADR-026].** Everything that is a **policy or definition** — the Model/System Card *template*, the incident-class taxonomy, the Fairness & Bias Test Suite *definitions*, the oversight policy (who must be a named approver for which decision class) — is a versioned, PII-free, CODEOWNERS-reviewed git file. Everything that is **live evidence** — a specific card's current scores, a specific incident instance, a specific Decision Explainability Record, a specific Oversight Record — is data-plane: Postgres + the hash-chained Event Log, erasable-or-held per ADR-015/ADR-017 §6. §8 states this split as a table.
- **[Q1 — Long-Horizon Programs, ADR-027].** A Model/System Card's periodic re-certification and a fairness-drift remediation (deprecate or retrain a route whose Fairness Score has regressed) are each **multi-step, checkpointed, resumable Programs** — not a single blocking task and not a silent background cron — per §9.

---

## 1. Context — why "responsible AI" needs runtime mechanisms, not a policy binder

`GAP_ANALYSIS_VS_AI_PLATFORMS.md` names the exact shape of the gap: *"As an RBI-regulated payment org (and with EU-AI-Act-style regimes spreading), AI-specific governance is mandatory, not optional: model cards/system cards, bias & fairness testing, explainability, AI decision audit trails, human-oversight records, and an AI incident-response process."* It also names what is **already solved and must not be re-solved here**: the DRAFT→PENDING_APPROVAL→APPROVED→PRODUCTION lifecycle itself is git-native (ADR-026) — branch=DRAFT, PR+CI=PENDING_APPROVAL, merge=APPROVED, signed tag=PRODUCTION, CODEOWNERS=authoring RBAC, git history=audit. **What is missing is AI-specific content flowing through that lifecycle**, and the runtime mechanisms that keep that content honest instead of stale.

Four structural facts make a policy document insufficient here, the same way `REGULATED_FI_COMPLIANCE_OPS.md` §0 argues a binder cannot hold a statutory clock:

1. **The fleet is heterogeneous and growing, not singular.** AiNxt is model-agnostic by mandate (`feedback_model_agnostic.md`) across cloud Claude/GPT/Gemini and in-house OSS Qwen/GLM/Gemma/Kimi, routed per data class (ADR-012) and gated for license/origin (ADR-018). A single "our AI is safe" statement cannot describe six-plus models with different training data, different licenses, different failure modes, and different regulatory postures. Each **route** and each production **Role/agent/skill** needs its own current card, or the org cannot answer "which of your models processed this decision, and what are its known limitations" — a question an RBI examiner, an EU-AI-Act-style regulator, or an internal risk committee can ask about any single turn.
2. **Bias/fairness is a live property of a route, not a one-time PoC finding.** A model that passes a fairness eval on launch day can regress after a provider-side model update (the same live-quality-drift problem the router's circuit-breaker, `TOOLING_MCP_PLUGINS_ROUTING.md` §4.6, already exists to catch for *quality* — fairness needs the identical discipline, not a separate one-off audit deck.
3. **Explainability is currently internal to the router's ranking and the model's own reasoning — neither is retained as a first-class, queryable record.** The router's candidate-selection pipeline (`TOOLING §4.1`) already computes `tier_eligible → class_eligible → not_regressed → rank → select/failover` deterministically — but today nothing captures *that specific computation for that specific turn* as a durable, queryable artifact. "Why did the agent route this to Claude and not GPT-5.4" or "why did the SDLC judge reject this patch" is currently answerable only by re-deriving it from logs, if at all — not by querying a record built for exactly that question.
4. **The general incident middle is unowned.** `ADR-017`'s statutory breach engine (`REGULATED_FI_COMPLIANCE_OPS.md` §2) is excellent at what it is built for — it arms a hard legal clock the instant a candidate is *plausibly* a reportable class (personal-data breach, cyber incident, outsourced-service disruption, payment-boundary event). But by design it does **not** fire for an AI-specific harm that is real and damaging yet not legally reportable: a fairness regression, a hallucinated citation a user acted on, an autonomy-runaway loop that burned budget without touching regulated data, an oversight-failure where an approver rubber-stamped a decoy (`WORKFORCE_AND_OS.md` §7). Without a home, these classes either get silently absorbed into generic bug tickets (losing the responsible-AI-specific triage and remediation discipline they need) or never get tracked at all.

Point 4 is the crux of why this ADR must exist **underneath** ADR-017 rather than being subsumed by it: **a statutory breach engine that only arms on legally-reportable classes is, by construction, the wrong home for the majority of AI-specific harm classes** — and trying to force every fairness regression through a CERT-In/DPDP lens would either trivialize the statutory clock (false-arming on non-reportable events) or leave the non-reportable majority with no process at all. The right shape is one general taxonomy with a statutory sub-table, which is exactly what §6 builds.

---

## 2. Decision

**Responsible-AI governance is a first-class runtime subsystem, built on four runtime objects, each a control-plane definition backed by data-plane evidence:**

1. **Model/System Card** (§3.1) — one per model route (cloud or in-house) and one per production Role/agent/skill, generalizing `REGULATED_FI_COMPLIANCE_OPS.md` §4.2's Model-Risk Record beyond its current DPDP-SDF-only scope to **every** production surface, cloud or in-house, SDF-relevant or not. A card is a git-versioned document whose scores are live data-plane evidence, re-certified on a cadence (§9) and invalidated on material change (mirroring the DPIA diff-invalidation rule, `REGULATED_FI` §4.1).
2. **Fairness & Bias Test Suite** (§5) — a new scenario category inside the evaluation platform (ADR-010) and the adversarial test agent (`AGENT_TESTER.md`), built on the **metamorphic oracle**: paired prompts that vary only a protected attribute and must produce materially equivalent outcomes. Runs continuously, not once, and feeds a live **Fairness Score** into each affected card.
3. **Decision Explainability Record** (§4) — a structured, queryable "why" attached to every consequential router decision (§4.1) and every consequential agentic decision (§4.2): the excluded/eligible sets, the ranking weights, the selection, and — for agentic decisions — the reasoning chain the orchestrator or judge produced. Retained on the Event Log; surfaced to end users in a redacted/simplified form (§4.3), to DPO/auditors in full via the existing evidentiary export path (`REGULATED_FI` §8), never via a new bespoke channel.
4. **AI Incident Register + Human-Oversight Record** (§6, §7) — a general, non-statutory incident taxonomy and response playbook for AI-specific harm classes, using the same detection/classification pattern as `REGULATED_FI` §2 (model classifies, policy arms) but arming a **response playbook**, not a legal clock, by default; and a formal Oversight Record that extends `WORKFORCE_AND_OS.md` §7's `oversight_health`/decoy/`competency_status` mechanism from a standalone HITL-complacency check into a card-linked, auditor-visible governance artifact.

**A model route or a production Role/agent/skill cannot reach `PRODUCTION` (ADR-026's signed-tag state) without a current, approved card, a passing Fairness & Bias Test Suite run within the configured freshness window, and a wired explainability hook** — this is a promotion gate exactly like the DPIA gate (`REGULATED_FI` §4.1), reusing the identical CI-blocking mechanism (§8.2), not a second lifecycle.

---

## 3. Core objects

### 3.1 Model/System Card (control-plane, `cards/<route_or_role_id>/definition.md`)

```yaml
card_id: card.model.claude-sonnet-4-6            # or card.role.sdlc-coder, card.role.buddy-triage
subject_type: model_route | role                  # a cloud/in-house model route, or a production Role/agent/skill
provenance:
  license_ref: <ADR-018 license register entry>   # reused by reference, never re-collected
  origin_trust_tier: trusted | untrusted           # reused from ADR-018 Gate B, if subject_type=model_route
  weight_digest: <sha256>                          # if self-hosted OSS
permitted_data_class: [public, internal, confidential, regulated-payment, PII]  # reused from ADR-012 eligibility matrix
intended_use: "..."                                # what this route/role is authored to do
out_of_scope_use: "..."                            # what a reviewer must reject if the harness tries to route it here
autonomy_level: fully_auto | assisted | supervised  # per WORKFORCE_AND_OS.md §5 — supervised is mandatory for high-judgment/regulated roles
payment_boundary_class: none | adjacent | hard_blocked  # reused from ADR-016
known_limitations: "..."                            # DPO/eval-team authored, plain language
owner: <CODEOWNERS group>                           # named accountable owner, per WORKFORCE_AND_OS.md §6 succession rules
recert_after: 180d                                  # re-certification cadence (§9)
card_status: draft | approved | stale               # stale = past recert_after with no re-cert commit
```
```
scores (data-plane, live, projected onto the card at render time — never hand-edited):
  quality_score          # from the eval platform's continuous scoreboard (TOOLING §4.3)
  fairness_score         # from §5's Fairness & Bias Test Suite, per task-type
  explainability_coverage # % of this subject's consequential decisions carrying a Decision Explainability Record (§4)
  oversight_health       # roll-up of Oversight Records (§7) for this subject's approval gates, if any
  incident_count_90d     # from the AI Incident Register (§6)
```

The **policy half** (front matter above the `scores` line) is the git-reviewed card. The **scores** are a live data-plane projection computed from the eval platform, the router's telemetry, and the incident/oversight registers — the card is never a static snapshot a reviewer fills in once; it is a reviewed *description* plus a live *dashboard*, exactly the split `REGULATED_FI` §4.2 already uses for its narrower Model-Risk Record.

### 3.2 Fairness & Bias Test Suite definition (control-plane, `fairness-suites/<task_type>/definition.md`)

```yaml
suite_id: fairness.sdlc-code-review.v1
task_type: sdlc_code_review
protected_attributes:            # India-contextualized, not an imported Western default (see §5.4, residual 5)
  - gender_coded_name
  - religion_coded_name
  - region_dialect
  - disability_mention
  - age_indicator
paired_prompt_generator: <ref to generator config>
invariant: "materially equivalent decision/answer/routing outcome across the paired attribute variants"
divergence_threshold: <config>    # beyond this, a fairness regression is flagged, not just scored
owner: <eval-team CODEOWNERS group>
```

### 3.3 Decision Explainability Record (data-plane, Event Log projection)

```yaml
record_type: routing_decision | agentic_decision
turn_id / run_id:
actor_of_record: <ADR-022 agent identity or human sub>
subject_card_ref: card.model.<...> | card.role.<...>       # §3.1
# routing_decision fields (mirrors TOOLING §4.1 exactly):
tier_eligible: [...]
class_eligible: [...]           # non-overridable step — reason if narrower than tier_eligible
not_regressed: [...]
ranked_candidates: [{model, quality_score, cost, latency}]
selected: <model>
failover_path: [...] | null
# agentic_decision fields:
reasoning_summary: "..."        # judge verdict, approval-gate recommendation, workflow branch taken, etc.
inputs_considered_ref: <Event Log slice>
outcome: <typed outcome, e.g. complete | capped | rejected>
```

### 3.4 AI Incident Register entry (data-plane; reuses the `IncidentCandidate` object of `REGULATED_FI` §2.1 verbatim)

No new detection or storage mechanism — §6 states the taxonomy this object's `class` field is classified against, which is the **superset** of the clock-arming table `REGULATED_FI` §2.2 already defines as its subset.

### 3.5 Oversight Record (data-plane; extends `WORKFORCE_AND_OS.md` §7's fields into a governance artifact)

```yaml
approver: <human sub, AD org-tree identity>
artifact_ref: <what was approved — an MR, a role-deployment, a risk-acceptance sign-off (ADR-018/019)>
decision: approve | reject | modify
latency: <time from surfaced-for-review to decision>
was_decoy: true | false
decoy_outcome: correctly_rejected | incorrectly_approved | n/a
competency_status_at_decision: normal | expired
linked_card_ref: card.role.<...>          # rolls up into that role's oversight_health score (§3.1)
```

---

## 4. Explainability of decisions and routing

### 4.1 Routing explainability

Every run of the Model Router's candidate-selection pipeline (`TOOLING §4.1`) emits a **Decision Explainability Record** (§3.3, `record_type: routing_decision`) with one field per pipeline step — `tier_eligible`, `class_eligible`, `not_regressed`, the ranked candidate list with the weights actually used, the selection, and the failover path if one was walked. This is not a new pipeline; it is an **observation tap on the existing, already-deterministic pipeline** — the router's behavior is unchanged, but its *reasoning* is now retained rather than discarded after the turn completes. Because `class_eligible` is non-overridable (`TOOLING §4.2`), a narrower `class_eligible` than `tier_eligible` on a given record is itself the explanation for "why didn't it use the better model" in the common regulated-data case.

### 4.2 Agentic-decision explainability

The same discipline applies to consequential **agentic** decisions that are not a router call at all: an SDLC judge's `complete | capped` verdict, an approval-gate recommendation, a workflow branch choice, an orchestrator's iteration-cap termination. `AgentRunner` and the SDLC state machine each emit a **Decision Explainability Record** (`record_type: agentic_decision`) carrying the reasoning summary and a reference to the Event-Log slice the decision was made over — the same "an agent may never say done except through a typed outcome" discipline `CODE_REVIEW_PIPELINE.md` already applies to correctness is applied here to *transparency*: an agent may never render a consequential verdict except through a call that also writes the record explaining it.

### 4.3 Query surface — no new export path

Two audiences, two views of the same records, both via **existing** mechanisms:

- **DPO / independent auditor / risk committee** — full-fidelity records via the auditor evidence-access mode (`REGULATED_FI` §8), read-only, chain-logged per query, exactly as that mode already serves the outsourcing register and DPIA coverage. No new auditor tooling is built for this ADR.
- **The affected end user** — a redacted, plain-language summary (never the raw ranked-candidate list or a competitor model's internal score) surfaced through the existing chat/trace UI (`TracePanel.jsx`), RBAC-gated to the user's own turns only. Generating the plain-language summary is itself an LLM call and is therefore subject to the compliance gate like any other output — an explanation can never itself leak a regulated class.

---

## 5. Bias & fairness testing

### 5.1 The metamorphic oracle, applied to fairness

`AGENT_TESTER.md` §2 already names the **metamorphic oracle** — "a required relation between inputs/outputs breaks" — as one of the layered oracles the Breaker uses to find silent correctness bugs. Fairness testing is the same oracle applied to a specific relation: **a paired-prompt generator (§3.2) holds task semantics fixed and varies only a protected attribute; the invariant is that the decision, answer, or routing outcome is materially equivalent across the pair.** A divergence is a fairness finding with the same rigor as a correctness finding — same reporting pipeline, same auto-generated regression scenario (`AGENT_TESTER.md` §6), so a fairness bug that is fixed can never silently return.

### 5.2 Continuous, not launch-day — the live Fairness Score

Beyond the eval-gate check at promotion (§8.2), the suite runs continuously against sampled production traffic, feeding a live per-`(model_or_role, task_type)` **Fairness Score** into the affected card's `scores.fairness_score` (§3.1) — the identical "quality as a live routing signal, not a static tier" discipline `TOOLING §4.3` already applies to quality, applied here to fairness.

### 5.3 A fairness regression trips the same circuit-breaker as a quality regression

A live Fairness Score drop past a configured threshold trips the **quality circuit-breaker** (`TOOLING §4.6`) for that `(model, task_type)` route exactly as a quality-score collapse does: auto-demote/quarantine, failover to the class-eligible chain, page + file the exact divergent-pair turns as a permanent regression scenario. There is **one** breaker discipline for both quality and fairness regressions, not two — to the router and to the user, a fairness collapse and a quality collapse are the same category of event: this route can no longer be trusted for this task type right now.

### 5.4 Scope discipline — localized protected attributes, not an imported taxonomy

The protected-attribute list in a Fairness & Bias Test Suite definition (§3.2) is **India-contextualized and DPO/legal-reviewed per task type**, not a copy of a Western bias-eval taxonomy: gender, religion, caste-adjacent surname and regional-dialect markers, disability mention, and age indicators are the named starting set, chosen to match the protected characteristics most relevant to an NPCI-serving population and to Indian anti-discrimination and constitutional-equality norms. This is stated as a design discipline here and named honestly as an ongoing residual (§13.5): a fixed list can miss an attribute that later proves material, and the list itself must be a reviewable, versioned git artifact for exactly that reason — never a hardcoded constant.

---

## 6. AI incident response — one taxonomy, two consumers

### 6.1 The general taxonomy (control-plane, superset of `REGULATED_FI` §2.2's clock-arming table)

| Incident class | Example trigger | Default response (this ADR) | Also statutory? (ADR-017 §2.2 extension) |
|---|---|---|---|
| **Quality-harm** | A degraded route shipped a materially wrong answer a user acted on | Containment (route quarantine, §5.3-style) + user notification if consequential | Only if on a regulated route (`REGULATED_FI` table row 5) |
| **Fairness-harm** | Fairness Score regression or a confirmed divergent-pair finding in production | Route quarantine (§5.3) + postmortem-as-eval-case (§6.4) + card `fairness_score` update | No, unless the harm also exposed PII in the process |
| **Explainability-failure** | A consequential decision has no Decision Explainability Record (a wiring gap, §4) | Blocks that subject's next promotion (§8.2) until the gap is closed; not itself a legal-reportable event | No |
| **Misuse / jailbreak success** | A guardrail (ADR-008, to be written) is bypassed and the model produces disallowed content | Containment + guardrail-suite regression case | Only if it also egressed a regulated class (compliance-gate-detected) |
| **Autonomy-runaway** | An agent loop exceeds its iteration cap or trips a loop-guard-style circuit breaker (`feedback_cowork_loop_guard.md`) without producing value | Kill-switch + cost/budget review; a postmortem, not by default a legal incident | Only if it approached the payment boundary (ADR-016 hard-class review row) |
| **Oversight-failure** | An approver approves a known-bad decoy, or `competency_status: expired` is detected (`WORKFORCE_AND_OS.md` §7) | Immediate incident to the approver's manager + mandatory-retraining flag (reused verbatim from `WORKFORCE_AND_OS` §7.2) | No |

### 6.2 Classification and response — model classifies, policy arms (reused pattern)

An `IncidentCandidate` (§3.4) is raised by the same class of detector `REGULATED_FI` §2.1 already lists (compliance gate, quality/fairness circuit-breaker, Side-Effect Ledger anomaly, an operator declaration) plus two AI-specific sources this ADR adds: an **explainability-coverage sweep** (a nightly job flagging any consequential-decision type whose coverage, §3.1, drops below 100%) and the **decoy/competency mechanism** (`WORKFORCE_AND_OS` §7.2/§7.3). A **triage Role** classifies the candidate against the taxonomy above; **the response playbook that fires is a deterministic function of the classified class**, not model judgment — the same fail-safe, model-classifies/policy-arms discipline `REGULATED_FI` §2.2 uses for statutory clocks, applied here to a response playbook instead of a legal deadline.

### 6.3 The statutory subset — the exact ADR-017 extension seam

`REGULATED_FI_COMPLIANCE_OPS.md` §2.2's clock-arming table is **the same classification step, reading the same `IncidentCandidate.class` field, consulting a second policy table** that maps a subset of this ADR's classes to CERT-In/DPDP/RBI clocks. ADR-017 does not define its own incident detection or its own candidate object — it consults this ADR's taxonomy and adds the one thing that is genuinely statute-specific: the clock. This is stated once, here, as the canonical description of the relationship, so neither document needs to re-derive it: **ADR-011's taxonomy is the superset; ADR-017 §2.2's table is the subset that also carries a legal deadline.**

### 6.4 Postmortem discipline

Every incident closes with a postmortem that, where the class is quality- or fairness-related, **files the exact triggering case as a permanent regression scenario** in the eval platform (`TOOLING §4.6`'s discipline, generalized) — a fairness or quality incident can be contained, but the regression it revealed can never silently return once the route recovers, because the recovered route must pass the new scenario, not merely climb back above a live threshold.

---

## 7. Human-oversight records

### 7.1 Formalizing `WORKFORCE_AND_OS.md` §7 into a governance artifact

`WORKFORCE_AND_OS.md` §7 already designs the mechanism — `oversight_health` metrics (approve-latency, override-rate), unpredictable decoy attention-checks on high-stakes approvals, and a `competency_status` gate at approval-dispatch time — as a standalone automation-complacency control. This ADR does not rebuild that mechanism; it **names its output as the Oversight Record (§3.5)**, a first-class, card-linked, auditor-visible object, so "is a named human's oversight of this Role's approvals real" becomes a queryable governance fact rather than only a manager-visible dashboard signal.

### 7.2 Card roll-up

Every Oversight Record whose `linked_card_ref` names a Role's approval gate rolls up into that Role's Model/System Card `scores.oversight_health` field (§3.1) — a card-consumer (a promoting engineer, a DPO, an auditor) sees the oversight-health signal in the same place they see the fairness and quality signals, not in a separate dashboard only a manager visits.

### 7.3 Sibling, not duplicate, of the ADR-019 Accountability Record

`ADR-019` §4 defines an **Accountability Record**: an after-the-fact object naming the human/agent action, environment, and control-plane SHA behind a specific financial loss, built for adjudication. This ADR's **Oversight Record** is its before-the-fact sibling: it captures whether a human's *judgment was actually exercised* at approval time (latency, decoy result, competency status), independent of whether that approval later turns out to have been correct. The two are related but answer different questions — "was oversight real when it happened" (Oversight Record, this ADR) versus "who is attributable now that harm occurred" (Accountability Record, ADR-019) — and ADR-019's adjudication function (§7.2 there) can consult this ADR's Oversight Record as one input to attribution without either object needing to subsume the other.

### 7.4 Extending decoy/competency checks beyond SDLC

`WORKFORCE_AND_OS` §7.2's decoy mechanism is scoped there to `payment_boundary != none` or regulated-data-class approvals. This ADR extends the identical mechanism, unmodified, to two more consequential approval classes named elsewhere in the corpus that were not originally in scope: an **agent-role production-deployment approval** (ADR-026's promotion gate) and a **risk-acceptance sign-off** (ADR-018 §origin-trust-designation, ADR-019 §5.3's reason-coded liability-posture override) — both are exactly the "high-judgment, rarely-exercised, easy-to-rubber-stamp" shape the decoy probe is designed to catch, and both now write an Oversight Record.

---

## 8. Governance & lifecycle (the Q2 split, and the promotion gate)

### 8.1 The split, stated as a table

| Artifact | Plane | Store | Erasable? |
|---|---|---|---|
| Model/System Card template + front-matter fields | Control | git (`cards/<id>/definition.md`) | No (versioned, reviewed) |
| Incident-class taxonomy (§6.1) | Control | git | No |
| Fairness & Bias Test Suite definitions + protected-attribute lists (§3.2, §5.4) | Control | git | No |
| Oversight policy (which approval classes require a decoy/competency gate, §7.4) | Control | git | No |
| A specific card's live scores (§3.1 `scores` block) | Data | Postgres, projected from eval platform + router telemetry | Rebuildable |
| A Decision Explainability Record (§3.3) | Data (append-only) | Event Log | Per ADR-015/017 §6 — held if it underlies an open incident/adjudication |
| An IncidentCandidate / register entry (§3.4) | Data | Event Log + `REGULATED_FI` incident register | Per ADR-017 §6 legal-hold precedence |
| An Oversight Record (§3.5) | Data (append-only) | Event Log | Per ADR-015/017 §6 — held if it underlies an ADR-019 adjudication |

### 8.2 Promotion gate — the DPIA-gate pattern, reused verbatim

A model route or a production Role/agent/skill **cannot reach `PRODUCTION`** (ADR-026's signed-tag state) unless, at promotion time:

1. Its Model/System Card (§3.1) exists, is `card_status: approved`, and is not past `recert_after` (§9).
2. The Fairness & Bias Test Suite for its task type(s) has run within the configured freshness window with no open, unremediated divergence finding above threshold.
3. Its consequential decision points are wired to emit Decision Explainability Records (§4) — verified by the explainability-coverage sweep (§6.2), not by reviewer attestation alone.

This is **the identical CI-blocking mechanism** `REGULATED_FI_COMPLIANCE_OPS.md` §4.1 already uses for the DPIA gate — a required, owned, versioned dependency the promotion job checks — extended to three new required dependencies rather than a second promotion pipeline. A diff that changes a subject's `permitted_data_class`, `autonomy_level`, or `payment_boundary_class` invalidates its card (content-hash mismatch, same discipline as the DPIA diff-invalidation rule) and blocks re-promotion until re-certified.

---

## 9. Interaction with Q1 — Long-Horizon Programs

- **Periodic card re-certification** (§3.1 `recert_after`) is a Program: it re-runs the Fairness & Bias Test Suite, re-checks provenance against the current ADR-018 license/origin registers, and re-derives `known_limitations` review — checkpointed so a re-cert that spans a provider outage or a model version bump resumes rather than restarts, and produces a fresh signed commit that resets the clock (mirroring `WORKFORCE_AND_OS` §6.2's re-cert-as-a-PR pattern).
- **Fairness-drift remediation** (a route whose live `fairness_score` has regressed past the threshold and been quarantined, §5.3) is a Program: contain → root-cause the divergence (which protected attribute, which task type) → remediate (prompt fix, retrain, or a permanent route exclusion) → re-run the suite → lift quarantine — with partial completion (the route stays quarantined pending a slower remediation track) as a first-class, deployable outcome, exactly as `LONG_HORIZON_PROGRAMS.md` requires rather than an all-or-nothing scramble.

---

## 10. Alternatives considered

1. **Treat responsible-AI governance as documentation adjacent to the platform — a model-card PDF, a bias-audit slide deck, an incident runbook.** Rejected for the identical reason `REGULATED_FI_COMPLIANCE_OPS.md` §0 rejects a compliance binder: none of these have a clock, an enforcement mechanism, or a queryable record, and every one goes stale the moment the fleet changes.
2. **Fold this entirely into ADR-017's statutory breach engine — one incident register, one clock table.** Rejected (§1 point 4, §6.3): the majority of AI-specific harm classes (fairness regression, explainability gaps, oversight complacency) are real and damaging but not legally reportable; forcing them through a statutory lens either trivializes the legal clock or leaves them untracked. One taxonomy, two consumers (this ADR's superset, ADR-017's statutory subset) is the correct shape.
3. **Import a generic Western bias-eval taxonomy (e.g., a fixed US-centric protected-attribute list) wholesale.** Rejected (§5.4): NPCI serves an Indian population under Indian constitutional-equality and anti-discrimination norms; the protected-attribute list must be locally reviewed and versioned, not copied.
4. **A single global "AI safety score" per model, computed once.** Rejected: collapses quality, fairness, explainability coverage, and oversight health into one number a promotion gate cannot reason about individually — `TOOLING §4.3`'s "quality as a live routing signal, not a static tier" argument applies identically here; each signal must be independently visible and independently able to trip its own gate.
5. **Let the model self-report its own explainability ("ask the model why it decided that" at read time, with no stored record).** Rejected: a model's post-hoc rationalization is not guaranteed to match the actual computation that produced the decision (especially for routing, which is a deterministic pipeline the model never sees), and it produces nothing durable for an auditor to query two years later. The Decision Explainability Record captures the *actual* pipeline state (§4.1) or the actual reasoning chain at decision time (§4.2), not a reconstruction.

---

## 11. Acceptance / scenario tests

| # | Scenario | Setup | Expected | Proves |
|---|---|---|---|---|
| 1 | No card, no promotion | A new Role attempts to promote to `PRODUCTION` with no approved card | CI blocks the promotion job | §8.2 gate |
| 2 | Stale card blocks promotion | A card's `recert_after` has lapsed with no re-cert commit | `card_status` flips to `stale`; the next promotion attempt for that subject is blocked | §8.2, §9 |
| 3 | Card diff invalidates approval | A promoted Role's `payment_boundary_class` changes | The card's content hash mismatches; re-promotion blocked until re-certified | §8.2 diff-invalidation |
| 4 | Routing decision is explainable | Inspect any turn that hit the Model Router | A Decision Explainability Record exists with the exact `tier_eligible/class_eligible/not_regressed/selected` values for that turn | §4.1 |
| 5 | Agentic decision is explainable | Inspect an SDLC judge's `capped` verdict | A Decision Explainability Record exists with the reasoning summary and Event-Log slice reference | §4.2 |
| 6 | Fairness divergence detected | Run the paired-prompt generator for a task type with a known-biased test route | The metamorphic oracle flags the divergent pair; a fairness finding is filed with the same rigor as a correctness finding | §5.1 |
| 7 | Fairness regression trips the breaker | A route's live `fairness_score` drops past threshold | The route is quarantined via the same mechanism as a quality-circuit-breaker trip; traffic fails over to the class-eligible chain | §5.3 |
| 8 | One taxonomy, two consumers | An `IncidentCandidate` is classified as "confirmed personal-data breach" | This ADR's general register logs it under `quality-harm`/`fairness-harm`/etc. as applicable, **and** `REGULATED_FI` §2.2's table independently arms the DPDP clock from the same classification | §6.3 |
| 9 | Non-statutory incident still gets a response | An autonomy-runaway incident with no PII/payment-boundary involvement | A response playbook (kill-switch + postmortem) fires; no statutory clock arms; the incident is still logged and auditable | §6.1, §6.3 |
| 10 | Oversight Record feeds the card | An approver rubber-stamps 50 consecutive approvals with 0 override-rate | `WORKFORCE_AND_OS` §7's complacency flag fires; the linked card's `oversight_health` score reflects it | §7.1, §7.2 |
| 11 | Decoy extended to a new approval class | A decoy risk-acceptance sign-off (ADR-019 §5.3-shaped) is injected into a governance-approval queue | An approver who approves it triggers an immediate incident + mandatory-retraining flag, identically to the existing SDLC-scoped decoy | §7.4 |
| 12 | Explainability-coverage gap is itself an incident | A new consequential decision point ships with no wired Decision Explainability Record | The nightly coverage sweep flags it; the subject's next promotion is blocked until closed | §6.1 (explainability-failure), §8.2 |
| 13 | Auditor queries without an engineer | The DPO pulls a card's fairness/oversight history and a set of Decision Explainability Records for a disputed turn | Read-only auditor-mode session, chain-logged, no new export mechanism built | §4.3, `REGULATED_FI` §8 |
| 14 | Oversight vs. Accountability distinction holds | A payment-loss incident triggers an ADR-019 Adjudication Program | The Program consults the relevant Oversight Record(s) as one input to attribution; the Oversight Record itself is not overwritten or reinterpreted as an Accountability Record | §7.3 |

---

## 12. Consequences

**Positive.** Every clause of gap D now has a concrete runtime mechanism instead of a promise: a card exists per route/Role and cannot go stale unnoticed (§3.1/§8.2/§9); fairness is tested continuously with the same rigor and the same circuit-breaker discipline as quality (§5); every consequential routing and agentic decision is retained as a queryable record rather than reconstructed after the fact (§4); the AI-specific incident middle that ADR-017's statutory engine structurally cannot own now has a home, without diluting ADR-017's legal clocks (§6); and human oversight — the thing that makes "a named human is accountable" (`WORKFORCE_AND_OS` §5) more than a sentence — is now a governance artifact a card, a promotion gate, and an auditor can all see. Three later ADRs (017/019/025) each get a clean extension seam instead of having to build their own incident/accountability/evidentiary substrate from scratch.

**Negative / cost.** Every production model route and Role now carries a card-maintenance and re-certification burden on its owning CODEOWNERS group; the Fairness & Bias Test Suite is a new, ongoing eval-engineering investment (paired-prompt generators, threshold tuning) that does not yet exist anywhere in the corpus; the explainability-coverage sweep and the promotion gate add a new CI dependency every subsystem touching a model route or Role must satisfy before shipping; the decoy/competency extension (§7.4) imposes the same "an approver's queue occasionally contains a test" friction WORKFORCE_AND_OS §7 already accepted, now on two more approval classes.

**Neutral.** No existing mechanism is replaced: the Model Router pipeline (`TOOLING §4.1`), the quality circuit-breaker (`TOOLING §4.6`), the statutory breach engine (`REGULATED_FI` §2), the `WORKFORCE_AND_OS` §7 oversight mechanism, and the ADR-026 promotion machinery all continue to work exactly as designed — this ADR instruments and extends them, and gives their outputs a shared home (the card) and a shared query surface (the existing auditor mode).

---

## 13. Residual risks (honest, not deferred silently)

1. **The Fairness & Bias Test Suite does not yet exist as running code, and "protected attribute" for an Indian payment-services population is a genuinely harder and less-precedented eval-engineering problem than the Western bias-eval literature this space usually draws on.** §5.4 names the discipline (locally reviewed, versioned, not imported); it cannot itself produce a validated, complete attribute list or a calibrated divergence threshold — that is real eval-engineering work with no shortcut.
2. **Explainability for an agentic (non-routing) decision is only as good as the reasoning summary the orchestrator/judge chooses to emit.** Unlike the router's Decision Explainability Record (§4.1), which mirrors an actually-deterministic pipeline, an LLM-produced reasoning summary (§4.2) can still be a rationalization rather than a faithful trace of the model's actual internal computation — this ADR retains what the agent *reports* as its reasoning, which is a meaningfully weaker guarantee than the router case, and is stated as such rather than oversold.
3. **The general/statutory taxonomy split (§6.3) depends on the classification step being correct.** A triage Role that misclassifies a genuinely reportable incident as a non-statutory class would leave ADR-017's clock unarmed — the same fail-safe, arm-early mitigation `REGULATED_FI` §2.2 already applies (provisional arming, human-confirmed downgrade only) is the load-bearing safeguard here, not a property of this ADR's taxonomy alone.
4. **Card staleness is caught by a recert cadence, not continuously** — a card can describe a route's provenance or known limitations slightly out of date for up to `recert_after` before the gate catches it, the same class of residual `WORKFORCE_AND_OS` §6.1's decay-sweep names for citizen-authored artifacts generally.
5. **This ADR adds real, ongoing operational cost (card maintenance, continuous fairness testing, coverage sweeps) to every model route and production Role, ahead of any confirmed India-specific AI-governance statute mandating it at this granularity today.** It is built proactively, matching the trajectory of EU-AI-Act-style regimes and RBI's general model-risk direction (`REGULATED_FI` §4.2), but — honestly, as ADR-023 names for its own PQC roadmap — no binding NPCI-specific mandate is asserted to exist at design time for every clause of this ADR.

---

## 14. Self-score (honest)

**Design ceiling: 9/10.** Every clause of gap D has a concrete, testable mechanism: a card per subject with a live-scores/reviewed-policy split (§3.1, §8.1) that generalizes rather than duplicates the existing Model-Risk Record; a fairness discipline built on the corpus's own metamorphic-oracle pattern rather than a bolted-on separate framework (§5.1); explainability that instruments the router's already-deterministic pipeline instead of inventing a parallel one (§4.1); an incident taxonomy whose relationship to ADR-017's statutory engine is stated as one precise sentence rather than left implicit (§6.3); and a human-oversight mechanism that names its exact sibling relationship to ADR-019's Accountability Record instead of overlapping with it (§7.3). The three forward extension seams (ADR-017/019/025) are each anchored to a specific section a reader can go verify, per the task's own framing.

The missing point is honest and concentrated in what a design document cannot manufacture: **the Fairness & Bias Test Suite's actual content (attribute list, divergence thresholds) is real, unstarted eval-engineering work specific to an Indian context with limited external precedent** (residual 1) — the mechanism around it is fully specified, but the mechanism's first real run will surface calibration questions no design pass can pre-answer; and **agentic-decision explainability is a reported rationalization, not a verified trace** (residual 2), a limitation inherent to instrumenting an LLM's reasoning rather than a deterministic pipeline. **Build maturity: 0/10** — no code exists, consistent with every other artifact in this corpus; the ceiling is set so implementation has a real target to descend from, not an inflated one.
