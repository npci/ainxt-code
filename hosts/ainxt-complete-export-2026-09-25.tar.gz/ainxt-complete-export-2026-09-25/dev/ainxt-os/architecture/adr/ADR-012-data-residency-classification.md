# ADR-012 — Data Residency, Sovereignty & Data Classification: the taxonomy and the non-overridable data-class → model-eligibility matrix the Model Router enforces as a compliance component

**Status:** Accepted — Design only (no code). Authors, as the single source of truth, the two facts the rest of the corpus already consults as a settled invariant but which no document yet *defines*: (a) the **data-class taxonomy** `{public, internal, confidential, regulated-payment, PII}`, and (b) the **non-overridable data-class → model-eligibility matrix**. Closes gap **N** (`GAP_ANALYSIS_VS_AI_PLATFORMS.md` §N — "the architecture-breaking one": cloud model-routing contradicts RBI payment-data-localisation and DPDP cross-border limits) and gap **O** (data classification & purpose limitation). The README (`adr/README.md`) explicitly records this debt: *"ADR-012 … remains formally unwritten even though ADR-004/ADR-006/ADR-018 already consult its non-overridable data-class gate as a settled invariant — the standalone ADR-012 file still owes the classification taxonomy and eligibility-matrix authoring independent of the seams that consult it."* This ADR discharges that debt.

**Decision class:** Architecture-defining, P0 foundational, **safety-invariant**. Per `IMPLEMENTATION_PLAN.md` §Phase 0, ADR-012 is load-bearing on the Phase-1 pipeline design and **must be decided before P1 code** (§67: *"ADR-012 (data-class-driven routing) … [is] load-bearing on the P1 pipeline design"*; Part D P1: *"Router as compliance component: N/O data-class → model-eligibility routing 🔴"*). It is the decision that turns `feedback_model_agnostic.md`'s "model-agnostic" into "**compliance-gated** model-agnostic": the runtime routes to the best model *among the eligible set*, where eligibility is a compliance determination, not a preference.

**What this ADR owns vs. what it deliberately defers (one source of truth per fact):**
- **This ADR owns** — the taxonomy (§4), the classification mechanism (§5), the eligibility matrix content (§6), the residency axis (§7), and the class-awareness requirement on **retrieval and embedding** (§8). These are the *substance* the other seams enforce.
- **This ADR defers** — the *seam mechanics* to the documents that own them, and states its binding contract with each: **ADR-006** (Provider Gateway + Model Router) owns *where* the gate slots into the selection pipeline (step 2) and *that* it is non-overridable and pre-filters failover; **ADR-018** (Model Governance) owns the license + nation-of-origin gates that run *underneath* this one (steps 3–4); **ADR-003** (Policy/Compliance seam) owns that the exclusion is *authorization on the un-skippable seam*, not a router optimization; **ADR-017** (Regulated-FI Compliance Ops) owns the Outsourcing Register that *declares* per-external-route `permitted_data_class` + `data_residency`; **ADR-026** (Control-Plane Git-Native) owns that the matrix + taxonomy are *versioned definitions, not DB rows or code*. This ADR neither re-derives nor duplicates those mechanisms; it supplies the content they consume.

**Relates to / extends:** ADR-001 (strangler-fig sidecar — the classifier + eligibility gate are Rust-native runtime/control-plane components the sidecar owns), ADR-003 (Policy/Approval/Compliance seam — §7.5 there records the data-class exclusion as a Policy-Engine authorization that runs before ranking; this ADR is the *content* of that exclusion), ADR-004 (config-first, safety-invariant — the eligibility matrix is control-plane per ADR-026, **not** a config key; a per-request override can tighten but never loosen it via `narrow_only` MEET semantics, §9), **ADR-006 (Provider/Model-Router — the seam this ADR's gate is step 2 of; consulted first and non-overridably, ADR-006 §4.1/§5)**, ADR-007 (Event Log — the turn's computed data-class, chosen route, residency label, and embedder digest are recorded beside the route decision), ADR-009 (Prompt-Injection Defense — *provenance/trust* is a **separate** axis from *data-class*; §5.4 keeps them orthogonal), ADR-015 (Data Lifecycle / DPDP retention-erasure — **an embedding of PII is itself PII**, so §8's class-partitioned vector namespaces are subject to ADR-015's erasure cascade; ADR-015 remains to-be-written), ADR-016 (Agent-Payment Boundary — the `regulated-payment` class includes every ADR-016 payment path; ADR-018's origin gate keys on this class), **ADR-017 (Outsourcing Register — the register *is* the router's eligibility input for external routes; its `permitted_data_class` + `data_residency` fields are the per-route declaration this ADR's matrix is evaluated against, `REGULATED_FI_COMPLIANCE_OPS.md` §3.2)**, **ADR-018 (Model Governance — the license + origin gates run *underneath* this data-class gate; ADR-018 §3 lays them beneath ADR-012 §4.2 and never relaxes it)**, ADR-020/021 (Serving-Ops / Hardware-Trust — the *residency zone* of a self-hosted route and the attestation that a regulated route runs on trusted in-zone hardware compose beneath this gate), **ADR-026 (Control-Plane Git-Native — the eligibility matrix + taxonomy + classification policy are versioned, CODEOWNERS-governed, signed, air-gap-clean definitions, §9)**. Reconciles `feedback_model_agnostic.md` (agnostic *where safe*, not unconditionally) and `feedback_redact_dont_block.md` (redact-and-proceed is a *user-facing-sink* rule, and is **not** a licence to redact regulated context and ship it to a cloud model — §11 alt. 4).

**Python-platform analog (strangler-fig):** `agents/compliance_engine.py` (the PAN/CVV/Aadhaar/IFSC/UPI/account detectors whose findings are one of the three classification signals), `models/model_router.py` + `core/model_registry.py` (routing + `BLOCKED_MODELS`), `models/hybrid_retriever.py` / `hybrid_search.py` + `services/embed_svc/main.py` (the retrieval + embedding path §8 makes class-aware). CLAUDE.md's retrieval-scope-separation rule (voice/chat vs projects/threads RBAC) is the existing coarse form of the class-aware filter this ADR generalizes.

---

## 1. Context — the one gap that does not merely *add* a feature; it *contradicts* the architecture

Every other gap in the corpus is additive. This one is subtractive: left unaddressed, it makes a core design assumption **illegal**. `GAP_ANALYSIS_VS_AI_PLATFORMS.md` §N states it precisely and flags it 🔴 as *"the architecture-breaking one"*:

> *"Our design happily routes to Claude/GPT/Gemini in the cloud. **For NPCI that may be illegal for sensitive payment/customer data** — RBI mandates payment data stays in India; DPDP constrains cross-border transfer. **Every cloud model call ships context abroad.** This is not a feature gap; it contradicts the model-router-picks-the-best-model design."*

A model router whose job is "pick the smartest/cheapest/fastest model" will, unmodified, send a customer's card number or a settlement record to a cloud endpoint in another jurisdiction — because the cloud model is often the best on those axes. For the runtime of India's national payment switch, that is not a quality trade-off; it is a **residency and sovereignty breach** the moment the bytes cross the boundary. Three regimes bind simultaneously (`REGULATED_FI_COMPLIANCE_OPS.md` §0):

- **RBI payment-data-localisation** — payment-system data must be stored (and, for the sensitive path, processed) *in India*. A cloud LLM call is processing abroad.
- **DPDP Act 2023** — cross-border transfer of personal data is constrained; purpose limitation and lawful basis bind every use.
- **PCI-DSS v4.0** — cardholder data must never reach an out-of-scope system or a durable store it does not belong in; a cloud prompt and a cloud embedding are both out-of-scope destinations.

The resolution §N names — and which this ADR authors in full — is: **the Model Router becomes a compliance component that happens to also optimize cost/latency/quality, not the reverse.** Data is *classified*; a *data-class → model-eligibility matrix* confines regulated/PII data to in-house self-hosted models; non-sensitive traffic may still use cloud. This is *why* the OSS fleet (Qwen/GLM/Gemma/Kimi/Llama, ADR-018) is a **hard architectural requirement** and not one option among several — the eligible set for the highest-sensitivity classes is *empty* without self-hosting.

**Two things §N says almost in passing are load-bearing and are this ADR's sharpest content:**

1. *"Retrieval/context assembly must also be class-aware (you can't RAG a regulated doc into a cloud prompt)."* The gate cannot live only at the moment a generative model is dialed. Context is *assembled* before it is sent; a regulated document retrieved into a cloud-eligible prompt has already leaked at assembly time. **And the same is true of embedding** — an embedding call is a model call that ships the raw plaintext to whatever endpoint computes the vector. A cloud embedding API used to index a regulated document is *identical exposure* to a cloud prompt, and it is far easier to miss because embedding is mentally filed as "just indexing." §8 makes both retrieval and embedding class-aware, and treats **an embedding of regulated/PII content as regulated/PII content** (both in transit and as an artifact).

2. The other seams already *assume this ADR exists.* ADR-006 §4.1 lists `class_eligible ← ADR-012` as step 2 of its pipeline; ADR-018 §3 lays its license + origin gates *"underneath the existing data-class → model-eligibility gate"*; ADR-003 §7.5 records the exclusion as a Policy-Engine authorization; ADR-017 §3.2 makes its Outsourcing Register *"the router's eligibility input"*; `TOOLING_MCP_PLUGINS_ROUTING.md` §4.2 sketches the matrix. Four documents consult a gate whose taxonomy and matrix live nowhere as an authored, versioned source. **That is the exact one-source-of-truth failure ADR-026 exists to prevent** — a fact enforced by many consumers but defined by none. This ADR is the source; the consumers reference it, never restate it.

The subtle point that makes this a *classification* problem and not merely a *routing* problem: you cannot route by data class until you can *assign* one, per turn, to a body of text assembled from many sources plus free-form user input. §5 is the classification mechanism; §6 is what the class then forbids.

---

## 2. Decision

**Author the data-class taxonomy and the non-overridable data-class → model-eligibility matrix as versioned control-plane definitions, make every model-facing surface — generative, embedding, rerank, vision, ASR — class-aware, and enforce two orthogonal axes (eligibility and residency) in the router's single exclusion phase, before any ranking, failover, or user preference.**

1. **A five-class taxonomy (§4).** Every unit of content the runtime handles carries exactly one of `{public, internal, confidential, regulated-payment, PII}`, defined against NPCI's actual regulated types (PAN/CVV/expiry/PIN-block, account-number/IFSC, Aadhaar/INDIA-PAN, UPI/mobile/email) and their regulatory basis. A cross-cutting **`secret`** class (keys/tokens) is *removed*, never routed — orthogonal to residency and owned by ADR-003 (§4.4).

2. **Classification is a per-turn MEET of three signals that must agree (§5).** A turn's (or a chunk's, or an embedding input's) data class = the **most sensitive** of: the Compliance Gate's live findings on the assembled content, the chunk/node-level data-class labels carried by retrieved content (the Context Fabric security filter — *same classifier, same labels*, so retrieval and routing can never disagree), and the static per-harness ceiling declared at authoring time. Any one signal escalating the class escalates the turn. Ambiguous/unscannable content **fails safe** to the most-restrictive class. Data-class is **orthogonal to trust/provenance** (ADR-009) — a class is *how sensitive*, provenance is *how trustworthy*; conflating them is a category error (§5.4).

3. **The eligibility matrix is non-overridable and confines the sensitive classes to in-house models (§6).** `regulated-payment` and `PII` → **in-house self-hosted OSS models only**; `confidential` → in-house, **or** a contracted private-tenancy deployment under a data-processing agreement, **never a generic public-cloud endpoint**; `internal`/`public` → any tier-eligible model (cloud included, subject to §7). This is the *content* of ADR-006 §4.1 step 2 / ADR-003 §7.5's Policy-Engine exclusion: it runs **before ranking and before failover**, it **pre-filters the failover chain**, it **fails closed** on an empty eligible set, and **a user's explicit model selection is a rank-preference inside the eligible set, never a re-admission of an excluded model** (§6.3).

4. **Residency is a second, orthogonal axis enforced in the same exclusion phase (§7).** Data-class decides *which* model; residency decides *where even an eligible route physically runs*. A request carrying an in-country residency label (RBI localisation) excludes any route — cloud *or* in-house — whose serving zone is out-of-country. For external routes this reads ADR-017's Outsourcing-Register `data_residency`; for self-hosted routes it reads the Serving-Ops zone (ADR-020). Two labels, one exclusion phase, same fail-closed discipline.

5. **Retrieval AND embedding are class-aware (§8).** Regulated/PII content **never enters a cloud prompt** (Context Fabric pre-rank security filter) **and never enters a cloud embedding** (the embedding model is governed by the *same* matrix as a generative model). Vector indexes are **partitioned by data class** — no shared namespace mixes tiers, and the *query* is embedded by the class-eligible embedder too. An embedding of regulated/PII content is regulated/PII (ADR-015 erasure cascades to it). Multimodal (vision/ASR) models that *touch* regulated artifacts are gated identically (§8.4).

6. **The matrix, the taxonomy, and the classification policy are control-plane definitions (§9).** They are versioned Markdown-with-front-matter files in `ainxt-control`, CODEOWNERS-governed (security-council + DPO), signed, all-or-nothing loaded, air-gap-clean — **not** config keys (ADR-004 draws the line: *eligibility* is control-plane; *endpoint/credential wiring for reachable providers* is config), **not** DB rows, **not** hardcoded match arms.

---

## 3. The invariant, stated once

> **Every unit of content the runtime handles is assigned exactly one data class, computed per-turn as the most-sensitive of the compliance findings, the retrieved-content labels, and the harness ceiling. `regulated-payment` and `PII` content may reach only in-house self-hosted models — for *every* model-facing operation: prompt, embedding, rerank, vision, and ASR — and only in an in-country zone. This exclusion runs before ranking, before failover, and before any user preference; it pre-filters the failover chain; it fails closed on an empty eligible set; and there is no surface — user selection, failover fallback, retrieval path, or embedding path — through which excluded data can reach an ineligible model. What is configurable is which providers are reachable at all; what is not configurable is which class may reach which of them.**

This is the *content* of the exclusion ADR-003 §7.5 places on the un-skippable Policy seam and ADR-006 §5 makes mechanically non-overridable. Those ADRs guarantee the gate *runs and cannot be bypassed*; this ADR defines *what it decides*.

---

## 4. The data-class taxonomy (authored here; consulted everywhere)

Five classes form a total order of sensitivity. A class is a **ceiling**: it states the *maximum* sensitivity present, and — like every safety ceiling in the corpus (ADR-004 `narrow_only`) — a more-specific signal may only *tighten* it, never loosen it (§5).

| Class | What it is | NPCI-specific types (from `agents/compliance_engine.py`) | Regulatory basis | Model eligibility (§6) | Residency (§7) |
|---|---|---|---|---|---|
| **public** | Already-public information; general knowledge; published standards/docs | — | none | any tier-eligible model | any |
| **internal** | Ordinary NPCI working data with no personal/payment/restricted content — internal code, tickets, most engineering docs | — | none (org policy) | any tier-eligible model (cloud incl., per §7 register) | any |
| **confidential** | Non-personal but commercially/operationally sensitive — unreleased settlement logic, security configurations, member-bank contracts, internal audit findings, incident postmortems | — | org + contractual | in-house, **or** contracted private-tenancy + DPA; **never** generic public cloud | in-region |
| **regulated-payment** | Cardholder + payment-system data | `PAN`, `CVV`, `EXPIRY`, `PIN_BLOCK`, `ACCOUNT_NUMBER`, `ACCOUNT_NAME_COMBO`, `IFSC_CODE`, UPI transaction data, settlement/clearing records | RBI payment-data-localisation; PCI-DSS v4.0 | **in-house self-hosted OSS only** | **in-country only** |
| **PII** | Personal data of an identifiable data principal | `AADHAAR`, `INDIA_PAN`, `MOBILE`, `EMAIL`, name+identifier combos, KYC documents/images, biometrics | DPDP Act 2023; Aadhaar Act | **in-house self-hosted OSS only** | **in-country only** |

**Notes that matter:**

- **`regulated-payment` and `PII` are distinct but co-eligible.** They differ in regulatory basis (payment-localisation vs DPDP) and in downstream obligations (PCI scoping vs DSAR/erasure), so they are kept as two classes rather than collapsed — but they share the *same* model-eligibility and residency verdict (in-house, in-country). A datum can be both (a KYC image bearing a PAN); the MEET (§5) simply resolves to the union of obligations. `AADHAAR` is deliberately `PII`, not `regulated-payment`, because its obligations are DPDP/Aadhaar-Act-shaped even though its routing verdict is identical.
- **`confidential` is the one class with a *conditional* cloud path.** Unlike the two regulated classes, it *may* use cloud — but only a **contracted private-tenancy deployment under a DPA**, which is an *external route* and therefore an **Outsourcing-Register arrangement** (ADR-017 §3) whose `permitted_data_class` must be `confidential` and whose `data_residency` must satisfy §7. A generic public-cloud endpoint (no tenancy contract, no DPA) is *never* eligible for `confidential`. This is the tier where §6 and §7 most visibly compose.
- **The taxonomy is a total order for the MEET.** `public < internal < confidential < {regulated-payment, PII}`. The two top classes are incomparable in *basis* but equal in *routing verdict*; the MEET on a mixed body of content takes the maximum verdict and the union of obligations.

### 4.4 The cross-cutting `secret` class — removed, never routed

Keys and credentials (`SECRET`, `API_KEY`, `ACCESS_TOKEN`, `PRIVATE_KEY_LEAK`, `CERTIFICATE_LEAK`, `SSH_KEY_LEAK`, `KEY_ASSIGNMENT_LEAK`, `PAYMENT_KEY_LEAK`) are **not** a residency class and are handled *before* routing even arises. A secret is never "routed to an in-house model"; it is **redacted/removed from the payload entirely** by the Compliance Gate (ADR-003 §6) regardless of which model — cloud or in-house — the turn will use. This distinction is stated explicitly because it is a common error to file secrets under "route to in-house": a secret has *no* legitimate destination in a model prompt at all, so the correct action is removal, not confinement. Residency routing (§6/§7) governs *where legitimate content may go*; secret handling governs *content that may go nowhere*.

---

## 5. Classification — how a turn is assigned a class

Routing by class is impossible until a class is assigned. A turn is not a single document — it is free-form user input plus content assembled from many retrieval layers (Context Fabric §2), each carrying its own label. The class must be computed **per turn, at assembly time, as a MEET (most-sensitive-wins)** — never assumed, never defaulted-down.

### 5.1 Three signals, that must agree, MEET to the class

```
data_class(turn) = MAX(
   compliance_findings(assembled_content),   # ADR-003 ComplianceGate live scan — a Luhn-valid
                                             #   PAN in free text ⇒ regulated-payment, no matter
                                             #   what the harness or the sources said
   max(label(chunk) for chunk in retrieved), # Context Fabric §3 chunk/node data-class labels —
                                             #   SAME classifier, SAME labels as the security
                                             #   filter, so retrieval and routing cannot disagree
   harness_ceiling                           # static per-Surface-Profile floor declared at
)                                            #   authoring time (control-plane, ADR-026) —
                                             #   defense-in-depth: "this surface never touches
                                             #   regulated data" is independently assertable
```

- **Any single signal escalates the whole turn.** If the compliance scan finds one PAN, the turn is `regulated-payment` even if every retrieved chunk was `public` and the harness ceiling was `internal`. The MEET is a *maximum*, never an average or a vote — one drop of regulated data taints the whole assembled context, because the whole context is what would be shipped.
- **The three signals are defense-in-depth, not redundancy.** The compliance scan catches *content the model would see* that no upstream labelled; the chunk labels catch *known-sensitive sources* even when the specific sensitive token is absent from the excerpt (a document *about* a settlement dispute is `confidential` even if this excerpt names no account); the harness ceiling catches *both misses* by declaring a coarse floor a whole surface can never exceed. A leak requires all three to fail simultaneously — the property §12 test 1 exercises.

### 5.2 Fail-safe: ambiguity and unscannable content default to the most-restrictive class

If the Compliance Gate cannot fully scan the assembled content (oversize, timeout, an unsupported modality it has no detector for), the classification **fails closed to the most-restrictive class the harness ceiling admits** — never fails open to a cloud-eligible class. This is the routing-side face of ADR-003 §6.3's "the gate never silently passes a text it could not scan": an unscannable turn is treated as maximally sensitive for routing, so the worst that a scan-gap can cause is an *unnecessarily conservative* route (an in-house model on data that might have been cloud-eligible), never a *leak* (regulated data on cloud). The cost is real and named (§14 residual) — over-conservative routing degrades quality on the affected turns — but it is the correct direction to fail.

### 5.3 The class is a ceiling that only tightens (composition with ADR-004)

A turn's class is a *ceiling*, and the config layering (`defaults → deployment → tenant → profile → request`, ADR-004) may only *narrow* it. A per-request override can declare a turn *more* sensitive than computed (a user working with data they know is regulated but that the detectors might miss can pin `regulated-payment` up-front) — but **no layer, including a per-request override, can declare a turn *less* sensitive than the MEET computed** (§12 test 15). This is the same `narrow_only` MEET semantics ADR-004 applies to every safety ceiling (a more-specific layer may tighten but never loosen): strictness composes upward, laxity never does.

### 5.4 Data-class is orthogonal to trust/provenance (ADR-009) — the category error to avoid

The runtime carries *two* labels on a piece of content, and they answer different questions:

| | **Data-class** (this ADR) | **Trust / provenance** (ADR-009) |
|---|---|---|
| Question | *How sensitive is this content?* | *How trustworthy is this content's origin?* |
| Values | `public … regulated-payment/PII` | `user-authored / retrieved-untrusted / model-generated` |
| Governs | *which model + which zone* may process it (§6/§7) | *which capabilities the model may invoke* while it is in context (ADR-003 §11) |
| A regulated doc the user pasted | `regulated-payment`, **trusted** | high sensitivity, trusted origin |
| A public web page a tool fetched | `public`, **untrusted** | low sensitivity, untrusted origin |

The two are independent: a highly-sensitive datum can be perfectly trustworthy (the user's own card number), and a non-sensitive datum can be wholly untrusted (a public page carrying an injection payload). Conflating them would either over-restrict trusted regulated data or under-defend untrusted public data. This ADR owns the *sensitivity* axis; ADR-009/ADR-003 own the *trust* axis; both ride in the `ScanContext`/`AuthQuery` (ADR-003 §4.1) and are enforced at different gates.

---

## 6. The non-overridable eligibility matrix (authored here; its seam is ADR-006 §4.1 step 2)

### 6.1 The matrix

```
regulated-payment, PII  → in-house self-hosted OSS models ONLY
                          (the Qwen/GLM/Gemma/Kimi/Llama fleet, served in-zone; ADR-018 then
                           further filters this set by license + nation-of-origin)
confidential            → in-house self-hosted OSS,
                          OR a contracted private-tenancy deployment under a DPA
                            (an ADR-017 Outsourcing-Register arrangement, permitted_data_class:
                             confidential, satisfying §7 residency)
                          — NEVER a generic public-cloud endpoint
internal, public        → any tier-eligible model (cloud included), subject to the Outsourcing
                          Register (ADR-017 §3.2) and §7 residency
```

This is *why* self-hosting is not optional (§1): the eligible set for the two top classes is **empty without it**. The matrix is the authored content that `TOOLING_MCP_PLUGINS_ROUTING.md` §4.2 sketched and ADR-006 §4.1 step 2 references as `class_eligible ← ADR-012`.

### 6.2 Where it slots — step 2, before everything that could reach around it

The router's exclusion-then-rank pipeline (owned by ADR-006 §4.1; ADR-018 §3 lays its gates beneath this one) is, in order:

```
0. classify complexity                                              (ADR-006 §4.1 step 0)
1. tier_eligible   = tier ∩ capability-flag match                   (ADR-006 §4.1 step 1)
2. class_eligible  = tier_eligible ∩ {allowed for this data class}  ← THIS ADR (§6.1), non-overridable
                       + residency filter (§7); + Outsourcing Register for external routes (ADR-017 §3.2)
3. license_eligible= class_eligible ∩ {license permits use}         ← ADR-018 Gate A, underneath step 2
4. origin_eligible = license_eligible ∩ {origin-trusted for path}   ← ADR-018 Gate B, underneath step 2
5. not_regressed   = origin_eligible ∩ {not quality-flagged}        (ADR-006 §4.7)
6. rank(not_regressed); USER PREFERENCE is a weight applied HERE    (ADR-006 §4.1 step 6)
7. select top; walk FAILOVER CHAIN — pre-filtered to steps 2–4      (ADR-006 §4.6)
```

**Why step 2, and why before 3–4:** the data-class gate is the *first* exclusion because ADR-018's origin gate (step 4) is a *function of* the class computed here — the origin gate excludes untrusted-origin weights *only on regulated/payment paths*, which requires the class to already be known (ADR-018 §3 "why this order"). Running origin before class would be undefined. The data-class gate never depends on license or origin, so it is first.

### 6.3 Non-overridability, restated as this ADR's binding contract with the seam

- **User preference is a rank input (step 6), never a re-admission.** There is no surface — no "use gpt-5-5 anyway" toggle, no harness setting, no per-request override — that re-admits a candidate excluded at step 2. A user's explicit pick reorders the eligible set; it cannot enlarge it. (Shared invariant: ADR-006 test 8, ADR-018 test 14, `TOOLING` test 16, ADR-003 test 8 — all restate this; ADR-012 is the *authority* those tests enforce.)
- **Failover cannot cross the class line.** The failover chain is pre-filtered to steps 2–4 at construction (ADR-006 §4.6); walking it can never reach a cloud model for a regulated turn, even as a last resort.
- **Fail-closed on an empty eligible set.** If no in-house model can serve a regulated turn (e.g., a task type no in-house weight handles well, or ADR-018 excluded the only capable weights on origin grounds), the router returns the best in-house-eligible answer with an explicit low-confidence flag, queues, or refuses with a residency reason — it **never** escalates to a cloud model to "rescue" quality. A thin in-house bench is a *procurement problem to fix, not a gate to weaken* (ADR-018 §6.4, shared residual).

### 6.4 Redact-and-proceed is NOT a cloud escape hatch (the rule this ADR must not be read to contradict)

`feedback_redact_dont_block.md` and ADR-003 §6 make compliance **redact-and-proceed** at *user-facing sinks* — a PAN in a chat question is tokenized in place and the turn continues. This ADR does **not** contradict that, and must not be read as doing so: redact-and-proceed governs *what the user sees*; it is **not** a licence to redact regulated tokens out of a prompt and then ship the redacted-but-still-regulated context to a cloud model. Two reasons this is rejected (§11 alt. 4): (a) detector recall is < 100% (ADR-003 §16.1), so "redact then ship abroad" leaks whatever the detector missed *across a residency boundary*, the worst possible place to leak; (b) residency law binds the *regulated context leaving the boundary*, not merely the specific token — a settlement narrative with the account number redacted is still payment-system data that RBI localisation covers. The correct posture for a *regulated-classified turn* is an in-house model on the *whole* context; redaction is the user-facing-sink behavior *within* that in-house path, not a downgrade of the route.

---

## 7. Residency / RBI in-country enforcement — the second orthogonal axis

Data-class answers *which model*; it does not answer *where that model physically runs*. These are two axes, and collapsing them (§11 alt. 8) misses two real cases: an in-house OSS model could be served in a foreign data centre (a multi-region self-hosted fleet), and a `confidential` private-tenancy cloud deployment could be in-region or not. So residency is a **distinct label, enforced in the same step-2 exclusion phase**.

### 7.1 The residency label and the exclusion

Every request carries a residency label derived from its data class and the deployment policy — the two regulated classes are **`in-country`** by default (RBI payment-data-localisation), `confidential` is **`in-region`**, `internal`/`public` are unconstrained unless a tenant policy tightens them. At step 2, alongside the class filter, the router excludes any candidate route whose serving *zone* does not satisfy the request's residency label:

- **External / cloud routes** — the zone is read from the ADR-017 Outsourcing-Register arrangement's **`data_residency`** field. *"A route whose `data_residency` violates the request's residency label (RBI payment-data-localisation) is excluded, same mechanism"* (`REGULATED_FI_COMPLIANCE_OPS.md` §3.2, test 3). A route with **no register entry is invisible** (no ungoverned outsourcing).
- **Self-hosted / in-house routes** — the zone is read from the Serving-Ops placement metadata (ADR-020). An in-house model served out-of-country is excluded for an `in-country` turn *exactly as* a cloud model would be — being in-house earns eligibility on the *class* axis, not automatically on the *residency* axis. (§12 test 7.)

### 7.2 Composition, not duplication

Residency and eligibility are two filters in one phase, not two subsystems. For a `regulated-payment`/`in-country` turn both must pass: the class filter removes all cloud (§6), and the residency filter removes any in-house route outside India — the surviving set is *in-house, in-country* models. For an `internal` turn destined for cloud, the class filter admits cloud but the residency filter (via the register's `data_residency`) still constrains *which* cloud region, if a tenant policy set one. DPDP cross-border-transfer constraints attach to the residency axis for personal data; the register's board-approval + right-to-audit + sub-processor-chain controls (ADR-017 §3.3) attach to whether an external route is *permitted at all*. This ADR owns the *axis and its label*; ADR-017 owns the *per-route declaration* the label is checked against.

---

## 8. Class-aware retrieval AND embedding — "you can't RAG *or embed* a regulated doc into a cloud path"

This is the section §N's parenthetical forces and where this ADR does its most load-bearing new work. The gate cannot live only at the generative-model call; it must live at **every point where content reaches a model**, and the most-missed such point is *embedding*.

### 8.1 Retrieval is class-aware (the assembly-time filter)

The Context Fabric's **pre-rank security filter** (`CONTEXT_FABRIC.md` §3) applies the *same* chunk/node-level data-class labels this ADR defines, *before* ranking, so that **regulated content never enters a cloud-eligible prompt** and **existence never leaks** (a restricted chunk is filtered before ranking, so its mere presence is invisible to an ineligible path). Because the classifier and labels are shared with §5's classification signal, *retrieval and routing can never disagree* — the same datum that would force a turn to `regulated-payment` at §5 is the same datum the filter excludes from a cloud-eligible assembly (§12 test 3, restating `TOOLING` test 18). Budget-fitting further resolves the *eligible model set first* so context is never fit to a wider window than the eventual in-house model can accept (`CONTEXT_FABRIC.md` §3 Gap-22 fix) — a detail owned there, referenced here.

### 8.2 An embedding call is a model call — so the matrix governs it identically

The insight that makes this ADR complete: **embedding is not "just indexing"; it is a model inference that ships the raw plaintext to whatever endpoint computes the vector.** A cloud embedding API used to index a regulated document sends that document's plaintext across the residency boundary — *identical exposure to a cloud prompt*, and worse for being invisible in the "which models did we call" mental model. Therefore:

- **The eligibility matrix (§6) applies to embedding models exactly as to generative models.** `regulated-payment`/`PII` content is embedded **only by an in-house, in-country embedding model** (the self-hosted `embed_svc`, `nomic-embed-text`), **never a cloud embedding API**. This is the corpus's standing PII-in-embeddings discipline (gap AJ; `ENTERPRISE_MEMORY_LEARNING.md` §2: *"regulated/PII-classed memory is embedded only via an in-country/self-hosted embedding model, never a cloud embedding API"*), authored here as a consequence of the matrix rather than a separate rule.
- **The rerank step is a model call too** and is gated identically — a cloud reranker on regulated candidates is the same leak.
- **This is the flagship acceptance test (§12 test 4):** classify a document `regulated-payment`, index it, and assert *at the network layer* that no request to a cloud embedding/rerank endpoint ever fired.

### 8.3 Vector indexes are partitioned by data class; the *query* is embedded class-aware too

An embedding is a reversible-enough projection of its input that **an embedding of PII is itself PII** (embedding-inversion attacks recover meaningful content). Two structural consequences:

- **No shared vector namespace mixes data-class tiers** (`ENTERPRISE_MEMORY_LEARNING.md` §2: *"a shared vector index never mixes data-class tiers"*). Each class tier lives in its own pgvector namespace, embedded by a specific pinned in-house embedder. A shared index would be wrong twice: the regulated rows might have been embedded by a cloud embedder (already a leak), and a cloud-eligible query path could compute similarity against regulated vectors (a retrieval-side leak). Partitioned namespaces + class-eligible embedders keep the vector spaces disjoint by construction.
- **The query side is class-aware.** Searching a regulated namespace requires embedding the *query* — and that query text (potentially itself regulated, and at minimum correlatable) must be embedded by the *same* in-house embedder, not a cloud API. A regulated search that embedded its query in the cloud would leak on the query path even if the corpus was indexed correctly (§12 test 5).
- **Embedding-lifecycle consistency (gap AN)** — a namespace is embedded by one pinned embedder version; cross-version mixing is a separate correctness concern (`CONTEXT_FABRIC.md` §4), but the class-partition boundary is enforced *above* it: you can never re-embed a regulated namespace with a cloud embedder as a "migration."

### 8.4 Multimodal artifacts — the models that *touch* them, not just where bytes rest

Cheque images, KYC scans, and call recordings are `PII`/`regulated-payment` by definition (§4). Any model that *processes* them — a vision model doing OCR/field-extraction, an ASR model transcribing a call — is routed through the **same matrix** (`STRUCTURED_FEDERATED_RETRIEVAL.md` §8.2: *"No cheque image, KYC scan, or call recording is ever sent to a cloud vision/ASR endpoint"*). This is not a new rule for multimodal data; it is the matrix given a new data-class *input signal* — the vision/ASR model is a model, its input is regulated, so only in-house-eligible vision/ASR models are candidates, before ranking (§12 test 8).

### 8.5 Erasure cascades to embeddings (ADR-015 boundary)

Because an embedding of PII is PII (§8.3), a DPDP right-to-erasure request must cascade to *every derived artifact*: source, embedding row(s) in the class-partitioned namespace, and any ASR transcript (`STRUCTURED_FEDERATED_RETRIEVAL.md` §8.5). ADR-012 states *that* the derived embedding inherits the class (and thus the erasure obligation); ADR-015 (retention/erasure, to-be-written) owns the *cascade mechanism*. The boundary is named so neither ADR duplicates the other.

---

## 9. The matrix + taxonomy as control-plane definitions (ADR-026); the config boundary (ADR-004)

**Why git, not config, not code.** A data-class taxonomy and a model-eligibility matrix are **review-governed, versioned, PII-free regulatory determinations that must never be erased** — the audit record of *what the organization decided may touch what*. That is exactly ADR-026's "definition" column: they must be diffed (a change to which class may reach cloud is a security + DPO decision, reviewed as a diff), rolled back (a mistaken loosening is a `git revert`), attributed (who signed off that `confidential` may reach a private-tenancy cloud, on what contractual evidence), and never erased (a regulator asks "what could reach a cloud model in March"). So they inherit ADR-026 wholesale:

```
ainxt-control/policies/
├─ data-class-taxonomy/definition.md        # the §4 taxonomy — class defs, NPCI type→class map
├─ data-class-routing/definition.md         # the §6 eligibility matrix (feeds ADR-006 §4.1 step 2)
└─ residency/definition.md                  # the §7 residency labels + zone rules
```

- **CODEOWNERS** = `@security-council @dpo` (a change to the matrix is a two-group, board-relevant decision — the same "sovereignty is board-level" bar ADR-018 §4 sets for its origin register). An engineer cannot self-loosen which class may reach cloud; the merge is blocked without the accountable groups' signed approval.
- **All-or-nothing, content-addressed, hot-reloaded** (ADR-026 §6): a malformed matrix fails load; the runtime stays on last-good; the turn pins the `control_commit_sha` so *which matrix was in force* for any routing decision is reconstructable (ADR-007).
- **Air-gap-clean** (ADR-026 §12): the matrix is PII-free, so it crosses the sovereignty boundary as a signed `git bundle`; a sovereign NPCI zone enforces the *same* classification + eligibility with no live connection. The residency gate matters *more* in an air-gapped zone, not less.

**The config boundary (ADR-004 §9, stated there and honored here):** *eligibility* is control-plane (this ADR); *which providers are reachable at all from a deployment, and their endpoint/credential wiring* is config. ADR-004 records it precisely: *"router eligibility policy is control-plane per ADR-012/ADR-018 … endpoint/credential wiring for a deployment's reachable providers is config."* An air-gapped profile simply has *no reachable cloud endpoint* (config), *and* a matrix that would exclude cloud for regulated data anyway (control-plane) — defense-in-depth: even a misconfigured deployment that made a cloud endpoint reachable could not route regulated data to it, because the matrix is a separate, non-config gate.

---

## 10. Composition — one exclusion phase, one source per fact, no overlap

| Concern | Owned by | Relationship to ADR-012 |
|---|---|---|
| The data-class taxonomy + the eligibility matrix content | **ADR-012 (this ADR)** | The single source of truth; every row below *consults* it, none restates it. |
| *Where* the class gate slots in the router; that it is non-overridable; failover pre-filter | ADR-006 §4.1/§5 | ADR-006 owns the seam mechanics; ADR-012 supplies the matrix it enforces at step 2. |
| License + nation-of-origin gates | ADR-018 §3 (Gates A/B) | Run **underneath** the data-class gate (steps 3–4), keyed on the class ADR-012 computed; never relax it. |
| The exclusion is *authorization on the un-skippable seam*, not ranking | ADR-003 §7.5 | ADR-003 guarantees the gate *runs and can't be bypassed*; ADR-012 defines *what it decides*. |
| Per-external-route `permitted_data_class` + `data_residency` declaration | ADR-017 §3 | The Outsourcing Register *is* the router's eligibility input for external routes; ADR-012's matrix + residency label are evaluated against its fields. |
| Payment paths | ADR-016 | The `regulated-payment` class includes every ADR-016 payment path; ADR-018's origin gate keys on it. |
| Trust / provenance (which capabilities, not which model) | ADR-009 / ADR-003 §11 | Orthogonal axis (§5.4); rides the same `ScanContext`, enforced at a different gate. |
| Erasure of embeddings-of-PII | ADR-015 (to-be-written) | ADR-012 states the derived embedding inherits the class + obligation; ADR-015 owns the cascade mechanism. |
| Pre-rank retrieval security filter; budget-fit-to-eligible | Context Fabric §3 | Uses ADR-012's *same* classifier + labels, so retrieval and routing cannot disagree. |
| Serving zone of a self-hosted route; regulated-path attestation | ADR-020 / ADR-021 | Supplies the in-house residency zone (§7.1) + trusted-hardware precondition beneath the gate. |
| Matrix/taxonomy as versioned definitions; config vs control-plane line | ADR-026 / ADR-004 §9 | ADR-026 stores them as git definitions; ADR-004 draws the eligibility(control-plane)/wiring(config) line. |

The composition test: for one regulated-payment turn, exactly one path is exercised end-to-end — the class is computed (§5), cloud is excluded and in-house-in-country survives (§6/§7), ADR-018 filters that set by license+origin, retrieval excludes cloud-eligible-only chunks and the embedder is in-house (§8), and every decision is one Event-Log record with the class, route, zone, and embedder digest. No fact is decided in two places; no gate is skipped.

---

## 11. Alternatives considered

1. **Preference-only routing — trust the user or the harness to pick a compliant model.** Rejected: this *is* the architecture break §N names. A router optimizing cost/latency/quality will pick cloud for regulated data because cloud is often best on those axes; "please pick a compliant model" is a convention a single turn violates. Eligibility must be a *precondition of selection*, not a preference — exactly the reasoning ADR-006 alt. 3 and ADR-017 alt. 2 apply to their own gates.
2. **Rank first, then filter out ineligible candidates.** Rejected (identical to ADR-006 alt. 3): a cost-optimal-but-excluded candidate could win the rank and require a second exclusion check on every consuming path, one of which will eventually be omitted — reopening the leak. Exclusion before ranking is the whole design.
3. **Classify documents once, at rest, and route by the document's stored class only.** Rejected: a turn assembles free-form user input plus content from many layers; the class that matters is the MEET *of the assembled turn* at send time (§5). At-rest labels are one of the three signals, not the whole answer — a user can type a PAN into a turn drawing only public sources.
4. **Redact regulated data, then send the redacted context to a cloud model.** Rejected (§6.4): detector recall is < 100% (ADR-003 §16.1), so this leaks whatever was missed *across the residency boundary* — the worst place to leak; and residency law binds the regulated *context* leaving the boundary, not just the specific token, so a redacted-but-still-payment-shaped narrative is still localisation-covered. Redact-and-proceed is a user-facing-sink behavior *within* the in-house path, not a cloud downgrade.
5. **Use a cloud embedding API for regulated content — "an embedding isn't the data."** Rejected (§8.2): the embedding *call* ships the raw plaintext to the cloud endpoint (vectorization happens server-side on the plaintext), and the resulting embedding is a reversible-enough projection to be PII itself (inversion attacks). Both the transit and the artifact are regulated; the matrix governs embedding models identically to generative ones.
6. **One shared vector index with per-row ACL, embedded once by any embedder.** Rejected (§8.3): the regulated rows might have been embedded by a cloud embedder (already a leak), and a shared vector space lets a cloud-eligible query path compute similarity against regulated vectors. Class-partitioned namespaces + class-eligible embedders keep the spaces disjoint by construction, not by a filter a bug could skip.
7. **Store the matrix as ADR-004 config, or as DB rows.** Rejected (§9): it is a review-governed, versioned, never-erased regulatory determination = a control-plane *definition* (ADR-026), CODEOWNERS-gated by security-council + DPO. Config owns endpoint/credential *wiring*; a mutable DB row would let one actor silently loosen which class may reach cloud without board-level review — the exact failure ADR-026 exists to kill.
8. **Treat residency as identical to data-class (one axis).** Rejected (§7): two orthogonal axes — *which model* vs *where it runs*. Collapsing them misses the in-house-served-in-a-foreign-zone case and the confidential-private-tenancy-in-region case. Two labels, one exclusion phase.
9. **A binary sensitive/non-sensitive split instead of five classes.** Rejected: `confidential`'s conditional cloud path (private-tenancy + DPA) and the distinct regulatory bases of `regulated-payment` (RBI localisation/PCI) vs `PII` (DPDP/Aadhaar) carry different downstream obligations (PCI scoping vs DSAR/erasure) that a binary split cannot express — and `internal` vs `public` matters for the Outsourcing Register's per-route ceiling. Five classes is the minimum that captures the real regulatory distinctions without over-engineering.

---

## 12. Acceptance / scenario tests

| # | Scenario | Setup | Expected | Proves |
|---|---|---|---|---|
| 1 | Three-signal MEET escalates | Harness ceiling `internal`; all retrieved chunks `public`; the user's free text contains one Luhn-valid PAN | The turn classifies `regulated-payment` (the MAX); cloud is excluded; routes in-house | Any single signal escalates the whole turn (§5.1) |
| 2 | Non-overridable vs user selection | A `regulated-payment` turn; the user explicitly selects a cloud model | `class_eligible` excludes all cloud regardless of the selection; the pick is honored only among in-house-eligible candidates; no request leaves the boundary (network-asserted) | The matrix is non-overridable (§6.3) — authority for ADR-006 test 8 / TOOLING test 16 |
| 3 | Retrieval class-awareness | A `regulated-payment` chunk exists in the KB; a cloud-eligible turn is assembled | The chunk is excluded from the cloud-eligible prompt by the pre-rank filter — *same labels* as would force the turn's class — and its existence never leaks | Retrieval and routing cannot disagree (§8.1; restates TOOLING test 18) |
| 4 | **Embedding class-awareness (flagship)** | A document classified `regulated-payment` is indexed | It is embedded **only** by the in-house `embed_svc`; assert at the network layer that **no** request to a cloud embedding/rerank endpoint ever fired | An embedding is a model call; the matrix governs it (§8.2) |
| 5 | Query-side embedding | A search is run against a `regulated-payment` vector namespace | The *query* is embedded by the in-house embedder, not a cloud API; no cloud embedding request fires | Class-awareness covers the query path, not just indexing (§8.3) |
| 6 | No mixed-class namespace | A `regulated-payment` doc and a `public` doc are both indexed | They land in *separate* pgvector namespaces embedded by different pinned embedders; no shared index; a cloud-eligible query can never compute similarity against regulated vectors | Class-partitioned vector spaces (§8.3) |
| 7 | Residency ≠ eligibility (in-house, foreign zone) | An in-house OSS model is served in an out-of-country zone; an `in-country` `regulated-payment` turn arrives | The route is excluded on the *residency* axis despite being class-eligible; only in-house *in-country* routes survive | Two orthogonal axes in one phase (§7.1) |
| 8 | Residency via Outsourcing Register | An `internal` turn labelled `in-country`; a cloud route's register `data_residency` is foreign | The route is excluded at selection (localisation), same mechanism | Composition with ADR-017 §3.2 (restates its test 3) |
| 9 | Confidential — private-tenancy yes, generic cloud no | A `confidential` turn; candidates include a generic public-cloud model and a contracted private-tenancy+DPA route (register `permitted_data_class: confidential`, in-region) | Generic public cloud excluded; the private-tenancy route eligible and rankable | The one conditional-cloud class (§4, §6.1) |
| 10 | Fail-safe on unscannable content | The Compliance Gate times out/oversizes on a turn's assembled content | Classification fails closed to the most-restrictive class the harness ceiling admits; routes in-house; never fails open to cloud-eligible | Fail-safe default (§5.2) |
| 11 | Fail-closed on empty eligible set | Every in-house-eligible (post ADR-018) model for a regulated task is unavailable | The router returns the best in-house answer with a low-confidence flag / queues / refuses with a residency reason; a cloud model is never attempted | Fail-closed, never cloud-rescue (§6.3) |
| 12 | Multimodal artifact routing | A KYC image needs OCR/field-extraction | Only in-house-eligible vision models are candidates; network-assert no cloud vision request | Matrix governs models that *touch* artifacts (§8.4; restates STRUCTURED test 19) |
| 13 | Cross-surface classification consistency | The same regulated datum appears as prompt input, a retrieved chunk, an embedding input, and a structured-query filter value | All four resolve to the *same* class and route — one classifier, one label set | Retrieval, routing, and embedding agree (§10; restates STRUCTURED test 22) |
| 14 | Secret is removed, not routed | An `API_KEY` appears in a turn's input | It is redacted/removed by the Compliance Gate before *any* model call — cloud or in-house; it is *not* "routed to in-house" | Secret class is orthogonal to residency (§4.4) |
| 15 | Override can tighten, never loosen | A per-request override attempts to declare a MEET-computed `regulated-payment` turn as `internal` | The override is rejected for the invariant; strictness can rise (a user may pin *more* sensitive), never fall below the MEET | `narrow_only` ceiling (§5.3, ADR-004 composition) |
| 16 | Matrix change is CODEOWNERS-gated | An engineer opens a PR loosening `confidential` to allow generic public cloud | Merge blocked without security-council + DPO signed approval; CI + branch protection enforce it | Matrix is a control-plane definition (§9) |
| 17 | Air-gap parity | The control repo is delivered to a sovereign zone as a signed `git bundle` | The in-zone router enforces the identical taxonomy + matrix + residency against the in-zone keyring, no egress | Air-gap-clean because the matrix is a PII-free definition (§9) |
| 18 | Audit reconstruction | A regulator asks "what class was this turn, which model + zone served it, and which embedder indexed its sources, two years ago" | The Event-Log record beside the route decision yields class + route + residency zone + embedder digest at the pinned control-plane SHA; git history yields who approved the matrix and why | Two-trail audit (§9, ADR-003 §8.2 / ADR-007) |
| 19 | Erasure cascades to the embedding | A DPDP erasure request targets a PII document with a derived embedding | The source *and* its embedding row in the class-partitioned namespace are erased in one cascade | An embedding of PII is PII (§8.5, ADR-015 boundary) |
| 20 | Ordering — class before origin | A `regulated-payment` turn where the only capable in-house weights are PRC-origin | The class gate (step 2) admits the in-house set; ADR-018's origin gate (step 4) then excludes the PRC weights; the result fails closed if empty — origin runs *after* class, never before | Gate ordering rationale (§6.2, ADR-018 §3) |

---

## 13. Consequences

**Positive**
- The architecture-breaking contradiction (§N) is closed *at the one seam that can enforce it*: regulated data *cannot be selected onto a cloud model* — for prompt, embedding, rerank, vision, or ASR — not "is a finding later."
- The taxonomy + matrix are authored *once*, as versioned definitions; ADR-006/018/003/017 stop consulting an undefined invariant and start referencing a real source — the one-source-of-truth discipline ADR-026 demands, applied to the fact four seams depend on.
- The embedding path — the most-missed leak — is closed structurally: an embedding is a model call, governed by the same matrix, into class-partitioned namespaces, with the query embedded class-aware too.
- Eligibility and residency are two clean axes in one exclusion phase, so RBI localisation (in-country) and DPDP cross-border are enforced *at selection*, not audited after.
- Self-hosting the OSS fleet is now a *justified architectural requirement with a stated reason* (the eligible set is empty without it), not an unexplained mandate — and ADR-018 has a class to key its origin gate on.
- Air-gap-clean by construction (§9): the matrix is PII-free, so a sovereign zone enforces identical classification + routing offline.

**Negative / cost**
- Every turn pays a classification cost (the three-signal MEET) before a model is chosen — mitigated by RE2-class linear-time detectors (ADR-003 §6.3) and the fact the class needs only task-type + assembled-content signals already computed, but it is a real per-turn tax on the hot path.
- Fail-safe classification (§5.2) can *over-restrict* — an unscannable or ambiguous turn routes in-house even when it might have been cloud-eligible, costing quality/cost on those turns. The correct direction to fail, but a real cost, named.
- The in-house fleet must be genuinely capable on regulated tasks, or §6.3's fail-closed degrades regulated-path quality (shared with ADR-018 §6.4) — a procurement/in-house-training investment, not a gate to weaken.
- Class-partitioned vector namespaces multiply storage + the embedding-lifecycle surface (one pinned embedder per tier, re-embed pipelines per namespace) versus a single shared index — the price of never mixing tiers.
- The `confidential` private-tenancy path depends on a correct Outsourcing-Register arrangement (ADR-017); the gate faithfully enforces a *wrong* `permitted_data_class` determination, so the register's accuracy is on the critical path.

**Neutral**
- `BLOCKED_MODELS` (`core/model_registry.py`) is unchanged — it stays the coarse fast denylist beneath this conditional class gate, exactly as ADR-018 §9 composes it.
- Nothing is removed; this ADR authors the content the existing seams already reference and threads the existing compliance detectors + retrieval labels + harness ceilings into one classification signal.

---

## 14. Residual risks (honest, not deferred silently)

1. **Classification recall is the ceiling on the whole gate.** The router can only route by the class it computed, and the class is only as good as the compliance detectors + chunk labels feeding §5. A novel PAN/PII format missed by all three signals could reach a cloud-eligible route — a leak *across a residency boundary*, the worst place. Mitigation: the three-signal MEET (any one catches it), the fail-safe default (§5.2), the harness ceiling (a coarse floor even when token-detection misses), and defense-in-depth at the write-path and egress boundaries (ADR-003 §11). Real and named; a design cannot prove recall it has not measured on NPCI data.
2. **Embedding-inversion is an evolving research area.** Treating an embedding of PII as PII (§8.3) is the correct conservative posture today; the *strength* of inversion attacks is not fixed, so the design errs safe (class-partitioned, in-house-embedded) at a real storage/compute cost rather than betting embeddings are "safe enough" to ship abroad.
3. **In-house fleet quality on regulated paths** (shared with ADR-018 §6.4). Fail-closed (§6.3) can leave a regulated task with a weaker in-house answer than the best-available cloud model. A deliberate trade — correctness of *who/where* over marginal quality — and a procurement/in-house-training mandate, not a gate to weaken.
4. **Residency label accuracy depends on truthful zone metadata.** For a multi-region self-hosted fleet, §7.1 reads the Serving-Ops zone (ADR-020); a mislabelled zone would let an out-of-country in-house route pass the residency filter. Named as an ADR-020 dependency, not solved here.
5. **The `confidential` private-tenancy path is only as correct as the Outsourcing-Register arrangement.** The gate faithfully enforces a *wrong* `permitted_data_class` or `data_residency` determination (ADR-017); a mistaken register entry is a wrong route the gate cannot second-guess. Mitigation: the register's two-group CODEOWNERS + board-approval fields, and its own diff-and-re-approve discipline.
6. **Purpose limitation (DPDP) is only partially enforced by class-eligibility.** A class-eligible model is *necessary* but not *sufficient* for a lawful use; full purpose-binding + consent is ADR-015 territory (gap Q). This ADR closes the residency/eligibility half of gap O; the purpose-limitation half is named as an ADR-015 boundary, not claimed here.
7. **Legitimate cross-border flows via connectors are out of scope of this ADR.** A connector that legitimately sends data abroad (an approved external integration) is governed by ADR-017's register, not the model-eligibility matrix. The boundary is named so a reader does not mistake this ADR's model-path residency gate for a whole-system egress control — egress DLP (ADR-003 §11 / TOOLING §1.7) is the complementary control on the connector path.

---

## 15. Self-score (honest)

**Design ceiling: 9.5 / 10.** Every clause of the brief has authored content plus a concrete enforcement point, not a restated principle: the **taxonomy** is a five-class total order mapped to NPCI's actual compliance types and their regulatory basis (§4), with the `confidential` conditional-cloud nuance and the orthogonal `secret`-is-removed class both handled explicitly; **classification** is a per-turn three-signal MEET with a stated fail-safe direction and a clean orthogonality to trust/provenance (§5); the **eligibility matrix** is authored as the single source of truth (§6) and its non-overridability is stated as *this ADR's binding contract with* ADR-006's seam rather than re-implemented, including the sharp clarification that redact-and-proceed is not a cloud escape hatch (§6.4); **RBI in-country residency** is a second orthogonal axis composed with ADR-017's register and ADR-020's zones (§7); and the hardest, most-missed requirement — **class-aware embedding** — is met head-on with "an embedding call is a model call," class-partitioned namespaces, query-side embedding, multimodal coverage, and an erasure cascade (§8). It honors ADR-026 (matrix-as-definition, §9) and ADR-004's config boundary, composes with six neighbouring gates with no overlap and no gap (§10), considers nine real alternatives (§11), and exercises exactly the properties that decide correctness across twenty scenario tests — the flagship being a network-level assertion that a regulated document is never embedded in the cloud (test 4).

The missing half-point is honest and named (§13, §5.2): the whole gate's *effectiveness* rests on **classification recall** — the same detector-recall ceiling ADR-003 §16.1 carries, here with the sharper stake that a missed regulated token could reach a cloud-eligible route; the three-signal MEET and the fail-safe default mitigate it (a leak requires all three to miss) but cannot prove recall on data that does not yet exist. Residency correctness leans on **truthful Serving-Ops zone metadata** (ADR-020) and a **correct Outsourcing-Register determination** (ADR-017) — inputs this ADR consumes but does not itself guarantee — and the `confidential` private-tenancy path and the in-house-fleet-quality fail-closed are trade-offs (§13) whose numbers need real load. **Build maturity: 0 / 10** — no code exists, consistent with every artifact in this corpus. The ceiling is set so implementation can only descend from a real 10-shaped target: the taxonomy and matrix are complete and authoritative; what remains genuinely open is the recall and the zone/register truthfulness that determine how well the complete architecture performs.
