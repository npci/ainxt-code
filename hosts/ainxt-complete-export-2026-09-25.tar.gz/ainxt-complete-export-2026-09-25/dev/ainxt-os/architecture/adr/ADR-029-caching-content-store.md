# ADR-029: Caching & Content Store — FINAL

Status: Accepted (grounded in ainxt-cli code, 2026-07-21)
Related: ADR-006 (provider/model router), ADR-012 (data residency), ADR-013 (idempotency),
ADR-009 (agentic security), ADR-007 (licensing/OSS)

## Context (decisions that shape this)
- ~90% interactive TUI on local user machines; headless/SDLC later.
- Aggregate ~2K TPS; must NOT require a Redis cluster per customer (air-gapped).
- **Default model → local `kimi`** (self-hosted, OpenAI-compatible).
- **LLM-provider prompt-caching is being DISABLED** (data residency, ADR-012; and
  irrelevant for a local model).

## Code reality found (why most of this is already done)
- **Embedding cache: ALREADY EXISTS.** `ainxt-memory` caches embeddings in a
  sqlite-vec `chunks_vec` table, content-addressed by `blake3(chunk)`, re-embeds
  only changed chunks (`embedding.rs`, `index.rs:256-270`). Nothing to build.
- **Compaction: ALREADY EXISTS and is sophisticated.** Threshold-triggered
  (default 85%, background "prefire" pass ~75%), LLM-summarizes the session
  (FullReplace default) and replaces old turns with the summary
  (`ainxt-compaction`, `ainxt-shell/session/compaction.rs`). Tunable via
  `AINXT_AUTO_COMPACT_THRESHOLD_PERCENT`. This is the token-COUNT reducer.
- **Provider cache directives: almost none.** Chat Completions emits none;
  Responses leaves `prompt_cache_key`/`retention` = None; only the Anthropic
  Messages path sets one `cache_control:{ephemeral}` on the last system block
  (`conversation.rs:3192`). For local kimi (ChatCompletions) nothing is emitted.
- **Embedded-DB standard: SQLite (rusqlite bundled + sqlite-vec).** No
  redb/sled/rocksdb in the tree. `ainxt-sqlite-journal` already handles WAL/NFS.
- **Context ordering already prefix-friendly:** system prompt at index 0, then
  history, then tools (`prompt_build.rs:94-111`, `conversation.rs:3199-3222`).
- **Default model + local serving = pure config,** no code: precedence `-m` >
  `AINXT_DEFAULT_MODEL` > `[models] default` > server `/v1/settings default_model`;
  any model's `base_url` can point at a self-hosted OpenAI-compatible server
  (`config.rs`, `models.rs:1712-1806`, `remote/client.rs:837-839`).

## Decision

### 1. Token cost WITHOUT provider caching — two levers, both already available
- **Compaction (built, on).** Keeps context under the window by LLM-summarizing
  old turns. Primary token-COUNT reducer. Tune the 85% threshold if needed.
- **Self-hosted inference prefix caching (SERVING config, not CLI code).** Serve
  kimi on **vLLM (`--enable-prefix-caching`) or SGLang (RadixAttention)**. Because
  the CLI already sends system-prompt-first (stable prefix), the server reuses the
  prefix KV across turns for free, on your GPU, with no third-party retention.
  This is the on-prem replacement for provider prefix caching.

### 2. Local content store (my earlier "layer A") — mostly EXISTS
- Embedding cache: done (sqlite-vec/blake3).
- Gap (minor, optional): `ainxt-codebase-graph` invalidates its `.goto_index.bin`
  by mtime+size, not content hash. Low priority; leave unless churn shows misses.
- No new general-purpose KV store is warranted for the TUI path.

### 3. Answer cache ("layer C") — DEFER to the gateway, for headless/SDLC
Full `request → response` caching only earns its keep on repetitive programmatic
traffic. Build it in the gateway/runtime when headless/SDLC lands, on **SQLite**
(the established substrate — NOT redb; keeps deps + licensing clean, ADR-007).
Mandatory safety-envelope key (never prompt-only):
```
key = blake3( normalized_prompt + system_prompt + tools + model + params
            + identity/RBAC(dept,ad_level) + data_class + retrieval_version + project )
```
+ single-flight coalescing first, TinyLFU admission, short TTL, version invalidation.
Never cache side-effecting/payment tool calls (ADR-013). Not on the laptop.

### 4. Optional hygiene
Remove the lone Anthropic `cache_control:{ephemeral}` directive (`conversation.rs:3192`)
so the CLI emits ZERO provider-cache hints once provider caching is disabled.

## What we are NOT building
- No Redis dependency. No new embedded KV (redb/sled/rocksdb). No laptop answer
  cache. No prompt-only keys. No reliance on cloud-provider prompt caching.

## Net
For the 90%-TUI + local-kimi + provider-cache-off reality, the "caching" work is:
(a) config to make kimi the default + point it at the local vLLM/SGLang server;
(b) enable prefix caching in that serving stack; (c) rely on the existing
compaction + embedding cache. The heavy answer-cache is a later gateway concern.
Maps to GAP_ANALYSIS item I; key ties to AI/AJ + ADR-012/013.
