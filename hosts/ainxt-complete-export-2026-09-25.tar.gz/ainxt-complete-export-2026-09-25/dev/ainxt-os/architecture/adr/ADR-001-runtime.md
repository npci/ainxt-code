# ADR-001 — AiNxt Runtime: Rust, Actor-per-Session, Protocol-First, Strangler-Fig Sidecar

**Status:** Accepted (P0 — foundational). Design only (no code).
**Decision class:** Architecture-defining and root-of-tree. Every other ADR runs *on* the runtime this ADR chooses; it fixes the language, the concurrency model, the client contract, the provider seam, and the migration shape that all subsequent design assumes.
**Relates to / extends:** ADR-002 (Tool+MCP Runtime — the `Capability` seam this runtime dispatches), ADR-003 (Approval/Policy/Compliance — the mandatory gate traits the pipeline takes as required objects), ADR-004 (Config model — "config-first, safety-invariant", the layering this runtime loads), ADR-005 (Protocol — the versioned command/event contract this ADR makes the single client seam), ADR-006 (Provider/Model-Router — the router that rides the provider event-enum seam), ADR-012 (data-class → model routing — non-overridable, resolved on the same seam), ADR-013 (idempotency / side-effect ledger — enforced in the capability layer), ADR-016 (agent-payment hard boundary — a compile-time denial in this runtime's type system), ADR-024 (microVM sandbox — a tier behind the Sandbox Host facade), ADR-026 (control-plane git-native — the Definition Registry this runtime loads at startup and hot-reloads), ADR-027 (Long-Horizon Programs — the durable layer above a Run). Honors the standing rules `feedback_scale_2k_users`, `feedback_model_agnostic`, `feedback_cli_v2_yoga_wasm_leak_fix`, `feedback_ainxt_cli_build`, `feedback_agent_chains_scrapped`, and `feedback_redact_dont_block`.
**Companion:** `CRATE_ARCHITECTURE.md` — the concrete Rust workspace decomposition that realizes every seam this ADR asserts. This ADR decides *what* and *why*; that document decides *which crate owns it*.

---

## 1. Context — what this runtime has to be, and the failure it replaces

The existing platform is a Python/FastAPI spine (`gateway.py`) serving ~2,000 concurrent users of India's payment switch. It works, and it is not to be disturbed while its successor is built (`ainxt_runtime_solution.md` §2A). But its own honest post-mortem (`AINXT_OS.md` §1) names why a *rewrite of the same shape* would fail again, and every cause is structural, not cosmetic:

- **Fragmentation.** Four overlapping subsystems (Agents, Skills, Tools, Workflows) ran on **three** execution models (orchestrator loop, `AgentRunner`, the now-scrapped `WorkflowEngine`). Each product re-implemented a shallow loop; only ever one was hardened at a time.
- **PoC depth.** Happy-path loops with no cancellation, no backpressure, no partial-failure handling; "done" declared from a single manual run.
- **Client coupling.** Buddy was welded to the CLI and connectors were client-side, so web parity was structurally impossible.

The replacement is not "an AI platform." Pass 5 (`GAP_ANALYSIS_PASS5.md`) reframed it as **regulated national infrastructure**: it must sustain ≥ 2,000 req/s, be genuinely model-agnostic (cloud Claude/GPT/Gemini **and** the in-house OSS fleet behind vLLM, ADR-012), enforce PCI/DSS + RBAC as un-skippable invariants, carry a compile-time-provable payment-initiation boundary (ADR-016), and expose *one* implementation to every surface (CLI, Web Chat, REST, Desktop, IDE, Buddy, SDLC) — "implement once, expose everywhere" (`AINXT_OS.md` §2).

The prior client stack was TypeScript/Ink. It leaked vendor patterns and identifiers, and it shipped a **26 GB memory leak** rooted in npm Ink's yoga-WASM never-shrinking arena (`feedback_cli_v2_yoga_wasm_leak_fix.md`). A clean-room break from that stack is both a legal requirement (Rule 3–4, `ainxt_runtime_solution.md` §12) and an engineering one.

Six agent CLIs were studied clean-room (`VENDOR_SYNTHESIS.md`); the convergent patterns below (actor-per-session, protocol-first client, provider event-enum) appear *independently* in multiple codebases, which is the strongest available evidence they are architecture, not any one vendor's protectable expression. Everything here is re-derived from first principles in AiNxt's own vocabulary (§3 term register); no vendor identifier, prefix, layout, or prompt is reproduced.

This ADR makes five load-bearing decisions. They are not independent — each is chosen partly *because* it makes the others enforceable.

---

## 2. Decision

1. **Language: Rust (stable).** The runtime spine, the engine, and the headless CLI are Rust; the web/desktop renderers stay React; SDKs are generated bindings (§D1).
2. **Concurrency: actor-per-session, single-writer, bounded inbox, per-turn cancellation token.** One task owns one session's mutable state and drains a *bounded* command channel serially; each turn runs under a `CancellationToken` shared by the model stream and every concurrent tool future (§D2).
3. **Client model: protocol-first — every client is a renderer, and in-proc vs daemon is one trait.** A single versioned command/event protocol (ADR-005) is the only seam between any surface and the engine; a `Conduit` trait has exactly two implementations — in-process (embed the engine, no OS boundary) and remote (dial a daemon) — and a renderer cannot tell which it holds (§D3).
4. **Provider integration: a provider-neutral streaming Event enum is the only seam between the engine and any vendor.** Three layers — raw transport → per-provider normalization → one shared Event enum. The agent loop never sees a vendor wire format (§D4).
5. **Migration: strangler-fig sidecar.** Rust ships as a separate service the Python gateway *calls* (the embed_svc/llm_proxy pattern); capabilities cut over one at a time behind flags + shadow mode; Python is decommissioned incrementally, never big-bang (§D5).

A sixth property is a *consequence* of the config model (ADR-004) but is load-bearing enough to state here: **the turn pipeline takes Compliance, Policy/RBAC, and Audit as required trait objects — there is no build of the runtime without them** (§D3.3, §7). You configure *which* gate implementation runs; you cannot configure the gate *out*.

---

## D1. Why Rust

Rust is chosen for six reasons, each tied to a specific requirement this runtime cannot meet otherwise:

1. **Compile-time concurrency safety is the enabling condition for §D2.** The actor-per-session invariant ("no shared mutable session state across tasks") and the shared per-turn cancellation token are *hoped-for* properties in a GC'd, dynamically-typed runtime and *proven* properties under Rust's ownership + `Send`/`Sync` model. The class of bug that killed the prior CLI — shared mutable state, unbounded growth, a leak nobody could see (`feedback_cli_v2_yoga_wasm_leak_fix.md`) — is largely unrepresentable when the borrow checker rejects the aliasing that causes it. For a 2,000-user payments component, "the data race cannot compile" is worth more than any amount of test coverage.
2. **No GC → predictable streaming tail-latency.** Perceived latency is a product feature (`GAP_ANALYSIS…` BO). A stop-the-world GC pause during token streaming is a visible stutter; Rust's deterministic drop-based reclamation has no such pause. This matters most under the mixed interactive/batch load the Serving-Ops QoS design (ADR-020) admits.
3. **Sum types + exhaustive `match` make the safety invariants structural.** The provider Event enum (§D4), the uniform tool-result taxonomy (ADR-002), and above all the **payment-initiation denial** (ADR-016 mechanism 1: `effect_class::PaymentInitiating` is a `match` arm that is a *denial, not a call*) all depend on non-`_` exhaustive matching and "make illegal states unrepresentable." Adding a payment-dispatch path becomes a source change to the most-scrutinized enum in the tree, caught at compile time and in review — not a runtime check that can be forgotten.
4. **Memory safety without GC shrinks the attack surface of a PCI-adjacent component.** This runtime sits beside the CDE (ADR-024, ADR-010 PCI scoping). Eliminating the memory-corruption CVE class at the language level is a direct reduction in the payment-boundary blast radius, and a defensible answer to a supervisory examiner asking "what stops a buffer bug near settlement code."
5. **One static binary per platform → the CLI and air-gap story.** The headless CLI must ship as a single self-contained binary for Windows and Mac (`feedback_ainxt_cli_build.md`) and run in an air-gapped zone with no runtime VM to provision. Rust cross-compiles to exactly that; it is also the clean-room break from the scrapped Ink/Node stack.
6. **A mature async ecosystem that already expresses this design, and convergence evidence.** `tokio`/`tower` give the actor + cancellation primitives; `serde` + schema-from-struct generation keep the protocol and every tool schema from drifting from their parsers (a drift bug we will not have because the schema and the deserializer are the same struct). And the two studied vendors that solved the actor+cancellation+provider-seam design at scale (codex, grok-build) are *both* Rust — independent arrival at the same language for the same reasons is corroboration, not coincidence.

Rust's cost — a steeper contributor ramp and longer compile times — is real and accepted; it is bought back by the defect classes that never reach production and by the enterprise-grade bar (`IMPLEMENTATION_PLAN.md` Part A) that forbids PoC-depth shortcuts anyway.

---

## D2. Actor-per-session, single-writer, bounded inbox, per-turn cancellation

The concurrency baseline is one **Session Actor** per active session:

- **Single-writer.** Exactly one task owns a session's mutable state (the Event-Log projection head, the turn state machine) and drains a **bounded** inbound command channel serially. No other task mutates that state; cross-task access is by message, not by shared lock. This is the direct fix for the standing "no in-process shared state across workers" rule (`feedback_scale_2k_users`) and it removes locks from the hot path — the borrow checker makes the single-owner discipline structural, not conventional.
- **Bounded inbox = backpressure = the 2,000-user mandate.** The inbound channel has a fixed capacity; when it is full the runtime returns **503** (the `check_queue_pressure()` discipline, ADR carried from `core/job_queue.py`) rather than growing an unbounded queue into an OOM. Unbounded channels crossing session boundaries are a named anti-pattern (`VENDOR_SYNTHESIS.md` §4) precisely because they defeat backpressure.
- **Per-turn cancellation token.** Each turn spawns a child scope holding one `CancellationToken`, **shared by the provider stream and every concurrent tool future** it launches. ESC, ctrl-c, an HTTP/WS disconnect, a budget trip, or a turn timeout cancels the token once; the stream and all in-flight tool futures observe it and unwind — no orphaned tool process, no half-applied edit, no leaked file handle. This is the "clean cancel on ESC" property (`VENDOR_SYNTHESIS.md` §1.2), and it is testable (test 2, §8).
- **Need-driven loop with two independent circuit breakers.** The loop runs while there are unanswered tool calls or queued input — not a fixed iteration count. It is bounded by (a) a hard iteration/step cap and (b) a **deterministic** stuck/thrash detector (canonicalized-argument dedup + repetition-pattern matching over a bounded window) — **never** a model self-report (`VENDOR_SYNTHESIS.md` §1.2; ADR carried from the SDLC no-progress detector). A soft tool failure is fed back to the model as an ordinary observation, not a turn-abort.
- **Per-file locking for tool concurrency.** Same-file edits serialize; everything else runs in parallel under the shared token. This is the finest-grained safe parallelism for the edit engine without a god-lock.

The Session Actor is deliberately *not* a god-struct with one giant command-dispatch `match` (the monolith anti-pattern, `VENDOR_SYNTHESIS.md` §4). It owns session state and sequencing only; the pipeline stages (context, routing, gates, dispatch) are called through traits, so the actor stays small and the subsystems stay independently testable.

---

## D3. Protocol-first: every client is a renderer; in-proc vs daemon is one trait

### D3.1 One protocol, many renderers
There is exactly one versioned **protocol** (ADR-005): typed client→engine *commands* and engine→client *events* (text deltas, reasoning deltas, tool-call lifecycle, approval requests, artifacts, usage, errors). Every surface — headless CLI, Web Chat, REST/SDK, Desktop Code, IDE extension, Buddy, SDLC — is a **renderer** of that one event stream. No renderer contains business logic; the enterprise-hard machinery (the whole turn pipeline, `RUNTIME_FEATURE_FLOWS.md` §1) is implemented and tested **once** in the engine. This is the structural cure for the fragmentation and client-coupling failures (§1): a feature cannot "forget" a gate because it does not own the loop, and Buddy cannot be welded to the CLI because Buddy is a Surface Profile over the same protocol, not a CLI mode.

### D3.2 In-proc vs daemon is one trait (`Conduit`)
A renderer talks to the engine through a single trait — call it the **`Conduit`** — with exactly two implementations:

- **In-process Conduit** — embeds the engine directly via an async bridge, **no OS process boundary**. This is how the headless CLI ships as a single static binary that runs the whole runtime locally (air-gap, CI), and how the Desktop app can host the engine without a second process.
- **Remote Conduit** — dials a running daemon over the transport (REST/gRPC/SSE/WS). This is how a thin CLI, the web app, or an IDE extension talks to a central runtime.

A renderer holds a `dyn Conduit` and **cannot tell which it has** — the command/event types are identical either way. The consequence is that the same renderer code path serves the embedded CLI and a remote IDE, and an external integration (editor plugin, desktop shell) uses the *same* boundary the first-party CLI uses. This is the "every UI is just a renderer" convergence (`VENDOR_SYNTHESIS.md` §1.8), realized as a two-impl trait rather than two code paths.

### D3.3 The mandatory-gate consequence
Because the engine is the single place the loop lives, it is also the single place the **🔒 gates** live (`RUNTIME_FEATURE_FLOWS.md` §1): identity/policy, compliance-in, compliance-on-tool-args, approval, compliance-on-tool-result, compliance-out. Per ADR-004 §A1, the pipeline constructor **takes the Compliance, Policy/RBAC, and Audit implementations as required trait objects** — the runtime does not compile without them. Enterprises configure *which* implementation (NPCI supplies its PCI/DSS engine + AD-RBAC as private plugin crates); no one configures the gate *off*. Compliance is redact-and-proceed, never a user-facing hard block (`feedback_redact_dont_block`) — the block-at-entry inversion is reserved for the control-plane commit gate (ADR-026 §10), not the runtime path.

---

## D4. Provider event-enum seam — the mechanism of model-agnosticism

The **only** thing that ever knows a vendor's wire format is the provider layer, and it exposes exactly one shape upward: a **provider-neutral streaming Event enum** (content-delta, reasoning-delta, tool-call start/delta/stop, usage, error). Three layers (`VENDOR_SYNTHESIS.md` §1.1):

1. **Transport** — raw HTTP/SSE, shared TLS/proxy/retry config (one construction path, reused everywhere — including the air-gap `LLM_PROXY_URL`/web02 route).
2. **Per-provider normalization** — translate the vendor's stream into the Event enum. **One generic, config-driven implementation** covers the entire OpenAI-schema-compatible family (vLLM in-house fleet, Azure, OpenRouter, local) by swapping base-URL + headers; a bespoke normalizer is written *only* for a provider with an incompatible shape (Anthropic, Gemini). Tool calls are always native structured JSON, never freeform-text parsing.
3. **The Event enum** — the seam the agent loop consumes.

This is what makes AiNxt genuinely multi-model (`feedback_model_agnostic`): the loop, the context engine, and the tool dispatcher are provider-blind, so the data-class router (ADR-012) can select the in-house vLLM fleet for a `regulated-payment` turn — and **fail over** across the eligible chain — with the loop none the wiser. It is also why "no capability hardcodes a provider" is enforceable rather than aspirational: there is no vendor type above the seam to hardcode. The seam is published as a trait crate (`CRATE_ARCHITECTURE.md` §provider), so a new provider is a new adapter crate behind the same enum — zero engine change.

---

## D5. Strangler-fig sidecar

The Rust runtime lands as a **separate service the Python gateway calls** over localhost (HTTP/gRPC) — the exact pattern already proven by `embed_svc` and `llm_proxy` (`ainxt_runtime_solution.md` §2A). Python is the caller; Rust is the callee. Non-negotiables:

- **Do not modify the Python platform to accommodate the runtime.** The runtime adapts to the current contracts.
- **Per-capability cutover behind feature flags,** with **shadow mode** — mirror production traffic to the Rust path, compare outputs against Python offline, cut over only when parity + the capability's scenario matrix hold (`IMPLEMENTATION_PLAN.md` §A4). Instant rollback via flag.
- **A capability's Python implementation is retired only after** its Rust equivalent is stable and verified in production.
- **End state:** Rust is the single spine; Python is decommissioned incrementally.

The same strangler discipline applies to *definitions* on a separate axis (ADR-026 Workstream CP: per-kind `authority: db → git`); the two migrations are independent and neither is big-bang. This is the only migration shape that keeps a live payment platform serving 2,000 users uninterrupted while its spine is replaced.

---

## 3. Vocabulary lock (own terminology — clean-room)

The workspace crate prefix is **`ainxt-`** (consistent with the existing `ainxt-cli`, `ainxt-control` repo, and the `ainxt-id://` URN scheme). It is deliberately **not** any vendor crate prefix, and no vendor internal jargon is used ("doom loop", "yolo", "roster", "leader", "pager", "gboom", "tengu" — all forbidden, `VENDOR_SYNTHESIS.md` §3). Internal subsystem names are drawn from AiNxt's own sanctioned register (`VENDOR_SYNTHESIS.md` §3): Runtime, Execution Engine, **Session Actor**, **Turn**, **Provider Gateway**, **Model Router**, **Capability** (tool) + **Capability Registry**, **Extension** (plugin), **Skill**, **Connector**, **Context Engine** + **Condenser**, **Event Log** + **Projection**, **Approval Gate**, **Policy Engine**, **Compliance Gate**, **Sandbox Host**, **Artifact**, **Renderer** (any client), **Conduit** (the in-proc/daemon seam, coined here). The concrete crate names that realize these are fixed in `CRATE_ARCHITECTURE.md`.

---

## 4. Alternatives considered

### Alt A — Extend the existing Python / FastAPI platform (do not build a new spine)
**Rejected.** The failure diagnosed in §1 is *structural to the existing codebase*, not a feature gap — extending it re-inherits the fragmentation and PoC depth. Concretely:
- **No compile-time concurrency safety.** The actor/single-writer/shared-cancellation invariants (§D2) would be runtime-hoped in Python, not proven; the "no shared state across workers" rule (`feedback_scale_2k_users`) is enforced today only by review vigilance.
- **The GIL forces process-fork parallelism,** which is exactly the source of the macOS RQ fork-crash class of bug (`feedback_macos_rq_fork_crash`) and adds per-worker memory cost at 2,000 sessions.
- **No single static binary** — the CLI/air-gap requirement (`feedback_ainxt_cli_build`) cannot be met with a Python interpreter to provision.
- **No type-level safety invariants** — the ADR-016 payment-boundary denial and the ADR-013 effect-class ledger degrade from "won't compile" to "a runtime check someone can skip", which is unacceptable for the operator of the rails.
- Python *remains* — as the incumbent the runtime strangles (§D5), and for the ML sidecars (`embed_svc`) where its ecosystem is the right tool — but it is not the new spine.

### Alt B — Go
**Rejected**, though it is the closest contender.
- **GC pauses** hurt streaming tail-latency (§D1.2) under mixed interactive/batch load.
- **No sum types / no exhaustive `match`.** This is decisive: the provider Event enum, the tool-result taxonomy, and above all the payment-boundary *denial-as-a-match-arm* (ADR-016) rely on exhaustive matching and "illegal states unrepresentable." Go's `interface{}`-style erasure and lack of exhaustiveness make those safety mechanisms far weaker — a new provider or a new effect class can silently fall through a default case rather than forcing a reviewed source change to a closed enum.
- **Convergence evidence points the other way:** the two vendors that built the actor+cancellation+provider-seam design (codex, grok-build) chose Rust; the Go vendor (opencode) is the one the study flags for *lacking* a hard iteration cap and leaning on an event-bus monolith (`VENDOR_SYNTHESIS.md` §4). Go's genuine strengths (fast builds, easy static binaries, gentle ramp) do not outweigh losing the type-level safety guarantees on a payments runtime.

### Alt C — TypeScript / Node
**Rejected hardest — this is the stack we just scrapped.**
- It is the origin of the **26 GB yoga-WASM leak** and of the vendor pattern/name leakage the clean-room program exists to end (`feedback_cli_v2_yoga_wasm_leak_fix`, `ainxt_runtime_solution.md` §12).
- **Single-threaded event loop + no true parallelism** for 2,000 concurrent sessions; **GC** on the streaming path; **no static binary** (ships a Node runtime — fails the air-gap/CLI requirement).
- **Weakest memory-safety / attack-surface story** for a PCI-adjacent component; structural typing makes "impossible states unrepresentable" unenforceable.
- Node keeps a legitimate, bounded role: the **React web/desktop renderers** and a thin **TypeScript SDK binding** over the protocol — never the runtime engine.

### Summary
| Criterion | **Rust (chosen)** | Extend Python | Go | TS/Node |
|---|---|---|---|---|
| Compile-time concurrency safety (§D2) | ✅ ownership/`Send`+`Sync` | ❌ runtime-hoped | ⚠ races possible | ❌ |
| Streaming tail-latency (no GC) | ✅ | ⚠ | ⚠ GC | ⚠ GC |
| Exhaustive sum types for safety invariants (ADR-016/013, §D4) | ✅ | ❌ | ❌ | ❌ |
| Single static binary / air-gap CLI | ✅ | ❌ | ✅ | ❌ |
| PCI-adjacent attack surface | ✅ | ⚠ | ✅ | ❌ |
| 2,000-session parallelism without fork cost | ✅ | ❌ GIL/fork | ✅ | ❌ |
| Clean-room break from scrapped stack | ✅ | n/a | ✅ | ❌ (is the stack) |
| Convergence with vendors that solved this design | ✅ codex/grok-build | — | ⚠ opencode (flagged) | — |

---

## 5. How this ADR binds the rest of the corpus

- The **turn pipeline** (`RUNTIME_FEATURE_FLOWS.md` §1) is the engine's public behavior; every per-feature trace is that pipeline under a different Surface Profile + Renderer.
- The **gates** (ADR-003) are required trait objects (§D3.3); the **router** (ADR-006/012) rides the provider seam (§D4); **idempotency** (ADR-013) and the **payment boundary** (ADR-016) live in the capability/type layer this runtime dispatches through.
- The **control plane** (ADR-026) is loaded by this runtime into an in-memory Definition Registry at startup and hot-reloaded on change; the runtime pins each in-flight turn to the control-plane commit SHA it started under.
- **Long-Horizon Programs** (ADR-027) are a durable layer *above* a Run, scheduling thousands of bounded base-loop Runs — not a second loop.
- The **scrapped Workflow engine is not resurrected** (`feedback_agent_chains_scrapped`): there is no orchestration-engine crate; workflow *definitions* execute as scheduled Runs / in-feature orchestration on this one loop.

---

## 6. Consequences

**Positive**
- One hardened spine; every surface inherits compliance, RBAC, backpressure, cancellation, retry, stuck-detection, and audit for free — fragmentation is structurally impossible because there is one loop.
- The hardest safety invariants (payment boundary, effect classes, provider-neutrality) are compile-time-enforced, not runtime-hoped.
- Genuine model-agnosticism and clean data-class failover fall out of the single provider seam.
- A single static CLI binary and an air-gap-clean in-proc mode fall out of the `Conduit` trait — the same code serves embedded and remote.
- The live platform is never disturbed (strangler-fig); every cutover is flag-gated, shadow-verified, and instantly reversible.

**Negative / cost**
- Rust's contributor ramp and compile times are real; mitigated by small single-purpose crates (`CRATE_ARCHITECTURE.md`) and workspace-shared dependency pinning.
- Two languages in the tree during coexistence (Rust runtime + Python incumbent); accepted and bounded by §D5.
- Protocol-first imposes a versioning discipline (backward-compat contract tests on every bump, Phase 4) — a real obligation, called out so it is not discovered late.

**Neutral**
- React/Node persist as renderers + SDK bindings; the ML sidecars stay Python. Rust replaces the *spine*, not every process.

---

## 7. Acceptance / scenario tests (the house bar)

| # | Scenario | Setup | Expected | Proves |
|---|---|---|---|---|
| 1 | Single-writer isolation | N turns fan out concurrent tool futures against one session | Session state is mutated only by the owning actor; no data race under `--race`/loom-style model checking; output deterministic | Actor-per-session single-writer (§D2) |
| 2 | Cancel frees everything | ESC / disconnect mid-turn with 3 tool futures + an open model stream in flight | The shared token cancels; stream and all tool futures unwind; zero orphaned processes / leaked handles | Per-turn cancellation token (§D2) |
| 3 | Bounded-inbox backpressure | Offer commands past inbox capacity | Runtime returns 503; no unbounded queue growth; memory flat | Backpressure = the 2,000-user mandate (§D2) |
| 4 | Provider failover on the seam | Primary provider errors mid-stream; eligible chain has a second model | Loop continues on the Event enum across the switch; no vendor type reaches the loop; no evidence dropped | Provider event-enum seam + model-agnostic failover (§D4) |
| 5 | Malformed vendor wire | Provider emits partial/garbage SSE | Normalization layer surfaces a typed `error` Event; the loop treats it as a soft failure, never panics | The wire format is contained below the seam (§D4) |
| 6 | In-proc ≡ daemon | Run the identical script through the in-process `Conduit` and the remote `Conduit` | Byte-identical command/event streams; renderer code path unchanged | One trait for in-proc vs daemon (§D3.2) |
| 7 | Gate non-removability | Attempt to construct the pipeline without a Compliance / Policy / Audit implementation | **Does not compile** — the constructor requires the trait objects | Mandatory-gate invariant (§D3.3 / ADR-004 §A1) |
| 8 | Single static CLI, no TUI | Build `ainxt-cli`; inspect its dependency tree | One self-contained binary per OS; `cargo tree -p ainxt-cli` contains no `ratatui`/`crossterm`/`reedline` | Static-binary CLI + headless-only (§D1.5) |
| 9 | 2,000-session soak | Sustain ≥ 2,000 concurrent sessions for the soak window | Memory flat (no yoga/WASM-class leak); no fork-crash; latency within SLO | Scale mandate + clean-room break (§D1, §D2) |
| 10 | Protocol backward-compat | Bump the protocol minor version; run an old renderer against the new engine | Contract tests pass; old renderer still renders | Versioned protocol discipline (§D3.1) |
| 11 | Strangler shadow parity | Mirror production traffic to the Rust path for a migrated capability | Outputs match Python offline before any cutover; flag rollback is instant | Strangler-fig safety (§D5) |
| 12 | Payment-boundary compile denial | A diff attempts to turn the `PaymentInitiating` match arm from a denial into a dispatch | Compiles only as a reviewed source change to the closed effect-class enum; shows up as the most-scrutinized diff (ADR-016) | Type-level safety invariant (§D1.3) |
| 13 | Turn pinned to control-plane SHA | A definition is hot-reloaded (ADR-026) mid-turn | The running turn completes on the SHA it captured at start; the Event Log records that SHA | Reproducibility across the runtime/control-plane seam (§5) |

---

## 8. Residual risks (honest)

1. **The gate-as-trait-object guarantee is only structural at the composition root.** The engine *cannot* be built without the gates (test 7), but a mis-wired composition-root binary could still inject a permissive no-op implementation. Mitigation: the OSS default gates are real (never no-ops), the NPCI plugin gates are the deployed ones, and a CI "no-op gate" lint plus the compliance/RBAC scenario matrix (`IMPLEMENTATION_PLAN.md` §A3) exercise real redaction/deny — but the DI seam is a surface a determined implementer could weaken, so it is named.
2. **Strangler-fig parity is only as good as shadow-mode coverage.** A behavior the shadow comparison doesn't exercise can differ silently post-cutover. Mitigation: per-capability scenario matrices gate every cutover, and rollback is a flag — but rare-path parity is a residual until each capability's matrix is proven at production breadth.
3. **Rust ramp is an adoption risk** (`GAP_ANALYSIS_PASS5.md` AZ/BD): a small pool of Rust-fluent reviewers can bottleneck the enterprise-grade bar. Mitigation: small crates with narrow public APIs, the vendor studies + ADRs as onboarding evidence, and Python/TS SDKs so *consumers* never write Rust.
4. **Two-language operational surface during coexistence** doubles the deploy/observability matrix until Python is decommissioned. Accepted and bounded by §D5; tracked in the Part C risk register.
5. **In-proc mode embeds the whole engine in the client process,** so a client crash takes the embedded runtime with it and an embedded CLI has the engine's full dependency footprint. Mitigation: the `Conduit` trait means any client can switch to the remote daemon without code change; in-proc is the air-gap/CLI convenience, not the multi-tenant serving path.

---

## 9. Self-score (honest)

**Design ceiling: 9.5 / 10.** Every one of the five decisions has a concrete enforcement mechanism (ownership-checked single-writer, a shared cancellation token, a two-impl `Conduit` trait, a three-layer provider seam with the Event enum as the only upward type, required gate trait objects that won't compile if absent) and an acceptance test that exercises exactly the property that matters (§7) — the corpus bar. The alternatives are rejected on requirement-specific grounds, not taste, and the language choice is tied point-by-point to the safety invariants (§D1). The missing half-point is honest: the gate-as-trait guarantee and strangler-parity are *composition-root and coverage* properties this design specifies but cannot itself prove until built (residuals 1–2), and the Rust ramp is a real organizational cost (residual 3). **Build maturity: 0 / 10** — no code exists, consistent with every artifact in this corpus. The ceiling is set at a true-10 shape so implementation can only descend from it.
