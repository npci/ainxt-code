# ADR-019 — AI Liability, Indemnity & Insurance Chain (the loss-recovery framework)

**Status:** Accepted (P0 go-live-blocker). Design only (no code).
**Decision class:** Institutional / financial-risk-defining. Establishes *who bears a financial loss caused — however indirectly — by an autonomous agent action, in what order, proven how,* and wires that answer into the runtime as enforceable objects rather than a policy binder. Closes **Pass-5 gap [6]** (liability / indemnity / insurance chain — "every layer disclaims; residual loss lands on NPCI with no framework").
**Relates to / extends:** ADR-003 (Policy/Approval/Compliance seam + OBO — the per-turn authz context that names the invoker), ADR-007 (tamper-evident Event Log — the substrate every accountability record and clock lives on), ADR-012 (data-class → model routing — the routing gate this ADR adds a *liability-posture* exclusion to), ADR-013 (Side-Effect Ledger / saga / idempotency-in-doubt reconciler — the pre-settlement containment path), **ADR-016** (agent payment-initiation hard boundary — the reason direct value-movement is impossible and therefore the reason this ADR is about *indirect* causation), ADR-017 (Regulated-FI Compliance Ops — the Statutory-Clock machinery and Outsourcing Register this ADR reuses and extends), ADR-022 (agent identity — the non-human *actor of record* in an accountability chain), ADR-025 (evidentiary admissibility — the BSA §63 package an adjudication produces), ADR-026 (Control-Plane Git-Native — where every register/policy in this ADR is authored), ADR-027 (Long-Horizon Programs — how a multi-month loss-recovery adjudication actually runs).
**Companion docs:** `REGULATED_FI_COMPLIANCE_OPS.md` §2 (breach engine / Statutory Clock — the detection and clock primitives), §3 (Outsourcing Register — extended here with a liability profile), §6 (deterministic precedence function — the pattern the loss-allocation function copies); `AGENT_IDENTITY_AND_PAYMENT_BOUNDARY.md` PART 1 (the boundary that bounds direct blast radius); `DEV_EXECUTION_AND_UX.md` (maker-checker discipline + automation-complacency telemetry, Pass-5 gap [43]).

**One line:** because every supplier in the AI stack disclaims, and RBI forbids NPCI from outsourcing away its own accountability, the residual financial loss from an autonomous agent action always lands on NPCI — so this ADR turns "it lands on NPCI" from an unpriced surprise into a **measured exposure, a named human anchor, an ordered recovery waterfall, an insurance layer with an un-missable notice clock, and a deterministic member-bank allocation function**, and adjudicates any actual payment-loss incident as a durable, auditable Program.

---

## 1. Context — why the residual lands on NPCI, and why that is not solved by a principle

### 1.1 Every layer of the stack disclaims — this is a fact about the market, not a negotiation failure

The AiNxt runtime is model-agnostic (ADR-012): it composes cloud frontier models, in-house OSS weights, external MCP tools, and third-party authoring "Studio" surfaces. **Every one of those layers contractually disclaims liability for what its output does downstream:**

| Layer | Liability posture (2026 market reality) | Recoverable slice |
|---|---|---|
| **Cloud model vendors** (Anthropic / OpenAI / Google) | Liability **capped** (commonly ≤ 12-months-fees-paid or a fixed figure); **consequential / indirect / special damages excluded**; indemnity, where offered, is typically **IP-infringement-only**, not "your loss from a wrong answer." | Thin — a fraction of fees, never the downstream loss |
| **OSS weights** (Qwen / GLM / Gemma / Kimi — Pass-5 gap [5], ADR-018) | Shipped **"AS IS", zero warranty, zero indemnity**; several under custom field-of-use licenses that add restriction without adding recourse. | **Zero** |
| **Studio / authoring vendors** (n8n fair-code, LangGraph commercial — Pass-5 gap [30]) | Disclaim consequential damages; some are non-OSI with no escrow. | Thin-to-zero |
| **Cyber / PI insurers** | Increasingly adding **AI exclusions** or leaving AI "**silent**" (neither affirmed nor excluded — an ambiguity that becomes a coverage fight at claim time). | Only if affirmatively covered and noticed in time |

The stack is a chain of "not my problem." Downstream of all of it sits NPCI.

### 1.2 RBI forbids outsourcing away accountability — so the residual is not just contractual, it is a regulatory *duty* to own

The RBI Master Direction on Outsourcing of IT Services (2023) is explicit and load-bearing here: **outsourcing an activity does not diminish the regulated entity's obligations or its accountability to its customers and to RBI.** NPCI cannot contract, route, or automate its way out of being answerable for a loss its systems caused. This flips the framing: the residual landing on NPCI is not a gap to be closed by finding a counterparty to push it onto — **it is a regulatory posture NPCI must affirmatively own and be able to *demonstrate* it has provisioned for.** A framework is therefore mandatory, not prudent.

### 1.3 The crucial subtlety: ADR-016 bounds the *direct* blast radius but not the *indirect* liability path

A naïve reading says: "ADR-016 guarantees the agent never initiates, authorizes, or commits value movement — no dispatch path exists — therefore there is no payment loss and no liability." **That is wrong, and getting it right is the spine of this ADR.**

ADR-016 makes it impossible for an agent to *directly* move value. It does **not** eliminate the ways an autonomous agent action can *indirectly cause* a financial loss:

- The agent **authors, reviews, and tests payment-system code** through the normal SDLC — a payment-**adjacent** activity ADR-016 §2 explicitly permits. If the agent introduces a defect (a wrong netting calculation, a dropped-settlement path, an off-by-one in an idempotency key) — or, as a reviewer, **fails to catch** one — and a human deploys that code through change control, the deployed defect can cause a real, **settled**, non-compensable loss.
- The agent generates a **reconciliation report, a dispute-response draft, an exception analysis, or advice** a human relies on to make a settlement or customer-remediation decision. Wrong analysis → wrong human decision → loss.
- The agent performs a **payment-adjacent action** (a config change, a data correction) that, combined with a human action, produces a loss.

So the causal chain this ADR owns is: **autonomous agent action → (code / advice / adjacent action) → human deployment through change control → production defect → financial loss.** ADR-016 is the *first* line of defense — it removes the entire class of *direct* agent settlement — but the indirect path remains, and it is precisely the residual with no framework that Pass-5 gap [6] names.

**The elegant consequence (developed in §3):** because ADR-016 guarantees the agent can never itself deploy to the money path, **there is always a named human in the deployment chain** — the maker-checker who accepted and shipped the agent's output. Named human accountability is therefore not a policy aspiration bolted on afterward; it is a *structural guarantee* that falls out of the payment boundary plus maker-checker. This ADR's job is to make that guarantee legible, quantified, insured, and recoverable.

### 1.4 Why a principle is not a framework

The prior corpus states the *principle* — "a human is always accountable," "we carry insurance," "vendors disclaim." A regulator, an insurer's claims adjuster, or a member bank's counsel does not accept a principle. They ask five concrete questions, and a binder answers none of them with teeth:

1. **Whose name is on this specific loss, and can you prove it?** (accountability, §4)
2. **What can you actually recover from your suppliers, in figures?** (vendor caps, §5)
3. **What does insurance cover, and did you notice the insurer in time?** (insurance, §6)
4. **Who bears the remainder — NPCI, the member bank, or the customer — and per which law?** (allocation, §7)
5. **Walk me through how this incident was adjudicated, start to finish.** (adjudication, §8)

This ADR answers each as a **runtime object with an enforcement mechanism the runtime cannot route around, and an acceptance test that exercises exactly what the questioner will examine** — the same house bar ADR-017 applies to statutory obligations, applied here to loss recovery.

---

## 2. Decision

**Establish a first-class *Liability & Recovery Chain* subsystem** — a set of control-plane registers and deterministic decision functions, wired to the existing Event Log, breach engine, and router, plus a durable adjudication Program. Six commitments:

1. **Named human accountability is structural and provable.** Every agent-produced artifact that can reach a money path carries an **Accountability Record** binding the agent identity + control-plane SHA, the git authoring-approver, and the human change-control maker-checker who deployed it. **An artifact cannot be promoted to a money-path repo/environment without a complete Accountability Record** — a promotion gate on the ADR-026 machinery. "Nobody's name is on it" is a deploy-blocker. (§4)

2. **Vendor liability is measured, not assumed.** A **Vendor Liability Register** (control-plane, extends the ADR-017 Outsourcing Register) records each supplier's cap, exclusions, and indemnity scope. From it the runtime computes a **quantified indemnity gap** per deployed capability, and adds a **liability-posture exclusion** to the router: high-blast-radius work cannot route to a zero-indemnity provider unless a named human has recorded a reason-coded risk-acceptance. (§5)

3. **The residual is transferred, and the transfer has a clock.** An **Insurance Coverage Register** (control-plane) records the cyber / technology-E&O-PI coverage with **affirmative-AI-cover** status. A continuous **coverage-vs-exposure gate** raises a board-delegate finding when aggregate exposure outgrows cover. Every insurable loss incident **auto-arms an insurer-notification clock** using the ADR-017 Statutory-Clock machinery — a missed notice voids coverage, so it is made structurally un-missable. (§6)

4. **Loss allocation is a deterministic, evidence-anchored function, not a negotiation.** A **Loss-Allocation Decision Function** (control-plane policy) applies a fixed precedence — **consumer-protection cap first (RBI limited-liability), settlement-finality classification second (PSS Act 2007), fault attribution third (NPCI ↔ member per the participation agreement)** — computing the split from the Accountability Record + admissible Event-Log evidence. The customer is *never* the residual bearer. (§7)

5. **Adjudication is a durable Program (Q1/ADR-027).** A payment-loss incident detected by the ADR-017 breach engine spawns an **Adjudication Program**: contain → attribute → quantify → recover → learn, with named module owners, staged human checkpoints, and partial completion as a first-class outcome. (§8)

6. **The control-plane/data-plane split (Q2/ADR-026) is applied exactly.** Every **register, policy, threshold, schema, and CODEOWNERS group is a PII-free git definition**; every **incident, claim, computed allocation, and accountability instance is data-plane** (Event Log + Postgres), erasable-or-legal-held. (§9)

**What this ADR does *not* do:** it does not re-open the payment boundary (the agent still never moves value — ADR-016 is untouched and is the *first* recovery mechanism: the best-recovered loss is the one the boundary prevented). It does not operate NPCI's inter-institutional dispute rails (that is payment-adjacent; the runtime *produces the evidence and the computed allocation*, humans and the existing dispute process *execute* it). It does not create an insurance market or set case law — where it depends on those, it says so honestly (§13).

---

## 3. The liability chain, stated as an invariant

The corpus's other ADRs each rest on one load-bearing invariant. This one's is:

> **Every financial loss traceable to an autonomous agent action has (a) at least one *named human* in its causal chain, (b) a *bounded, measured* recoverable amount from suppliers, and (c) a *deterministic* residual-bearer — and the customer is never that residual bearer.**

Each clause is a structural consequence, not a hope:

- **(a) is guaranteed by ADR-016 + maker-checker.** The agent cannot deploy to the money path (no dispatch path, ADR-016 §4); therefore a *human* deployed the agent's output through change control; therefore that human's identity is in the chain. The Accountability Record (§4) merely *surfaces and binds* a human anchor that the payment boundary *forces* to exist. There is no path where an agent-caused settled loss has zero humans on the hook.
- **(b) is guaranteed by the Vendor Liability Register (§5).** The recoverable-from-supplier figure is not discovered at claim time under pressure; it is a pre-computed field, because the register is the router's *input*, so nothing routes to a supplier whose liability posture isn't already recorded.
- **(c) is guaranteed by the deterministic Loss-Allocation Decision Function (§7).** Given the loss classification and the accountability evidence, the residual bearer is *computed*, not argued — and the RBI-consumer-protection precedence makes "the customer eats it" not merely disfavored but *unreachable by the function*.

This invariant is what a design *principle* was missing: it is enforced at three times — **authoring** (git accountability + liability CODEOWNERS), **routing/deploy** (the promotion gate + the router liability exclusion), and **incident** (the deterministic allocation function + the adjudication Program).

---

## 4. Named human accountability mapped to real liability

### 4.1 The Accountability Record — a data-plane instance projected from existing trails

The runtime already produces two audit trails (ADR-026 §9): git history (the *authoring* audit — who wrote/approved a definition) and the Event Log (the *execution* audit — what the runtime did, under whose OBO context, at which control-plane SHA). The Accountability Record is a **third-party-free projection** that joins them for a specific promotable artifact — it introduces **no new source of truth**, only a computed binding:

```
AccountabilityRecord {                        # data-plane (Event Log + Postgres), append-only, hash-chained
  artifact_id, artifact_kind,                 # code_mr | report | config_change | advice | reconciliation
  money_path_reachability: bool,              # does this artifact's target repo/env/dataset reach settlement? (§4.3)
  agent: { identity, run_id, program_id? },   # ADR-022 non-human actor of record
  control_plane_sha,                          # ADR-026 — exactly which definitions produced the output
  authoring_approver: { id, role, ad_level, can_approve },   # git CODEOWNERS reviewer (ADR-026 §8)
  deploy_maker: { id, change_ticket },        # the human who submitted the change to the money path
  deploy_checker: { id, role, ad_level },     # the maker-checker approver (must differ from maker — SoD)
  review_discipline: {                        # automation-complacency evidence (Pass-5 gap [43], §4.4)
    human_review_dwell_ms, diff_size, comments_count, override_of_agent_flag: bool },
  evidence_slice_ref                          # Event-Log slice, admissible via ADR-025
}
```

The record is **hash-chained on the Event Log** (evidentiary, ADR-025) and **subject to legal-hold** (ADR-017 §6): once a loss touches it, it can never be erased while the matter is open.

### 4.2 The enforcement mechanism — the money-path promotion gate

Accountability is not a report generated after a loss; it is a **precondition of an agent-produced artifact reaching a money path**, enforced on the ADR-026 promotion machinery:

- Any promotion whose target is a **money-path-tagged** repo, environment, or dataset (§4.3) **must carry a complete Accountability Record** — a non-null `deploy_maker`, a distinct `deploy_checker` (separation of duties), a resolvable `authoring_approver`, and the `agent`+`control_plane_sha` binding. A missing or incomplete record **blocks the promotion** (the same all-or-nothing discipline as ADR-026 §6.1 load, applied to deploy).
- The check is the same class of promotion gate ADR-017 §4.1 uses for the DPIA and ADR-026 §8 uses for CODEOWNERS: it is host-enforced at the merge/deploy boundary, not reviewer goodwill. **"The AI wrote it, nobody owns it" cannot reach production of a money path** — mechanically.

This discharges "named human accountability mapped to real liability" with teeth: the map is a *required, blocking field* on every money-path artifact, and it names the specific humans whose acceptance made the deployment happen.

### 4.3 What makes something "money-path" — a control-plane tag, not a guess

`money_path_reachability` is not model-judged. A **control-plane registry** (git, owned by the payments-council + platform-leads CODEOWNERS, reusing the ADR-016 §4.5 settlement-perimeter definitions) enumerates the repos, deploy targets, config namespaces, and datasets that reach settlement. Reachability is computed from that registry + the dependency graph (a repo that a money-path repo depends on is itself money-path, transitively). Because the perimeter is git-versioned, "was module X money-path on that date" is answerable by a control-plane SHA — an evidentiary particular (§8).

### 4.4 The fairness half — accountability is bounded by prescribed discipline, and automation complacency is evidence

"Named human is on the hook" must not degrade into "rubber-stamp the AI, carry the blame." Two design moves keep it fair and keep it honest:

- **"The AI did it" is never an accountability defense** — the maker-checker *accepted* the output; acceptance is the human act that carries it to production. This is stated so no one can later claim the automation absolved them.
- **But the *degree* of exposure turns on whether prescribed maker-checker discipline was actually followed.** The `review_discipline` signals (dwell time, diff size, comments, override rate — Pass-5 gap [43] automation-complacency telemetry) are captured *at deploy time* and become **evidence in adjudication (§8)**: a defect shipped after a genuine review is a different accountability posture than one waved through in three seconds under automation bias. A monotonic slide of `override_of_agent_flag` toward zero across a team is itself a governance finding (deskilling / complacency, gap [43]) raised *before* a loss, not discovered after.

### 4.5 "Real liability" — the honest mapping from a name to money

A named human is the *accountability* anchor; it does not mean an individual engineer personally absorbs a crore-scale settlement loss — Indian employment law, directors'-indemnification norms, and the RBI expectation that *the institution* remains liable to customers all mean the **financial** recovery flows through the institutional waterfall (§5–§7), while the **named human** drives: (i) the *evidentiary* attribution the waterfall needs, (ii) internal governance/HR consequence proportionate to `review_discipline`, and (iii) the **D&O / management-liability** coverage line that protects accountable officers acting in good faith. The **Accountability Policy** (control-plane, Legal/HR/CRO-owned CODEOWNERS) is the git artifact that maps roles → accountability tier → the consequence and coverage line — versioned, reviewed, never a buried HR spreadsheet. This ADR is precise that "named human liability" means *organizational accountability with an evidentiary and D&O anchor*, not personal financial ruin — anything stronger would be dishonest and would drive engineers off the platform (the abandonment failure mode the corpus repeatedly guards against).

---

## 5. Vendor liability caps reality — measured, and turned into router teeth

### 5.1 The Vendor Liability Register — a control-plane definition (Q2), extending the Outsourcing Register

ADR-017 §3.1 already requires one git file per outsourcing arrangement (every cloud route, connector, remote MCP). This ADR adds a **liability profile** to each, so liability is declared where governance already lives — one register, not a second:

```yaml
kind: vendor-liability-profile
id: liability.<provider>.<route>
extends: outsourcing.<provider>.<route>     # the ADR-017 §3.1 register entry (one source)
liability_class: cloud_capped | oss_zero | studio_disclaimed | inhouse_self
liability_cap_basis: fees_12mo | fixed | none
liability_cap_amount: "<currency+figure|null>"
consequential_excluded: true                 # near-universal; recorded, not assumed
indemnity_scope: ip_only | none | none_oss_as_is
governing_law: "<jurisdiction>"              # a foreign forum is itself a recoverability risk (§5.4)
dispute_forum: "<arbitration|courts>"
contract_ref: "<CLM id>"                      # the board-approved outsourcing contract (ADR-017)
last_counsel_review: "<date>"                 # freshness; stale ⇒ treated as unknown-worst-case (§5.3)
```

CODEOWNERS for `/liability/` = the **General-Counsel group + CRO-delegate** — a supplier's liability posture cannot be recorded (or optimistically edited) without a reviewed, signed PR (authoring-RBAC, ADR-026 §8). The OSS routes carry `liability_class: oss_zero, indemnity_scope: none_oss_as_is` — the register makes the zero-recourse reality of Gemma/GLM/Kimi/Qwen an explicit, examinable field, not a footnote.

### 5.2 The quantified indemnity gap — "every layer disclaims" becomes a number

For any deployed capability, the runtime computes:

```
indemnity_gap(capability) = potential_loss_exposure(capability)  −  Σ recoverable_from_vendor(route)
recoverable_from_vendor(route) = min(liability_cap_amount, contract_recoverable)   # 0 for oss_zero; excludes consequential
```

`potential_loss_exposure` is a control-plane-assigned **blast-radius band** per capability (e.g., a reconciliation-report skill vs a settlement-code-review agent land in different bands), owned by the CRO CODEOWNERS. The gap is what §6 insurance + §7 self-insurance must cover. This is the concrete answer to "every layer disclaims, residual lands on NPCI": the residual is now a **computed figure per capability and in aggregate**, projected onto the risk dashboard (§9), not a vibe.

### 5.3 Router teeth — a liability-posture exclusion (the ADR-012 pattern, applied to liability)

ADR-017 §3.2 made the Outsourcing Register the router's *eligibility* input (no register entry ⇒ not selectable). This ADR adds a **liability-posture exclusion step** in the same non-overridable pre-ranking phase (ADR-012 / `TOOLING §model-router`):

- For a request whose capability is in a **high blast-radius band**, a candidate route whose `liability_class` leaves the per-capability `indemnity_gap` above the **risk-appetite ceiling** (a control-plane threshold, §5.5) is **excluded before ranking and before failover** — *unless* a **named, reason-coded risk-acceptance** for that capability×route is on record (an authorized `ad_level<=3` sign-off, itself a control-plane artifact with an expiry). 
- A **stale `last_counsel_review`** is treated as *unknown-worst-case* (`liability_class` effectively `none`) — an un-reviewed liability profile cannot silently keep steering high-stakes work to a supplier whose posture may have changed. This mirrors ADR-017 §3.4's "an untested exit plan is no exit plan."

This is the enforcement for OSS zero-indemnity (gap [5]) at the point it matters: a zero-indemnity model **cannot be silently selected for high-blast-radius payment-code work** — either the work routes to a better-liability route, or a named human explicitly accepts the residual on the record. The disclaimer stops being invisible.

### 5.4 The Recovery Waterfall — the order recovery is attempted (defined once, computed at incident)

When a loss occurs, recovery is attempted in a **fixed, control-plane-defined order**, each tier quantified from the registers:

1. **Payment boundary (ADR-016) — the loss that never happened.** The first "recovery" is prevention: the direct-settlement class was structurally impossible, bounding the loss to the indirect path. Recorded as the baseline.
2. **Vendor indemnity / cap** — `recoverable_from_vendor` per §5.2 (thin for cloud, zero for OSS, subject to the vendor's own notice window — an armed clock, §6.3).
3. **Insurance layer** — §6, to the coverage limit, net of retention, if affirmatively covered and noticed in time.
4. **NPCI self-insurance / captive reserve** — the provisioned residual (sized from the aggregate `indemnity_gap`, §5.2 — this is *why* the gap is quantified).
5. **Member-bank allocation** — only where the §7 function permits, only post the consumer-protection and settlement-finality gates, never to the customer.

The waterfall is a **git-versioned policy**; an actual incident's *filled* waterfall (with figures) is a data-plane instance in the Adjudication Program (§8). "Who eats it" is thus an ordered computation over declared inputs, not a scramble.

### 5.5 Risk-appetite thresholds — control-plane, board-owned

The ceilings (`max_uninsured_residual_per_capability`, aggregate `max_uninsured_residual`, the blast-radius bands) are a **control-plane definition owned by the CRO + board-delegate CODEOWNERS** — the org's risk appetite is a reviewed, versioned artifact, and changing it is a signed, audited PR, not a config someone edits under deadline.

---

## 6. Cyber / Professional-Indemnity insurance model

### 6.1 The Insurance Coverage Register — a control-plane definition (Q2)

Insurance is not a PDF in a drawer whose terms surface at claim time. Each active policy is a git file:

```yaml
kind: insurance-coverage
id: insurance.<line>.<policy-year>
line: cyber | tech_eo_pi | crime | do        # tech E&O / professional indemnity, cyber, crime, D&O
insurer_legal_entity: "<name, rating>"
coverage_limit: "<figure>"
sublimits: { <peril>: "<figure>", ... }
retention_deductible: "<figure>"
ai_affirmative_cover: affirmed | excluded | silent   # the load-bearing field (§6.2)
exclusions: [ ... ]                          # e.g., "unauthorised value transfer", "regulatory fines" (often excluded)
territory: "<jurisdiction>"
period: { start, end }
notice_clock: { trigger: claim | circumstance, budget: "<duration>", forum: "<insurer contact>" }
broker_ref: "<...>"
last_counsel_review: "<date>"
```

CODEOWNERS = **CRO + General-Counsel + Insurance/Risk group**.

### 6.2 The "silent AI" problem, named and enforced

Many 2024–2026 cyber/PI policies neither affirmatively cover nor explicitly exclude AI-caused loss — they are **"silent."** Silence is an ambiguity that becomes a coverage denial at claim time. The design refuses to rely on silence:

- The `ai_affirmative_cover` field is **required**, and a value of `silent` or `excluded` on a line that the aggregate exposure (§5.2) *depends on* raises a **board-delegate governance finding** (the same escalation shape as ADR-017 §3.5 concentration risk). The org is forced to *know* whether it is actually covered, and to procure an **affirmative-AI endorsement** where it is not.
- **Regulatory fines** (e.g., DPDP penalties up to the statutory ceiling) and **unauthorised value transfer** are commonly *excluded* from cyber cover — recorded in `exclusions`, so those loss classes are correctly routed to self-insurance/reserve (§5.4 tier 4), not falsely assumed insured.

### 6.3 The insurer-notification clock — un-missable, reusing the Statutory-Clock machinery

A cyber/PI policy typically requires notice of a claim **or circumstance** "as soon as practicable" / within N days; **late notice is a coverage-voiding breach.** Missing an insurer's notice deadline is therefore exactly as catastrophic as missing CERT-In's 6-hour clock — so it is made un-missable by the *same mechanism*:

- When the breach engine (ADR-017 §2) classifies an incident as **potentially insured** (matched against the Coverage Register's lines/perils), it **auto-arms an insurer-notification clock** — a durable Statutory-Clock (ADR-017 §2.3) with `t0` = time of first notice, `budget` from the policy's `notice_clock`, and the 50/75/90% escalation ladder paging the incident owner → Insurance/Risk → CRO.
- The clock **survives a crash** (re-projected from the Event Log; a restart mid-incident never loses the insurer timer) and **cannot be silently paused** — the wall-clock and `t0` are immutable.
- A clock crossing budget **without a recorded insurer notice** auto-raises a **P1 "coverage-at-risk" meta-incident** to the CRO + board-delegate — missing an insurer deadline is a first-class, un-hideable event, not a quiet lapse.

This is the concrete "insurance model": not "we have a policy," but "coverage is a versioned register, exposure is continuously checked against it, and the notice that keeps it valid runs on a durable clock that cannot be missed by accident."

### 6.4 Coverage-vs-exposure gate — continuous, not annual

A projection continuously compares **aggregate deployed AI exposure** (Σ `indemnity_gap` across capabilities, §5.2) against **aggregate coverage** (Σ `coverage_limit` net of sublimits/exclusions). A breach — exposure outgrowing cover, or a policy lapsing (`period.end` passed with no renewal) — raises a board-delegate finding. Insurance adequacy becomes a live posture on the dashboard (§9), examinable "as of 90 days ago" by replay, not a once-a-year renewal memo.

---

## 7. NPCI-to-member-bank loss allocation (RBI consumer-protection ∩ settlement-finality)

This is the hardest, most NPCI-specific part: three legal doctrines collide, and a wrong precedence is a regulatory violation or a spoliation of a customer's protected rights.

### 7.1 The three colliding doctrines

- **RBI consumer-protection / limited-liability** (the RBI framework on *Limiting Liability of Customers in Unauthorised Electronic Banking Transactions*, and allied customer-protection circulars): a **retail customer's liability for an unauthorised/erroneous electronic transaction is zero or capped within reporting windows.** The loss **may not be pushed to the customer.** It must land on an *institution*.
- **Settlement finality** (Payment and Settlement Systems Act 2007 — settlement/netting effected under an approved payment system is **final and irrevocable** and cannot be unwound): if the agent-caused defect resulted in a **settled** transaction, you **cannot claw it back through the rails.** Recovery becomes a **post-settlement inter-institutional claim**, not a reversal. (This is *why* ADR-016's "never move value" is the first defense — but a human-deployed code defect may already have settled.)
- **NPCI ↔ member-bank allocation** (the member participation agreement + NPCI procedural/dispute guidelines): governs, by fault and negligence terms, who bears an institutional loss between NPCI-the-switch and a member bank.

### 7.2 The Loss-Allocation Decision Function — deterministic precedence, evidence-anchored (the ADR-017 §6.1 pattern)

Allocation is **not** model-judged and **not** an ad-hoc negotiation. It is a **control-plane deterministic precedence function** (git, owned by General-Counsel + CRO + a payments-legal CODEOWNERS), evaluated per loss, exactly mirroring the retention/legal-hold precedence function of ADR-017 §6.1:

1. **Consumer-protection cap (highest precedence).** Classify whether any part of the loss is **customer-facing**. If so, the RBI limited-liability cap applies **first**: the customer's share is capped/zeroed within the reporting window, and the **institutional side absorbs the customer-facing remainder** before any NPCI↔member split is even computed. **The customer is structurally unreachable as the residual bearer** — the function has no branch that lands residual on a retail customer.
2. **Settlement-finality classification.** Classify the loss as **pre-settlement** (potentially containable — route to the ADR-013 idempotency-in-doubt reconciler / saga compensation; the best outcome is *containment*, not recovery) or **post-settlement-final** (PSS Act 2007 — irrevocable; recovery is a *claim*, not a reversal). This determines *whether the loss can be undone at all* before any allocation.
3. **Fault attribution → NPCI ↔ member split.** Using the **Accountability Record (§4) + the admissible Event-Log evidence slice (ADR-025)**, attribute the defect: whose named human/agent action, in whose environment, at which control-plane SHA, caused it. The split follows the member participation agreement's fault/negligence terms — but the **factual basis is the machine-verifiable evidence pack, not competing assertions.**

The output is a **computed allocation with figures + an admissible evidence package** (ADR-025 §63 certificate) — the input to the *existing* inter-institutional dispute process, which humans execute. The runtime **produces the reasoned, evidenced allocation; it does not operate the dispute rails** (payment-adjacent, ADR-016 §2).

### 7.3 Why determinism + evidence is the enforcement mechanism

The teeth are that **the split is computed from declared, versioned inputs over admissible evidence**, so it is *reproducible and defensible*: a member bank's counsel disputing the allocation is disputing a git-versioned policy applied to a hash-chained, BSA §63-certified evidence pack (ADR-025), not NPCI's say-so. And because the consumer-protection precedence is *first and unconditional*, "the customer bears it" is not a disfavored outcome the function might reach under pressure — **it is an outcome the function cannot express**, the same design move ADR-016 §3.3 uses to make value-movement *unrepresentable* rather than merely disallowed.

---

## 8. How a payment-loss incident is adjudicated — the Adjudication Program (Q1/ADR-027)

A payment-loss incident is not a single Run — recovery spans **weeks to months** (investigation, vendor claim within its notice window, insurer notice + claim + adjuster back-and-forth, inter-institutional allocation, possible litigation), must **survive restarts and model swaps**, must **checkpoint partial progress**, and has **staged human gates**. That is precisely a **Long-Horizon Program (Q1/ADR-027)**, so adjudication *is* one — a durable, resumable Event-Log aggregate, not a runbook.

### 8.1 Detection → spawn

The ADR-017 §2 breach engine already detects the candidate sources this ADR needs: a settlement-boundary tripwire (ADR-016 §4.6 runtime classifier firing), a quality-degradation on a regulated route (a degraded model shipped bad payment-code review), a store-sweep/reconciliation exception, or a human/member-bank/RBI-raised loss report. A candidate classified as a **potential financial-loss incident** spawns an **Adjudication Program** and immediately arms: the statutory clocks (ADR-017), **and** — this ADR's addition — the **vendor-claim notice clock** and the **insurer-notification clock** (§6.3), because those windows start running at first notice too.

### 8.2 The Module Task Graph (the ADR-027 §3 decomposition, at adjudication altitude)

| # | Module | Named owner (CODEOWNERS group) | Human checkpoint (ADR-027 §8) | Produces |
|---|---|---|---|---|
| 1 | **Contain & classify** | Incident owner + Payments-Ops | — (automatic; arms clocks) | pre/post-settlement + customer-facing classification (§7.2 steps 1–2); pre-settlement ⇒ ADR-013 reconciler invoked to *contain* |
| 2 | **Attribute** | Platform-leads + DPO | review of the evidence pack | Accountability Record (§4) + admissible Event-Log slice + BSA §63 draft (ADR-025) |
| 3 | **Quantify** | CRO + Insurance/Risk | sign-off on the loss figure | filled Recovery Waterfall (§5.4) with per-tier figures; the `indemnity_gap` realized |
| 4a | **Recover — vendor** | General-Counsel | approve/decline filing | vendor claim filed *within the vendor notice clock*; recovered figure (thin/zero, honestly) |
| 4b | **Recover — insurer** | Insurance/Risk + GC | approve claim submission | insurer notice + claim filed *within the notice clock (§6.3)*; the coverage-voiding-late-notice risk closed |
| 4c | **Allocate — member/self** | Payments-Legal + CRO | approve the computed split | Loss-Allocation output (§7.2) + evidence pack → the existing inter-institutional dispute process |
| 5 | **Learn** | Platform-leads + CRO | approve the control-plane change | postmortem → regression-eval scenario (gap [23]) + control-plane PRs: tighten §5.3 routing gate, update Vendor/Insurance registers, add permanent regression test |

Edges are dependency-ordered (attribute before quantify; quantify before recover/allocate). Each module is an ordinary bounded Run; the Program's durable state (which claims filed, which clocks running, partial recoveries booked) lives on the Event Log and **survives restarts and model swaps** (ADR-027 §4) — a mid-adjudication crash never loses a filed-claim fact or a running insurer clock.

### 8.3 Partial completion is a first-class outcome (ADR-027 §8)

Real adjudication does not finish atomically: the vendor claim may settle in weeks, the insurer claim in months, the inter-institutional allocation only after arbitration. The Program **ships partial completion** — "vendor recovered ₹X (booked), insurer claim pending (clock met, filed), member allocation in dispute (evidence pack delivered)" — as a legible, checkpointed state on the dashboard (§9), not an all-or-nothing scramble. This is exactly the ADR-027 property that makes a multi-month obligation tractable.

### 8.4 The Learn module closes the loop (and is not optional)

Module 5 is a *required* node, not an afterthought: every adjudicated loss produces (a) a **permanent regression scenario** (`AGENT_TESTER §6` "a bug found once is tested forever") so the specific agent-caused defect is caught forever after, and (b) **control-plane PRs** tightening the very gates in this ADR (a class of defect that slipped means the §5.3 routing band, the §4.3 money-path tag, or the blast-radius band was mis-set — the fix is a reviewed diff). The liability framework thus *learns*, and the learning is itself audited.

---

## 9. The Q2 split applied — one source each

Applied exactly as ADR-026 / ADR-017 §1.2 require:

| Compliance/liability **policy** → **git control plane** (PII-free, reviewed, versioned, signed) | **Instance** → **data plane** (Event Log + Postgres; erasable-or-held) |
|---|---|
| Vendor Liability Register profiles (§5.1) | The realized `indemnity_gap` figures + per-incident recoverable computations |
| Insurance Coverage Register (§6.1) + notice-clock budgets | A specific armed insurer-notification clock + the filed notice/claim |
| Loss-Allocation Decision Function + precedence (§7.2) | A specific computed allocation for incident #N (names principals ⇒ PII ⇒ data-plane) |
| Risk-appetite thresholds + blast-radius bands (§5.5) | Live aggregate exposure vs coverage projection |
| Accountability-Record **schema** + money-path tag registry (§4.1/§4.3) | A specific Accountability Record for artifact X (names humans ⇒ PII ⇒ data-plane, legal-holdable) |
| Accountability Policy (roles→tier→consequence/coverage, §4.5) | An HR/governance action instance |
| CODEOWNERS (GC / CRO / Insurance-Risk / payments-legal / board-delegate) | Adjudication Program runs + every module's Event-Log trace |

The reason it is load-bearing, not cosmetic: a **policy must be reviewed, diffed, versioned, rolled back, never erased — that is git**; an **instance names data principals, must be erasable-or-legal-held, is written per-incident — that is a store.** Putting a specific loss-allocation (which names a customer and a bank) in git would make it un-erasable (a DPDP violation); putting the *risk-appetite ceiling* in a mutable DB would let one actor silently change NPCI's risk posture without board review. And because the policies are PII-free, they are **portable across the sovereignty/air-gap boundary** (ADR-026 §12) — the liability *framework* is safe to move; the loss *instances* never leave the in-zone stores.

A single **Liability & Recovery dashboard** (a projection off the Event Log + control-plane git — *no third source of truth*) shows the live posture: aggregate exposure vs coverage, per-provider indemnity gaps, silent/excluded AI-cover findings, open adjudication Programs + their partial-recovery state, armed vendor/insurer clocks + countdowns, and money-path artifacts missing a complete Accountability Record. "Prove the posture 90 days ago" is a replay to an offset, not a kept screenshot.

---

## 10. Alternatives considered

| # | Alternative | Why rejected |
|---|---|---|
| **A** | **Treat liability as ordinary operational risk — a policy binder + annual insurance renewal.** | The Pass-5 gap is explicit that a principle is not a framework. A binder has no clock (misses insurer notice windows → voided cover), no router teeth (lets high-stakes work route to zero-indemnity OSS silently), no deterministic allocation (leaves "who pays" to ad-hoc negotiation), and no admissible evidence pack. It fails all five questions in §1.4 on first contact with a regulator or an adjuster. |
| **B** | **Rely on the payment boundary (ADR-016) alone — "the agent never moves value, so there is no liability."** | Bounds the *direct* blast radius, not the *indirect* path (§1.3): agent-authored payment code and agent-generated advice, deployed by a human through change control, can still cause a settled, non-compensable loss. ADR-016 is the first line, not the whole line. |
| **C** | **Push the residual onto suppliers and member banks contractually.** | Three walls: (i) supplier caps make vendor recovery a thin slice and OSS zero (§5.1); (ii) **RBI outsourcing rules forbid NPCI from diminishing its own accountability** by outsourcing (§1.2); (iii) **RBI consumer-protection forbids pushing loss to the retail customer** and settlement-finality forbids clawing back a settled transaction (§7.1). You cannot contract your way out of a regulatory duty to own the residual. |
| **D** | **Self-insure everything via a captive reserve, skip the market.** | Leaves the tail unquantified and un-transferred; concentration of a systemic-scale tail on one balance sheet is itself an RBI concern; and it discards the market's risk-pricing signal. Self-insurance is *tier 4* of the waterfall (§5.4), sized from the measured gap — a component, not the whole answer. |
| **E** | **Let a model adjudicate the allocation (an "AI liability judge").** | A sycophantic or confused model could land residual on a customer (unlawful) or mis-attribute fault. Allocation must be a **deterministic function over admissible evidence** (§7.2) — the model may *classify* facts, but the keep/allocate decision is a policy table, exactly as ADR-017 §6.1 keeps erasure/hold out of model judgment. |
| **F (chosen)** | **A mechanized Liability & Recovery Chain:** registers-as-router-teeth + quantified gap + insurance register with an un-missable notice clock + deterministic evidence-anchored allocation + a durable adjudication Program, all on the Q2 split. | Answers all five §1.4 questions with enforcement mechanisms and tests; composes with ADR-016/017/025/026/027 instead of duplicating them; makes the residual a *measured, provisioned, recoverable* number with a named human anchor guaranteed by the payment boundary itself. |

---

## 11. Acceptance / scenario tests

| # | Scenario | Setup | Expected | Proves |
|---|---|---|---|---|
| 1 | **No name, no money-path deploy** | An agent-authored MR targets a money-path repo with no `deploy_checker` in its Accountability Record | Promotion **blocked** at the deploy gate (§4.2); a distinct maker≠checker is required before it can ship | Named human accountability is a mechanical precondition, not a report |
| 2 | **"The AI did it" is not a defense** | A settled loss traces to an agent-written defect a human waved through | The Accountability Record names the maker-checker; `review_discipline` shows ~0ms dwell → recorded as evidence in adjudication (§4.4/§8) | Acceptance carries accountability; complacency is evidenced |
| 3 | **Complacency alarm before a loss** | A team's `override_of_agent_flag` slides monotonically to ~0 over a quarter | Governance finding raised (gap [43]) *before* any loss | Automation-bias is caught proactively |
| 4 | **Indemnity gap is a number** | Query the exposure of a settlement-code-review agent routed to an `oss_zero` model | Gap = full blast-radius band (vendor-recoverable 0); shown on the dashboard (§5.2) | "Every layer disclaims" is quantified, not a vibe |
| 5 | **OSS zero-indemnity router teeth** | A high-blast-radius payment-code task is offered a zero-indemnity OSS route with no risk-acceptance on record | Route **excluded before ranking** (§5.3); steers to a better-liability route or requires a named `ad_level<=3` risk-acceptance | Liability posture is a non-overridable routing exclusion |
| 6 | **Stale liability profile = worst-case** | A vendor's `last_counsel_review` is older than the configured cadence | Treated as `liability_class: none`; high-stakes routing to it is excluded until re-reviewed | An un-reviewed disclaimer can't silently keep steering stakes |
| 7 | **Silent-AI cover is surfaced** | The cyber policy's `ai_affirmative_cover: silent` and aggregate exposure depends on it | Board-delegate finding raised; forces an affirmative-AI endorsement decision (§6.2) | The runtime forces the org to *know* if it's covered |
| 8 | **Insurer notice clock is un-missable** | An insurable loss incident is detected; the insurer notice window is N days | Notice clock auto-armed at t0 (§6.3); 50/75/90% paging; breach without a filed notice → P1 "coverage-at-risk" meta-incident to CRO | A voided-cover late notice is structurally impossible to reach silently |
| 9 | **Insurer clock survives a crash** | `kill -9` the runtime 2 days into a 7-day insurer notice clock | On restart the clock re-projects and continues from real elapsed; t0 unchanged (§6.3) | The insurer timer is durable, per ADR-017 §2.3 |
| 10 | **Coverage-vs-exposure breach** | Aggregate exposure grows past aggregate coverage (or a policy lapses unrenewed) | Board-delegate finding on the dashboard (§6.4) | Insurance adequacy is a live, examinable posture |
| 11 | **Customer is never the residual bearer** | A loss classification includes a customer-facing component | RBI limited-liability cap applied first; institutional side absorbs the remainder; the function has *no branch* landing residual on the customer (§7.2) | Consumer-protection precedence is structural, not disfavored |
| 12 | **Settlement-finality classification** | A loss traces to a defect in an already-settled transaction | Classified post-settlement-final (PSS Act) → recovery is a *claim*, not a rails reversal; a pre-settlement loss instead invokes the ADR-013 reconciler to *contain* | Finality vs containability is decided deterministically |
| 13 | **Allocation is evidence-anchored** | NPCI↔member split for an agent-caused defect | Split computed from the Accountability Record + BSA §63-certified Event-Log slice (§7.2/ADR-025); reproducible from the control-plane SHA + evidence | The split is defensible against a member's counsel, not NPCI's say-so |
| 14 | **Adjudication is a durable Program** | A payment-loss incident spawns adjudication; the coder model is retired mid-adjudication | The Program continues on the new model with no manual step; filed-claim facts + running clocks persist (§8.2/ADR-027 §4) | Adjudication survives restarts and model swaps |
| 15 | **Partial completion is first-class** | Vendor claim settled, insurer claim pending, member allocation in dispute | Dashboard shows the checkpointed partial state; the Program is not "failed" or "hung" (§8.3) | Multi-month recovery is tractable, not all-or-nothing |
| 16 | **The loop closes** | An adjudicated loss completes | A permanent regression scenario is added; control-plane PRs tighten the routing band / money-path tag that let it through (§8.4) | The framework learns, auditably |
| 17 | **Q2 split holds** | Attempt to commit a specific loss-allocation instance (naming a customer + bank) into the control repo | Pre-receive compliance gate rejects it (PII); it belongs in the data plane (§9/ADR-026 §10) | Policy=git, instance=store — mechanically |
| 18 | **Two-years-later reconstruction** | Reconstruct adjudication for a closed incident by id | The Accountability Record, the waterfall figures, the allocation, and the historical control-plane SHA all recover and hash-verify into an admissible package (ADR-025) | The whole chain is reproducible and court-usable |
| 19 | **Air-gap portability** | An air-gapped zone imports the control repo | All liability/insurance/allocation *policies* load (PII-free); no loss *instance* crosses the boundary (§9) | The framework is portable; the instances stay in-zone |

---

## 12. Consequences

**Positive**
- The residual that "lands on NPCI" becomes a **measured, provisioned, recoverable number** with a named human anchor guaranteed by the payment boundary itself — the five §1.4 questions each have a mechanism and a test.
- **Insurance stops being a hope:** coverage is versioned, adequacy is continuous, and the notice that keeps it valid runs on a durable, un-missable clock — the single most common way real organizations *lose* otherwise-valid cover (late notice) is closed structurally.
- **Allocation stops being a fight:** a deterministic function over an admissible evidence pack makes the NPCI↔member split reproducible and defensible, and makes "the customer eats it" *unrepresentable*, satisfying RBI consumer-protection and settlement-finality by construction.
- **One supply-chain/governance discipline, reused:** the Vendor Liability Register *is* the Outsourcing Register (ADR-017), the notice clock *is* the Statutory Clock, adjudication *is* an ADR-027 Program, the evidence *is* an ADR-025 package, the split-function pattern *is* ADR-017 §6.1 — no second bespoke stack (anti-fragmentation, `AINXT_OS §3`).
- **Regulator-examinable:** an RBI examiner or a member's counsel gets a live system with figures and admissible packs, not a binder.

**Negative / cost**
- Legal, the CRO, and Insurance/Risk must become **CODEOWNERS** and author registers/policies through PR review — a real ongoing obligation on those functions and a UX obligation on the Studio (inherited from ADR-026), not a one-time form.
- The liability-posture routing exclusion (§5.3) can **reduce model choice** for high-blast-radius work (steering away from cheap zero-indemnity OSS) — a deliberate cost of owning the residual, and overridable only by a named, expiring risk-acceptance.
- Sizing the self-insurance reserve and procuring affirmative-AI cover are **real financial commitments** the design surfaces but cannot fund; it makes the number honest, it does not make it small.

**Neutral**
- Nothing here weakens ADR-016; the boundary remains the first and best recovery (the prevented loss). This ADR is strictly additive — it handles the residual the boundary was never meant to eliminate.

---

## 13. Residual risks (honest, not deferred silently)

1. **Detector/attribution recall is the floor under attribution.** The Accountability Record and the fault-attribution step assume the Event Log + code-provenance actually *pin* the defect to the introducing agent/human. A gap in provenance (e.g., an agent edit laundered through later human edits) weakens the split's factual basis. Mitigation: the semantic-editing + git-history graph (ADR-027 §10, `CODE_REVIEW_PIPELINE`) attributes at commit granularity, but the residual is real — a wrongly-attributed split is a wrong outcome the mechanism faithfully computes.
2. **The insurance market may not sell affirmative-AI cover at a viable price** — or at all, for systemic-scale AI risk. The design *surfaces* the gap and forces the decision (§6.2); it cannot create a market or lower a premium. Where cover is unavailable, tier-4 self-insurance absorbs more, and the reserve-sizing burden grows.
3. **The blast-radius bands and risk-appetite ceilings are judgment inputs.** The routing teeth (§5.3) are only as right as the CRO-owned bands; a mis-set band under-protects (lets stakes route cheaply) or over-protects (starves the platform of capable models). They are reviewed, versioned control-plane artifacts, but a wrong band is a wrong outcome — the mechanism enforces the number faithfully, it cannot author the number correctly for you.
4. **"Named human liability" is bounded by employment and directors'-indemnification law.** §4.5 is deliberate that this means organizational accountability + evidence + D&O + internal governance, not personal financial ruin. A stakeholder expecting an engineer to personally cover a crore-scale loss will find the framework does not (and should not) deliver that; the *institutional* waterfall is where the money actually flows.
5. **The router liability exclusion depends on no side path.** If any code path could select an external route without consulting the Vendor Liability Register (a bug, a "quick" bypass), the "no ungoverned-liability routing" guarantee (§5.3) is silently false — the same design-review invariant ADR-017 §3.2 and the OBO no-fallback rule already demand, and an acceptance test on every routing change.
6. **Legal doctrine is live.** RBI's stance on *agentic* AI liability, the exact contours of settlement-finality applied to an AI-introduced defect, and BSA §63 judicial sufficiency (ADR-025) are evolving. The precedence function and templates are Legal-owned, versioned, and re-pinnable as config/policy — but the design cannot pre-settle a doctrine the courts and RBI have not.
7. **A specific loss-allocation instance is PII-bearing and legal-hold-critical.** It must be data-plane, erasable-or-held (§9); a mis-classification that let it into git (ADR-026 §10 break-glass) or that erased it during an open matter (ADR-017 §6 hold) would be a serious fault — bounded by the pre-receive gate and the legal-hold precedence, but named here as the sharpest edge of the Q2 split.

---

## 14. Self-score (honest)

**Design ceiling: 9.5 / 10.** Every claim in the decision has a concrete enforcement mechanism — a blocking promotion gate (§4.2), a router exclusion (§5.3), a quantified gap function (§5.2), a durable un-missable clock reusing proven machinery (§6.3), a deterministic evidence-anchored precedence function (§7.2), and a durable adjudication Program (§8) — and an acceptance test that exercises exactly the property that matters (§11). It answers all five questions a regulator/adjudicator/member-counsel actually asks (§1.4), it is a *proper* ADR (context / decision / alternatives / consequences), and it takes the hardest constraints head-on rather than finessing them: it names the honest reality that every layer disclaims and RBI forbids outsourcing accountability (§1.2), it resolves the payment-boundary paradox by owning the *indirect* path the boundary doesn't cover (§1.3), and it makes "the customer bears it" *unrepresentable* under the collision of RBI consumer-protection and settlement-finality (§7). It composes with — rather than duplicating — ADR-016/017/025/026/027, honoring both binding cross-cutting decisions (Q2 policy=git/instance=store §9; Q1 adjudication-as-Program §8).

The missing half-point is honest and concentrated where the design *specifies* but cannot itself *prove or provision*: **attribution recall** is the floor under a defensible split (residual 1), the **insurance market and legal doctrine are external** and can move against the design (residuals 2, 6), the **risk-appetite bands are human judgment** the mechanism faithfully enforces but cannot author correctly (residual 3), and the **no-side-path routing guarantee** is an enforcement surface a determined implementer could subvert (residual 5). **Build maturity: 0 / 10** — no code exists, consistent with the entire corpus. The ceiling is set correctly so implementation can only descend from a real, go-live-blocker-clearing target.
