# ADR-010 — Evaluation is a Gate, not a Dashboard (no prompt / model / retrieval / skill change ships without an eval delta)

**Status:** Accepted (P0 — the keystone). Design only (no code).
**Decision class:** Architecture-defining. It makes *measured quality* a structural precondition of change — the same way ADR-026 makes *review* a structural precondition and ADR-003 makes *compliance/RBAC* a structural precondition. It is the single decision the rest of the corpus's design-10s silently depend on (`RUNTIME_SCORECARD.md` Keystone note 1: "several 10s silently assume the eval platform exists").
**Relates to / extends:** ADR-001 (Runtime — the eval runner is a dogfooded harness on the same loop), ADR-003 (Policy/Approval/Compliance seam — eval runs pass the same compliance gate; a redaction-correctness eval *tests* it), ADR-006 (Provider/Model Router — the router's "quality-not-regressed" scoreboard and live quality circuit-breaker are *fed by* this platform; `TOOLING_MCP_PLUGINS_ROUTING.md` §4.3/§4.6), ADR-012 (data-class → model routing — eval **data** and the **Judge model** are themselves data-class-routed; a regulated eval never leaves the boundary), ADR-013 (idempotency — an eval that exercises a `SideEffecting` capability runs against a sandboxed/ledgered stand-in, never a live side effect), ADR-014 (Model Risk Management — an eval run **is** the independent-validation + challenger + ongoing-monitoring evidence RBI/SR-11-7 requires), ADR-016 (Agent-Payment-Initiation Boundary — the eval platform can never itself initiate settlement; §7), ADR-018 (Model Governance — model onboarding requires a passing eval baseline), ADR-025 (Evidentiary Admissibility — an eval run is a signed, reproducible audit artifact), ADR-026 (Control-Plane Git-Native — **eval sets are definitions**; the eval delta is a merge-blocking CI status check enforced by branch protection, not a convention), ADR-027 (Long-Horizon Programs — a corpus-wide re-eval or embedding-migration re-eval runs as a Program).
**Companion design docs:** `EVAL_PLATFORM.md` (the full mechanism — offline suites, online A/B/canary, Judge calibration & inter-rater reliability, statistical methodology, RAG evals, drift, contamination/holdout governance, postmortem→regression minting), `SCENARIO_MATRIX.md` (the 1,000+-scenario adversarial acceptance rig — the *safety/correctness* half of "done"), `AGENT_TESTER.md` (the Breaker — the adversarial engine that mints cases), `PROMPT_ENGINEERING.md` §8 (eval-gated deployment for prompts specifically — the first consumer of this ADR).
**Closes gaps:** **C** (evaluation-as-a-continuous-gate), **AQ** (eval integrity — contamination/overfitting/holdouts), **X** (behavioral reproducibility / behavioral diffing), **BF/BT** (answer-quality + quality-drift), **AS** (progressive delivery — canary + auto-rollback), **G** (RAG evals — jointly with `STRUCTURED_FEDERATED_RETRIEVAL.md`), Pass-5 **[40]** (eval statistical methodology — power, multiple-comparison correction, sequential testing), **[41]** (human-rater calibration / IRR / kappa), and the eval-loop half of **[23]** (postmortem→regression-eval loop; the live circuit-breaker mechanism itself lives in `TOOLING_MCP_PLUGINS_ROUTING.md` §4.6).
**Supersedes:** the advisory **evals dashboard** (`EvalsDashboard.jsx`) as a place where quality is *optionally observed after the fact* (`GAP_ANALYSIS_VS_AI_PLATFORMS.md` C: "an evals dashboard exists but not eval-gated deployment or online experimentation"). The dashboard is not deleted — it is re-hosted as a **read view over the Gate's decisions**, never the decision itself.

---

## 1. Context — why "we have a dashboard" is exactly how the last platform failed

The existing platform has an evals dashboard. It measured nothing that could stop a bad change. A prompt was edited and shipped because "it read fine"; a model was swapped and shipped because "it looked better on a few queries"; the embedding model was upgraded and the corpus half-re-embedded, silently degrading retrieval; and the canonical bug — "generate this as pdf" shipping a PDF of the *instruction* instead of the prior answer (`AINXT_OS.md` §35, `RUNTIME_FEATURE_FLOWS.md` §2.2) — reached users because **no quality signal was in the path of the change.** A dashboard is a thing you look at *after* you already shipped. It is quality as aspiration.

The whole rest of this corpus quietly assumes the opposite. Every subsystem doc that self-scores a 10 leans on a sentence of the form "…and it is eval-gated / not-regressed / quality-tracked":

- `PROMPT_ENGINEERING.md` §8: "no prompt ships without an eval delta" — and §12 residual 1 explicitly *defers* Judge calibration and drift to "the eval-platform design."
- `TOOLING_MCP_PLUGINS_ROUTING.md` §4.3/§4.6: the router deprioritizes and then *quarantines* a model whose live judge-score collapses, and "files the regression into the evaluation platform as a permanent regression scenario" — a live→eval loop that presupposes an eval platform to file into.
- `ENTERPRISE_MEMORY_LEARNING.md` §4: the improvement flywheel turns feedback into "held-out eval sets," which presupposes eval sets exist and are governed against contamination.
- `STRUCTURED_FEDERATED_RETRIEVAL.md` §5.2, residuals: Global-mode answer quality and re-derivation-mismatch patterns "need their own eval set."
- `AINXT_OS.md` §7/§130: "nothing ships until it passes **both** gates — the quality-eval suite *and* the Breaker."
- `RUNTIME_SCORECARD.md` Keystone note 1: *"The Eval Platform is the keystone. Routing 'quality-not-regressed', prompt drift, review confidence, and quality gates all assume the eval platform exists. If it rots or ships late, those 10s silently become 'never checked.' → Build the eval platform (gap C) first, in P0/P1."*

So this ADR is not a new feature. It is the load-bearing beam the corpus was designed around and named but never poured. Its decision is small to state and expensive to honor: **make measured quality a gate, with the statistical rigor a payment regulator's model-risk function will actually audit, and the anti-gaming governance that keeps the gate from becoming theater.**

Two failure modes must be designed *out*, not hoped away, because both are how eval programs die in practice:

1. **The gate satisfiable by noise** (Pass-5 gap [40]). A gate that blocks on "candidate mean < baseline mean" blocks on coin-flips: with enough metrics × model-families × categories, something always looks worse (or better) by chance. A gate you can pass by re-rolling, or that flaps on noise until people route around it, is not a gate. The gate must be a *statistical decision* — pre-registered, powered, multiple-comparison-corrected, and (online) sequentially valid — or it is worse than nothing, because it manufactures false confidence.
2. **The gate that rots into contamination** (gap AQ). Evals that leak into prompts/fine-tunes, or that authors overfit to, produce perfect scores on a memorized set and zero real signal. A prompt that scores 100% against a contaminated eval is a *false-positive gate pass* — and must be treated as a platform defect of the same severity as a prompt defect.

---

## 2. Decision

**Evaluation is a gate on change, enforced structurally, with statistical validity and anti-contamination governance as first-class parts of the mechanism.**

Concretely, five commitments:

### D1 — Eval-as-a-gate: no in-scope change ships without a non-regressing, statistically valid eval delta.
Any change to a control-plane definition whose behavior an eval measures — **a prompt layer, the model-routing policy or a newly-onboarded model, a retrieval/chunking/embedding/catalog change, or a skill/agent/role composition** — carries an **Eval Delta**: the change in scores, per watched `(metric × model_family × category)` cell, against the version currently live at `env/prod`. The Eval Delta is produced by a **required, merge-blocking CI status check on the PR** (ADR-026 §7.1, branch protection) and re-checked at the online **canary** stage (D4). A PR with no Eval Delta on record, or with a **statistically significant regression** on any watched cell after multiple-comparison correction (D3), **cannot merge and cannot be tagged**. This is the git-native equivalent of a `NOT NULL` foreign key on quality (`PROMPT_ENGINEERING.md` §3, §8), applied beyond prompts to every quality-bearing definition kind.

### D2 — The Judge is a calibrated, versioned, pinned instrument — not an oracle taken on faith.
Where scoring uses an LLM-as-Judge, the Judge is itself a **versioned control-plane definition** (a `judge` kind, pinned by model + version + params + rubric content-hash), and its trustworthiness is **measured, not assumed**:
- Every Judge Spec has a **Gold Set** — human-labeled reference cases from a **Calibration Panel** of ≥3 qualified human raters. The panel's **inter-rater reliability is quantified (Cohen's/Fleiss' κ)** and the panel is itself re-calibrated on a schedule (gap [41]).
- A Judge is admitted only if its **agreement with the human Gold Set clears a documented κ / balanced-accuracy floor**; Judge-vs-human agreement is re-audited on every Judge version bump and periodically in production (defeats silent judge drift when a provider updates the underlying model).
- Structural bias controls are mandatory: pairwise scoring is **position-randomized and order-averaged** (anti-position-bias), a Judge **never scores its own producer model's output** (anti-self-preference; ties `RUNTIME_FEATURE_FLOWS.md` §4.1 cross-model review), and verbosity/length is a controlled covariate. A regulated-data eval is scored by an **in-house OSS Judge only** (ADR-012), never a cloud model.

### D3 — The gate is a statistical decision, pre-registered and corrected — not a mean comparison (gap [40]).
- **Powered.** Each eval set is sized so the gate can detect its **pre-registered minimum detectable effect (MDE)** at the declared power (default 0.8) and significance — a set too small to detect the MDE is a **defect of the eval set**, surfaced, not silently trusted.
- **Pre-registered.** The metrics, the per-metric non-inferiority margin, the direction, and the analysis are declared **in the eval-set definition before the run** — you cannot metric-shop after seeing results.
- **Multiple-comparison-corrected.** Significance across all watched `(metric × model_family × category)` cells is controlled by **Benjamini-Hochberg FDR** (with a Bonferroni-family option for the small hard-safety subset), so "some cell looks worse" from pure multiplicity does not block, and — critically — a real regression is not hidden in the noise of many cells.
- **Effect sizes, not just p-values.** The gate reports effect size + confidence interval per cell; a "significant" but sub-MDE change is reported as *no material effect*, and an improvement that is not statistically distinguishable from noise is reported as *no measured improvement* (never "better").
- **Sequential-testing-safe online.** The offline gate is **fixed-sample** (pre-registered N). The online canary (D4) uses **always-valid inference** (confidence sequences / mixture-SPRT-family), so operators may watch a live canary continuously **without inflating the false-positive rate** — the correct engineering resolution of "no peeking," because you cannot forbid operators from looking at a live rollout (gap [40]).

### D4 — Two gates in series: offline (block-merge) then online (canary + auto-rollback).
Offline evals gate the **merge/tag** (D1). A tagged version then enters **canary** (`env/prod-canary`, `PROMPT_ENGINEERING.md` §3/§8): a small, always-valid-monitored slice of live traffic, scored on the **same** metrics computed online plus latency/cost/guardrail-trigger-rate. A statistically-established regression on any watched metric **auto-rolls-back** (a pointer flip, ADR-026 §6.2) — **a human is notified, not paged to manually revert** (gap AS). A/B and multi-arm live at canary (`env/prod` vs `env/prod-canary` traffic split). Offline can't prove real-user impact; online can't be a first line of defense (it exposes users to the regression first) — so both, in series, neither alone.

### D5 — Eval integrity is engineered: sealed holdouts, contamination scanning, and a permanent Regression Vault (gap AQ, [23], X).
- **Holdout sealing.** The eval-set *definition* (its id, version, size, taxonomy, oracle types, provenance, rotation policy, and a **content-commitment hash**) is a PII-free git definition (ADR-026). The eval-set *case corpus and gold labels* live **sealed in a data-plane store readable only by the eval-runner service identity** — never by the humans who author the definitions they gate. This is ADR-026 §3's authorization-vs-data split applied to evals: git governs the set's *existence and versioning*; the *content* stays out of author eyeballs so it cannot be memorized or leaked, and out of the boundary when regulated. (§5 details how this preserves git-native governance without defeating the point of a holdout.)
- **Contamination scanning.** Before any candidate ships, the platform scans for overlap between eval-case content and the candidate's prompts / retrieved context / fine-tune corpus; a hit **fails the gate as a platform defect**, not a quality pass.
- **Rotation + tripwires.** Holdouts rotate on a schedule; a small set of **canary tripwire cases** (deliberately never used for tuning) detects overfitting — a candidate that aces the visible set but drops on the sealed slice is caught (`PROMPT_ENGINEERING.md` PE10).
- **The Regression Vault (a bug found once is tested forever).** Every confirmed defect — from the Breaker, from a production incident postmortem, or from a live quality-circuit-breaker trip (`TOOLING` §4.6) — is **minted into a permanent, frozen regression case** the gate runs forever. A route/prompt/model that regressed cannot be restored by merely climbing back above the live threshold; it must pass the exact frozen case that caught it (§6, closing gaps [23] and X).

**The gate is configurable in *strictness and content*, never *off*** — the same "configurable provider, never configurable off" invariant as compliance/RBAC/audit (`IMPLEMENTATION_PLAN.md` A1). An enterprise sets which suites, which margins, which Judge; no build of the release pipeline exists that can promote a quality-bearing definition without an Eval Delta on record.

---

## 3. The rule, stated as an invariant

> **A quality-bearing definition reaches `env/prod` only if a pre-registered, powered, multiple-comparison-corrected eval run shows no statistically significant regression on any watched cell versus the version it replaces — and stays there only while online canary and continuous drift monitoring confirm the same on live traffic.**
> Corollary (anti-gaming): **an eval a change can pass by chance, by memorization, or by leaking the answers into itself is a platform defect, tracked and fixed at the same severity as the quality defect it failed to catch.**

The axis is: *is this change measured against something it cannot see, sized to be sure, and corrected for the fact that we looked many times?* If not, "it passed the gate" means nothing, and the corpus's 10s silently become "never checked."

---

## 4. Alternatives considered

| Alternative | Why rejected |
|---|---|
| **Dashboard-only / advisory evals** (the status quo) | Quality observed *after* shipping is not a gate. This is precisely the failure this ADR exists to end (§1); it is how "generate this as pdf" reached users. |
| **Human review only** (a reviewer eyeballs sample outputs) | Doesn't scale, isn't reproducible, and is exactly the "it read fine to me" that `PROMPT_ENGINEERING.md` §10 calls out. Human judgment is retained where it is best — as the **Gold Set / Calibration Panel** that *calibrates the Judge* (D2) — not as the per-change gate. |
| **Online/monitoring only** (skip offline, catch regressions in prod) | Exposes real users (in a payment system) to the regression *first*. Online is the second gate (D4), never the first. |
| **Offline only** (no canary) | Offline evals approximate; they cannot measure real-traffic distribution shift, latency/cost, or guardrail-trigger-rate. Both, in series. |
| **A single aggregate quality score as the gate** | Averages hide category regressions — a change that lifts the mean while silently dropping steerability or a data-class-leak safety cell would pass. The gate is **per-cell non-regression** with FDR correction, not one number (D3). |
| **Raw mean comparison as the gate** | Satisfiable by noise (gap [40]); flaps, gets routed around, manufactures false confidence. The gate is a pre-registered, powered, corrected statistical decision (D3). |
| **Judge-as-oracle (trust the LLM judge)** | An uncalibrated Judge is an un-audited instrument; judge drift silently shifts every score (`PROMPT_ENGINEERING.md` §12 residual 1). The Judge is calibrated against a human Gold Set with a documented κ and re-audited (D2). |
| **Eval sets as DB rows** | Violates ADR-026 (definitions are git, not DB) and gives no content-hash pinning, no diffable versioning, no reproducibility-from-SHA. Eval *sets* are git definitions; eval *runs/scores* are data-plane. |
| **Eval case corpus fully in readable git** | Defeats the holdout: any author with repo read access can memorize the answers → contamination (gap AQ). The definition is git; the sealed corpus is data-plane, machine-readable-only (D5, §5). |
| **Eval as a one-time acceptance milestone** (test once, then trust) | Models drift, retrieval mixes shift, usage moves off-distribution (`PROMPT_ENGINEERING.md` §8). Evals are continuous (drift monitor) and permanent (Regression Vault), not a milestone. |

---

## 5. Holdout sealing — how eval sets stay git-native *and* uncontaminated

This is the one genuinely subtle reconciliation, so it is stated explicitly, mirroring ADR-026 §10's "enforced, not hoped" discipline. Two requirements pull opposite ways: ADR-026 says definitions live in **readable, diffable git**; a holdout requires the answers be **unreadable to the people the gate judges**. Resolving it by "just put the eval cases in git" would silently reintroduce contamination (gap AQ) — an author reads the holdout, tunes to it, and the gate passes on memorization.

**Resolution — split the eval set exactly as ADR-026 splits every definition (authorization vs data):**

| Part of an eval set | Plane | Store | Who can read |
|---|---|---|---|
| **Set manifest** — `id`, `version`, `owner` (CODEOWNERS), category taxonomy, oracle types, metric/margin/MDE pre-registration (D3), rotation policy, `content_commitment` (a Merkle root over the sealed corpus) | Control | git (`ainxt-control/evals/`) | Anyone with repo read — it is PII-free and reveals *nothing about the cases' content* |
| **Case corpus + gold labels** — the actual inputs, expected outputs, human labels | Data | **sealed store**, encrypted, access = the **eval-runner machine identity** (ADR-022) + a small **break-glass human quorum** (audited) | **Not the authors of the definitions the set gates** |

- The manifest is content-addressed to the sealed corpus (the `content_commitment` Merkle root), so a tampered or swapped corpus is caught at run time exactly like the ADR-026 `control.lock` hash check — you cannot quietly change what the gate tests without a reviewable manifest diff.
- The eval **runner** (a dogfooded harness with its own machine identity, ADR-001/ADR-022) fetches sealed cases, runs them, and emits only **aggregate scores + per-cell effect sizes + pass/fail** to the data-plane run store and the dashboard. Humans see the *verdict and the distribution*, never the held-out answers.
- **Regulated eval data** (synthetic-but-realistically-shaped payment cases from the Breaker; `AGENT_TESTER.md` §3 uses test-range Luhn-valid PANs — synthetic by construction, never real PII) stays in-boundary and is scored by an in-house Judge (ADR-012). The seal therefore serves *both* contamination defense *and* data-class residency in one mechanism.
- **git-native governance is fully preserved**: the set's existence, ownership, versioning, pre-registered analysis, rotation, and deprecation are all reviewed, diffable, signed git operations (ADR-026 §7). What is *not* in git is the answer key — which was never supposed to be reviewable-by-the-graded.

---

## 6. Postmortem → permanent regression (closing gaps [23] and X)

Three sources feed one sink — the **Regression Vault**, a frozen, ever-growing eval set the gate runs on every relevant change forever:

1. **The Breaker** (`AGENT_TESTER.md` §6): every verified, minimized finding auto-generates a regression case.
2. **The live quality circuit-breaker** (`TOOLING` §4.6): when a `(model, task_type)` route trips, the exact turns that scored below baseline are frozen into a Vault case; a recovered route must pass that case, not merely climb back above the live threshold.
3. **Production incident postmortems** (`ENTERPRISE_MEMORY_LEARNING.md` §4, the `IncidentPostmortem` OKI): a confirmed AI-incident's reproducing input becomes a Vault case, wired through the same human-gated curation (the flywheel *proposes*, a human *promotes*, contamination-guarded into the sealed store).

Every Vault case carries the Event-Log id / control-plane commit SHA it was born from, so it is **reproducible from SHA** (ADR-026 §17; gap X): "what regressed, on which control-plane version, and does the frozen case still catch it" is a query, not archaeology. This is the mechanism that makes the platform *monotonic in safety* — the set of things that can never silently return only grows.

---

## 7. Safety invariants the eval platform itself must honor

The eval platform is powerful (it drives the real product at scale) and therefore is held to the same boundaries it verifies:

- **It never initiates a payment.** An eval that exercises a `SideEffecting` or `initiates-settlement` capability runs against a sandboxed/ledgered stand-in; there is no eval code path to real settlement (ADR-016, ADR-013). Testing the payment boundary means testing that it *refuses*, never that it *fires*.
- **Its own actions pass compliance.** Eval inputs/outputs traverse the same Compliance Gate (ADR-003); a redaction-correctness eval *is* a test of that gate, run through the gate.
- **It respects data-class + RBAC.** Regulated eval data and its Judge stay in-boundary (ADR-012); the runner's OBO identity is least-privilege (ADR-022). An eval cannot become a side channel that reads across a tenant/dept scope the product forbids.
- **It is budget-bounded** (`AGENT_TESTER.md` §5): Judge-at-scale and large re-eval campaigns run under a cost ceiling; a corpus-wide re-eval is an ADR-027 Program, not an unbounded loop.

---

## 8. Acceptance / scenario tests

| # | Scenario | Setup | Expected | Proves |
|---|---|---|---|---|
| 1 | Gate blocks a real regression | A prompt PR that improves correctness but drops steerability past its margin | The EVAL CI check fails; branch protection blocks merge; the PR shows the per-cell effect size + CI (D1/D3) | Eval-as-a-gate is structural, per-cell, merge-blocking |
| 2 | Gate is not satisfiable by noise | Submit the *same* definition twice (a null change); re-run the eval many times | No run reports a "regression" or "improvement" — a null change yields "no measured effect" after FDR correction (D3) | The gate is a powered, corrected statistical decision, not a mean comparison (gap [40]) |
| 3 | Multiplicity does not false-block | 40 watched cells, all truly unchanged | BH-FDR keeps the family-wise error at the declared rate; the gate passes; no cell false-blocks (D3) | Multiple-comparison correction works both ways — no false block, no hidden regression |
| 4 | Underpowered set is a defect | An eval set too small to detect its own MDE | The platform flags the set as underpowered and fails the *set*, not silently passes the change (D3) | A gate that cannot see the effect it claims to gate is surfaced, not trusted |
| 5 | No peeking online | Operators watch a live canary continuously and stop early on a confidence-sequence crossing | Early stop does **not** inflate the false-positive rate; the always-valid bound holds (D3/D4) | Sequential-testing-safe online monitoring (gap [40]) |
| 6 | Canary auto-rollback | A tagged version passes offline but regresses on live traffic at canary | Auto-rollback to the last PRODUCTION tag (pointer flip); a human is notified, not paged (D4) | Two gates in series; online catches what offline approximated (gap AS) |
| 7 | Judge calibration floor | A candidate Judge whose agreement with the human Gold Set is below the κ floor | The Judge is **not admitted**; scores from it never gate a change (D2) | The Judge is a calibrated instrument, not an oracle (gap [41]) |
| 8 | Judge drift caught | The provider silently updates the model behind an admitted cloud Judge | The periodic Judge-vs-Gold re-audit detects the agreement drop and quarantines the Judge (D2) | Judge drift does not silently shift every score |
| 9 | Judge self-preference blocked | A Judge is asked to score output produced by its own base model | The pairing is refused (cross-model rule); position is randomized on all pairwise scoring (D2) | Structural bias controls, not trust |
| 10 | Holdout stays sealed | An author with control-repo read access tries to read the gold answers for the set that gates their PR | The manifest is readable; the case corpus + labels are not (sealed, runner-only) (D5/§5) | git-native governance without defeating the holdout (gap AQ) |
| 11 | Contamination is a gate failure | A prompt candidate embeds text lifted from held-out eval cases | The contamination scan fails the gate as a platform defect, even though the score is perfect (D5) | A memorized eval is a false-positive pass, treated as a defect |
| 12 | Overfit caught by tripwire | A candidate tuned to the visible set | Measurable drop on the sealed slice / rotated holdout; the gate blocks (D5; PE10) | Held-out + rotation catch overfitting |
| 13 | RAG eval as a gate | An embedding-model upgrade with the corpus only half-re-embedded | The RAG suite (groundedness, context precision/recall, recall@k, citation faithfulness) shows a significant recall regression; the gate blocks (D1; gap G/AN) | Retrieval change is gated exactly like a prompt/model change |
| 14 | Regulated eval stays in-boundary | An eval set classified `regulated-payment` | It is scored by an in-house OSS Judge; no case or embedding leaves the boundary; a cloud Judge is never attempted (D2/§7; ADR-012) | Eval data + Judge are data-class-routed |
| 15 | Breaker → Vault | The Breaker finds and minimizes a new failure | A frozen regression case is minted into the Vault and runs on every relevant change thereafter (D5/§6) | A bug found once is tested forever |
| 16 | Circuit-breaker → Vault → restore | A live route trips the quality circuit-breaker (`TOOLING` §4.6); later a fix is proposed | The offending turns are frozen; the recovered route must pass that exact Vault case, not merely beat the live threshold (§6) | Closes the live→eval loop (gap [23]) |
| 17 | Reproduce-from-SHA | A 90-day-old gate decision, given its Event-Log record | The exact eval set version, Judge version, and candidate are recoverable by SHA; the run replays to the same verdict (§6; ADR-026 §17) | Behavioral reproducibility (gap X); admissible eval evidence (ADR-025) |
| 18 | Eval never fires a side effect | An eval exercises an `initiates-settlement` capability | It runs against a ledgered stand-in; no real settlement occurs; the test asserts the boundary *refuses* (D-§7; ADR-016/013) | The eval platform cannot become a path around the payment boundary |
| 19 | Model onboarding requires a baseline | A new in-house model is added to the router's candidate set | It cannot become routable until it has a passing eval baseline per task type (D1; ADR-018/014) | Model change is eval-gated; feeds Model-Risk evidence |
| 20 | Dashboard is a read view, not the decision | An operator "approves" a regressing change from the dashboard | The dashboard cannot promote; only a passing gate + CODEOWNERS-signed tag can (D1; supersede clause) | The dashboard reports the Gate; it is not the Gate |

---

## 9. Consequences

**Positive**
- The corpus's design-10s stop being aspirational: "quality-not-regressed," "prompt drift caught," "review confidence," "router quality scoreboard" all now have a real, statistically valid engine behind them (`RUNTIME_SCORECARD.md` Keystone).
- Change velocity *increases* net, because a green gate is trustworthy — teams stop hand-reviewing sample outputs and stop fearing prompt/model/retrieval changes.
- Model-risk evidence (ADR-014) falls out for free: an eval run is the independent-validation + challenger + ongoing-monitoring artifact RBI/SR-11-7 asks for, signed and reproducible (ADR-025).
- Safety is monotonic: the Regression Vault only grows; a fixed bug cannot silently return.
- One eval discipline serves prompts, models, retrieval, skills, and the router's live scoreboard — not five bespoke quality mechanisms.

**Negative / cost**
- **Judge-at-scale and re-eval campaigns cost real tokens/compute** — budget-bounded (§7) and sampled (drift), but a genuine line item someone must own (residual 1).
- **Building and maintaining Gold Sets + a human Calibration Panel is ongoing human effort** — κ audits, rotation, panel re-calibration (residual 3).
- **The gate can slow a hotfix** — the same pressure ADR-026 §17.4 names for Studio-as-git-client; the answer is fast CI and pre-warmed eval infra, never a "skip the gate" side door (residual 4).
- **Statistical rigor demands eval sets big enough to be powered** — small/new capabilities may not have the data yet; the honest interim is an explicit "underpowered, advisory-only" label, not a fake pass (residual 2).

**Neutral**
- The evals dashboard survives, re-hosted as a read view over the Gate.
- Sits cleanly on ADR-026 (eval sets are definitions), ADR-006/TOOLING (feeds the router scoreboard), and ADR-014 (supplies model-risk evidence) — additive, not disruptive.

---

## 10. Residual risks (honest, not deferred silently)

1. **Judge cost + residual judge drift.** Calibration + pinning + re-audit *reduce* judge drift; they don't eliminate it, and Judge-at-scale is expensive. Mechanical/deterministic oracles are preferred wherever a property is objectively checkable (steerability counts, schema validity, re-derivation diffs — `PROMPT_ENGINEERING.md` §9, `STRUCTURED_FEDERATED_RETRIEVAL.md` §5), reserving the Judge for genuinely semantic judgments — but the semantic core remains a calibrated-but-imperfect instrument. Named, not hidden.
2. **The cold-start / underpowered problem.** A brand-new capability has too little data to power a gate; until it does, its gate is honestly "advisory," which is a window where a regression could ship. Mitigation: seed from Breaker-generated + synthetic cases, and label advisory gates loudly so nobody mistakes them for enforced.
3. **Gold-label quality is a human bottleneck.** The whole calibration edifice rests on a human panel whose own κ must stay high; panel fatigue or turnover degrades the reference the Judge is calibrated against. Mitigation: rotation, κ monitoring, and treating the panel as a funded, owned role — not a favor.
4. **Gate-latency pressure → side-door temptation.** If the gate feels slow, teams will lobby for a bypass, which is the DB-status-field failure mode returning in eval clothing. The mitigation is speed + a hard "no bypass" (structural, per A1), not a fast lane that skips measurement.
5. **Contamination scanning is recall-bounded.** The scanner catches overlap it can detect; a cleverly paraphrased leak of a held-out case could evade it, quietly overfitting. Rotation + sealed corpora + tripwires are the defense-in-depth; the residual is that no single scanner is complete — the same "detector recall" honesty ADR-026 §17.1 states for PII-at-entry.

---

## 11. Self-score (honest)

**Design ceiling: 9.5 / 10.** Every commitment has a concrete enforcement mechanism (a merge-blocking CI check, a sealed corpus with a content-commitment, a κ floor, FDR correction, always-valid online inference, a frozen Vault case reproducible from SHA) and an acceptance test that exercises exactly the property that matters — the house bar. It resolves the two ways eval programs actually die (satisfiable-by-noise §D3/gap [40]; contamination §D5/gap AQ) head-on rather than assuming them away, reconciles holdout secrecy with ADR-026's git-native rule via the same authorization-vs-data split ADR-026 itself uses (§5), and closes the live→eval loop (§6) that `TOOLING` §4.6 and `ENTERPRISE_MEMORY_LEARNING.md` §4 both depend on.

The missing half-point is the same honest one every quality artifact in this corpus carries: the semantic core leans on a calibrated-but-imperfect Judge (residual 1), the gate is only as strong as eval sets being powered and uncontaminated (residuals 2, 5), and the human calibration panel is a real, load-bearing human dependency (residual 3) — enforcement surfaces this design specifies but cannot itself prove hold until built. **Build maturity: 0 / 10** — no code, consistent with the whole corpus. The ceiling is set where implementation can only descend from a real 10-shaped target.
