# ADR-007 — Licensing & Open-Source Strategy

**Status:** Accepted (design). **Date:** 2026-07-18. **Owners:** to be set by NPCI legal + platform eng.
**Related:** ADR-018 (model-weight licensing/origin), ADR-019 (liability), ADR-028 (clearance gate + CI), `runtime.md` §12, `feedback_legal_first_oss`.

## Context
AiNxt Runtime is to be open-sourced. The #1 non-negotiable is that it must be **legally, independently NPCI's** — no one can credibly claim it is a fork, and open-sourcing must carry **zero legal risk on any single term**. It sits inside a monorepo alongside a **proprietary** NPCI platform, and it routes to third-party models and (later) uses third-party dependencies and self-hosted model weights with heterogeneous licenses.

## Decision
1. **License = Apache-2.0** for the AiNxt Runtime OSS project. *(Confirmed by the project owner 2026-07-18; still requires formal NPCI legal sign-off — Gate 1 — before public release.)*
2. **OSS boundary = the `runtime/` tree only** (to be extracted to a standalone repo, e.g. `ainxt-runtime`). The surrounding proprietary NPCI platform is **not** relicensed. NPCI-specific enterprise plugins (PCI/DSS rule packs, AD/RBAC, IP-bearing connectors) live in a **separate private repo** and are never in the OSS tree — the **core/enterprise split**, enforced in CI (ADR-028).
3. **Permissive-only dependency policy:** Apache-2.0/MIT/BSD/ISC/Unicode/Zlib. **No copyleft** (GPL/LGPL/AGPL/MPL/EPL/CDDL) and **no source-available** (BUSL/SSPL) in the OSS tree — shell out to installed binaries instead of vendoring. Unknown license ⇒ treated as disallowed.
4. **DCO** (not CLA) as the default contributor mechanism; CLA reserved as a future maintainer option.
5. **Clean-room provenance** is part of the license story: ADRs are the evidence of independent design; reference projects are studied-only and recorded in `THIRD_PARTY_INVENTORY.yaml` under `reference_only`.
6. **Model weights are out of scope of the code license** — governed separately by the licensing/origin register (ADR-018) and never distributed in the source tree.

## Why Apache-2.0 (over the alternatives)
- **vs MIT:** Apache-2.0 adds an **explicit patent grant + patent-retaliation termination** — material for a payments/enterprise context and for contributor patent risk. Also has an explicit `NOTICE`/attribution mechanism. MIT is simpler but silent on patents.
- **vs a copyleft license (GPL/AGPL):** would impose reciprocal obligations on adopters (and, for AGPL, on network use) — hostile to enterprise adoption and to the core/enterprise split. Rejected.
- **vs source-available (BSL/SSPL):** not OSI open-source; contradicts the "open, adoptable by everyone" goal. Rejected.
- **vs dual-license/open-core license gymnastics:** unnecessary — the open-core split is achieved by *repository boundary* (OSS core vs private enterprise plugins), not by a restrictive license.

## Consequences
- **Apache-2.0 is irreversible** for released code (cannot be clawed back). A hyperscaler could host a rival; a hostile fork is possible. These are accepted trade-offs of true open-source; mitigations (trademark on "AiNxt", governance, sustainability model) are tracked in ADR-019/gap BA/gap 31 — a license is not a moat.
- The **copyright holder legal entity must be set by legal** before public release (NOTICE currently uses the placeholder "The AiNxt Authors").
- Every dependency and its license is tracked and CI-gated (ADR-028); every model weight is registered (ADR-018).
- Trademark ≠ copyright: register the "AiNxt" mark separately if brand protection is wanted (Apache-2.0 grants no trademark rights).

## Open items for legal (must close before public release)
- Confirm copyright-holder entity; confirm Apache-2.0 vs any NPCI-mandated license; confirm DCO vs CLA; confirm trademark strategy; confirm that model-weight field-of-use/pass-through (ADR-018) does not force any obligation onto the OSS code.
