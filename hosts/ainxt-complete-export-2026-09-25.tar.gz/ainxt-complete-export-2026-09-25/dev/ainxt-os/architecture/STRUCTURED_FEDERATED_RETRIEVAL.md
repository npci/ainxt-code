# Structured + Federated Retrieval — design to 10/10

**Status:** Design (no code). Closes Pass-5 gaps **4** (structured/relational retrieval — NL-to-SQL + semantic metrics + row-level security), **15** (federated privacy-preserving cross-member-bank retrieval), **24** (global/sensemaking query mode), **25** (multimodal evidence retrieval) — cluster D, "NPCI's mission-differentiating data surfaces." Also closes gap **BH** (never trust model arithmetic) as it applies specifically to structured retrieval, where a confidently-wrong sum is a payment incident, not a bad answer.
**Relates to / extends:** `CONTEXT_FABRIC.md` (this doc adds four new graph layers — §1 below — to the fabric; the Context Optimizer, security filter, and lineage-record discipline are reused, not reinvented), `TOOLING_MCP_PLUGINS_ROUTING.md` §4 (data-class → model-eligibility matrix, made concrete here for structured/multimodal data classes; the Federated Query Broker is a governed capability in the same `CapabilityRegistry`, §1.6 OBO + idempotency apply to it unchanged), `ENTERPRISE_MEMORY_LEARNING.md` §2 (OKIs/postmortems are the corpus Global mode summarizes), ADR-007 (Event Log — every structured/federated query's lineage, epsilon spend, and control-plane commit SHA are written there), ADR-015 (DPDP retention/erasure — multimodal artifact embeddings are PII and must cascade-erase), ADR-016 (agent-payment boundary — the Federated Broker and the NL-to-SQL compiler are read-only surfaces; neither may ever resolve to a capability with `effect_class: SideEffecting` against a settlement system), **ADR-026 (Control Plane is Git-Native, Q2 decision — the semantic-metrics/dimension catalog and the federated-metric registry are both control-plane *definitions*, not database rows; §2 and §5 below are structured as ADR-026 definition kinds and inherit its all-or-nothing reload, CODEOWNERS review, and content-addressed pinning)**, **ADR-027 (Long-Horizon Program Execution, Q1 decision — onboarding a new member bank into the federation, or a catalog-wide metric migration across hundreds of curated views, is sized and scheduled as a Program, not a single Run — §5.5 below)**.
**Target:** an agent can answer *"how many failed settlements did bank X have last Tuesday"* by compiling to a governed view, never a raw table; can answer a numeric question about ledger data with a **server-verified**, never merely model-stated, number; can surface network-wide fraud signal across member banks **without any bank's raw data ever leaving its own boundary**; can answer *"what are the recurring root causes of settlement failures this quarter"* by reasoning over the corpus, not one document; and can retrieve a cheque image or a KYC document under the same RBAC/data-class discipline as every other artifact — with none of the four surfaces able to bypass compliance, RBAC, or data-class routing, because none of them are a second retrieval system: they are four new Context Fabric layers behind the same Context Optimizer and security filter.

---

## 0. The shape of the problem

The Context Fabric (layers 1–12) is a **document/code/memory** fabric — it answers "what does this say" and "what did we decide." NPCI's mission-critical asks are a different shape entirely, and treating them as "RAG but on a bigger corpus" fails four separate ways:

| Ask | Wrong tool if forced through prose-RAG | Right shape |
|---|---|---|
| "How many failed settlements did bank X have last Tuesday?" | An LLM free-texting SQL against `settlement_txn` — SQL injection surface, no RBAC, wrong joins, silently wrong aggregates | **Curated NL-to-SQL** against a governed metric catalog (§1–§2) |
| "What's NPCI's network-wide mule-account velocity this month?" | No single party holds this; a naive "federate the RAG index" leaks bank A's transactions to bank B | **Privacy-preserving federated broker** (§5) |
| "What are the recurring root causes behind settlement failures this quarter?" | Top-k chunk retrieval returns 6 postmortems out of 400; the model sees a biased sample and calls it a theme | **Global/sensemaking (GraphRAG map-reduce)** (§6) |
| "Find the cheque matching this MICR pattern" / "pull the KYC doc for this applicant" | Not text at all; embedding it into the text namespace mixes modalities and RBAC | **Multimodal artifact tier** (§7) |

All four are designed as **Context Fabric layers 13–16**, reusing its optimizer/security-filter/lineage machinery (§8), not as parallel bespoke subsystems.

---

## 1. New Context Fabric layers

```
Fabric layers (extends CONTEXT_FABRIC.md §2, 1–12 unchanged):
13. Structured/relational layer  — curated metric+dimension catalog over governed views (§2–§4)
14. Federated signal layer       — cross-tenant DP/k-anon aggregate signals only, never raw rows (§5)
15. Global/community-summary layer — GraphRAG community summaries over OKIs/postmortems (§6)
16. Multimodal artifact layer    — cheque/KYC image + call-recording audio embeddings, own RBAC (§7)
```

Each is queried through the same structured query interface (§5 of `CONTEXT_FABRIC.md`), extended here with:
`metric(id, dims, grain, filters)` · `federatedSignal(metric_id, filters)` · `communitySummariesFor(theme, scope)` · `artifactsMatching(query, artifact_type)` — each returns graph/table slices the Context Optimizer folds into the window under the *same* RBAC/data-class pre-rank filter as every other layer. **No layer here is reachable by any path that skips the security filter.**

---

## 2. The semantic metrics & dimension catalog (never raw free-form SQL)

### 2.1 The catalog is a control-plane definition kind (ADR-026)

The catalog is **not** a database table of metric metadata and it is **not** a prompt instruction telling the model "only query these tables." It is a versioned tree of definition files in the git-native control plane, one file per metric family:

```
control-plane/metrics/settlement/failed_settlement_count.metric.yml
control-plane/metrics/dispute/dispute_resolution_sla.metric.yml
control-plane/metrics/reconciliation/recon_break_amount.metric.yml
control-plane/metrics/ledger/account_balance_snapshot.metric.yml
```

Each metric definition's front-matter declares, exhaustively:
```yaml
id: failed_settlement_count
owner: settlement-eng            # CODEOWNERS path — who may approve a change
source_view: v_settlement_failures_curated   # a read-only DB VIEW, never a base table
grain: [bank_id, failure_reason_class, settlement_date]
dimensions:
  - {name: bank_id,      type: string, data_class: internal}
  - {name: failure_reason_class, type: enum,  data_class: internal}
  - {name: settlement_date, type: date, data_class: internal}
aggregation: {fn: COUNT, formula: "count(*)"}
unit: count
data_class_ceiling: confidential        # feeds Model Router §4.2, unchanged mechanism
rls_predicate_ref: rls_settlement_by_dept   # named Postgres RLS policy, validated to exist (§3)
freshness_sla_seconds: 300
federated: false                        # true only for the whitelisted subset in §5
deprecation: null
```

**The catalog is the entire vocabulary the runtime allows structured retrieval to reference.** A metric or dimension not in the catalog does not exist to the compiler (§4) — this is the concrete, structural form of "never raw free-form SQL," not a system-prompt instruction the model could be talked out of.

### 2.2 Load-time validation (extends ADR-026 §6 all-or-nothing)

At control-plane load/hot-reload, the loader additionally, for every metric definition:
1. **Schema-introspects** `source_view` against the read replica (§3) — the view must exist, and every declared dimension/aggregation column must exist in it with a compatible type. A metric pointing at a dropped or renamed view fails validation.
2. **Verifies `rls_predicate_ref`** resolves to an actual `CREATE POLICY` on that view (§3.2) — a metric with no enforceable row-level security cannot load.
3. **Verifies `source_view`'s own definition** was itself reviewed (a CI check requiring the view's DDL to live in the same reviewed migration set as `db/sql/*` — a metric can never point at an ad hoc, unreviewed view someone stood up to "just get the query working").

Any single metric failing (1)–(3) fails the **entire** catalog reload — the runtime serves the last-good catalog snapshot and pages an operator, identical to ADR-026 §6's "no partially-valid control plane" rule. A half-loaded metrics catalog (some metrics validated, others silently dropped) is exactly the silent-degradation failure mode ADR-026 exists to prevent, generalized to a new definition kind.

### 2.3 Authoring governance

New metric = a pull request against the control-plane repo. **CODEOWNERS = the data-domain owner** (Settlement Eng for settlement metrics, Risk for dispute metrics, Compliance for anything touching PII-adjacent dimensions) — the same git-native authoring RBAC ADR-026 §1 defines for skills/roles, applied to a new subject. A metric that changes `aggregation.formula` for an existing `id` is a **breaking change** requiring a semver bump and a migration note (existing dashboards/answers computed under the old formula are labeled with the commit SHA they ran under — ADR-026 §6's "turns pinned to snapshot," here applied to "answers pinned to catalog version").

---

## 3. Row-level security at query time, on read replicas

### 3.1 Read replicas only

Every structured/NL-to-SQL query executes against a **dedicated read-replica pool**, never the OLTP primary. This is a hard routing rule enforced at the connection-pool layer (the compiler, §4, is only ever handed a replica connection string) — an adhoc analytical query, however well-formed, must never compete with or add latency risk to the live settlement path. Replica lag is monitored per-view; if lag exceeds a metric's `freshness_sla_seconds`, the response carries an explicit `stale_as_of: <replica_ts>` flag rather than silently serving old settlement data as current — the same "never silently serve stale" discipline the platform already applies to embedding freshness (`CONTEXT_FABRIC.md` §4).

### 3.2 RLS enforced by the database, not the application

Row-level security is implemented as **native Postgres `ROW LEVEL SECURITY` policies on the curated views themselves** (`rls_predicate_ref` in §2.1), keyed off session variables the runtime sets — not an application-layer `WHERE dept = ?` clause that a bug or a prompt-injected query could omit:

```sql
-- one-time, per curated view (part of the reviewed DDL, §2.2.3)
ALTER VIEW v_settlement_failures_curated ENABLE ROW LEVEL SECURITY;
CREATE POLICY rls_settlement_by_dept ON v_settlement_failures_curated
  USING (bank_id = current_setting('app.scoped_bank_id', true)
         OR current_setting('app.ad_level', true)::int <= 1);  -- exec override, still logged
```

Before executing any compiled query (§4), the runtime opens the replica session and issues `SET LOCAL app.scoped_bank_id = <from OBO context>`, `SET LOCAL app.department = ...`, `SET LOCAL app.data_class_ceiling = ...` **inside the same transaction** as the query — sourced from the turn's OBO context (`TOOLING_MCP_PLUGINS_ROUTING.md` §1.6), never from a value the model supplied. The database engine — not the agent, not the compiler, not a filter the LLM could talk its way around — is what refuses a row outside the caller's scope. This is the same "enforced by the runtime, not developer discipline" pattern the idempotency ledger applies to side effects, applied here to read-scoping.

### 3.3 Break-glass is logged, not silent

An `ad_level`-based override (a senior exec or auditor querying cross-bank inside NPCI's own data) is a first-class, **audited** RLS branch — every override-path row-read is written to the Event Log with the OBO context and business justification field required at request time, the same break-glass discipline `ENTERPRISE_MEMORY_LEARNING.md` §5 applies to viewing another user's PII-classed memory.

---

## 4. The NL-to-SQL compiler pipeline (structural, not prompted, "never raw SQL")

Two stages, with a **hard architectural boundary between them**: the LLM never sees or emits SQL text at all.

```
NL question
   │
   ▼
Stage A — Query Intent extraction (LLM, schema-constrained)
   tool-call schema is GENERATED FROM the metrics catalog (§2) — same
   schema-from-struct discipline as TOOLING §1.1: the JSON schema's enum
   for "metric" and "dimension" literally contains only catalog IDs.
   The model CANNOT reference a metric/dimension outside the catalog —
   not "shouldn't," structurally cannot, because it is not in the enum.
   Output: QueryIntent { metric_id, dimension_filters[], grain, time_range,
                          comparison?, requested_format }
   │
   ▼
Stage B — Query Intent → SQL (deterministic compiler function, NOT the LLM)
   A template/query-builder maps QueryIntent to a parameterized statement
   against the metric's declared source_view. Every value is a bound
   parameter; nothing is string-interpolated. If dimension_filters
   references a dimension not in that metric's declared dimensions[],
   the compiler REJECTS before touching the database — a structural
   400, never a passed-through SQL error that could leak schema shape.
   │
   ▼
Execute on read replica, under RLS (§3), with SET LOCAL from OBO context
   │
   ▼
Typed table result {columns, rows, dtypes} — never a bare string of numbers
```

**Why this is the concrete fix, not a rephrasing of the gap:** the failure mode "never raw free-form SQL" is usually closed with a prompt instruction ("only query approved tables") — which a sufficiently adversarial or confused turn can still violate, because the model is the thing emitting SQL. Here the model **never emits SQL**. Its only output is a constrained-vocabulary JSON object; a separate, non-generative, fully deterministic compiler is the only thing that ever produces a SQL string, and that compiler's target surface is the catalog's `source_view`s exclusively. There is no code path from "model output" to "arbitrary table access" — the compiler has no branch that accepts a table name it wasn't handed by catalog lookup.

**Ambiguity → clarify, never guess:** if Stage A's extraction is low-confidence on which catalog metric matches the ask (e.g., "failed transactions" could map to `failed_settlement_count` or `dispute_resolution_sla`'s underlying count), the runtime asks a calibrated clarifying question (ties to gap BQ) rather than silently picking one and returning a plausible-looking wrong answer.

---

## 5. Answer re-derivation & verification (never trust model arithmetic, applied to structured retrieval)

Gap **BH** states the general principle: offload calculation to deterministic tools, the model orchestrates, never computes. Structured retrieval is where this is **enforced as a hard gate**, not a best practice, because the artifacts here are ledger/settlement numbers.

### 5.1 Numeric-claim contract

Any model turn that states a number derived from structured retrieval must emit it through a structured output contract, not free prose alone:
```json
{ "value": 47, "unit": "count", "source": {"kind": "metric", "id": "failed_settlement_count", "query_hash": "…"} }
```
A number with no `source` — one the model appears to have computed itself in free text (a sum across rows, a percentage, a rate) — is a **compliance-adjacent output-lint failure**, exactly analogous to a citation-less factual claim, and is blocked before it reaches the user (same "audit input/output, never bypass" discipline as the compliance engine).

### 5.2 Server-side re-derivation (the verification, not just the ban)

For any answer citing a `metric`-sourced value, the runtime **independently re-executes** the same `query_hash`'s compiled query (§4 Stage B) server-side — a fresh, deterministic recomputation, not a re-ask of the model — and diffs the result against the value the model's structured output claims. For any derived arithmetic beyond a single catalog metric (a ratio of two metrics, a delta across two time windows), the model must route the computation through a **deterministic compute tool** (`code.exec` in the sandbox, or an in-process decimal-safe evaluator capability) whose result is itself tagged `source: {"kind": "tool", "call_id": …}` and is *also* independently re-run server-side against the tool's recorded inputs.

```
Model emits answer with numeric claims (each tagged: metric | tool)
   │
   ▼
Runtime re-executes: each metric claim → re-run compiled SQL against query_hash
                      each tool claim   → re-run the deterministic tool against
                                          the recorded inputs
   │
   ▼
Diff claimed value vs re-derived value (epsilon = 0 for counts/exact aggregates;
a configured rounding tolerance for currency/rate fields)
   │
   ├─ match      → answer ships, re-derivation hash attached to the lineage record
   └─ mismatch   → answer is BLOCKED; regenerate with an explicit "recompute
                    mismatch" note injected into context — never shipped silently
```

A mismatch is written to the Event Log as a first-class incident-adjacent signal (not just a retry) — a model that "confidently" states a wrong sum on ledger data is exactly the failure mode gap BH names as a payment incident, and a recurring mismatch pattern is fed to the eval platform as a regression, the same "quality drift is tracked, not shrugged off" discipline `TOOLING_MCP_PLUGINS_ROUTING.md` §2.4 applies to tool-ranking regressions.

### 5.3 What this does not cover (honest scope)

Re-derivation verifies that a *stated number matches what the deterministic path actually computed*. It does not verify that the deterministic path's own logic (the metric's `aggregation.formula`) is business-correct — that is a data-domain-owner review responsibility at catalog-authoring time (§2.3), not something re-derivation can catch, because re-derivation would faithfully reproduce a wrong formula's wrong answer. The two are complementary, not substitutes.

---

## 6. Federated privacy-preserving cross-member-bank tier

### 6.1 Tenant isolation is physical, not a filter

Every member bank is a fully isolated tenant: its own Postgres schema/database, its own pgvector namespace, its own Knowledge Graph partition. **There is no code path by which one bank's raw rows, embeddings, or KG nodes are queryable from another bank's context, or directly by NPCI.** This is the same department-scoping boundary the platform already enforces (`CONTEXT_FABRIC.md` §3 security filter, RBAC/data-class labels), generalized from "department" to "bank tenant," and it holds even for NPCI operators — NPCI has no ambient cross-tenant read credential to fall back on (the same "no substituting a broader ambient credential" rule `TOOLING_MCP_PLUGINS_ROUTING.md` §1.6 enforces for confused-deputy prevention).

### 6.2 The only cross-tenant surface: the Federated Query Broker

The Broker is a governed **capability** in the one `CapabilityRegistry` (`TOOLING_MCP_PLUGINS_ROUTING.md` §0) — `effect_class: Pure` (read-only, never side-effecting; ADR-016's payment-boundary discipline means this capability structurally cannot resolve to a settlement action), `risk_tier: Elevated`. It accepts only **pre-approved federated metrics** — a subset of the §2 catalog flagged `federated: true` and additionally reviewed by NPCI Risk + a representative member-bank governance forum before merge (the catalog PR's CODEOWNERS for a federated metric includes both). This extends "never raw free-form SQL" to the federation: **the federated query itself is closed-vocabulary and git-reviewed**, never an open cross-bank query surface.

```
Federated query execution:
1. Requester (NPCI risk analyst) calls federatedSignal(metric_id, filters)
   — metric_id MUST be federated:true, or the call is rejected at the
   capability boundary before any bank is contacted.
2. Broker dispatches the SAME compiled query template (§4 Stage B) to
   every participating bank's isolated instance. Each executes LOCALLY,
   under its OWN RLS (§3), on its OWN replica. Raw rows never leave the
   bank's boundary — only the bank's own instance ever sees them.
3. Each bank instance computes its local partial aggregate and adds
   calibrated DP noise (Gaussian/Laplace mechanism, ε drawn from a
   per-metric, per-time-window PRIVACY BUDGET LEDGER, §6.3) BEFORE the
   partial result leaves the tenant boundary. The noised partial is the
   only thing transmitted.
4. Broker aggregates the noised partials across participating banks and
   applies a K-ANONYMITY THRESHOLD: any bucket (e.g., a failure-reason-
   class cell) contributed to by fewer than k banks, or underpinned by
   fewer than k underlying transactions bank-side, is suppressed or
   merged into an "other" bucket — never returned as a distinguishable
   small cell.
5. Broker returns ONLY the final aggregate signal. Per-bank breakdowns
   are never included unless every contributing bank has a standing,
   git-reviewed, per-metric-class opt-in on file (§6.4) — default is
   aggregate-only, always.
```

### 6.3 The privacy budget ledger (bounding repeated-query erosion)

A single DP-noised query leaks little; **repeated queries of the same metric/filter combination average out the noise and erode the guarantee.** The Broker tracks a per-metric, per-time-window **epsilon ledger** (append-only, same durability discipline as the Side-Effect Ledger, `TOOLING_MCP_PLUGINS_ROUTING.md` §1.2): each `federatedSignal` call debits ε from the metric's budget for that window; when the budget is exhausted, further queries against that exact metric/window combination are refused (not silently re-noised weaker) until the window rolls over. This is enforced by the Broker itself, not left to "please don't query this too often" guidance — the same "runtime-enforced, not developer-discipline" pattern as §3.2's RLS.

### 6.4 Disclosure is opt-in, auditable, never default

A bank's explicit, standing consent to per-bank (non-aggregate) disclosure for a specific federated-metric class is itself a git-reviewed control-plane record (`control-plane/federation/disclosure-consent/{bank_id}.yml`), revocable by that bank's own CODEOWNERS-equivalent at any time, taking effect on the next control-plane reload. Every Broker decision — which banks participated, how much ε was spent, what k-threshold applied, whether disclosure consent existed — is written to the Event Log, so **the privacy mechanism is fully auditable without auditing the private data it protects.**

### 6.5 Onboarding a new bank is a Program, not a Run (ADR-027)

Provisioning a new member bank's isolated tenant (schema, pgvector namespace, KG partition, replica, RLS policies, initial catalog sync, federation opt-in review) at NPCI's member-bank scale is sized and scheduled through the **Long-Horizon Program subsystem** (ADR-027) — a durable, checkpointed, dependency-ordered rollout with staged human approval gates, not a single agent turn that "sets up federation" and hopes it fits in one window. The same applies to a catalog-wide metric migration (e.g., re-deriving `aggregation.formula` for a metric family across every bank's replica) that touches hundreds of curated views: it decomposes into a Module Task Graph of per-bank/per-view migration units, each an ordinary bounded Run, verified per-node and per-program-sweep exactly as ADR-027 §1 specifies for a codebase migration — the mechanism generalizes because the property that matters (durable, resumable, checkpointed, compositionally verified) is the same regardless of whether the "modules" are code files or bank tenants.

---

## 7. Global / sensemaking query mode (GraphRAG map-reduce)

### 7.1 Mode selection is classified, not keyword-matched

The query planner (`CONTEXT_FABRIC.md` §3's "query planning" step) is extended with a **scope classifier** — point-lookup vs global/sensemaking — riding the same complexity-classification substrate (`classifier.py`-style) already used for model-tier routing, given a new dimension rather than a new component. "How many failed settlements did bank X have last Tuesday" classifies point (routes to §4's NL-to-SQL). "What are the recurring root causes behind settlement failures this quarter" classifies global (routes here). A low-confidence classification asks, rather than guessing which mode to run — the same calibrated-clarification discipline as §4.

### 7.2 Community detection over the unified Knowledge Graph

Layer 15 runs as a **background, incremental** job (not per-query): Leiden/Louvain-style community detection over the entity-relationship edges of the unified Knowledge Graph (`CONTEXT_FABRIC.md` §2's layer 1, extended by `ENTERPRISE_MEMORY_LEARNING.md`'s OKI nodes — `IncidentPostmortem`, `CommonFix`, `ApprovedLibrary`, etc.), clustering related postmortems/OKIs into hierarchical communities. Each community gets a **pre-computed summary node** in the KG, carrying the same RBAC/data-class labels as its most-restrictive contributing member — a summary can never be visible more broadly than its most sensitive input allows.

### 7.3 Map-reduce at query time

```
Global query
   │
   ▼
MAP:    retrieve relevant community summaries (not raw chunks) for the
        theme, RBAC/data-class-filtered pre-rank (identical security
        filter to CONTEXT_FABRIC §3 — filtering happens before ranking
        so a restricted community's existence never leaks)
   │
   ▼
REDUCE: synthesize across the retrieved community summaries into one
        answer; each contributing community is cited in the lineage
        record (same lineage discipline as every other Fabric layer)
```

### 7.4 Freshness

Community summaries recompute **incrementally** as new postmortems/OKIs land (event-driven, same discipline as `CONTEXT_FABRIC.md` §4's "graphs update on file change/index/commit/runtime event, not batch") — a live incident's postmortem is reflected in the next Global-mode answer within the same incremental-update latency as any other Fabric layer, not "whatever the last nightly community rebuild caught."

---

## 8. Multimodal artifact retrieval tier

### 8.1 Modality-isolated embedding pipelines

Cheque images, KYC documents (scanned ID/PAN images), and call recordings each get their **own embedding pipeline and own pgvector namespace** — a vision encoder for cheque/KYC images, a speech encoder producing both an audio embedding and an ASR transcript (itself separately indexed) for call recordings. Namespaces are never mixed with text-document namespaces: similarity semantics differ per modality, and so does the RBAC/data-class posture (§8.2) — mixing them would mean one filter has to correctly handle two incompatible meanings of "similar."

### 8.2 Data-class routing applies to the models that touch these artifacts, not only to storage

Cheque images and KYC documents are `PII`/`regulated-payment` by definition. Any model that processes or describes them — a vision model doing OCR/field-extraction, an ASR model transcribing a call — is itself routed through the **same data-class → model-eligibility matrix** (`TOOLING_MCP_PLUGINS_ROUTING.md` §4.2): for this data class, only in-house-OSS-eligible vision/ASR models are candidates, structurally, before ranking. **No cheque image, KYC scan, or call recording is ever sent to a cloud vision/ASR endpoint.** This is not a new rule invented for multimodal data — it is the existing router mechanism given a new data-class input signal.

### 8.3 RBAC filters existence, not just content

A retrieved artifact match (e.g., a cheque whose MICR/signature embedding is nearest-neighbor to a query) is filtered by the requester's department/`ad_level` **before** the match — including its existence — is surfaced, identical to `CONTEXT_FABRIC.md` §3's "filtering happens before ranking so existence never leaks." A fraud analyst outside the relevant department gets zero results, not a redacted result that confirms something exists.

### 8.4 Structured query surface

`artifactsMatching(query, artifact_type)` joins the Fabric's structured query interface (`CONTEXT_FABRIC.md` §5) alongside `whoCalls`/`refsOf`/etc.: `artifactsMatching("MICR 123456", "cheque_image")`, `artifactsMatching("applicant Jane Doe DOB 1990-04", "kyc_doc")`, `artifactsMatching("mentions chargeback dispute", "call_recording")` (the last resolving against the ASR-transcript text index, itself PII-classed and RBAC-filtered independently of the audio embedding).

### 8.5 Erasure cascades to embeddings, not just source documents

Per ADR-015, a DPDP erasure request against a KYC document or call recording must cascade to **every derived artifact**, explicitly including its embedding row(s) in the artifact-specific pgvector namespace and its ASR transcript — an embedding of PII is itself PII, and "we deleted the source file but the vector index still nearest-neighbor-matches it" is not compliant erasure. This is an explicit extension of ADR-015's erasure cascade, called out here because the artifact tier introduces a derived-data class the original ADR's examples didn't enumerate.

---

## 9. Integration summary — how this stays one system, not four

- **Security filter is one filter.** All four new layers pass through the *same* Context Fabric §3 pre-rank RBAC/data-class filter — there is no second, bespoke ACL implementation for structured, federated, global, or multimodal data.
- **Model routing is one router.** §5's numeric-claim compute tools, §6's Broker (in-house-eligible only when handling any bank's raw pre-aggregation data path), and §8's vision/ASR models all resolve through the *same* data-class → model-eligibility matrix (`TOOLING_MCP_PLUGINS_ROUTING.md` §4.2) — no parallel routing table.
- **Governance is one control plane.** The metrics catalog (§2), the federated-metric whitelist and disclosure-consent records (§6.2, §6.4), and the community-detection job configuration (§7.2) are all ADR-026 control-plane definition kinds — reviewed by CODEOWNERS, all-or-nothing validated, content-addressed, hot-reloaded. There is no fifth place metric definitions could live.
- **Audit is one Event Log.** Query lineage, re-derivation hashes (§5.2), Broker epsilon spend (§6.3), and community-summary provenance (§7.3) are all written to the same Event Log ADR-007 already defines, tagged with the control-plane commit SHA active at query time — a query from eighteen months ago is reproducible against the exact catalog/federation-config version it ran under.
- **Scale is one Program subsystem.** Bank onboarding and cross-catalog migrations (§6.5) run on the same Long-Horizon Program Supervisor (ADR-027) the codebase-migration use case defined — no bespoke "federation rollout orchestrator."

---

## 10. Acceptance / scenario tests

| # | Scenario | Setup | Expected | What it proves |
|---|---|---|---|---|
| 1 | Metric not in catalog | User asks about a metric with no catalog entry | Stage A's constrained schema has no matching enum value; runtime asks a clarifying question or reports "no governed metric for this," never guesses a table to query | Catalog is the entire vocabulary (§2.1, §4) |
| 2 | Dangling `source_view` | A metric definition's `source_view` is renamed/dropped in the DB without a corresponding catalog PR | Load-time schema introspection fails; the **entire** catalog reload is rejected, runtime serves last-good snapshot | All-or-nothing catalog validation (§2.2), ADR-026 discipline generalized |
| 3 | Dimension not declared on that metric | Query Intent requests a filter dimension valid for a different metric but not this one | Compiler Stage B rejects before touching the database — structural 400, no passed-through SQL error | Compiler-level structural rejection (§4) |
| 4 | RLS boundary | User scoped to `bank_id = B1` requests the same metric filtered to `bank_id = B2` | Zero rows returned (RLS-filtered at the DB engine), not an application-layer 403 that could be bypassed by a different code path | DB-enforced RLS, not app-layer (§3.2) |
| 5 | Break-glass audit | An `ad_level<=1` exec queries cross-bank data via the override branch | Query succeeds; a break-glass Event Log entry with justification is written | Override is audited, never silent (§3.3) |
| 6 | Stale replica | Replica lag exceeds a metric's `freshness_sla_seconds` | Response includes `stale_as_of` flag; never presented as current without it | No silent stale-serving (§3.1) |
| 7 | Numeric claim with no source | Model states a percentage in prose with no `source` tag | Output-lint blocks the answer before it ships | Numeric-claim contract enforcement (§5.1) |
| 8 | Re-derivation mismatch | A model states a metric value that doesn't match server-side re-execution of the same `query_hash` | Answer blocked, regenerated with an explicit mismatch note; incident-adjacent signal logged | Server-side re-derivation catches a wrong stated number (§5.2) |
| 9 | Derived arithmetic without a tool | Model computes a ratio of two metrics inline in prose instead of calling the compute tool | Output-lint flags the untagged number; answer blocked pending a tool-routed recomputation | "Model orchestrates, never computes" enforced structurally (§5.1–5.2) |
| 10 | Federated metric not whitelisted | `federatedSignal` called with a `metric_id` where `federated: false` | Call rejected at the capability boundary; no bank is contacted | Closed-vocabulary federation (§6.2) |
| 11 | Raw cross-bank access attempt | An NPCI operator's credential is used to attempt a direct read of Bank A's tenant schema | Denied — no ambient cross-tenant credential exists, same confused-deputy prevention as OBO | Physical tenant isolation, no fallback path (§6.1) |
| 12 | k-anonymity suppression | A federated query's bucket is contributed to by only 2 banks, below `k=5` | That bucket is suppressed/merged into "other," never returned distinguishably | K-anonymity threshold enforced (§6.2 step 4) |
| 13 | Privacy budget exhaustion | The same federated metric/window is queried repeatedly until ε budget is spent | Further queries against that exact metric/window are refused, not weaker-noised | Epsilon ledger prevents averaging-out attacks (§6.3) |
| 14 | Disclosure without consent | A requester asks for a per-bank breakdown of a federated metric with no standing consent record | Only the aggregate is returned; per-bank rows are withheld regardless of requester's seniority | Default aggregate-only, opt-in only exception (§6.4) |
| 15 | Federated audit trail | Any `federatedSignal` call, successful or refused | Event Log records participating banks, ε spent, k-threshold, consent state | Full auditability of the privacy mechanism (§6.4) |
| 16 | Global mode over a biased sample | "What are recurring root causes this quarter" asked when only 6 of 400 postmortems would surface via plain top-k | Community-summary map-reduce synthesizes across all relevant communities, not a 6-chunk sample; lineage cites contributing communities | Global mode ≠ point-lookup with a bigger k (§7) |
| 17 | Restricted postmortem in a community | A community's contributing postmortems include one from a restricted department | The community summary node inherits the most-restrictive label; a requester outside that department never sees the summary, or sees one recomputed excluding that input | RBAC on summaries, not just source docs (§7.2) |
| 18 | Live-incident freshness | A new postmortem lands mid-day | The next Global-mode query on that theme reflects it within the same incremental-update window as any other Fabric layer, not next-day | Incremental, not batch, community recompute (§7.4) |
| 19 | Multimodal model eligibility | A KYC document image needs OCR/field extraction | Only in-house-OSS-eligible vision models are candidates; verify at the network layer no request to a cloud vision API occurs | Data-class routing applies to models touching artifacts (§8.2) |
| 20 | Artifact RBAC pre-rank | A cheque-image query's nearest match belongs to a department the requester can't access | Zero results returned; requester gets no signal the artifact exists | Existence never leaks (§8.3) |
| 21 | Artifact erasure cascade | A DPDP erasure request targets a KYC document that has a derived embedding and (for a call recording) an ASR transcript | Source doc, embedding row, and transcript are all erased in the same cascade | Embeddings-of-PII are PII (§8.5), extends ADR-015 |
| 22 | Cross-layer classification consistency | The same regulated-payment data appears as a structured metric filter value, a federated signal input, and inside a multimodal artifact | Data-class ceiling and RBAC decision agree across all three layers — same classifier, same labels | One security filter, one router, not four bespoke ones (§9) |

---

## 11. Why this is now a 10

Every Pass-5 gap in this cluster gets a **mechanism**, not a restated principle. Gap 4 (structured/relational retrieval) is closed by a catalog that is a **git-reviewed, all-or-nothing-validated control-plane definition** — not a database row a runtime override could drift from — feeding a compiler where **the model never emits SQL**, only a closed-vocabulary intent object whose schema is generated from the catalog itself, so "never raw free-form SQL" is a structural property of the pipeline, not an instruction. Row-level security is enforced by **the database engine via session variables sourced from OBO context**, on **read replicas** with an honest staleness flag — not an application filter a bug could skip. Gap BH (never trust model arithmetic) gets its sharpest form here: a **numeric-claim output contract** plus **server-side re-derivation that diffs the model's stated number against an independent recomputation** turns "the model promises it computed correctly" into "the runtime verified it did," and a mismatch blocks the answer rather than shipping a confidently-wrong sum on ledger data. Gap 15 (federation) is closed by **physical tenant isolation with no cross-tenant credential path at all**, a **closed-vocabulary federated-metric whitelist**, **local-before-transmit DP noise with a budget ledger that prevents averaging-out**, and a **k-anonymity floor** — banks get network-level fraud signal through a broker that structurally cannot leak a raw row, and every decision the broker makes is itself audited. Gap 24 (global mode) is closed by **GraphRAG community detection + incrementally-maintained summaries + map-reduce synthesis**, riding the *same* RBAC/data-class labels as point-lookup, so a thematic answer over 400 postmortems is as governed as a single-document citation. Gap 25 (multimodal) is closed by **modality-isolated embedding namespaces**, **data-class routing extended to the vision/ASR models that touch the artifacts** (not just to where the bytes are stored), **existence-never-leaks RBAC**, and an **explicit erasure cascade to derived embeddings**. And none of the four is a parallel subsystem: all four are Context Fabric layers 13–16 behind the one Context Optimizer, one security filter, one Model Router, one control plane (ADR-026), and one Event Log (ADR-007) — plus, for federation onboarding and catalog-wide migrations at NPCI's scale, the one Long-Horizon Program Supervisor (ADR-027). Twenty-two scenario tests exercise exactly the properties a payment regulator and a member-bank governance forum would both ask for: a query cannot reach an ungoverned table, a stated number is independently checked before it ships, and no bank's data is ever visible to another bank or to NPCI beyond a noised, thresholded, audited aggregate.

**Residual risks (honest, not deferred silently):**
- **The re-derivation gate (§5.2) is only as good as the deterministic compute tool's own correctness** — if the tool itself has a bug, re-derivation will faithfully confirm the wrong number as "verified." This closes "model states an unverified number," not "the deterministic path has a latent bug"; the latter needs the same tool-testing rigor as any other capability (`CODE_REVIEW_PIPELINE.md`), not a false sense of safety from having a verification step at all.
- **Differential-privacy parameter choice (ε, k) is a genuine judgment call**, not something this design derives automatically — too loose leaks signal, too strict makes the federation useless for its stated purpose (systemic-risk detection). This needs Risk + member-bank governance sign-off per metric class, documented in the catalog PR, and revisited as attack literature evolves; the ledger (§6.3) bounds erosion *given* a chosen ε, it does not choose the right ε.
- **Community detection quality (§7.2) degrades like any clustering algorithm** on a sparse or skewed postmortem corpus — a quarter with few incidents may produce noisy or overly broad communities; Global mode's answer quality needs its own eval set (same discipline `TOOLING_MCP_PLUGINS_ROUTING.md` §2.4 demands for tool-ranking), not an assumption that map-reduce over any corpus is automatically insightful.
- **Multimodal vision/ASR model quality on the in-house-eligible fleet is unproven** — the data-class constraint (§8.2) is a hard, correct requirement, but if in-house OCR/ASR quality lags cloud alternatives materially, this is a real product-quality tradeoff being made for compliance reasons, not a free win; it needs its own eval track, not an assumption that "OSS-only" costs nothing.
- **The catalog's authoring bottleneck is human review capacity**, not the mechanism — every new metric or federated-metric whitelist entry requires a domain-owner CODEOWNERS review; at NPCI's scale, this could become the limiting factor on how fast new mission-data-surface questions get answered, trading a real correctness/governance win for authoring latency.
