# AiNxt OS & the Skill/Role Factory — the Digital Workforce Layer

**Status:** Vision + design brainstorm (no code). Sits above the runtime; the top of the extensibility stack (P5+). Note: a prior "AiNxt OS" discussion is NOT in current memory — this reconstructs the concept from the runtime architecture; **confirm/correct**.

---

## 1. The creation ladder — skill → agent → role → digital team

The runtime already gives us the units. The Factory productizes *composing* them, so **anyone (not just engineers) can build up the ladder**, declaratively and governed:

| Unit | What it is | Who builds it |
|---|---|---|
| **Skill** | one reusable capability — *behavioral* (SOP/domain instructions) or *execution* (sandboxed `run()`) | anyone (declarative) |
| **Agent** | persona + skills + capabilities + model policy | anyone (declarative) |
| **Role** | a *digital worker*: agent(s) + workflows + connectors + knowledge + governance + KPIs — does an entire job function | manager/owner (declarative), governed |
| **Digital team** | multiple roles collaborating = a digital department | org-level, governed |

The "replace an entire person" idea = the **Role** rung: a role is not one skill, it's a *composition* that maps to a job.

---

## 2. How a Role ("digital worker") is composed

A Role Studio walks an owner through 8 elements (most auto-assembled from a job charter):

1. **Charter** — the job description → structured spec (responsibilities, inputs, outputs, escalation rules).
2. **Capabilities** — least-privilege tools/connectors/data-classes the role may touch (Policy Engine grants).
3. **Skills** — behavioral SOPs + execution skills for the domain tasks (compose existing or author new).
4. **Autonomy & oversight model** — fully-auto / assisted / supervised; HITL gates; **escalation thresholds** (from uncertainty/abstention, gap U).
5. **Knowledge** — the role's RAG namespace / KB / ongoing memory.
6. **Governance** — RBAC + on-behalf-of authority, **model-risk classification (P)**, data-residency (N), audit (AK), data-lifecycle (Q).
7. **KPIs & evals** — role-specific quality + outcome metrics (how you *know* it's doing the job well — quality evals BF/BT applied per role).
8. **Validation before deploy** — the adversarial **Test Agent ("Breaker")** stress-tests it; **shadow-run alongside a human** before cutover; instant rollback.

Output: a deployable, governed, measured digital worker.

---

## 3. Roles mapped to what we've already designed

- **Developer** → Code profile + SDLC judge-loop + edit engine + git/CI connectors. (Largely designed.)
- **Tester** → *this is the Breaker* — already specced (`AGENT_TESTER.md`).
- **Ops/SRE** → runbooks (behavioral skills) + monitoring/alert connectors + remediation tools (**must be idempotent — gap R**) + escalation.
- **Risk analyst** → data connectors + models + report generation, **heavily human-overseen + model-risk-governed** (regulated).
- **HR** → HRIS/email/policy connectors + doc-gen; **PII-heavy → data-lifecycle/consent critical (Q)**.

Each role is a Surface Profile + capability grant + skills + governance — the same runtime primitives, composed differently.

**Control vs data plane, applied to §1's ladder (ADR-026):** each rung — skill, agent, role, digital team — is a **git-native definition**: a versioned file in the control repo, authored via PR, CODEOWNERS-gated, promoted by a signed tag (ADR-026 §7). What a rung *does at runtime* — its KPIs, run/invocation history, escalation logs, memory — is **operational state** and lives in the data plane (Postgres/Redis/pgvector/Event Log), never git. A Role's `definition.md` is control-plane; the same Role's "how did it perform last quarter" dashboard is data-plane (ADR-026 §3). Neither substitutes for the other, and §6–§7 below (citizen-artifact lifecycle, oversight health) are designed on exactly that split: the lifecycle *signals* are computed from data-plane telemetry, but every *action* they trigger (recertify, reassign owner, deprecate) is still a reviewed git change.

---

## 4. AiNxt OS — the framing (reconstructed)

"OS" = the runtime becomes the **operating system for an organization's work**: digital workers run on it, alongside humans, governed and scheduled like processes on a kernel.

| OS concept | AiNxt |
|---|---|
| Kernel | the **Runtime** (execution, scheduling, permissions, resources) |
| Control plane / config store | **git-native definition repo** — skills/agents/roles/teams/workflows/policies as versioned, reviewed files; **CODEOWNERS = authoring RBAC** (ADR-026) |
| Processes / apps | **skills / agents / roles** running on the runtime |
| Drivers | **Connectors** (to the org's systems: GitLab/Jira/Graph/DB/…) |
| System calls | the **Tool + MCP Runtime** (governed capability invocation) |
| Security model | **Identity + RBAC/ABAC + Policy + Compliance + on-behalf-of authz** |
| Scheduler / IPC | **Scheduler + Event Bus** (async work, agent-to-agent) |
| App store | a **federation of pinned git repos** (ADR-026 §11) — TOFU hash-pin, publish/install *is* a PR, diff-and-re-approve on update |
| User space | the **hybrid workforce** — digital workers + humans collaborating |
| Audit/telemetry | tamper-evident audit + LLM observability |

So AiNxt OS = **the governed operating system on which an org runs a hybrid human+digital workforce**, built from the Factory, executed by the runtime, wired to systems via connectors.

**Every row above splits along the same control/data-plane axis (ADR-026 §3).** "Control plane / config store" and "App store" are **definitions** — git-native, PII-free, immutable-per-version, reviewed by CODEOWNERS, never a DB row. Everything the OS *does* with those definitions at run time — scheduler state, connector tokens, event-bus messages, audit/telemetry, and every digital worker's KPIs/memory — is **operational state** in the data plane (Postgres/Redis/pgvector/Event Log), erasable per DPDP where required (ADR-015). The OS "boots" by loading signed definitions from git (ADR-026 §6) and then runs them against data-plane state — the same relationship a conventional OS has between its config files and its runtime process state.

---

## 5. The responsible reality (non-negotiable, especially at NPCI)

"Replace an entire person" is architecturally supportable — but in a regulated payment org it must be framed honestly, or it fails legally and operationally:

- **Digital worker + human accountability.** A digital worker cannot be *legally accountable*. A human must own its decisions (RBI model governance, liability, audit). "Replace a role" in practice = *a digital worker does the work; a named human is accountable and oversees it.* This is regulatory reality, not timidity.
- **Augmentation → task automation → role automation, in that order.** Most roles decompose into tasks: some fully automatable, some needing human judgment. Automate task-by-task, measure, expand — don't flip a whole regulated role to autonomous on day one.
- **High-judgment/regulated roles stay supervised.** An autonomous Risk or Ops role in a payment system without human-in-the-loop is a regulatory non-starter (human-oversight requirement, model risk, abstention).
- **Role automation makes EVERY safety gap load-bearing.** A Dev role opening MRs and an Ops role restarting services → **idempotency (R)** and **on-behalf-of authz (AI)** become critical; an autonomous Risk role → **model risk management (P)**; every role → **audit/reproducibility (AK/X)**, **abstention/escalation (U)**, **data residency (N)**. The Factory must *bake in* oversight + governance by construction — you can't ship a role that bypasses them.
- **People/change-management dimension.** Replacing work is an organizational decision with real human impact; the platform *enables* it, leadership *decides* it. The Factory's job is to make it safe, measured, and reversible — not to cheerlead headcount cuts.

---

## 6. Citizen-authored artifact lifecycle (Pass-5 gap 28)

"Anyone can build up the ladder" (§1) is the point — and the risk it opens: a citizen-authored skill/agent/role outlives the author's attention, context, or even employment, and keeps running on stale assumptions, unowned, un-reviewed. ADR-026 §5 already blocks a *new* PR whose `owner` has no CODEOWNERS coverage (its test 16) — but that check only fires when someone touches the file. It cannot see an owner who quietly leaves while the definition sits untouched. Five designed controls close that gap, each with a concrete enforcement mechanism and an acceptance test:

1. **Decay signal.** A nightly `decay-sweep` job computes a per-definition decay score from data-plane signals already collected for other purposes — the KPI/eval trend (§2 step 7, 90-day window), invocation-count trend, and the age of the git definition's last signed commit (control-plane metadata, read-only). Breaching threshold writes a `decay_flag` row to a **data-plane** table and surfaces an amber badge in the Studio + a digest to the owner — it never mutates the git definition itself, keeping git sole-authoritative for the artifact (ADR-026 §3).
   *Acceptance test:* seed a role whose eval trend is below threshold and whose `definition.md` has no commit in >180 days → the next nightly sweep flags it amber and the owner receives exactly one digest notification (not a storm).
2. **Re-certification nudge.** A `recert_after` policy (owner-set, front-matter default e.g. 180 days) drives a nudge to the owning CODEOWNERS group once `now − last_signed_commit_date > recert_after`. Recertifying is opening a PR — even a no-op "reviewed and current as of `<date>`" signed commit — which resets the clock; the PR still runs the full ADR-026 §10 compliance gate, so recertification can never become a rubber-stamp bypass of review.
   *Acceptance test:* advance past `recert_after` with no commit → owner gets one nudge; owner merges a recert PR → the clock resets, verified against the merge commit's timestamp in git history.
3. **Orphan-detection sweep (continuous, not just at PR time).** A nightly sweep cross-references every *live, already-merged* definition's `owner` against (a) the current CODEOWNERS file and (b) the AD org-tree's `is_active` status (Auth, CLAUDE.md). A hit writes to a data-plane `orphan_definitions` table, and routes to the deactivated owner's manager (the org-tree parent) for reassignment — the definition itself is flagged, never auto-disabled (disabling a live production role by a background sweep is its own incident).
   *Acceptance test:* deactivate a role's sole owner in the org-tree sync → the next nightly sweep flags the role orphaned and notifies the manager one level up within 24h, with no new git push required to trigger it.
4. **Ownership succession.** Reassigning `owner` is itself a control-plane change: a PR touching only the `owner:` front-matter field, requiring approval from either the outgoing owner's group (if still reachable) or, when the outgoing owner is deactivated, the platform-leads CODEOWNERS group as fallback. CI blocks a succession PR that also silently rewrites the SOP/logic body — an ownership change and a behavior change must be two reviewable diffs, never one, so "who owns it" and "what it does" are never conflated in a single approval.
   *Acceptance test:* a succession PR that changes only `owner` on an orphaned role merges once the fallback group approves; a succession PR that also edits the body is blocked until split into two PRs.
5. **Forced review before deprecation.** A definition with live invocation volume above a floor (data-plane signal) cannot move to `deprecated/` (ADR-026 §7.1) on owner say-so alone — deprecating an actively-used artifact requires a Breaker dry-run (§2 step 8) *and* a signed-off approval from the owning group's manager, logged to the Event Log, so an artifact "200 people still call" cannot be silently killed.
   *Acceptance test:* a deprecation PR against a role with >0 invocations in the trailing 30 days is blocked in CI until a `deprecation-approval` label from the manager is applied; a role with zero recent invocations deprecates on ordinary CODEOWNERS approval alone.

Ownership succession is structural at *authoring* time (ADR-026 §5, test 16); §6.1–§6.5 add the *continuous* half — decay, recertification, the standing orphan sweep, succession-as-a-reviewable-diff, and a forced-review floor on deprecation — that a PR-time-only check cannot see.

---

## 7. Automation complacency & deskilling (Pass-5 gap 43)

The more roles automate, the more a human overseer's judgment atrophies from disuse — maker-checker degrades silently into rubber-stamping, and §5's "a named human is accountable and oversees it" only holds if that human's oversight stays real. Three designed controls, again each with a mechanism and a test:

1. **Measure approve-latency / override-rate → 0.** Every HITL approval gate (§2 step 4; ADR-003) already logs to the Event Log. A nightly job derives two metrics per approver × role: **approve-latency** (time from surfaced-for-review to decision — a floor latency below the artifact's minimum read time is itself a signal) and **override-rate** (fraction of approvals that change/reject rather than rubber-stamp). A rising-volume trend where override-rate → 0 is the complacency signature, not a success metric. Both write to a data-plane `oversight_health` table and surface on a manager-visible dashboard.
   *Acceptance test:* simulate an approver whose median approve-latency drops below the artifact's minimum-read-time threshold and whose override-rate reaches 0 over 50 consecutive approvals → the dashboard flags that approver-role pair amber and the manager is notified.
2. **Verification attention-checks on high-stakes approvals.** For any approval where `payment_boundary != none` (ADR-016) or `data_class_ceiling` is regulated-payment or above, the approval-surfacing service periodically and unpredictably injects a **known-bad decoy** — a synthetic case, generated by the Breaker (§2 step 8, no new component needed), engineered to require rejection. This is the aviation/nuclear attention-probe pattern: it verifies the human is actually reading, not merely present. An approved decoy is a hard-fail incident routed to the manager immediately, never just a dashboard data point; a correctly-rejected decoy is invisible to the approver, so the probe itself stays a genuine test.
   *Acceptance test:* inject a decoy into a high-stakes approval queue → an approver who approves it triggers an immediate incident + a mandatory-retraining flag; an approver who rejects it sees no change in their queue.
3. **Competency maintenance.** An approver whose override-rate has sat at ~0 for N consecutive high-stakes approvals, or who fails an attention-check, gets a `competency_status: expired` flag (data-plane) before their next high-stakes approval is honored. The Policy Engine (ADR-003) checks `competency_status` at approval-dispatch time exactly as it checks `execute_rbac` (ADR-026 §8); an expired/failed status re-routes the approval to a designated secondary approver rather than blocking the workflow outright — a competency gate must never itself become an outage.
   *Acceptance test:* flag an approver `competency_status: expired` → the next high-stakes approval routed to them is automatically re-routed to the secondary approver, with the re-route reason logged to the Event Log.

This is the operational counterpart to §5's accountability principle: a named human being accountable only means something if their judgment stays exercised — §7 makes that measurable and enforced, not aspirational.

---

## 8. Where it lands in the plan
- **Prerequisite (P0–P3):** the governance/safety foundations (authz, idempotency, model-risk, audit, abstention, data-class routing) — a Role Factory is only safe on top of these.
- **P5:** the Factory itself (Skill/Agent/Role Studio), the Marketplace (ADR-026 §11 federation of pinned repos), WASM plugins for custom skills, the data flywheel to improve roles.
- **Cross-cutting:** the Breaker validates every role (and generates the §7 attention-check decoys); role KPIs use the quality-eval engine and feed the §6 decay signal; roles run under the same compliance/RBAC/audit spine; the §6 lifecycle sweeps and §7 oversight-health metrics run continuously in production, not just at build/deploy time.

**One line:** the Factory is how AiNxt goes from *a tool people use* to *an OS on which an organization runs a governed hybrid workforce* — and the safety work we did in passes 1–4, plus the citizen-lifecycle and human-oversight controls in §6–§7, is precisely what makes role-level automation legally and operationally possible, sustainably, not just on day one.
