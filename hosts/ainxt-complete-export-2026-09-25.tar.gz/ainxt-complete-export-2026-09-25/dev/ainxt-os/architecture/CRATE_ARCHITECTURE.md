# AiNxt Runtime — Crate Architecture

**Status:** Design (no code). Companion to `adr/ADR-001-runtime.md` (the "why"); this doc is the "what" — the concrete Rust workspace decomposition that realizes every seam ADR-001 asserts. Consistent with ADR-002 (Tool+MCP), ADR-003 (mandatory gates as traits), ADR-004 (config), ADR-005/`PROTOCOL.md` (protocol), ADR-006 (provider/router), ADR-012 (data-class), ADR-026 (git-native control plane).

Crate prefix: **`ainxt-`** (AiNxt) — our own convention; never a vendor prefix.

## 1. Principles (dependency discipline)
1. **Layers depend downward only.** A crate may depend on lower layers, never upward or sideways within the same layer except via a lower contract crate. Enforced in CI (a dependency-direction lint).
2. **Contracts are pure.** Type/trait crates (L1–L2) contain no I/O and no heavy deps — so every renderer, the SDK, and tests can link them cheaply.
3. **Mandatory gates are traits, taken by the engine as required constructor args** (ADR-003/004): there is *no way to build the engine* without a compliance, authz, and audit implementation. Not a feature flag — a type-system invariant.
4. **Protocol-first (ADR-001):** clients depend only on `ainxt-protocol` + a client crate, never on `ainxt-engine`. In-proc and network are two impls of one client trait.
5. **Public seams for Phase-5 extensibility:** the capability, provider, rail, and connector traits are stable public interfaces so plugins/harnesses slot in without touching the core (runtime.md principle #9).
6. **Version-conflict quarantine:** a dependency whose version collides with another (e.g., an MCP client needing a newer HTTP-stack major) is isolated in its own thin wrapper crate that re-exports only what's needed — the conflict never leaks into the workspace graph.

## 2. Layered workspace

```
L6  binaries / clients   ainxt-runtimed · ainxt-cli · ainxt-sdk (Rust) · (ffi → py/ts SDKs)
L5  transport            ainxt-ipc (in-proc) · ainxt-server (gRPC/REST/SSE over ainxt-protocol)
L4  engine / core        ainxt-engine  (session actor · turn pipeline · agent loop)
L3  subsystem impls      ainxt-router · ainxt-provider-{openai,anthropic,gemini,vllm}
                         ainxt-tools · ainxt-mcp · ainxt-context · ainxt-memory · ainxt-sandbox
                         ainxt-connectors · ainxt-artifact · ainxt-eval · ainxt-guardrails
                         ainxt-compliance-default · ainxt-authz-default · ainxt-controlplane
L2  seams (traits)       ainxt-provider · ainxt-capability · ainxt-compliance · ainxt-authz
                         ainxt-audit · ainxt-rail · ainxt-policy · ainxt-connector
L1  contracts (pure)     ainxt-protocol · ainxt-types · ainxt-eventlog-core · ainxt-schema
L0  utils                ainxt-error · ainxt-telemetry · ainxt-crypto · ainxt-config · ainxt-time
```

## 3. Crate responsibilities (selected)

| Crate | Layer | Responsibility | Key ADR |
|---|---|---|---|
| `ainxt-protocol` | L1 | versioned command/event contract (the typed Event enum, session/turn lifecycle) | 005 / PROTOCOL.md |
| `ainxt-types` | L1 | domain types: DataClass, TrustContext, CapabilityId, RunId, ProgramId… | 012, 009 |
| `ainxt-eventlog-core` | L1 | immutable tree event-log types + projection contract | SUBSYSTEM §Journal |
| `ainxt-compliance` / `ainxt-authz` / `ainxt-audit` | L2 | the **mandatory gate traits** (impls are pluggable, presence is required) | 003, 004 |
| `ainxt-capability` | L2 | the one `Capability` trait + registry contract (native == MCP == plugin) | 002 |
| `ainxt-provider` | L2 | provider trait + the shared normalized Event enum seam | 006 |
| `ainxt-rail` | L2 | guardrail trait (`RailChain`) mounted inside the compliance slot | 008 |
| `ainxt-policy` | L2/L3 | data-class → model-eligibility matrix + policy engine (non-overridable) | 012, 018 |
| `ainxt-router` | L3 | Model Router (consults `ainxt-policy` first, then tier/cost/quality; failover) | 006, 012 |
| `ainxt-provider-vllm` etc. | L3 | one generic OpenAI-schema impl + bespoke per incompatible auth | 006 |
| `ainxt-tools` / `ainxt-mcp` | L3 | tool runtime (Side-Effect Ledger, saga, OBO) + MCP adapter (TOFU, ranking) | 002, 013 |
| `ainxt-context` | L3 | Context Fabric graphs + optimizer (budget-fit resolved vs eligible model set) | CONTEXT_FABRIC |
| `ainxt-controlplane` | L3 | git-native definition loader (skills/agents/roles/prompts/policies) + hot-reload | 026 |
| `ainxt-sandbox` | L3 | microVM/container execution seam | 024 |
| `ainxt-eval` | L3 | eval-as-gate + scenario-matrix runner hooks | 010 |
| `ainxt-engine` | L4 | session actor, turn pipeline, agent loop, cancellation, backpressure | 001, 003 |
| `ainxt-ipc` / `ainxt-server` | L5 | in-proc + network transports of `ainxt-protocol` | 001, 005 |
| `ainxt-runtimed` | L6 | the runtime service (the sidecar the Python gateway calls) | 001, A4 |
| `ainxt-cli` | L6 | headless CLI (thin client over `ainxt-protocol`, links in-proc) | INTERACTION §1 |
| `ainxt-sdk` | L6 | Rust SDK; Python/TS SDKs via FFI/codegen over the protocol | HARNESS_SDK |

## 4. How clients link (protocol-first)
- **`ainxt-runtimed`** (service) links `ainxt-engine` + `ainxt-server` + the chosen gate impls (NPCI's PCI/DSS + AD-RBAC in prod; defaults in OSS core).
- **`ainxt-cli`** links `ainxt-protocol` + `ainxt-ipc` and *embeds* the engine in-proc for air-gapped single-binary use — the same client trait a network client uses.
- **`ainxt-sdk`** (Python/TS) talks the protocol over `ainxt-server`. The **CLI is a thin wrapper over the SDK path** where remote; embeds where local.
- No client links `ainxt-engine` internals directly — only via `ainxt-protocol` + a client trait. This is what makes "every UI is a renderer" true.

## 5. Core/enterprise split (ADR-007/028)
The OSS tree = the `ainxt-*` crates above with **generic default** gate impls (`ainxt-compliance-default`, `ainxt-authz-default`). NPCI-specific impls (PCI/DSS engine, AD-RBAC, IP-bearing connectors) are **separate crates in a private repo** that implement the L2 traits and are injected at `ainxt-runtimed` composition — they never enter the OSS workspace. CI's boundary check (ADR-028) blocks private-plugin paths from landing in the OSS tree.

## 6. Why this is a 10
Every seam ADR-001–013 asserts has a home crate; the mandatory gates are un-removable by construction (required trait args, not flags); clients are protocol-only so the runtime-first thesis holds; the control plane is git-native (`ainxt-controlplane`); the core/enterprise split is a crate boundary, not a fork; and dependency direction + version quarantine are CI-enforceable.

## 7. Residual risks
- Crate boundaries are asserted, not yet proven under real compile/build — some may merge or split once code exists.
- The dependency-direction and boundary lints are specified (ADR-028) but not yet implemented.
- FFI ergonomics for the Python/TS SDKs over the protocol need a spike before the SDK layer is firm.
- Prefix/vocabulary (`ainxt-`) is **locked** as the brand crate prefix (consistent with ADR-001 §"vocabulary lock"); the internal subsystem vocabulary register (Session Actor, Turn, Provider Gateway, …) stays clean-room, no vendor prefixes.
