# Code-Review Pipeline — design to 10/10

**Status:** Design (no code). Closes the gap the other three docs assume but never specified: `SEMANTIC_EDITING.md` says "every edit flows into the Code-Review Pipeline (compile→test→lint→type→SAST→…) before commit" and `CONTEXT_FABRIC.md` says the pipeline "uses architecture/dependency graphs for architecture + regression review" — this doc *is* that pipeline. It also generalizes and formalizes the SDLC judge-loop's "deterministic verify + independent judge" pattern (`SUBSYSTEM_DEEP_DIVES.md` §1) into the **one reusable gate every edit passes through**, whether it comes from the SDLC Role, the Code profile, or any future harness that writes code.

**Target:** an agent may never say "done" about a code change except through a typed pipeline outcome. There is no other path to a completion signal.

---

## 1. The principle — a typed outcome, not a claim

The rubric's mandate — *"the model must never declare done until this succeeds OR clearly explains why it cannot"* — is not implementable as an instruction to be polite about. Prompts get rationalized around under pressure (that is precisely what the Judge exists to catch elsewhere). It is implemented as a **protocol invariant**: the runtime defines

```
PipelineOutcome =
    Complete { confidence: u8, report: StageReport[] }
  | Capped   { blocking_stage: Stage, reason: String, rounds_exhausted: u8, gap_report: StageReport[] }
  | Blocked  { stage: Stage, deterministic_failure: ToolOutput }
```

and the **turn renderer has no code path** that emits a "done" / success affordance for a code-editing turn without a `Complete` value in hand. `Capped` and `Blocked` render as an honest gap report and a human hand-off, never as a soft "done, mostly." This mirrors the SDLC judge-loop's existing `complete | capped` outcome (`SUBSYSTEM_DEEP_DIVES.md` §1) — this doc lifts that pattern out of SDLC and makes it the **one gate every edit passes through**, structural in the spine rather than reimplemented per harness (`AINXT_OS.md` §3's anti-fragmentation move applied to quality, not just execution).

Two invariants drive every design choice below:
1. **Deterministic verify owns pass/fail.** Where a tool can give a binary answer (compiles, tests pass, no critical CVE), the model never adjudicates that answer — it can only react to it. Model judgment is reserved for what tools structurally cannot decide (is this the right design, does this satisfy intent, is this diff *actually* what the ticket asked for).
2. **`Capped` is a first-class, honest outcome**, not a failure of the pipeline design. A pipeline that always finds a way to declare `Complete` is a sycophantic pipeline. The Confidence Score and the Judge exist specifically so `Capped` happens when it should, and is legible when it does.

---

## 2. Trigger & scope — what counts as "an edit"

The pipeline fires on **every** write the Semantic Editing engine commits to the working tree — a single method add, a multi-file rename, a full-file regeneration — not just at the end of an SDLC run. It receives from the edit engine's apply protocol (`SEMANTIC_EDITING.md` §5):
- the resolved multi-file edit set (the diff),
- the **rung used** per file (LSP / AST / structured-patch / text-patch) — lower rungs carry a trust penalty into the Confidence Score (§8),
- the **blast radius**: every symbol/file touched, resolved via the Context Fabric's symbol/call/import graphs (`CONTEXT_FABRIC.md` §2).

The pipeline does not re-plan the edit; it verifies what was already applied and, on failure, feeds a structured observation back to the Coder (§6) for a bounded fix-and-reverify loop.

---

## 3. Risk classification & stage selection (cost control)

Running all twelve stages on a docstring typo is waste that trains users to distrust the gate ("it's always red for nothing") and burns LLM spend the platform cannot recover. The pipeline is **risk-scaled**: a classifier (deterministic first, cheap heuristics — no LLM call needed to decide *whether* to run stages) computes a risk tier before stage 1 ever runs.

**Risk inputs (all deterministic, computed from the Context Fabric):**
- **Semantic diff class** — from the AST diff: comment/doc/formatting-only vs local-logic vs signature/public-API change vs new dependency.
- **Blast radius size** — fan-out in the call/import graph from touched symbols.
- **Critical-path flag** — does the touched module carry an `architecture-graph` tag such as `payments`, `settlement`, `ledger`, `compliance` (declared once per module, read every time — same mechanism as the data-class routing matrix in `GAP_ANALYSIS_VS_AI_PLATFORMS.md` §N/O)?
- **Test-coverage overlap** — fraction of the blast radius covered by the test graph.
- **Edit-engine rung** — text-patch rung is inherently riskier than an LSP-verified rename.
- **Prior findings** — did any earlier round on this edit already trip SAST/architecture findings (a "no longer trivial" escalator that can only move risk *up*, never down, within one pipeline run).

| Tier | Profile | Stages run |
|---|---|---|
| **0 — Trivial** (doc/comment/formatting only, confirmed by AST diff — no executable-semantics change) | typo fix, comment | Compile sanity + Lint only. Everything else is *skipped and logged as skipped*, not silently passed. |
| **1 — Local** (single function/file, no signature/API change, small blast radius, non-critical path) | bugfix in one function | Compile, scoped tests (blast-radius-only via test graph), Lint, Type-check, incremental/fast SAST. Lightweight LLM Review. Confidence Score computed; Judge and Architecture/Regression/Performance stages run only if the score lands below the auto-complete threshold. |
| **2 — Moderate** (multi-file, signature change, or touches a shared/common module) | new field on a shared type | Full Phase A (stages 1–5) + Architecture Review + Regression Detection + full-suite affected tests + LLM Review + Judge. Commit gated on Confidence Score. |
| **3 — High-risk** (critical-path tag, cross-service blast radius, public-API break, or any SAST finding at any severity) | edit touching `settlement/*` | Full 12-stage pipeline, **mandatory** Performance Analysis (not skippable even if the diff looks small), optionally a scoped Breaker differential/invariant run (`AGENT_TESTER.md` §2) against a reference implementation, Judge mandatory, **autonomy forced down to `assisted`** regardless of the harness's configured autonomy dial (`AINXT_OS.md` §4's per-task autonomy, invoked automatically here) — a human approves the commit even if the Confidence Score is 100. |

**Re-classification, not a one-shot decision:** if a self-heal round (§6) touches a file outside the original blast radius, or a fix lands in a critical-path module the original edit didn't touch, the tier is recomputed upward before the next pipeline pass — risk can escalate mid-run but never de-escalate within the same run (a de-escalation would be exactly the kind of self-graded relief the anti-sycophancy design forbids).

**Ordering for fail-fast economy:** within Phase A, stages run cheapest-and-most-likely-to-fail first (compile → lint/type-check → tests → SAST) so an LLM Review or Performance Analysis call — the expensive stages — is never spent on code that doesn't even compile. Stage results are cached by content-hash of the touched file set (same discipline as the embedding cache's SHA256 keying elsewhere in the platform): a fix confined to file X does not force Architecture Review or Performance Analysis to redo work on unrelated files whose hash didn't change.

---

## 4. The stages

Each stage below states: what it checks · deterministic or model-judged · inputs/outputs · what a failure feeds back.

### Stage 0 — Generate Patch
- **What:** the Semantic Editing engine's apply protocol has already produced and written the multi-file edit set (§2). This stage's job in the pipeline is purely to **register** the artifact: diff, rung-per-file, blast radius, pre/post AST snapshots.
- **Deterministic.** No judgment happens here; it is the contract handoff from the edit engine.
- **Output:** `EditSet{files, rung, blast_radius, ast_diff_class}` — the shared input every later stage reads from, so no stage re-derives it independently.

### Stage 1 — Compile / Build
- **Checks:** does the workspace build after the edit, for every affected build target.
- **Deterministic.** The compiler/build tool's exit code is the verdict; no model call.
- **Inputs:** `EditSet`. **Output:** pass, or a structured `CompileFailure{file, line, message}` list.
- **Failure feedback:** the raw compiler output is injected as an observation to the Coder — exact file/line/message, not a paraphrase — and the loop re-enters at stage 0 for a bounded fix. This is the same per-step Critic behavior already designed for SDLC (`SUBSYSTEM_DEEP_DIVES.md` §1.5), now the pipeline's own stage 1 rather than a bespoke SDLC-only check.
- **Language degradation:** interpreted/no-build languages (Python, JS without a bundler) substitute a **syntax + import-resolution check** (parse via tree-sitter + resolve every import against the symbol graph) as the compile-equivalent gate — still deterministic, just a different tool.

### Stage 2 — Run Tests
- **Checks:** the test suite scoped to the blast radius (Tier 0–1) or the full affected suite (Tier 2–3), resolved via the Context Fabric's **test graph** (`CONTEXT_FABRIC.md` §2 layer 10 — tests↔code coverage mapping).
- **Deterministic.** Pass/fail per test is the test runner's verdict.
- **Inputs:** `EditSet` + test graph lookup for "tests covering this blast radius." **Output:** pass/fail list + a **coverage-overlap number** (what fraction of the blast radius has *any* covering test) that Regression Detection (stage 8) and the Confidence Score (stage 10) both consume.
- **Failure feedback:** failing test name + assertion diff + relevant stack frames → Coder. A test that fails **intermittently** across two runs in the same pipeline pass triggers the same flake-handling discipline as the Breaker's oracle verifier (`AGENT_TESTER.md` §7) — re-run once under the same seed before treating it as a real finding, never file (or "fix") a flake as if it were deterministic.
- **Language degradation:** no test framework detected for the touched language → stage is `Skipped(no_test_runner)`, which is a **negative** input to the Confidence Score, not a neutral one (§8) — an untested edit in an untestable-by-tooling language is objectively riskier, and the report says so.

### Stage 3 — Lint
- **Checks:** style/convention rules, dead code, common anti-patterns via the language's standard linter (clippy for Rust, ruff/pylint for Python, ESLint for TS/JS, golangci-lint for Go…).
- **Deterministic** for rule violations. A small subset of lint rules are *advisory* (style preference, not correctness) — those are recorded but never gate the commit; only rules classified `error`-severity by policy are gating.
- **Inputs/Outputs:** `EditSet` → `LintFinding{rule, severity, file, line}` list.
- **Failure feedback:** gating findings → Coder as a fix observation. Advisory findings ride into the final report but don't block.

### Stage 4 — Type-Check
- **Checks:** static type soundness — native for statically-typed languages (Rust, Java, Go, TS-strict); for gradually-typed languages, whatever type-checker is configured (mypy for Python, TS's own checker in non-strict mode).
- **Deterministic** where a type-checker exists.
- **Language degradation:** a dynamically-typed codebase with no type-checker configured (plain JS, untyped Python) cannot produce this stage's verdict at all. It is marked `Skipped(no_typechecker)` — the same honest-skip treatment as stage 2 — and the LLM Review stage (9) is explicitly told to weight type-confusion bugs higher for this file, since deterministic coverage is thinner here (§9's compensating-control rule).

### Stage 5 — Static Analysis (SAST)
- **Checks:** security/quality patterns beyond lint — injection, hard-coded secrets, unsafe deserialization, known-vulnerable dependency versions, PCI-relevant patterns (this is where the platform's existing `sast.scan` capability — `HARNESS_SDK.md` §5 — plugs in, and where NPCI's compliance-adjacent findings, e.g. accidental logging of a PAN pattern in new code, are caught *in code* rather than only in the runtime's I/O compliance gate).
- **Deterministic.** SAST tools (Semgrep-class multi-language rule engines + language-specific scanners: `cargo audit`, `bandit`, `gosec`) emit typed findings with severity; there is no model adjudication of "is this actually a vulnerability" for a matched rule — a matched rule is a finding, full stop. (The model *can* propose a fix; it cannot argue the finding away.)
- **Policy-configurable severity gating:** `critical`/`high` findings are **hard-blocking** regardless of every other stage's outcome or the Confidence Score — this is the one place the design deliberately overrides "score decides commit" (§10): a critical secret leak at Confidence Score 100 still does not commit. `medium`/`low` findings are weighted into the score but don't hard-block by default (tunable per deployment, tighter for critical-path modules per §3's tier escalation).
- **Language degradation:** legacy/niche languages (see §11) without a maintained SAST ruleset run whatever generic entropy/secret-pattern scanning applies to any text (the compliance engine's own regex+entropy layer is reused here) and are flagged `Skipped(no_sast_engine, partial_generic_scan_only)` — never reported as "SAST clean" when it wasn't actually run.

### Stage 6 — Performance Analysis
Hybrid: a deterministic sub-check plus a model-assisted advisory sub-check, because tooling for "did this get slower" is uneven across languages and change types.
- **Deterministic sub-check:** if a benchmark harness exists for the touched code path (hot-path functions tagged in the architecture graph, or an existing `#[bench]`/benchmark suite), run it and diff against the last known-good baseline stored per commit in the Event Log. Regression beyond a configured budget (e.g. p95 latency +15%, peak memory +20%) is a hard finding, same treatment as a failing test.
- **Static heuristic sub-check (deterministic, tool-based, not model-judged):** AST-level complexity scan — new nested-loop depth, N+1-query shaped patterns (a loop containing a call into a data-access capability), unbounded recursion — flagged as findings via the same tree-sitter substrate the Semantic Editing engine uses.
- **Model-advisory sub-check:** only for algorithmic-complexity changes no benchmark exists for (no harness on this code path) — the model reasons over the diff ("this turned a single lookup into an O(n) scan inside a loop") and produces an **advisory** finding with a plausibility confidence, never a hard block, because it cannot measure, only estimate.
- **Failure feedback:** benchmark regression → Coder with the before/after numbers. Advisory findings ride into the report; they influence the Confidence Score but are clearly labeled *estimated, not measured*.
- **Cost control tie-in:** this is the stage most tempting to always-skip. It is mandatory for Tier 3 (§3) precisely because performance regressions in settlement/ledger paths are a production-incident class, not a nice-to-have.

### Stage 7 — Architecture Review
Hybrid, and this is where the Context Fabric's **architecture graph** (`CONTEXT_FABRIC.md` §2 layer 7) earns its place in the pipeline rather than staying a documentation artifact.
- **Deterministic sub-check:** the architecture graph encodes declared module boundaries and allowed dependency edges (e.g. "the `ui` layer may depend on `api-client`, never directly on `db`"). The edit's new/changed import edges are diffed against this contract. A new edge the graph does not allow is a **deterministic violation** — no model needed, it's a graph-membership check, the same class of check as the field-usage guard already proven in the known-bug rules (`sdlc_patch_engine.py`'s `changed_fields` guard, generalized here to any layering rule).
- **Model-judged sub-check:** for the class of architectural concerns that are real but not (yet) codified as a graph rule — duplicated logic that already exists elsewhere in the repo, a pattern that contradicts a documented convention in the memory layer (`CONTEXT_FABRIC.md` §2 layer 12 — org-knowledge/conventions), a god-function forming. The model proposes these as advisory findings, each with a **specific reference** (the existing implementation it's duplicating, the convention doc it contradicts) — an unreferenced "this feels architecturally off" finding is discarded as noise, not reported, because unfalsifiable model opinions are exactly the sycophancy-adjacent failure mode this design is built to exclude.
- **Failure feedback:** a deterministic boundary violation is a hard finding → Coder must restructure through the declared interface, or a human must explicitly amend the architecture graph's contract (a real, audited change to the rule, not a silent bypass).

### Stage 8 — Regression Detection
Hybrid, drawing on three Context Fabric layers together: call/import graph (blast radius), test graph (coverage), git-history graph (change-coupling).
- **Deterministic sub-check:** blast radius (from stage 0) minus test-graph coverage (from stage 2) = the **uncovered blast-radius fraction** — a hard number. Above a tier-dependent threshold (tighter for Tier 3 critical-path edits), this is a gating finding: *not* "block forever," but "the Coder must add tests for the uncovered call sites before this can reach `Complete`" — a concrete, actionable requirement, same shape as the SDLC Judge's "specific actionable what's-missing" (`SUBSYSTEM_DEEP_DIVES.md` §1.7).
- **Change-coupling cross-check (deterministic):** the git-history graph's "files that historically change together" is consulted — if file A changed here but its historically-coupled file B did not, that's a flagged advisory (not a hard block; coupling is a signal, not a rule) surfaced to the Coder as "these usually change together, confirm B doesn't also need an update."
- **Model-judged sub-check:** does the diff plausibly violate an *implicit* invariant no test encodes (reasoning over call sites and the diff, in the same spirit as the Breaker's invariant/metamorphic oracles — `AGENT_TESTER.md` §2 — but scoped to this one diff rather than exploratory testing). Produces advisory findings that typically manifest as **new regression-test suggestions** rather than blocking prose.
- **High-risk escalation:** Tier 3 edits may trigger a scoped Breaker differential run — comparing behavior against a reference implementation (the Rust-migration shadow-mode comparator is the concrete existing use of this pattern, `AGENT_TESTER.md` §6/§8) — as an additional regression oracle beyond what this pipeline computes standalone.

### Stage 9 — LLM Review
- **What it checks:** the class of correctness and quality issue no deterministic tool structurally catches — wrong business logic, an off-by-one that type-checks fine, a misread requirement, poor readability/naming, a subtly wrong condition. This is the pipeline's equivalent of a senior engineer's PR review pass.
- **Model-judged**, and deliberately **not** the same role as the Judge (stage 10 boundary, §5): LLM Review finds and lists issues against the diff and the stated task, with a severity and a confidence per finding; it does not decide overall completion.
- **Inputs:** the diff, the task/ticket intent, every prior stage's findings (so it isn't re-flagging what SAST/lint already caught — no duplicate noise), and the compensating-control weighting from any `Skipped` deterministic stage (§4 stages 2/4/5's honest-skip rule) — where deterministic coverage is thin, this stage is explicitly asked to look harder.
- **Failure feedback:** findings above a severity threshold → Coder as fix observations, same loop as every other stage.
- **Anti-noise discipline:** every finding must cite the exact lines and articulate the concrete failure mode ("if `amount` is negative here, the retry path double-credits") — unreferenced stylistic opinion is filtered out before it ever reaches the Coder or the report, borrowing the Breaker's "verified findings only, noise is a first-class enemy" discipline (`AGENT_TESTER.md` §5).

### Stage 10 — Confidence Score
Not a stage that inspects code — a **computed function** over every prior stage's structured output. Full mechanics in §8.

### Stage 11 — Commit Gate
The policy decision that consumes the Confidence Score plus every hard gate. Full mechanics in §9.

---

## 5. LLM Review vs the Judge — two different questions, not one renamed

It matters that these stay distinct roles, because collapsing them is exactly how a pipeline becomes sycophantic:

| | LLM Review (stage 9) | The Judge (before stage 11) |
|---|---|---|
| **Question** | "What's wrong with this diff?" | "Is this diff *done* — does it satisfy the acceptance criteria and ticket intent, given everything the tools and Review found?" |
| **Sees** | The diff + task + prior findings. | The diff + acceptance criteria + the **full stage report** (every deterministic result, every Review finding) — but explicitly **not** the Coder's self-summary/rationale. |
| **Independence** | May run in the same context as the Coder — it's a *finder*, correlated blind spots are a cost-quality tradeoff, not a safety hole. | **Must** run in a fresh context, ideally a different model, per the anti-sycophancy design already proven for SDLC (`SUBSYSTEM_DEEP_DIVES.md` §1.7, `VENDOR_SYNTHESIS.md` — the OpenHands three-tier pattern). This is the stage this whole pipeline generalizes out of SDLC: **every** edit now gets an independent completion adjudication, not just ticket-scoped SDLC runs. |
| **Output** | A findings list, feeding self-heal. | `approve` (feeds `Complete`) or a **specific, actionable "what's missing"** (feeds the next Coder round, exactly as in the existing SDLC pattern) — never a vague "looks mostly good." |
| **Skippable?** | Lightweight version runs at Tier 1; full at Tier 2+. | Skippable only at Tier 0/1 when the Confidence Score already clears the auto-complete bar with zero findings anywhere; **mandatory** at Tier 2+ and always at Tier 3. |

---

## 6. Failure → self-heal feedback loop

Every stage above feeds failures back the same way, so the Coder sees one consistent loop shape regardless of which stage rejected the edit:

```
stage fails → structured Observation{stage, tool_output, exact_location}
  → injected to Coder as the next turn's input (reactive loop, same shape as SDLC's tier-1 loop)
  → Coder proposes a fix → Semantic Editing engine applies it (stage 0 again)
  → pipeline RE-ENTERS at the earliest invalidated stage, not necessarily from stage 1:
      - content-hash cache (§3) skips stages whose inputs didn't change
      - a fix confined to file X only forces re-run of stages whose inputs include file X
      - ANY code change always re-runs compile+tests+lint+type-check for the touched files
        (never trust a "small" fix to not need re-verification of the basics)
  → bounded by: a round-cap (config, tighter at Tier 3) AND a stuck-detector
      (no material progress across N rounds — same diff-similarity detector already
       designed for SDLC's judge loop and the Breaker's exploration loop) → abort to Capped
```

The stuck-detector matters as much as the cap: a cap alone still lets the loop burn N rounds making no progress before giving up loud; the detector recognizes *thrashing* (the fix for stage A breaks stage B, the fix for B re-breaks A) early and cuts the loop with a diagnosis ("stages 1 and 5 are in conflict: the SAST-suggested fix reintroduces the compile error this round tried to resolve") rather than a bare "gave up."

---

## 7. Confidence Score — computation

The score exists to answer one question the binary gates can't: *given that everything deterministic passed, how much residual risk remains?* It never overrides a hard gate — it is only computed once Phase A (stages 1–5) and any hard-blocking finding in stages 6–8 are clear. Computing it earlier would imply a "mostly-passing broken build" reading, which the design explicitly rejects.

```
score = 100
  − Σ SAST findings (critical: hard-block, not scored; high: −20; medium: −8; low: −2; capped per-category)
  − performance_regression_penalty      (0 to −25, scaled to how far over budget; 0 if no benchmark existed — see skip rule below)
  − architecture_violation_penalty      (−15 per deterministic boundary breach not yet remediated)
  − regression_risk_penalty            = −30 × (1 − blast_radius_test_coverage_overlap)
  − Σ unresolved LLM Review findings    (severity-weighted, −2 to −10 each, capped)
  − Σ skipped-stage penalty             (−5 per stage that returned Skipped(no_tool) rather than a real verdict — a
                                          skip is never free; it is explicitly worse than "ran and passed")
  ± edit_engine_rung_adjustment         (LSP/AST rung: 0; structured-patch: −3; text-patch fallback: −8 — lower-fidelity
                                          edits carry their own residual risk per SEMANTIC_EDITING.md §2's ladder)
  clamp to [0, 100]
```

Two anti-sycophancy properties are load-bearing here, not incidental:
1. **The Judge's verdict is not an input to the arithmetic.** The Judge's `approve`/`what's-missing` is a *gate on top of* the score (§9), never a term that can inflate it. A model cannot talk the score up.
2. **A skip is a penalty, not neutral.** If skips were score-neutral, the cheapest way to a high score would be "run fewer checks" — exactly backwards. This is the same principle as the SAST honest-skip rule in §4, made numeric.

The score is reported with its **full breakdown**, not just the number — every deduction, every skip, every rung adjustment — because an opaque "87/100" is not auditable and an NPCI reviewer two years from now needs to see *why* 87, not just that it was 87.

---

## 8. Commit Gate — the policy decision

```
IF any Phase-A stage (1–5) has an unresolved failure           → Blocked (never reaches scoring)
IF any SAST critical/high finding is unresolved                 → Blocked (score is irrelevant, see §4 stage 5)
IF any Architecture deterministic violation is unresolved       → Blocked
ELSE compute Confidence Score (§7)
  IF Tier == 3 (critical-path/high-risk)                        → Judge mandatory; commit requires HITL approval
                                                                    regardless of score (autonomy forced to `assisted`)
  ELIF score >= auto_complete_threshold (policy, e.g. 90)
       AND Judge (if it ran) returned approve                   → Complete → commit proceeds
  ELIF score >= review_threshold (policy, e.g. 70)               → Complete, but flagged for post-commit spot-audit
                                                                    (sampled human review, not blocking — the
                                                                    "trust but verify" tier)
  ELSE                                                           → Capped: surface the gap report, hand to human,
                                                                    self-heal loop continues only if rounds remain
```

`Complete` is what unlocks the actual git commit and (for SDLC-originated edits) the existing idempotent MR flow (`gitlab_create_mr`, 409-safe, `SUBSYSTEM_DEEP_DIVES.md` §1.8) — this pipeline is upstream of that flow, not a replacement for it. For Code-profile edits with no ticket/MR involved, `Complete` unlocks the local commit and the turn's success framing in the renderer.

`Capped` is rendered to the human with the **full stage report** — not "something went wrong," but "stages 1–4 passed; stage 8 found 3 uncovered call sites in the blast radius; 5 self-heal rounds were spent; here is exactly what's missing." This is the same honesty requirement the SDLC design already established (`SUBSYSTEM_DEEP_DIVES.md` §1's "`capped` is a first-class, honest outcome") — this doc's contribution is making it the outcome of *every* edit's pipeline, with a machine-checked reason attached every time, not a prose excuse.

---

## 9. Event Log integration — journaling every stage

Every stage transition is an event, appended to the same durable, incrementally-projected Event Log the rest of the runtime uses (`RUNTIME_FEATURE_FLOWS.md`, `SUBSYSTEM_DEEP_DIVES.md` §6):

```
PipelineStarted   { edit_id, risk_tier, blast_radius, edit_engine_rung }
StageStarted      { stage }
StageResult       { stage, verdict: Pass|Fail|Skipped(reason)|Advisory, deterministic: bool, evidence_ref }
SelfHealTriggered { stage, round, observation }
RoundCapped       { rounds_exhausted, stuck_detector_fired: bool, diagnosis }
JudgeVerdict       { approve|what_is_missing, judge_model, context_isolation_confirmed: bool }
PipelineOutcome   { Complete|Capped|Blocked, confidence_score, breakdown }
```

Every event is **hash-chained** to the previous event for this edit (extending the tamper-evident-audit design flagged as a gap in `GAP_ANALYSIS_VS_AI_PLATFORMS.md` §AK) — a regulator reconstructing a settlement-path commit two years later gets a signed, ordered, un-editable trail from "patch generated" to "commit," including every self-heal round and the exact evidence (tool output, not paraphrase) behind every stage verdict. This is also what makes `forensic reproducibility` (`GAP_ANALYSIS_VS_AI_PLATFORMS.md` §X — exact prompt+context+model+params per turn) concrete for code changes specifically: the pipeline's Event Log entries are the reproducibility record for *this* class of turn.

The Event Log projection also becomes a **Context Fabric layer 1 (Conversation) citizen**: `pipelineHistory(commit_sha)` is a structured query any future agent (or human, or the Breaker) can run — "what did the pipeline find and decide about this commit" — the same way `whoCalls(sym)` or `testsCovering(fn)` are queried today (`CONTEXT_FABRIC.md` §5).

---

## 10. Per-language capability degradation

The pipeline's honesty depends on never letting a missing tool masquerade as a passed check. A capability matrix, in the same shape as the Semantic Editing engine's rung matrix (`SEMANTIC_EDITING.md` §6), is declared per language and read by every stage:

| Language | Compile/Build equiv. | Test runner | Type-check | SAST | Perf harness |
|---|---|---|---|---|---|
| Rust (the runtime itself) | `cargo build` | `cargo test` | native | `cargo audit` + Semgrep | `cargo bench` |
| Java | `javac`/build tool | JUnit/TestNG | native | Semgrep + language rules | JMH (if present) |
| TypeScript (strict) | `tsc --noEmit` | Jest/Vitest | native | Semgrep + ESLint security | benchmark.js (if present) |
| Python | syntax+import-resolve (tree-sitter) | pytest | mypy (if configured, else **skip**) | bandit + Semgrep | pytest-benchmark (if present) |
| Go | `go build` | `go test` | native | gosec + Semgrep | `go test -bench` |
| JavaScript (untyped) | syntax+import-resolve | Jest (if present, else **skip**) | **skip** (no checker) | Semgrep + ESLint security | **skip** |
| COBOL / mainframe batch (legacy settlement systems) | requires the actual mainframe toolchain/emulator — usually **unavailable** in the sandbox → **skip, manual-review-required flag** | **skip** (no runnable harness) | n/a | generic secret/entropy scan only (no COBOL-aware SAST ruleset) | **skip** |

Every `skip` in this table is a `Skipped(reason)` verdict, not a pass — it feeds the Confidence Score's skip-penalty (§7), forces LLM Review to compensate (§4 stage 9), and for legacy/no-tooling languages, the report explicitly states **"manual review required before commit; deterministic coverage was structurally unavailable for this language"** rather than presenting a score that looks comparable to a fully-tooled Rust edit. This is the honest-degradation principle stated once, applied everywhere: the pipeline never silently defaults to treating an unverifiable language as verified, the same discipline `SUBSYSTEM_DEEP_DIVES.md` §1 already requires of SDLC's language detection ("confidence 0.0 ⇒ block, never silently default").

---

## 11. Acceptance / scenario tests

The pipeline design is validated against concrete scenarios, not a self-reported readiness percentage (the same discipline `project_v2_full_parity_md`-style audits already apply elsewhere in this program):

- **Doc-only edit** → classified Tier 0, runs compile-sanity + lint only, still emits a full `PipelineStarted`→`PipelineOutcome` Event Log trail, reaches `Complete` in under a second of tool time.
- **Compile failure on a Coder-generated fix** → self-heal re-enters at stage 1, not stage 0's full re-plan; three consecutive *identical* compiler errors trip the stuck-detector before the round-cap does, yielding a diagnosis, not a bare timeout.
- **SAST finds a hard-coded secret** → hard-blocked at Confidence Score 100 with zero other findings; commit refused; the report names the exact rule and line, not "security issue found."
- **Field rename with existing call-site usages elsewhere** (the known regression class from `sdlc_patch_engine.py`) → caught deterministically by stage 7's architecture/xref check, blocked with the specific guidance to add via `new_functions` rather than mutate the declaration in place — verified, not just designed-to-catch.
- **High blast radius, tests green, 40% of touched call sites have zero coverage** → Confidence Score capped below the auto-complete threshold by the regression-risk penalty even though every deterministic gate passed; forces the Coder to add tests or forces HITL — never a false "all green."
- **Legacy COBOL edit** → SAST/type-check/perf all `Skipped(no_tool)`; report explicitly states manual review required; Confidence Score discounted accordingly; never reports a misleadingly comparable number to a fully-tooled edit.
- **Judge anti-sycophancy check** — the Coder's fix-round summary claims completeness; the Judge, given only the diff + acceptance criteria + stage report (not the Coder's summary), finds an unmet criterion and emits a specific what's-missing; verified by re-running with the summary deliberately misleading to confirm the Judge doesn't inherit it.
- **Flaky test** — a test fails once, passes on an immediate same-seed re-run within the same pipeline pass → treated as a flake (logged, not filed as a regression, not "fixed" by the Coder chasing a ghost) rather than triggering a wasted self-heal round.
- **Round-cap with no progress** — five self-heal rounds where stage 5's fix reopens stage 1's error and vice versa → stuck-detector fires before round 5, yields `Capped` with the thrash diagnosis from §6, never a silent infinite loop.
- **Critical-path (settlement module) edit at Confidence Score 100** — still requires HITL approval per Tier 3's forced autonomy-down rule; verified the gate cannot be bypassed by a high score alone.
- **Concurrent edits with overlapping blast radius** — the Semantic Editing engine's per-file/symbol serialization (`SEMANTIC_EDITING.md` §5) prevents two pipeline runs from racing to commit against the same files; the second run's stage 0 sees the first run's committed state as its new baseline.
- **Two-year-later audit replay** — given only a commit SHA, `pipelineHistory(commit_sha)` reconstructs the full hash-chained stage-by-stage trail, including every self-heal round's exact tool evidence, with no gaps.

---

## 12. Why this is now a 10

Every clause of the rubric has a concrete, checkable design behind it, not a restatement of the clause: a **typed `PipelineOutcome`** makes "never declare done" structural rather than a prompt request; **deterministic tools own every pass/fail they can decide**, and the Confidence Score is explicitly barred from letting model judgment inflate past what tools found; the **Judge is architecturally separated from LLM Review** so completion-adjudication stays anti-sycophantic exactly as proven in the SDLC pattern this design generalizes; **failure feeds back** through a bounded, thrash-aware self-heal loop instead of either infinite polishing or a bare timeout; the **Context Fabric's architecture/dependency/test/git-history graphs** turn Architecture Review and Regression Detection into mostly-deterministic graph checks instead of vibes-based model opinions; **every stage journals to the tamper-evident Event Log**, giving the audit and forensic-replay story regulators require; **per-language degradation is honest** — a skip is a penalty, never a silent pass, down to the COBOL/legacy-mainframe case NPCI actually has; and the whole thing is **risk-scaled** so a comment fix costs a lint pass, not twelve stages and three LLM calls, while a settlement-path change is structurally forced through the full gate plus a human, regardless of how good the score looks. It is the same rigor the platform already proved once, in one place (SDLC) — this design is what makes it the property of every edit, everywhere, once.
