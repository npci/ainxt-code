# P3 Exit — Definition-of-Done Status

**Status (2026-07-19):** P3 **Surface Profiles & Feature Parity** foundation BUILT + increment-tested.
The core thesis — *one runtime, N declarative surfaces* — is realized: Chat, Code, SDLC and Buddy are
expressed purely as configuration over the P1/P2 spine, and the profile-critical subsystems (skill
injection, edit engine, judge loop, artifact runtime) are implemented with their acceptance matrix
green locally. Shadow-mode parity vs the Python platform, live RAG/sandbox, and real doc renderers
remain — see "Not yet proven" (stated honestly per `feedback_enterprise_grade_no_poc`).

## What is built (8 crates over the spine + 4 canonical profiles)

`ainxt-profile` (surface schema + layered loader) · `ainxt-skill` (skill runtime) · `ainxt-surface`
(profile → runtime binding) · `ainxt-edit` (edit engine) · `ainxt-judge` (SDLC judge loop) ·
`ainxt-artifact` (doc-gen IR + renderer). Canonical profiles: `chat` · `code` · `sdlc` · `buddy`.

A turn under a surface is planned by one pipeline (`ainxt-surface`), fail-closed:

```
admit (RBAC role floor + required caps)
  → data-class ceiling (regulated data refused; ADR-012)
  → effective capabilities = profile ∩ principal   (a profile never escalates a principal)
  → skills: persona → behavioral → guard  (system prompt) + ## Context (execution output)
  → reasoning depth (adaptive per-query when Auto, else fixed) → routing tier (BE)
  → autonomy → side-effect + approval policy  (read-only / suggest / act-with-approval / autonomous)
  → retrieval scope (platform+namespace vs repo-scoped — no cross-repo/tenant reach)
```

## Evidence (all green: per-crate `cargo test` + `clippy -D warnings`)

- **P3 crate tests, 0 failed:** `ainxt-profile` 10 · `ainxt-skill` 8 · `ainxt-surface` 10 (+ 7
  canonical-profile integration tests) · `ainxt-edit` 17 · `ainxt-judge` 6 · `ainxt-artifact` 8.
  Clippy clean on every crate.
- **Four surfaces are declarative** (`ainxt-surface/profiles/*.toml`), each proven to bind to its
  intended policy: `chat` read-only + platform-scoped; `code` act-with-approval + repo-scoped +
  numeric-tools-only + edit caps; `sdlc` deep + model-agnostic (Claude primary / GPT fallback) +
  GitLab & Jira; `buddy` suggest-only + Graph. Every surface requires the baseline capability and
  refuses data above its class ceiling.
- **P3 acceptance matrix** (`ainxt-surface/tests/dod_p3_matrix.rs`): **10 scenarios** across the P3
  categories, layered oracles + JUnit — layered profile merge (deep + safe defaults); skill
  injection order; retrieval scope-separation; edit-engine dry-run safety (ambiguous anchor refused,
  nothing applied) + import restore; judge-panel independence + majority; honest `capped`; doc-gen
  fidelity + audit-and-proceed; data-class ceiling; RBAC admission denial.

### Enterprise invariants proven
- **Config-first surfaces** — a surface is a profile + a renderer; no per-surface code. The layered
  merge (`defaults → deployment → tenant → profile → request`) is deep, so a deployment overrides a
  single nested field without restating the rest. Autonomy defaults to the safest value (read-only).
- **A profile never escalates a principal** — effective authority = the surface's offered
  capabilities ∩ the principal's RBAC; the engine's authz gate is still the enforcement point.
- **RBAC scope is declared + carried (not yet enforced)** — the binding resolves each surface's
  retrieval scope (`platform+namespace` vs `repo-scoped`) into the `TurnPlan`. This is the *input* to
  scope separation; the actual "repo-scoped surfaces never reach platform/other-repo context"
  enforcement lives in the retrieval engine, which is **deferred** (see "Live RAG" below). Today the
  `TurnPlan.retrieval` field has no consumer — it is a carried decision, not a proven guarantee.
- **Safe edits** — exact then whitespace-insensitive matching, never fuzzy; ambiguous/unmatched
  anchors are structured errors; all-or-nothing application; and the three known SDLC edit bugs are
  encoded as invariants (import restore on full-file gen, field-rename-with-usages refused,
  declaration preferred over call site).
- **Honest SDLC verification** — deterministic verify gates the judges; judges score independently; a
  strict-majority consensus is required; hitting the iteration cap without consensus is reported as
  `capped`, never as success. HITL is the P1 approval gate, driven by `act-with-approval` autonomy.
- **Artifacts audit-and-proceed** — document compliance flags findings but never redacts inside the
  document (a mangled code block or table is worse); content is emitted intact.

## Not yet proven here (needs infra, or is a tracked follow-up)

- **Shadow-mode parity vs Python** — running each migrated capability side-by-side with the Python
  platform and diffing outputs needs both stacks + real traffic; the subsystems + their unit/matrix
  acceptance are done, the parity harness is not.
- **Live RAG** — the Chat/Code retrieval SCOPE is enforced (the RBAC-critical part); the actual
  pgvector/BM25 hybrid + rerank + repo symbol-map run against real indexes (P3's RAG-quality items
  land with the retrieval engine, not this foundation).
- **Sandbox + SAST** — the Code profile declares the tool-belt and edit engine; the sandbox (quick
  container + sandbox-as-server) and the SAST gate are seams here, executed by the sandbox runtime
  (needs Docker/infra).
- **Binary artifact renderers** — Markdown + plain text are built in and tested; docx/pptx/pdf/xlsx
  are skill renderers behind the `Renderer` seam (not implemented here).
- **Execution-skill runtime** — behavioral-skill injection is fully tested; execution-skill `run()`
  is a seam (the sandbox runs it), exercised in tests via a mock executor.
- **Composition binary** (`ainxt-runtimed`, plan L6) — assembling a live surface (profile →
  `TurnPlan` → Engine + Prompt Engine + router + approval + connectors) end-to-end from
  `RuntimeConfig` remains; this phase delivers the subsystems + their acceptance matrix.
- **Human Gate #0 (legal/OSS sign-off + real copyright entity + model-weight license clearance)**
  remains the standing P0 blocker before any public open-source release.
