# Tool + MCP Runtime, Plugin Runtime, Model Router — design to 10/10

**Status:** Design (no code). Closes gaps **AB** (tool/capability selection degrades at hundreds-of-tools scale), **AI** (confused-deputy / on-behalf-of authz), **R + S** (exactly-once + compensation for side-effecting actions), **T** (egress DLP), **N/O** (data-class → model-eligibility), **AD** (plugin supply-chain), **[2]** (MCP tool-manifest trust), **[20]** (detector DoS hardening), **[21]** (active lost-ack reconciliation), **[23]** (live quality circuit-breaker). References: ADR-002 (Tool+MCP Runtime), ADR-003 (Policy/Approval, extended here for OBO), ADR-009 (injection, paired here with egress), ADR-012 (data-class routing, made concrete here), ADR-013 (idempotency, made concrete here), **ADR-026 (control-plane git-native, applied here to the plugin lifecycle §3.3–3.4).** The Plugin Runtime / WASM supply-chain decision is recorded in §3 of this document itself — there is no separate ADR number for it (ADR-016 is canonically the Agent-Payment-Initiation Boundary, a distinct decision).
**Target:** every side-effecting action executes **exactly once** even under retries; every action is authorized **as the requesting user**, never the agent's own ambient identity; hundreds of capabilities never degrade tool-choice; third-party code never runs outside a signed, capability-scoped sandbox; and the Model Router is read as a **compliance component that happens to also optimize cost/latency/quality** — not the reverse.

---

## 0. The one-registry principle

Native capabilities, MCP-discovered capabilities, and (Phase 5) WASM-plugin-exposed capabilities are **one `Capability` trait, one `CapabilityRegistry`.** The dispatcher does not know or care where a capability came from — approval, idempotency, locking, OBO authz, and egress DLP apply uniformly to all three origins. MCP is an adapter that registers wrapped capabilities; a plugin is an adapter that registers sandboxed capabilities. Nothing downstream branches on origin.

```
Capability sources                 Dispatch (identical path for all)
──────────────────                 ──────────────────────────────────
native Rust fn        ──┐
MCP server tool        ──┼─▶ CapabilityRegistry ─▶ Policy(OBO+grant) ─▶ Idempotency Ledger
WASM plugin export     ──┘        (name-keyed)      check              (dedupe/commit)
                                                        │                    │
                                                        ▼                    ▼
                                              Resource Lock            Egress DLP (if
                                              (per resource_key)        effect crosses
                                                        │               the boundary)
                                                        ▼
                                                  Execute + record
                                                  side-effect receipt
```

---

## 1. Tool Runtime

### 1.1 One trait, schema-from-struct
Each capability's arguments are **one typed struct** deriving both the deserializer used to parse the model's tool-call JSON and the schema generator used to produce the model-facing JSON schema. Schema and parser are compiled from the same source — they cannot drift apart (a whole class of "model sent valid-looking JSON that the handler rejects" bugs is structurally impossible). The result type is equally uniform: `CapabilityResult { model_content, human_message, display_blocks, error, side_effect_receipt }` — model-facing text, human-facing UI, typed rich blocks, and an error flag travel together, regardless of capability origin.

Every capability manifest additionally declares:
```
effect_class:   Pure | Idempotent | SideEffecting
resource_key:   fn(args) -> String            # what this call touches, for locking
idempotency_key: fn(obo_ctx, args) -> String  # required if SideEffecting
compensate:     Option<fn(receipt) -> Action> # for saga participation
risk_tier:      Low | Elevated | HighRisk     # drives approval + two-phase requirement
```
This manifest — not developer discipline — is what the runtime enforces against. A capability cannot be `SideEffecting` without an idempotency-key function; the registry rejects registration otherwise.

### 1.2 Idempotency keys + the side-effect ledger (no double-execution)
The payment-critical property: **an agent that retries "create MR," "send email," "initiate settlement," or "post to ledger" must never execute twice.** This is enforced by the runtime, not the capability author:

1. Before dispatch, the runtime computes `idempotency_key = f(obo_ctx.user_id, capability, resource_key, semantic_args)` — a hash over the *semantic* request, not wall-clock time or a random nonce (so a genuine retry produces the *same* key, and two genuinely different requests never collide).
2. The runtime inserts `{key, status: PENDING, request_hash}` into the **Side-Effect Ledger** (Postgres, unique constraint on `key`) inside the same transaction that claims the slot. If the insert conflicts (key exists):
   - `status = COMMITTED` → return the ledger's stored result immediately. **The underlying capability is never invoked a second time.**
   - `status = PENDING` (a concurrent/in-flight duplicate, e.g., two retries racing) → the second caller blocks briefly on the first's completion, then returns its result — never runs in parallel with itself.
   - `status = FAILED` (a prior attempt cleanly failed, no side effect occurred) → safe to re-attempt, issued a fresh PENDING claim.
3. Only after the ledger claim succeeds does the runtime call the capability. On success, the ledger row is updated to `COMMITTED` with the result; on failure, `FAILED`.

This makes retries — from the agent loop's own error-recovery, from a network timeout where the downstream system actually succeeded but the ack was lost, or from a user re-running a turn — safe by construction. The ledger, not the capability, owns the exactly-once guarantee.

### 1.3 Saga / compensation for multi-step side effects
A composite action (e.g., "update the Jira ticket, then create the GitLab MR, then notify the channel") is modeled as an ordered list of ledger-tracked steps, each with its own `compensate` if declared:
```
run saga:
  for step in steps:
    claim ledger slot (per 1.2) → execute → record receipt
    on failure:
      for prior in completed_steps.reverse():
        if prior.compensate exists: invoke compensate(prior.receipt); record outcome
        else: mark NON_COMPENSABLE; surface an incident note to a human — never
              silently claim rollback for an effect that can't be undone (e.g., an
              email already sent)
      saga status = FAILED_COMPENSATED | FAILED_PARTIAL(list of non-compensable steps)
```
`FAILED_PARTIAL` is a first-class, honestly-reported outcome — the same "never claim done when it isn't" discipline the SDLC judge-loop uses for `capped`.

### 1.4 Two-phase commit for high-risk actions
Capabilities flagged `risk_tier: HighRisk` (settlement-adjacent, bulk-write, irreversible) expose `dry_run` (returns a preview, computes the idempotency key, no side effect) and `commit` (requires the exact key from a prior `dry_run` within a TTL). The dispatcher **rejects a `commit` with no matching prior `dry_run`/approval** — an agent cannot skip the preview step for the actions that most need one. This is the concrete form of the "propose, then act" contract for the highest-severity class.

### 1.5 Per-resource locking
Each call resolves a `resource_key` (file path, ticket ID, ledger account, DB row range). Concurrent calls sharing a `resource_key` **serialize**; calls on disjoint resources run fully in parallel — the same discipline already applied to file edits, generalized to any resource a capability touches. Locks are held only for the dispatch-and-ledger-claim window, never across a slow external call, so a stalled downstream system cannot starve unrelated turns. The lock prevents *concurrent* double-execution within a live process; the ledger (1.2) prevents it *across* retries, restarts, and process boundaries — together they cover both axes.

### 1.6 On-behalf-of authorization + least-privilege grants (no confused deputy)
The agent never executes under its own ambient identity. Every dispatch carries a resolved **OBO context** — `{user_id, role_id, department, ad_level, granted_permissions}` — threaded from the turn's JWT through the entire call chain, **including sub-agent invocation** (a sub-agent inherits the parent's OBO context; it can never present broader credentials than the human who started the turn actually holds).

The Policy Engine answers one question per call: *can this user, via this capability, do this action on this resource?* — evaluated against three independent layers, ALL of which must pass:
- **Declared grant** — a scoped tuple `{capability, resource_pattern, action, constraints}` on the harness/role (e.g., `connector.postgres.query: read-only, table=settlement_batches`), never a blanket `connector.postgres.*`.
- **Issued connector scope** — the actual OAuth/token scope the *user* consented to (GitLab token scopes, Graph consent) — a harness cannot grant what the user's own credential doesn't cover.
- **Resource-level ABAC** — the resource's own department/data-class must be within the user's clearance.

A missing grant is a **hard, structured denial** — the runtime never substitutes the agent's broader ambient credential to "help" the call succeed. That substitution is precisely the confused-deputy failure mode; refusing it is the fix. Every OBO decision (granted or denied) is written to the Event Log beside the tool call, reconstructable for audit two years later.

### 1.7 Egress DLP (the exfiltration half of the injection/exfiltration pair)
Any capability whose effect leaves the security boundary (HTTP call out, email/chat send, connector write with an external recipient, file upload) routes its **outbound payload** through the Compliance Gate — the same PCI/DSS + PII detectors that guard model output — *before* the network call fires, not after. This closes the attack chain a prompt-injection defense alone cannot: an instruction smuggled in via a poisoned document might get the agent to *attempt* an exfiltrating action; OBO (1.6) constrains *who* it can act as, and egress DLP inspects *what* it is about to send, redacting or blocking regulated classes regardless of who authorized the call. An explicit **egress allow-list** per capability and per data-class governs destinations (e.g., `connector.email` defaults to internal domains; anything else soft-blocks pending approval) — unknown destinations never get a silent send.

### 1.8 Active reconciliation of lost acknowledgements (gap [21])
The ledger (§1.2) makes a *retried* call safe, but it does not by itself resolve a row that is stuck `PENDING` — the case where the runtime claimed the slot, the capability fired against the downstream, and then the process died (or the network dropped the ack) before the row could move to `COMMITTED` or `FAILED`. Left alone, that row is a permanently ambiguous settlement-adjacent record: a future retry blocks on it (§1.2's `PENDING`-collision path) and no one knows whether the effect actually happened. Passive expiry is unacceptable for a payments platform — a timed-out `PENDING` is exactly the row we must *resolve*, not forget.

A background **reconciler** sweeps the ledger for rows `PENDING` beyond a per-`effect_class` bounded timeout and resolves each one *actively, not by guessing*:
- For a capability that exposes a `reconcile(idempotency_key) -> { Committed(result) | NotFound | Ambiguous }` probe — **mandatory** for any `SideEffecting` capability at `risk_tier: HighRisk` — the reconciler queries the downstream's *actual* state (the settlement API, the GitLab MR list, the mail log), keyed by the same idempotency key that was sent, and moves the row to `COMMITTED` (effect confirmed, result back-filled) or `FAILED` (downstream has no record, safe to re-attempt).
- If the probe returns `Ambiguous`, or the capability declares no probe, the reconciler **never fabricates a verdict**: it escalates the row to `MANUAL_RECONCILIATION`, files an incident carrying the full request hash and receipt, and pages the settlement on-call — the same honest-degradation discipline as §1.3's `FAILED_PARTIAL`. A settlement-adjacent row is *never* left indefinitely ambiguous, and *never* auto-resolved on a guess.

The reconciler claims each row it touches under a short lease, so it is idempotent and safe to run on every node — it survives the same restarts it exists to clean up after.

### 1.9 Detector DoS hardening (gap [20])
The Compliance Gate detectors invoked on egress (§1.7) and on the assembled context for data-class routing (§4.2) run regex, Shannon-entropy, and Luhn passes over attacker-influenceable text — a poisoned document, a tool result from a remote MCP server, a model-generated payload. An unbounded input or a catastrophically-backtracking pattern turns the *defensive* layer into the outage: a single crafted string can pin a worker at 100% CPU (ReDoS) and stall every turn sharing the pool. The detector layer is therefore hardened as an **availability boundary**, not only a correctness one:
- **Input bounded before any detector runs.** Every detector caps its input length before the first regex/entropy/Luhn pass; text beyond the cap is chunked with overlap (so a token straddling the boundary is still caught) rather than fed whole, and per-detector work is O(n) in the bounded chunk, never in the raw payload.
- **Guaranteed-linear-time engine, mandated.** All PII/PAN/secret patterns compile on a **RE2 / guaranteed-linear-time** engine — no backtracking constructs, so catastrophic patterns are impossible *by construction of the engine*, not by hand-auditing each regex. A pattern that will not compile under RE2 is a rejected pattern, enforced in CI over the detector rule-set, so a well-meaning contributor cannot land a backtracking regex that reopens the hole.
- **Per-call budget + fail-closed.** Each detector runs under a wall-clock budget; a detector that somehow exceeds it aborts and the enclosing action **fails closed** — an un-scannable payload is treated as un-sendable, never waved through because the scanner timed out.

This is the same "the guard cannot become the vulnerability" discipline applied to the compliance layer itself.

---

## 2. MCP Runtime

MCP servers register into the same `CapabilityRegistry` as an adapter layer — a server-provided tool is, to the dispatcher, indistinguishable from a native one the instant it's registered. Everything below is what happens *before* that point.

### 2.1 Lazy, parallel, per-server connection
MCP servers are not connected at process boot. At **turn start**, the runtime resolves which servers are in-scope for the active harness/session and kicks off connection attempts for **all of them concurrently** (bounded parallelism), each tracked as an independent state machine:
```
Unconnected → Connecting → { Ready | AuthRequired | Unreachable | CapabilityMismatch }
```
A server stuck in `AuthRequired` or `Unreachable` never blocks the others — the turn proceeds with whatever subset is `Ready`; the stalled server's capabilities are simply absent from planning (§2.3), the same soft-degrade discipline already used for connectors. Connections are cached **per session**, not per turn, with a liveness ping and TTL, so a multi-turn conversation doesn't re-pay handshake cost every turn; a dead connection is torn down and lazily reconnected on next need.

### 2.2 Per-server-URL OAuth
OAuth state is keyed by `(user_id, server_url)` — the URL, not the server's display name, is the trust boundary (two servers can share a name across environments/tenants without sharing a token), and this is **fully decoupled from model-provider auth**. Token storage reuses the runtime's existing encrypted-at-rest connector-token discipline (versioned-key encryption, distributed refresh lock) — MCP auth is not a second, bespoke system. A server pre-flight-checked as unauthenticated has its capabilities marked `requires_auth` and hidden from the model's tool list until the user completes a step-up consent, surfaced as an ordinary in-turn prompt rather than a mid-call failure.

### 2.3 Dynamic planning + capability discovery
Discovery is two-phase, deliberately separated by cost:
- **Phase 1 — manifest discovery** (once per connection, not per turn): a `Ready` server's capability manifest (name, description, schema, `resource_key` hints, `effect_class`) is fetched and merged into the registry.
- **Phase 2 — per-turn planning**: a cheap planning pass (small/fast model or heuristic — never the main model) reads the turn + conversation state and proposes which **capability classes** are relevant ("this turn needs ticketing + code-search," not "expose all 400 capabilities"). This bounds the candidate set *before* ranking runs, and is the same "decide which graphs matter" move the Context Fabric applies to context layers, applied here to tools.

### 2.4 Retrieval-based tool ranking at scale
Dumping hundreds of schemas into every prompt measurably degrades tool-choice and burns tokens — this is gap **AB**, and it is designed against directly:
- Capability manifests are embedded (name + description + example invocations) into a dedicated capability-vector namespace (same pgvector substrate as RAG) at registration time — not per turn.
- At planning time, the current turn (informed by §2.3's proposed classes) is embedded and used to retrieve the **top-K** most relevant capabilities (K sized to the target model's context budget, typically 15–30), re-ranked by semantic relevance, **session stickiness** (a capability just used is weighted to stay visible — most multi-step tasks reuse the same handful of tools), and harness-declared priority.
- An **always-visible core set** (read/edit/bash/`kb.search`) bypasses ranking entirely — retrieval must never accidentally hide the basics.
- A `capability.search(query)` meta-capability is always available as an **escape valve**: the model can explicitly search the full registry for something outside its top-K rather than silently never learning it exists. This is what prevents "the tool exists but the model was never shown it" from becoming a dead end.
- Ranking quality is itself an eval-gated property (same discipline as answer-quality drift elsewhere): a ranking regression that hides the right tool for a common task is tracked and blocked as a correctness bug, not shrugged off as "just retrieval."

### 2.5 Tool-manifest trust — TOFU pinning, reconnect-diff re-approval, namespace isolation (gap [2])
An MCP server's manifest is untrusted third-party input arriving over the network, and §2.3's discovery merges it straight into the registry the model plans against — so a server that silently *changes* its tool set between connections, or names a tool to impersonate a native one, is a live attack surface. This is **distinct from the WASM signing in §3.4**: that guards *code we load*; this guards *declarations a remote server hands us*, which never execute in our sandbox but do steer the planner.
- **TOFU content-hash pin.** On first successful connection to a `(user_id, server_url)`, the runtime computes a content hash over the *full normalized manifest* — every tool name, description, and JSON schema, not merely a version string the server controls — and pins `{server_url, manifest_hash, approved_by, approved_at}` to the control repo alongside the harness that declared the server (git-native per ADR-026). First use is an explicit human approval, not an implicit trust-on-connect.
- **Reconnect diff → re-approval.** Every subsequent connection (§2.1) re-hashes the freshly fetched manifest and diffs it against the pin. An identical hash proceeds silently. **Any** diff — an added tool, a changed schema, or even a reworded description (descriptions are model-facing instructions and therefore an injection vector) — freezes the *changed or added* tools out of §2.3 planning and surfaces a structured re-approval prompt showing the exact diff. Previously-pinned, unchanged tools keep working; only the delta is quarantined until a human re-pins. The runtime never auto-adopts a new or mutated remote tool into the model's plannable set.
- **Namespace isolation.** Every server's tools register under a per-server namespace (`mcp/{server_url_hash}/{tool_name}`) that cannot collide with native capabilities or with other servers. A remote server cannot register `bash`, `kb.search`, or another server's `jira.create_issue` and have it shadow the real one — resolution is namespace-qualified, native/core capabilities own the unqualified names, and two servers offering a same-named tool coexist without either capturing the other's calls. The planner and ranker (§2.4) see the qualified identity; only the disambiguated, collision-free set ever reaches the model.

---

## 3. Plugin Runtime (WASM/WASI, Phase 5)

Plugins extend the one-registry principle to third-party/engineer-authored code: a plugin registers capabilities into the **same** `CapabilityRegistry`, so approval, idempotency, OBO authz, locking, and egress DLP already apply without any plugin-specific work. The sandbox below is an **additional inner boundary**, not a replacement for the outer one.

### 3.1 Sandbox model
Every plugin is a WASM/WASI component instantiated fresh per invocation with **no ambient host access** — every host capability (filesystem read on a scoped directory, HTTP to an allow-listed host, a KV slice) is an explicit import the plugin's manifest must declare, and the host grants only what was declared and approved. This is WASI's capability model used deliberately as the security boundary, not as an incidental packaging format: a compromised or malicious plugin binary cannot escalate, because nothing beyond its declared imports is reachable from inside the sandbox — there is no ambient syscall surface to abuse.

### 3.2 Dependency isolation
A plugin's dependencies are linked **inside** its own WASM module; there is no shared, mutable, process-wide dependency graph the way native shared-library plugins have. One plugin's dependency version can never collide with or destabilize another's. Plugin-to-plugin interaction, when needed, goes through the host's typed `CapabilityRegistry` call — one plugin's exposed capability is invoked by the dispatcher like any other, never by a direct in-process call between two plugin instances.

### 3.3 Capability-based policy enforcement — git-native lifecycle (ADR-026)
A plugin's manifest declares, at publish time: the host imports it needs, the resource limits it requests, and the `effect_class`/`risk_tier` of every capability it exposes. Per **ADR-026** the manifest is a versioned *file* in the git-backed control repo, not a DB row, and its governance lifecycle **is** the git workflow itself — the **same** lifecycle every other control-plane definition follows:
- authoring on a **branch** is `DRAFT`;
- a **pull request** is `PENDING_APPROVAL` and runs the mandatory CI review gate — the **import-vs-declared-need** check (a plugin that asks for filesystem write to "read a config" fails the PR, not a shipped surprise) plus the §3.4 supply-chain scans;
- **merge** to the environment ref under CODEOWNERS is `APPROVED`;
- a **signed release tag** on the prod ref is `PRODUCTION` — the signed-tag-equals-production rule ADR-026 applies uniformly.

Authoring RBAC and the named owner come from CODEOWNERS; the audit trail is git history; the version and rollback handle are the tag/SHA. **Publishing** a plugin — including to the marketplace — is therefore *emitting a PR to a git repo*, never writing a database record: the marketplace is a federation of git repos of pinned plugin manifests (§3.4), and a publish is a PR against one that a maintainer merges.

### 3.4 Supply-chain security and signing (AD)
- Plugins are distributed as **signed artifacts** — a detached signature over the WASM binary and its manifest, tied to a verified publisher identity (keyless/transparency-log-style signing). The runtime verifies the signature and checks the publisher against an allow-list **before every load**, not only at install — a plugin that was legitimate yesterday and got its signing key compromised today does not get a free pass because it was already installed.
- The per-environment **plugin lock-file is the plugin-specific case of the control repo's `control.lock`** (ADR-026): it records `{plugin_id, version, content_hash, signer}` and is itself a versioned, reviewed file, so "what is approved to run in this environment" is a git-tracked, rollback-able fact rather than mutable runtime state. Because a compiled `run.wasm` is too large to live in the control repo directly, the binary is stored in **git-LFS or a content-addressed object store and pinned *by hash* in the lockfile** — the git repo carries the manifest and the hash-pin, the object store carries the bytes. A hash mismatch between the fetched binary and its lockfile pin at load time is a hard failure — the runtime never silently executes a binary that doesn't match what was reviewed and approved.
- Publish-time scanning: a dependency/vulnerability scan over the plugin's declared dependency manifest, plus a sandboxed dry-run in the Breaker's environment exercising every declared capability against synthetic inputs — a malicious or simply broken plugin is expected to surface *before* `APPROVED`, the same "quality is a gate, not an aspiration" discipline the runtime applies everywhere else.
- No plugin embeds its own model runtime or executes native code outside WASM; a plugin needing inference calls a governed `model.infer` capability instead — this keeps exactly one trust boundary (the sandbox) rather than a plugin quietly opening a second one.

### 3.5 Resource limits
Per-invocation CPU-time slice, memory ceiling, and wall-clock timeout are enforced by the **host** (epoch-based interruption / a resource limiter the guest cannot see or disable) — a runaway or adversarial plugin is killed, not merely slow, and cannot starve co-located plugins or the turn it was called from. Limits are configurable per plugin risk tier but bounded by a hard platform ceiling nothing can exceed. Plugin instances are stateless across invocations by default; persistent state requires an explicitly declared and granted scoped KV capability — bounding the blast radius of a compromised plugin to a single call unless state access was deliberately reviewed.

---

## 4. Model Router — a compliance component that also optimizes

The router's job, in order, is: **exclude what is not allowed, then rank what remains.** Cost/latency/quality preference is never allowed to reach into the excluded set.

### 4.1 Candidate selection (in order — the ordering is the design)
```
1. tier_eligible   = models matching the task-type's policy tier (CLAUDE.md model table)
2. class_eligible  = tier_eligible ∩ {models allowed for this turn's data class}   ← §4.2, non-overridable
3. not_regressed   = class_eligible ∩ {models not currently quality-flagged}       ← §4.3
4. rank(not_regressed) by (quality_score, -cost, -latency), weights per harness policy
5. select top; on failure, walk the FAILOVER CHAIN — but the chain is itself
   pre-filtered to class_eligible (§4.4) — failover can never cross the data-class line
```

### 4.2 Data-class → model eligibility (N/O — the router as a compliance component)
Every turn's context is data-classified **before** any model is chosen: `{public, internal, confidential, regulated-payment, PII}`. Classification draws from three signals that must agree: the Compliance Gate's own findings on the assembled context, the chunk-level RBAC/data-class labels carried by retrieved content (the Context Fabric's security filter — same classifier, same labels, so retrieval and routing can never disagree with each other), and a static per-harness ceiling declared at authoring time (defense-in-depth: a harness can declare "this surface never touches regulated data" independent of what any single turn contains).

The eligibility matrix itself is **governed, versioned config, not code**:
```
regulated-payment, PII  → in-house OSS models ONLY (Kimi/GLM/Gemma/Qwen fleet)
confidential            → in-house OSS, or a contracted private-tenancy deployment
                          with a data-processing agreement — never a generic public
                          cloud endpoint
internal, public        → any tier-eligible model
```
This is why self-hosting OSS models is a hard architectural requirement, not an option among several — the eligible set for the highest-sensitivity classes is empty without it. If, for a given turn, the eligible set is empty (regulated data plus a task type no in-house model currently handles well), the router **fails closed**: it returns the best in-house-eligible answer with an explicit low-confidence flag, rather than silently escalating to a cloud model that would violate residency. **A user's explicit model selection is a preference input to §4.1 step 4, never an override of step 2** — no user-facing "use gpt-5-5 anyway" path exists for a regulated-classified turn.

### 4.3 Quality as a live routing signal, not a static tier
Beyond the static tier table, the router consults a live per-model, per-task-type quality scoreboard fed by the evaluation platform (the same quality-drift discipline that gates prompt/model changes elsewhere). A model that has regressed on evals for a task type is deprioritized — or removed from candidates entirely below a floor — even though it nominally qualifies for its tier. This is what keeps "capability tier" from silently going stale as models are updated upstream.

### 4.4 Failover chains
Each tier declares an ordered fallback chain (e.g., SDLC's complex tier: in-house-eligible primary → in-house-eligible fallback, zero cloud for that specific policy). Failover triggers on provider error, timeout, an open circuit breaker (per `(provider, model)` pair, half-open probing to recover without a redeploy), or a `BLOCKED_MODELS` hit. The chain is filtered to `class_eligible` (§4.2) at construction time, not checked ad hoc during failover — there is no code path where a data-class-excluded model can ever be reached by walking the chain. An exhausted chain fails closed with an honest degraded response.

### 4.5 Prompt caching
Structural, provider-native prompt caching applies to the **stable prefix** of every assembled prompt — persona, behavioral skills, guard prompts, and large static context (KB namespace boilerplate, repo map) — leaving only the volatile tail (recent history + current turn) uncached. The Context Engine's deliberate stable-prefix-first assembly order exists specifically to make this caching effective rather than incidental. Cache state feeds back into §4.1's cost/latency ranking: a candidate with a warm cache for this session is cheaper/faster than the same model cold, so the router prefers cache-warm candidates among otherwise-tied options — sessions aren't bounced across models for a marginal gain that then loses cache warmth. For self-hosted models, the analogous mechanism is session-pinned KV-cache reuse across turns, coordinated by a router-emitted session-affinity hint to the inference-serving layer. This sits beneath, and is distinct from, the coarser full-turn semantic answer cache — prompt caching is the always-on layer under every call regardless of whether the coarse cache hits.

### 4.6 Live quality circuit-breaker (gap [23])
§4.3 makes quality a *ranking* signal; a sudden live regression demands more than deprioritization — it demands the route be pulled. The router watches the live judge-score stream (the evaluation platform scoring sampled production responses per `(model, task_type)`) and trips a **quality circuit-breaker** when the score drops past a threshold below the model's established baseline over a bounded window:
- **Auto-demote / quarantine.** The tripped `(model, task_type)` route is immediately removed from the candidate set (§4.1 step 3 treats it as quality-flagged) and traffic fails over to the class-eligible chain (§4.4) — a quality collapse is handled by the same mechanism as a provider outage, because to the user it is one. The breaker is per-`(model, task_type)`, half-open-probes to recover, and mirrors the transport circuit-breaker of §4.4 so there is **one** breaker discipline, not two.
- **Page + postmortem, automatically.** Tripping pages the on-call and **files the regression into the evaluation platform as a permanent regression scenario** — the exact turns that scored below baseline become a frozen eval case, so the same degradation can never silently return once the route is restored. A recovered route must pass that new scenario, not merely climb back above the live threshold. This closes the loop between live observation and the eval gate the rest of the doc leans on, rather than leaving a live drop as a dashboard someone might notice.

---

## 5. Acceptance / scenario tests

| # | Scenario | Setup | Expected | What it proves |
|---|---|---|---|---|
| 1 | Double-execution under retry | Agent calls a `SideEffecting` "create MR" capability; the response is lost to a network timeout after the downstream succeeded; the agent loop retries with identical semantic args | Exactly one MR exists; retry #2 returns the ledger's `COMMITTED` result without re-invoking the capability | Idempotency ledger (§1.2) — the payment-critical no-double-execution guarantee |
| 2 | Concurrent duplicate retries | Two retries of the same logical action race in parallel (e.g., a UI double-click + an internal retry) | Second caller blocks on the first's in-flight claim, then returns the same result; underlying capability invoked once | Ledger `PENDING`-collision handling, not just the sequential case |
| 3 | Saga partial failure | 3-step composite action; step 3 fails after 1–2 committed | Steps 1–2 compensated in reverse order; if a step is non-compensable, saga reports `FAILED_PARTIAL` with an incident note — never claims a clean rollback it didn't do | Saga/compensation honesty (§1.3) |
| 4 | Confused-deputy denial | User has no grant for `connector.postgres.query` on `ledger_accounts`; user asks the agent (which itself holds a broader service credential) to query it | Call is denied with a structured OBO failure; the agent's own broader credential is never substituted | Over-privilege / confused-deputy prevention (§1.6) — the core AI gap |
| 5 | Scoped grant boundary | User is granted `read-only` on `settlement_batches` only | Agent attempts a query against `settlement_batches` (succeeds) and against `ledger_accounts` (denied) in the same turn | Grants are resource-scoped, not capability-blanket |
| 6 | Sub-agent privilege inheritance | A parent turn's OBO context has a limited grant; the agent delegates a sub-task to a sub-agent | Sub-agent's calls are evaluated under the SAME OBO context; it cannot exercise a broader grant than the parent turn holds | OBO propagation across delegation, not just single-hop |
| 7 | Egress DLP on exfiltration attempt | A poisoned retrieved document instructs the agent to email a PAN-containing summary to an external address | Outbound payload is inspected pre-send; PAN is redacted or the send is blocked; unknown external domain soft-blocks pending approval | Egress DLP (§1.7) — the exfiltration half of the injection/exfiltration chain |
| 8 | Resource lock serialization | Two turns concurrently call capabilities sharing a `resource_key` (same file / same ticket) | Calls serialize; no interleaved write; a third call on an unrelated resource proceeds in parallel, unaffected | Per-resource locking (§1.5) doesn't over-serialize |
| 9 | MCP server partial outage | 5 declared MCP servers in scope; 1 is unreachable at turn start | Turn proceeds with the other 4's capabilities; no turn-wide failure or stall waiting on the dead server | Lazy parallel per-server connection, independent state machines (§2.1) |
| 10 | Per-server-URL OAuth isolation | Two MCP servers share a display name but have different URLs; user authorizes one | The other remains `requires_auth`; revoking one server's token does not affect the other | OAuth keyed by `(user, server_url)`, not name (§2.2) |
| 11 | Tool ranking at scale | Registry holds 400+ capabilities; a common task ("open a Jira ticket") is asked | Top-K retrieval surfaces the correct ticketing capability; the always-visible core set (read/edit/bash/kb.search) is present regardless of ranking | Retrieval-based selection quality + core-set floor (§2.4) |
| 12 | Ranking escape valve | The needed capability is a rare one outside the top-K | `capability.search(query)` surfaces and makes it callable within the same turn | The escape valve prevents a silent capability dead-end |
| 13 | Plugin sandbox escape attempt | A plugin attempts filesystem access outside its declared scoped directory, or an HTTP call to a non-allow-listed host | Host denies the call; the attempt is logged; no effect outside the sandbox; plugin instance is terminated on repeated violation | WASI capability-based sandbox enforcement (§3.1) |
| 14 | Plugin resource exhaustion | A plugin busy-loops or allocates unbounded memory | Host kills the instance at the CPU-time/wall-clock/memory ceiling; the turn and co-located plugins are unaffected | Host-enforced resource limits (§3.5), not guest-cooperative |
| 15 | Plugin supply-chain tamper | A plugin binary's hash no longer matches its lock-file entry, or its signature doesn't verify against the allow-listed publisher | Load is refused, at both install time and every subsequent load | Signing + lock-file verification (§3.4) — not install-time-only |
| 16 | Data-class leak via explicit override | Turn's context is classified `regulated-payment`; the user explicitly selects a cloud model | Router's `class_eligible` set excludes all cloud models regardless of the explicit selection; the selection is honored only among in-house-eligible candidates; verify at the network layer that no request leaves the deployment boundary | Data-class exclusion is non-overridable (§4.2) — the router as compliance, not preference |
| 17 | Failover doesn't cross the class boundary | The in-house-eligible primary and fallback are both down for a `regulated-payment` turn | Router fails closed with an honest degraded response; at no point is a cloud model attempted | Failover chain pre-filtered to `class_eligible` (§4.4) |
| 18 | Retrieval/routing agreement | A regulated-classified document chunk exists in the KB | It is excluded from context assembled for a cloud-eligible model's prompt (Context Fabric security filter) exactly as it would be excluded from the router's model choice — same classifier, same labels | Class-awareness is consistent across retrieval and routing, not two systems that can disagree |
| 19 | Cache correctness on prompt change | A harness's system prompt changes mid-session (e.g., a skill is hot-updated) | The next turn's model call reflects the NEW stable prefix; no response is served against a stale cached prefix | Prompt-cache invalidation correctness (§4.5) |
| 20 | MCP manifest change on reconnect | A pinned MCP server adds a new tool and rewords an existing tool's description on the next connection | The changed/added tools are frozen out of planning; a structured re-approval prompt shows the exact diff; unchanged pinned tools keep working; nothing new reaches the model until a human re-pins | TOFU manifest pin + reconnect-diff re-approval (§2.5) — gap [2] |
| 21 | Remote tool shadowing attempt | An MCP server registers a tool named `bash` (or another server's `jira.create_issue`) | The native/other-server capability is unaffected; resolution is namespace-qualified; the remote tool cannot capture calls meant for the real one | Per-server namespace isolation (§2.5) — gap [2] |
| 22 | Detector DoS / super-linear latency | A crafted multi-megabyte payload with a pathologically-backtracking structure is fed to the egress and data-class detectors | Input is bounded before any pass; the RE2-class engine keeps every detector linear-time; the scan completes within its wall-clock budget or the action fails closed — no worker is pinned, latency stays bounded regardless of adversarial input | Detector DoS hardening (§1.9) — adversarial super-linear-latency bound, gap [20] |
| 23 | Lost-ack reconciliation | A `HighRisk SideEffecting` call fires against the downstream, then the process dies before the ledger row moves off `PENDING` | The reconciler sweeps the timed-out `PENDING` row, probes the downstream's actual state, and resolves it to `COMMITTED` or `FAILED`; an `Ambiguous`/no-probe case escalates to `MANUAL_RECONCILIATION` and pages on-call — never left indefinitely ambiguous | Active lost-ack reconciliation (§1.8) — gap [21] |
| 24 | Live quality collapse | A model's live judge-score for a task type drops past the breaker threshold below baseline over the window | The `(model, task_type)` route is auto-quarantined and traffic fails over to the class-eligible chain; on-call is paged; the offending turns are filed into the eval platform as a permanent regression scenario a recovered route must pass | Live quality circuit-breaker (§4.6) — gap [23] |
| 25 | Git-native plugin publish gate | A plugin PR requests a filesystem-write import while its manifest only declares "read a config"; a second PR tries to reach `PRODUCTION` without a signed release tag | The CI import-vs-declared-need check fails the first PR at `PENDING_APPROVAL`; the second cannot be marked `PRODUCTION` without a signed tag on the prod ref; the lockfile hash-pin (a case of `control.lock`) governs the loaded binary | Git-native plugin lifecycle + control.lock hash-pin (§3.3/§3.4, ADR-026) |

---

## 6. Why this is now a 10

Every item the brief named has a concrete mechanism, not a principle statement: **one registry** spans native/MCP/plugin so nothing gets a second, weaker code path; **idempotency keys backed by a side-effect ledger** make exactly-once a runtime guarantee instead of a capability-author responsibility, with **saga compensation** for multi-step failures and **two-phase commit** gating the highest-risk actions; **per-resource locking** covers the concurrent axis the ledger doesn't; **OBO context threaded through sub-agent delegation** with **scoped, resource-level grants** closes the confused-deputy hole structurally (no fallback-to-ambient-credential path exists to close by policy alone); **egress DLP reusing the compliance classifier** closes the exfiltration half of the injection attack chain. MCP gets **lazy parallel per-server connections** with independent failure isolation, **per-server-URL OAuth** decoupled from provider auth, and **two-phase discovery + retrieval-based ranking with an always-visible core set and a search escape valve** — the concrete answer to "hundreds of tools degrade tool-choice." Plugins get a **capability-scoped WASI sandbox** (no ambient access, ever), **bundled dependency isolation**, governance-reviewed **capability-based policy**, **signed artifacts with load-time re-verification** and a **lock-file**, and **host-enforced resource limits** a guest cannot see or disable. The Model Router is redesigned around a **non-overridable data-class exclusion step that runs before ranking and before failover** — the concrete fix for the "model-agnostic contradicts data residency" architecture break — layered with a **live quality scoreboard**, **cost/latency-aware ranking among the eligible set only**, and **structural prompt caching** tied to the Context Engine's deliberate stable-prefix ordering, with a **live quality circuit-breaker** that auto-quarantines a route whose live judge-score collapses, pages on-call, and freezes the offending turns into the eval platform as a permanent regression scenario. MCP additionally gains **TOFU manifest pinning with reconnect-diff re-approval and per-server namespace isolation**, so a remote server can neither silently mutate the tool set the model plans against nor shadow a native capability. The compliance detectors are **DoS-hardened** — input bounded before every pass and all PII/PAN/secret patterns forced onto a guaranteed-linear-time RE2 engine — so the guard cannot itself become the outage. An **active lost-ack reconciler** resolves any settlement-adjacent ledger row stuck `PENDING` by probing the downstream's real state or escalating to manual reconciliation, never leaving it ambiguous. And per **ADR-026** the entire plugin lifecycle is **git-native** — branch = DRAFT, PR (with the import-vs-declared-need review) = PENDING_APPROVAL, merge under CODEOWNERS = APPROVED, signed release tag = PRODUCTION, publish = a PR to the marketplace git repo, and the plugin lock-file is the plugin-specific case of `control.lock` with the large `run.wasm` pinned by hash in git-LFS/an object store. Twenty-five scenario tests exercise exactly the properties that matter for a regulated payment org: an action cannot fire twice, a user cannot escalate through the agent, regulated data cannot reach an ineligible model, a remote server cannot silently mutate or shadow the tools the model plans against, a crafted payload cannot turn the compliance detectors into an outage, a lost ack cannot leave a settlement row ambiguous, and a live quality collapse pulls the route automatically — by construction, not by convention.

**Residual risks (honest, not deferred silently):** the quality scoreboard (§4.3) depends on the evaluation platform (gap C) existing and staying fresh — if it rots, "not regressed" quietly becomes "never checked." The data-class classifier (§4.2) is only as good as the underlying PII/PAN detectors and chunk-level ACL labels — a classification miss anywhere upstream is a leak the router cannot catch downstream. WASM/WASI plugin isolation is Phase 5 — until then, "programmatic custom capabilities" have no sandbox to land in, so scope creep into native code before the sandbox ships is the one path that would defeat §3 entirely. Tool ranking (§2.4) is itself a model in miniature and can regress like any retrieval system — it needs its own eval set, not an assumption that semantic similarity is always right. And exactly-once at the ledger is only as strong as the ledger's own durability and the idempotency-key derivation being truly semantic — a poorly chosen key (e.g., one that includes a timestamp) silently reopens the double-execution hole it exists to close. The lost-ack reconciler (§1.8) is only as strong as the downstream `reconcile` probes it calls — a capability with no probe degrades to human manual-reconciliation, whose throughput, not the code, becomes the bound. TOFU manifest re-approval (§2.5) still routes through a human: a reviewer who rubber-stamps every reconnect diff reopens exactly the hole the pin exists to close. Detector DoS hardening (§1.9) closes the *availability* failure (ReDoS, unbounded input) but not a detector rule that is simply *wrong* about a class — that remains the same upstream-accuracy dependency §4.2 already carries. And the quality circuit-breaker (§4.6) is a tuning problem in disguise: too tight and it flaps routes on eval noise, too loose and a real regression rides longer than it should — it is only as good as the live judge-sampling volume feeding it.
