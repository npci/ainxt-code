# Gap Analysis — What Mature AI Platforms Do That We Haven't Designed Yet

**Status:** Design brainstorm (no code). Honest self-critique of the AiNxt design vs how Anthropic / OpenAI / mature AI-platform teams operate.
**Framing:** Our design is strong on *architecture* (runtime spine, gates, harness model, adversarial test agent). The gaps are in the *empirical, safety, and lifecycle disciplines* — the things AI-native companies treat as core competency: **evaluation as a continuous loop, safety beyond data-leakage, the improvement flywheel, and LLMOps.** These are what make an AI system get *better and safer over time* instead of just *existing*.

Legend: 🔴 critical (esp. for a regulated payment org) · 🟠 high · 🟡 medium. "Have" = partially exists in the current Python platform.

---

## 🔴 CRITICAL gaps

### A. Agentic security — prompt injection (esp. *indirect*)
The single biggest blind spot. Our compliance gate stops *data leaving* (PII/PAN). It does **not** stop an attacker's instructions *entering* via content the agent reads — a malicious instruction hidden in a retrieved doc, a Jira comment, an email (Buddy), a web page, or a repo file that hijacks the agent to exfiltrate data, call tools, or bypass policy. For a tool-using, connector-wired, RAG-grounded agent this is the #1 threat.
- **What platforms do:** injection classifiers, data/instruction separation, tool-call allow-listing per context, "the model treats retrieved content as data, never instructions," dual-LLM patterns, taint-tracking, human confirmation on sensitive actions triggered by untrusted content.
- **Have:** nothing specific. **Must add** as a first-class layer in the pipeline (alongside compliance).

### B. Guardrails framework (beyond PCI redaction)
We have one specialized gate (PCI/DSS). Mature platforms run a *configurable rails framework* on input and output: jailbreak/prompt-injection detection, toxicity/harmful-content, topic/scope restriction, **groundedness/hallucination check** (is the answer supported by the retrieved sources?), format/schema validation, competitor/off-limits filters.
- **What platforms do:** OpenAI Moderation, NeMo Guardrails, Anthropic constitutional filters — pluggable, policy-driven rails.
- **Have:** compliance only. **Add** a general Guardrails layer with the compliance gate as one rail among many (all config-driven, per A1 principle).

### C. Evaluation & experimentation platform
The agent tester finds *breakage*. It does not measure *quality* continuously. AI-native companies live and die by evals: curated datasets, **LLM-as-judge at scale**, regression evals on **every prompt/model/retrieval change**, online A/B tests with real metrics, and RAG-specific evals (groundedness, context precision/recall, answer relevance — RAGAS-style).
- **What platforms do:** offline eval suites gate every change; online experiments measure real user impact; no prompt/model ships without an eval delta.
- **Have:** an evals dashboard exists but not eval-gated deployment or online experimentation. **Add** eval-as-a-gate + experimentation.

### D. Responsible-AI governance (regulatory)
As an RBI-regulated payment org (and with EU-AI-Act-style regimes spreading), AI-specific governance is mandatory, not optional: **model cards / system cards**, bias & fairness testing, **explainability** (why did the agent decide/answer this?), AI decision audit trails, human-oversight records, and an **AI incident-response** process.
- **What platforms do:** publish model/system cards, run bias evals, maintain transparency + incident processes.
- **Have:** the DRAFT→PENDING_APPROVAL→APPROVED→PRODUCTION lifecycle itself is now **satisfied** — it is git-native (ADR-026): branch=DRAFT, PR+CI=PENDING_APPROVAL, merge=APPROVED, signed tag on an env/prod ref=PRODUCTION, with CODEOWNERS as authoring RBAC and git history as audit. What's still missing is AI-specific: model/system cards, fairness evals, explainability, AI incident response. **Add** those artifacts as control-plane definition content under the same ADR-026 governance, not a new lifecycle.

---

## 🟠 HIGH gaps

### E. The data flywheel (continuous improvement loop)
The core competency of AI companies. We have no designed loop that turns usage into improvement: capture **feedback** (thumbs, corrections, abandonment, edits), curate it, and feed it back into prompts, retrieval, eval sets, and fine-tuning. Without this the product is static.
- **Add:** feedback capture → curation → auto-generated eval cases + retrieval/prompt improvements + fine-tune data.

### F. LLMOps — prompt & model lifecycle
Prompts and model choices are code and need the same rigor: a **prompt registry** with versioning + A/B + eval-before-deploy; **model migration/deprecation** handling (a provider retiring a model shouldn't break prod); reproducible prompt/model pinning per environment.
- **Have:** the prompt-registry and env-pinning half of this is now **satisfied** via ADR-026 — prompts are versioned files in the git-native control plane, PR review is the maker-checker/A/B-candidate gate, and a signed tag on a per-env ref *is* reproducible prompt/model pinning + rollback (no separate registry or pinning mechanism needed). **Still open, and not a DB lifecycle:** eval-before-deploy as a CI gate on the PR (ties to C) and model migration/deprecation handling when a provider retires a model.

### G. RAG quality engineering
We designed hybrid retrieval mechanically but not as an *engineered, evaluated* discipline: chunking-strategy selection, embedding-model **eval/selection**, reindexing/freshness pipelines, **citation accuracy** verification, knowledge-conflict resolution (two docs disagree), and retrieval eval as a gate.
- **Have:** hybrid retriever. **Add** RAG evaluation + chunking/embedding strategy + reindex pipelines.

### H. Fine-tuning / customization / distillation (for in-house OSS models)
We host OSS models (Kimi/GLM/Gemma/Qwen) but haven't designed customizing them: **LoRA/adapters** on NPCI data, **distillation** (frontier model → local model to cut cost while keeping quality), and safe fine-tune data pipelines (with poisoning defense).
- **Add:** a fine-tune/distillation pipeline + adapter registry, governed.

### I. Cost & latency optimization stack
Beyond routing: **prompt caching** (Anthropic-style — huge cost/latency win on repeated context), **semantic response caching**, request **batching**, speculative decoding, KV-cache reuse for local models, and per-turn cost attribution/budgets.
- **Have:** answer cache; circuit breaker. **Add** prompt/semantic caching + batching + speculative decoding.

---

## 🟡 MEDIUM gaps

### J. LLM-specific observability
Beyond OTel: token-level tracing, **per-turn/-user cost attribution**, prompt/completion logging (PII-safe), **quality-drift detection**, feedback correlation, and **trace replay** for debugging a bad turn.
- **Have:** OTel/telemetry, trace store. **Deepen** for LLM specifics.

### K. Developer experience for internal builders
A **playground** (try prompts/models/profiles interactively), **eval-driven development** workflow, and a prompt/harness IDE — so NPCI teams build quality harnesses, not PoCs.
- **Add** to the P5 platform + SDK.

### L. Advanced memory & user modeling
Long-term memory management (what to remember/forget/expire), user modeling, and memory conflict resolution — beyond session/episodic storage.
- **Have:** memory runtime (basic). **Deepen.**

### M. Multi-agent orchestration robustness
Agent-to-agent handoffs, delegation contracts, sub-agent cost roll-up, and failure isolation across a fleet — mature beyond "orchestrator calls AgentRunner."
- **Have:** in-feature orchestration. **Harden** for fleets.

---

## What we already cover well (for balance)
Runtime spine + gates; RBAC/ABAC + multi-tenancy; PCI/DSS compliance (redaction); model-agnostic routing + constrained decoding; the adversarial test agent (correctness/breakage); strangler-fig migration + shadow mode; clean-room + OSS/IP discipline; hybrid RAG (mechanically); HITL for SDLC; circuit breaker + backpressure.

---

## Recommended integration into the plan
- **P0:** add ADRs for **Guardrails (B)**, **Agentic security / prompt injection (A)**, **Evaluation platform (C)**, **Responsible-AI governance (D)** — these are safety/quality foundations, not afterthoughts.
- **P1:** the Guardrails layer + prompt-injection defense ship *with* the compliance gate (same pipeline seam). LLM observability (J) built in from turn one. Prompt caching (I) in the Provider Gateway.
- **P3:** RAG quality engineering (G) lands with the Chat/Code profiles; groundedness rail (B) gates answers.
- **P4/P5:** the data flywheel (E), LLMOps lifecycle (F), fine-tuning/distillation (H), playground/eval-driven DX (K), and responsible-AI artifacts (D) as platform capabilities.
- **Continuous:** eval-gated deployment (C) — no prompt/model/retrieval change ships without an eval delta; the test agent + eval platform together are the DoD.

**Bottom line (first pass):** the highest-value missing pieces are **(A) prompt-injection/agentic security, (B) a guardrails framework, (C) evaluation-as-a-continuous-gate, and (E) the improvement flywheel** — because those four turn a well-architected runtime into an AI system that is *safe and gets better*.

---

# Part 2 — Deeper gaps (second pass): the regulated-FI + self-hosting + agentic-actions lens

The first pass listed what *AI companies* do. This pass asks the harder question: what does a **payment institution under RBI, running self-hosted models, whose agents take real side-effecting actions**, additionally need? Several of these are more dangerous than Part 1 — one silently breaks a core assumption of our architecture.

## 🔴 The architecture-breaking one

### N. Data residency & sovereignty — and the cloud-routing contradiction
Our design happily routes to Claude/GPT/Gemini in the cloud. **For NPCI that may be illegal for sensitive payment/customer data** — RBI mandates payment data stays in India; DPDP constrains cross-border transfer. **Every cloud model call ships context abroad.** This is not a feature gap; it *contradicts* the model-router-picks-the-best-model design.
- **Resolution (must design now, ADR-012):** the Model Router becomes a **compliance component**. Data is **classified** (public / internal / confidential / regulated-payment / PII); a data-class → model-eligibility matrix routes **regulated/PII data to in-house OSS models only** (this is *why* Kimi/GLM/Gemma/Qwen hosting is mandatory, not optional), while non-sensitive traffic may use cloud. Retrieval/context assembly must also be class-aware (you can't RAG a regulated doc into a cloud prompt). This reframes the whole "model-agnostic" story as "compliance-gated model-agnostic."

## 🔴 Regulated-financial-institution gaps (likely mandatory)

### O. Data classification & purpose limitation
Feeds N. Classify data sensitivity; enforce which models/tools/connectors may touch which class; enforce purpose limitation + consent (DPDP). No capability sees data above its clearance.

### P. Model Risk Management (RBI / SR 11-7 style)
Financial institutions must formally govern models: a **model inventory**, independent **model validation**, **challenger models**, ongoing performance monitoring, and documented model risk. The DRAFT→PRODUCTION lifecycle question is already answered — it's git-native maker-checker per ADR-026, not a DB status field — but that answers *how a model version gets promoted*, not model-risk-specific content (inventory, independent validation, challenger models, performance monitoring). Those remain open and are additive artifacts inside the same control plane. (ADR-014.)

### Q. Data lifecycle — retention, erasure, minimization
We store the Event Log "forever" — that **conflicts with DPDP retention limits + right-to-erasure**. Need: retention policies, per-user erasure (delete a user's conversations/memory/traces), PII-minimized logging, and memory consent/user-control ("what do you remember about me?"). (ADR-015.)

## 🔴 Correctness & safety of ACTIONS (the agentic side-effect class)

### R. Idempotency / exactly-once for side-effecting tools
An agent that **retries** "create MR", "send email", "initiate settlement", "post to ledger" can **double-execute**. In a payment context, double-execution = **double payment**. Need **idempotency keys** per action + a **side-effect ledger** that dedupes retries. This is a concrete, high-severity gap our tool runtime hasn't addressed. (ADR-013.)

### S. Transactionality / compensation (sagas)
Multi-step agent actions with side effects need rollback: step 3 fails after steps 1–2 committed → **compensating actions** (saga pattern), or a dry-run+commit two-phase. Otherwise the agent leaves the world half-changed.

### T. Egress control / outbound DLP
The mirror of prompt injection: an agent with web/tool/connector access can **exfiltrate**. Need outbound allow-listing + DLP on what agents send out. Pairs with A (injection in, exfiltration out = the full attack chain).

### U. Uncertainty, calibration & abstention
For payments, a **confidently wrong** answer is worse than "I don't know." The system needs uncertainty estimation, calibrated confidence, **abstention**, and **escalation to a human** on low confidence / high stakes. Knowing when *not* to answer/act is a safety property we haven't designed.

## 🟠 Economics & inference operations

### V. FinOps / cost governance
Beyond a budget cap: cost **forecasting**, **anomaly detection** (a looping agent burning $$$), per-user/dept **chargeback/showback**, and **graceful degradation** when a cap is hit (downgrade model, not hard-fail).

### W. Inference serving operations for self-hosted models at scale
"Host Qwen/GLM" hides a serious ops discipline: **GPU capacity planning**, **vLLM/TGI batching** for throughput, autoscaling, cold-start/model-load latency, quantization trade-offs, and multi-model memory management — to actually hit 2,000 req/s on OSS models. Ollama ≠ production inference serving.

## 🟠 Reliability & quality engineering

### X. Forensic reproducibility & behavioral regression
For audit ("explain this decision 2 years later") and for change safety: capture the **exact prompt + context + model version + params + seed** per turn for **deterministic replay**; and on any prompt/model change, run **behavioral diffing** across the eval set (how did the *distribution* of answers shift), not just pass/fail.

### Y. SLOs / error budgets / degraded modes
Define AI SLOs (latency, availability, **quality**) and error budgets; design per-component degraded modes (provider down → fallback/local; vector DB down → keyword-only; connector down → soft-skip) as first-class, not incidental.

### Z. Knowledge freshness, source-conflict arbitration & data lineage
RAG indexes go **stale** (staleness tracking + reindex triggers); two sources **disagree** (recency/authority arbitration); and every answer needs **data lineage** (which records/docs contributed) for audit, debugging, and erasure.

### AA. Grounding / citation faithfulness
Beyond *having* citations — **verify the citation actually supports the claim** (faithfulness check), a specific groundedness rail under B.

### AB. Semantic tool/capability selection at scale
With hundreds of capabilities, dumping all schemas degrades model tool-choice and burns tokens. Need **retrieval-based tool selection** (surface only the relevant capabilities per turn).

## 🟡 Additional

- **AC. Content provenance / AI-output labeling** (mark AI-generated docs/code; C2PA-style) for audit/regulatory.
- **AD. Model supply-chain security** — OSS weight **provenance/signing/scanning** (a backdoored model is a real threat) + RAG/fine-tune **data-poisoning** defense.
- **AE. Localization/multilingual quality** — real quality across India's languages, not English-only (RAG + answers + evals per language).
- **AF. Accessibility (WCAG)** — enterprise/gov requirement for all UIs.
- **AG. Long-horizon task management** — hours/days-long tasks (SDLC, research): checkpointing, resumption, progress tracking, async notification.
- **AH. Human oversight & trajectory feedback** — feedback not just on final answers but on agent *trajectories* (was the approach right?), and defined human-oversight records for regulators.

---

## Revised top priorities (both passes)
**Design into P0/P1, non-negotiable:**
1. **N — data-class-driven routing** (breaks the architecture if ignored; makes OSS hosting mandatory). → ADR-012
2. **A + T — injection defense + egress DLP** (the full attack chain for an agentic system). → ADR-009
3. **R + S — action idempotency + compensation** (double-payment class). → ADR-013
4. **B — guardrails incl. groundedness (AA)**. → ADR-008
5. **C — evaluation-as-a-gate + X behavioral reproducibility**. → ADR-010
6. **P + Q — model risk management + data lifecycle** (regulatory). → ADR-014/015
7. **U — uncertainty/abstention/escalation** (confidently-wrong is dangerous).

**The one-sentence deeper insight:** the moment this system is (a) agentic with real side effects, (b) self-hosting for data sovereignty, and (c) under RBI — the hardest problems shift from "is the model smart" to **"can it act exactly once, keep regulated data in-country, know when it's unsure, and prove every decision later."** Those are the gaps that separate a demo from a system a payment regulator will actually allow into production.

---

# Part 3 — Third pass: delegation-security, ML-data-operations, delivery, product-UX, and the organizational gaps that quietly kill platforms

## 🔴 Delegation & retrieval security (subtle, high-severity, missed)

### AI. Confused-deputy / on-behalf-of authorization
The agent runs with **its own** credentials/capabilities. If it acts on a user's request but with its *own* (broader) privileges, a user can make it do things **they** aren't allowed to — classic **confused deputy / privilege escalation**. RBAC at the endpoint is not enough. The agent must act **as the user** (delegated/on-behalf-of authority), and authorization must be **fine-grained at the tool+resource level**: *can THIS user, via THIS agent, do THIS action on THIS resource?* — not "is the agent allowed." (Extends ADR-003.)

### AJ. Retrieval-time (chunk-level) access control — and PII-in-embeddings
Two linked holes:
- RBAC must filter **before ranking**. Post-filtering after retrieval **leaks existence** (the model/user learns a restricted doc exists, or it consumes the ranking slot). Retrieval must be permission-aware at the **chunk** level, applied pre-rank.
- **Embeddings of regulated data are still regulated data.** Vector inversion attacks can reconstruct PII from embeddings. A cloud embedding call, or a shared vector store, can leak regulated content. Embedding + vector storage must obey the same data-class rules as N/O.

### AK. Tamper-evident audit
A durable Event Log ≠ a **tamper-evident** one. A regulator needs **append-only, signed, WORM** audit that can't be altered after the fact. Design hash-chaining / signing into the audit trail from day one.

### AL. Secrets management discipline
Beyond FERNET: a real secrets story — vault integration, rotation, per-tenant keys, no secrets in prompts/logs/traces, and secret-scanning of everything the agent emits. (Pairs with T egress DLP.)

### AM. System-prompt / instruction leakage
Agents can be coaxed to reveal their system prompt, policies, or available tools (recon for an attack). Treat the system prompt as sensitive; detect/deny extraction attempts (a guardrail under B).

## 🟠 ML & data operations (real operational traps)

### AN. Embedding-model lifecycle & re-embedding migration
Changing the embedding model (or its version/dimension) means **re-embedding the entire corpus** — a massive, correctness-critical migration. Mixed-version embeddings silently degrade retrieval. Need embedding-version tracking, compatibility rules, and a re-index pipeline. (This alone can sink a RAG system.)

### AO. Vector index scaling & recall tuning
HNSW/ANN has a **recall vs latency vs memory** trade-off that must be *tuned and monitored* at scale (millions of vectors, 2,000 req/s). Silent recall degradation = silently worse answers. Plus online index rebuild without downtime.

### AP. "Lost in the middle" — context *positioning*, not just fitting
Models attend unevenly across the context window; relevant content buried in the middle is under-used. **Fitting** context to the budget (which we designed) is not enough — **positioning** (most-relevant at the edges, reranking for position) materially changes answer quality.

### AQ. Eval integrity — contamination, overfitting, holdouts
Evals rot: teams overfit to the eval set, eval data leaks into prompts/fine-tunes (contamination), and stale evals stop reflecting reality. Need holdout sets, eval-data governance, and rotation. (Extends ADR-010.)

### AR. Plan stability / anti-thrashing in long agent runs
Long autonomous runs can **thrash** — the agent changes its plan every turn, undoing prior work. Need plan persistence + change-justification + a thrash detector (distinct from the repetition stuck-detector).

## 🟠 Delivery & reliability

### AS. Progressive delivery for models & prompts (canary + auto-rollback)
Shadow mode (designed) compares offline. We still need **online canary**: route a small % of live traffic to a new model/prompt, watch guardrail metrics (quality/latency/cost/safety), and **auto-rollback on regression**. Prompts and models are the highest-churn, highest-risk changes.

### AT. Disaster recovery — RPO/RTO for AI state
Backup + recovery for the *AI-specific* state: Event Logs, memory, vector indexes, fine-tuned weights, connector tokens. Define RPO/RTO; test restores. (`ainxt_runtime_solution.md` lists DR as an NFR but there's no design.)

### AU. Time / clock / timezone awareness
LLMs have no clock. Agents reason about "today", schedules, SLAs, settlement windows, business days/holidays across timezones — all must be injected and handled explicitly, or the agent will confidently get dates wrong (dangerous for settlement).

## 🟠 Product & interaction UX

### AV. Conversation control — branch / edit / stop / steer
Users expect to stop mid-generation, edit a prior message and re-run, branch a conversation, or redirect the agent. This is core to feeling like ChatGPT/Claude and it needs first-class support in the Event Log (the tree model supports it — but the UX + protocol must expose it).

### AW. Trust & transparency UX + graceful error UX
Show sources/citations, confidence, "why did I get this / why this model," and let users **correct** — the UX of trust. And surface failures gracefully (not stack traces): partial-result handling, retry affordances, honest "I couldn't do X."

### AX. Multimodal I/O completeness
Full ingestion of images, audio/voice, files, and (Buddy) screen; and output modalities beyond text (audio, artifacts). Ensure the pipeline + compliance handle non-text modalities (PII in images, audio transcripts).

### AY. Collaboration — shared threads, team workspaces, sharing harnesses/agents
Enterprise work is collaborative: shared conversations, team workspaces, sharing/forking agents and harnesses, with RBAC. Absent from the design.

## 🟡 Organizational, OSS & lifecycle (where platforms actually die)

### AZ. Adoption & change management
The #1 reason internal platforms fail is **nobody uses them**. Need: a migration path off Kilo Code, user (not just dev) onboarding + docs, training, internal advocacy, and a "golden path" of vetted templates so teams don't start from scratch. Technical excellence ≠ adoption.

### BA. OSS community & release governance
Since it's open source: maintainership model, an **RFC process**, contribution + security-disclosure policy (SECURITY.md responsible disclosure), release cadence + semver, and public roadmap governance. Otherwise "open source" is just a license file.

### BB. Support model & platform SLAs
How users get help, report issues, and what the platform team commits to (SLAs, on-call, incident comms). A platform is a product with customers (internal teams).

### BC. Output ownership & licensing
Clarify ownership/licensing of AI-generated artifacts (code, docs) — can they be used commercially, what license attaches, provenance labeling (ties to AC). Matters legally once engineers ship AI-written code to production.

### BD. Team topology / ownership (Conway's law)
Who owns the runtime vs harnesses vs connectors vs evals; on-call; RACI. The architecture will mirror the org chart — design the ownership deliberately.

---

## Consolidated critical additions from Part 3 (design in, don't defer)
- **AI — on-behalf-of / fine-grained tool+resource authz** (confused-deputy). → ADR-003 extension. 🔴
- **AJ — pre-rank chunk-level ACL + PII-in-embeddings under data-class rules**. → ADR-012 extension. 🔴
- **AK — tamper-evident (signed/WORM) audit**. → ADR-011/015. 🔴
- **AN — embedding-model lifecycle / re-embedding pipeline** (silent RAG killer). 🟠
- **AS — online canary + auto-rollback for models/prompts**. 🟠
- **AU — explicit time/clock handling** (settlement-date safety). 🟠
- **AZ — adoption/change-management** (the platform-killer). 🟠

**Third-pass insight:** passes 1–2 asked "is it smart, safe, compliant, and provable." Pass 3 asks the questions that decide whether it *survives contact with reality*: **can a user escalate privilege through the agent, does restricted data leak through retrieval or embeddings, can the audit be trusted, will retrieval silently rot on the next embedding-model change, and will anyone actually adopt it.** Elegant architecture dies on exactly these unglamorous edges.

---

# Part 4 — The axis passes 1–3 under-weighted: INTELLIGENCE, output quality & experience

Passes 1–3 were the **"won't fail"** axis (secure/compliant/provable/operable). This pass is the **"is it actually good"** axis — reasoning quality, output quality, and interaction feel. This is the product's reason to exist: a safe, compliant system that gives shallow, messy, badly-formatted answers is a failed product. These gaps are *first-class*, not polish.

## 🔴 Reasoning & answer intelligence

### BE. Adaptive reasoning depth (thinking budgets)
We route by complexity to a model *tier* — but we never designed **how hard the model thinks**. Missing: extended-thinking / reasoning-mode budgets, chain-of-thought, **self-reflection**, self-consistency (sample-and-vote on hard problems), and **adaptive depth** (spend more reasoning on a settlement RCA than on a greeting). This is a top lever on answer quality and is entirely absent.

### BF. Answer quality as a measured, first-class dimension
Correctness ≠ quality. Is the answer **helpful, complete, well-structured, right-sized**, and does it actually resolve the ask? This must be **evaluated** (LLM-judge + human preference on helpfulness/completeness/format/tone) and **regression-tracked** — separate from the correctness/breakage the test agent covers.

### BG. Instruction-following & steerability
Models drift from explicit instructions (format, constraints, "only answer X", "in 3 bullets"). Precise instruction adherence is a measurable quality property that needs prompt design + evals, or the product feels like it "doesn't listen."

### BH. Numerical / tabular / data reasoning via tools (never trust model arithmetic)
LLMs are unreliable at math and multi-row data — **catastrophic for a payment org** (reconciliation, totals, rates). Offload all calculation/aggregation to **deterministic tools** (code exec, SQL, spreadsheet engine); the model orchestrates, never computes. A confidently-wrong sum is a payment incident.

### BI. Synthesis across sources (quality of RAG *use*)
Retrieval quality (Part 1 G) ≠ *using* it well. The model must **synthesize across multiple sources**, reconcile conflicts, and integrate — not quote one chunk. Multi-document reasoning quality is what makes grounded answers feel intelligent rather than copy-paste.

### BJ. Prompt engineering as an evaluated discipline + automated optimization
The **single biggest quality lever** is currently ad hoc. Need: a prompt-quality discipline, systematic iteration, and **automated prompt optimization** (DSPy-style: optimize prompts against the eval set) — treated with the rigor of code, per model (a prompt tuned for Claude ≠ tuned for Qwen).

## 🟠 Output quality & rendering (the "messy output" complaint)

### BK. Output formatting & rich rendering
Walls of text are the #1 "feels dumb" signal. Need clean, consistent **markdown/tables/code blocks**, and **rich artifacts** where appropriate — canvas/side-panel for long content, diagrams, charts, interactive elements — not everything crammed into the chat stream. Formatting is a quality feature, not cosmetics.

### BL. Tone / voice / persona consistency
A consistent, professional register (and a definable brand voice) across every surface and model. Inconsistent tone reads as unreliable.

### BM. Verbosity / length calibration
Right-sized answers: terse for simple asks, thorough for complex — matched to intent. Both over-explaining and under-explaining are quality failures.

### BN. Citations UX
Inline, verifiable, **clickable** citations (with faithfulness per AA). Grounding you can *see and check* is what converts "plausible" into "trusted."

## 🟠 Interaction intelligence (how it *feels*)

### BO. Perceived latency & streaming feel
Perceived intelligence ≈ responsiveness. Time-to-first-token, smooth streaming, and **"thinking" / progress indicators** during long agent turns. A fast, transparent stream feels smarter than a faster-but-silent one.

### BP. Proactivity, suggestions & capability discovery
Anticipate next steps, offer **suggested follow-ups**, and surface **what the system can do** (users don't discover capabilities on their own). Proactive help is the Copilot-grade experience differentiator.

### BQ. Clarification quality (the Goldilocks problem)
Ask the **right** clarifying question when genuinely ambiguous — and **only** then. Too many questions = annoying; too few = wrong answers (your UPI→PDF bug was partly this). Calibrated clarification is a hard, high-impact quality skill.

### BR. Progressive disclosure, interruptibility & easy correction
Show the right amount with expandable detail; let users steer/interrupt mid-turn (UX side of AV); and make correcting a wrong answer effortless (and let that correction improve future turns — ties to the flywheel E).

### BS. Personalization & continuity that feels natural
Adapt to the user's role, style, prior work, and preferences so it feels like a colleague who knows them — without being creepy (ties to memory consent Q). Continuity is a core "intelligence" perception.

## 🟠 Measuring & improving intelligence

### BT. Quality evals, quality-drift detection & quality-optimal routing
A quality eval suite (helpfulness/format/tone/instruction-adherence), **quality-drift detection** (did the last prompt/model change make answers worse, even if still "correct"?), and model selection that optimizes for **quality per task**, not just capability/cost. Without this, quality silently erodes.

---

## Consolidated critical additions from Part 4
- **BE — adaptive reasoning depth / thinking budgets** (top answer-quality lever). 🔴
- **BF + BT — answer-quality as a measured dimension + quality-drift detection**. 🔴
- **BH — numerical/data reasoning via tools** (payment-critical; never model arithmetic). 🔴
- **BJ — prompt engineering discipline + automated optimization** (biggest quality lever). 🔴
- **BK — output formatting & rich rendering** (the direct fix for "messy output"). 🟠
- **BQ — calibrated clarification** + **BP proactivity** + **BN citations UX** (the felt-intelligence trio). 🟠

**Fourth-pass insight:** security/compliance decide whether it's *allowed* in production; **intelligence + output quality + interaction feel decide whether anyone *wants* it there.** Both are first-class. The quality axis needs the same rigor we gave safety: measured (BF/BT), engineered (BE/BH/BJ/BI), and designed into the UX (BK/BN/BP/BQ) — not left to the base model and hope.
