# Reconciliation & Flagship Plan

**Status:** Canonical clarification. Resolves the "runtime vs 4-plane vs products" confusion and sets the next move.
**Decided (2026-07-24):** (1) `AINXT Enterprise Runtime v2.md` is a **re-articulation / review framing**, not a new build plan — nothing gets rebuilt toward it. (2) Open-source scope = **runtime core + SDKs + headless CLI only**; Desktop stays proprietary. (3) Next move = **this doc** + pick and spec ONE flagship surface.
**Read after:** `AINXT_OS.md` (the canonical model), `RUNTIME_SCORECARD.md` (build truth), `IMPLEMENTATION_PLAN.md` (phases).

---

## 0. The one-paragraph truth

There is **one thing**: the AiNxt Runtime — a Rust execution spine (65 crates, ~150K LOC, ~830 tests, ~7/10 build maturity) positioned externally as **"AiNxt OS."** Everything else is a *view* of it or a *client* on it. The `AINXT Enterprise Runtime v2.md` document is a **coarser, trust-boundary + cost lens** on the crates that already exist — useful for a security review, dangerous if mistaken for a greenfield backlog. The Python platform (~200K LOC) is the **shipping product** the runtime slots underneath via strangler-fig; it is not disturbed on day one.

---

## 1. The three lenses, collapsed

| Lens | Artifact | What it actually is | Action |
|---|---|---|---|
| **AiNxt OS** — runtime kernel + Studio factory + surfaces | `AINXT_OS.md` + the 65 crates | **The thing we built.** Canonical model. | Keep as canonical. |
| **4-plane Enterprise Runtime v2** — Security / Context / Runtime / Execution | `AINXT Enterprise Runtime v2.md` | A **re-articulation** of the same crates by trust boundary, weighted on Claude-cost. | Reconcile (this doc). Do **not** refactor crates to match it. |
| **Shipping products** — Python platform, grok-CLI fork, Desktop, connectors | `gateway.py`, `ai-ui/`, `ainxt-cli/` | **Production today.** | Untouched until strangler cutover, per-surface, shadow-first. |

---

## 2. v2 planes → existing crates (the reconciliation map)

The v2 doc's four planes are **not a new architecture**. They are the existing crates grouped by trust boundary. This map is the whole point of the reconciliation — it proves there is nothing new to build here.

| v2 Plane | Responsibility (per v2 doc) | Crates that already implement it |
|---|---|---|
| **Security Plane** | prompt firewall, injection detection, secret/DLP, compliance, tool/MCP authz, connector validation, audit, approval tokens | `ainxt-compliance` · `ainxt-guardrails` · `ainxt-injection` · `ainxt-identity` · `ainxt-governance` · `ainxt-oauth` · `ainxt-eventlog` (tamper-evident audit) |
| **Context Plane** | repo intelligence, snapshot/delta, conversation memory, context compiler, prompt fingerprinting, context cache, single-flight, prompt assembly | `ainxt-context` · `ainxt-retrieval` · `ainxt-memory` · `ainxt-prompt` · `ainxt-cache` · `ainxt-convo` · `ainxt-graph` · `ainxt-semantic` |
| **Runtime Plane** | planning, routing, streaming, model selection, tool planning, provider adapters | `ainxt-runtime` · `ainxt-planner` · `ainxt-providers` · `ainxt-classify` |
| **Execution Plane** | shell, docker, fs, git, python/node, OCR, MCP, REST, connectors — all behind signed authz | `ainxt-tools` · `ainxt-mcp` · `ainxt-wasm` · `ainxt-connector(-http)` · `ainxt-payments` · `ainxt-edit` |

### 2a. What the 4-plane model MISSES (why it's a lens, not the taxonomy)

The v2 model is a **runtime data-path** view. It has no box for two whole groups of crates that are central to why the platform succeeds:

- **Quality / Eval gate (cross-cutting, not a plane):** `ainxt-eval` · `ainxt-quality` · `ainxt-judge` · `ainxt-scenario` · `ainxt-conformance` · `ainxt-canary` · `ainxt-replay` · `ainxt-promptopt`. Per `AINXT_OS.md §5`, **nothing ships without passing eval + the Breaker.** The 4-plane diagram would let you forget this. The canonical model does not.
- **Control / Platform layer:** `ainxt-config` · `ainxt-protocol` · `ainxt-types` · `ainxt-client` · `ainxt-server` · `ainxt-runtimed` (composition binary) · `ainxt-cli` · `ainxt-surface` · `ainxt-profile` · `ainxt-session` · `ainxt-telemetry` · `ainxt-harness` · `ainxt-plugin`.
- **Workforce / Factory + domain surfaces + compliance-ops** also sit outside the four planes: `ainxt-workforce` · `ainxt-skill` · `ainxt-teams`; `ainxt-answer` · `ainxt-synthesis` · `ainxt-nl2sql` · `ainxt-artifact`; `ainxt-lifecycle` · `ainxt-responsibleai` · `ainxt-incident` · `ainxt-cryptoagility` · `ainxt-refresh` · `ainxt-serving` · `ainxt-token`.

**Takeaway:** use the 4 planes to *explain trust boundaries and the cost story to reviewers*. Use `AINXT_OS.md` (kernel + Studio + surfaces + quality gates) as the *architecture of record*.

---

## 3. What to KEEP from the v2 doc, and what to DROP

**Keep:**
- The **trust-boundary framing** — "Runtime never executes privileged ops directly; every execution needs a signed authz token." This is already true in the crates (`ainxt-tools` + `ainxt-identity`); the v2 doc states it crisply and is worth citing in security reviews.
- The **cost-optimization order** (repo-intelligence → context-compiler → snapshot → delta → compaction → fingerprint → single-flight → context-cache → response-cache). This is a good **backlog for the Context Plane subsystem** — several items exist (`ainxt-cache`, `ainxt-context`), some (snapshot/delta engines) are candidates to harden.
- The **OSS reference list** (ClamAV for content AV, ccusage for cost telemetry, etc.) — feed into `THIRD_PARTY_INVENTORY.yaml` review, subject to the legal gate.

**Drop:**
- The **"Phase 0..15, no coding, extract each plane"** sequence — it describes building what is already built. Superseded by `IMPLEMENTATION_PLAN.md`.
- Any implication of a **plane-based crate refactor.** The crate boundaries are the architecture of record; do not re-org 65 crates into 4 folders.
- The **cost-first identity.** Cost optimization is the Context subsystem's job, not the runtime's identity. Identity = intelligence + one-spine-many-surfaces + unbypassable safety (per `AINXT_OS.md`).

---

## 4. Build truth (do not re-litigate)

Per `RUNTIME_SCORECARD.md`: design ceiling 10/10 on the 19 dimensions; **build maturity ~7/10**. Built + tested: spine, all mandatory gates, tool runtime, MCP, WASM sandbox, hybrid RAG, governed memory, agent teams, eval platform, compliance detector, payments saga, serving control-plane, the **Skill/Role Factory** (`ainxt-workforce`), and **Chat wired end-to-end** (`ainxt-chat`).

**Uncloseable-in-code ceiling (the real remaining work):**
1. Legal **Gate #0** sign-off → blocks OSS release (`GATE_0_CHECKLIST.md`).
2. **Live infra at 2,000-user scale** (Postgres/Redis/GPU/vLLM) + real-load evidence.
3. **Real provider-key** runs.
4. **Python + TS SDKs** (only Rust client SDK exists).
5. Converge the two retrieval crates (`ainxt-context` lexical vs `ainxt-retrieval` hybrid).
6. The **NPCI private plugin** (PCI/DSS rules, AD-RBAC, IP connectors) — separate private repo.

---

## 5. Open-source scope (decided)

| Open-source — Apache-2.0, own repo | Proprietary — private |
|---|---|
| **Runtime core** (spine + gates-as-traits + generic defaults + protocol) | **NPCI plugin** (PCI/DSS rules, AD-RBAC, IP-bearing connectors) |
| **SDKs** — Python first, then TS | **Enterprise Desktop** (the rich, supported commercial surface) |
| **Headless CLI** — single static binary | **Managed deployment** (the "massive setup" — infra, ops) |

**Why not open-source the platform or Desktop:** it needs Postgres + Redis + Ollama + vLLM + GPUs + connectors + the compliance ruleset — un-adoptable as OSS and it leaks NPCI IP. The "massive setup" objection dissolves once split: **OSS = one binary + `pip install`; enterprise = the documented managed deployment.** Enforced by the core/enterprise split (ADR-028). Desktop is a *renderer over the runtime*, kept proprietary.

---

## 6. Flagship — narrow but perfect

Per `AINXT_OS.md §5`: we launch **the Runtime + the Studio + ONE flagship surface executed flawlessly** — not six at 60%.

**Recommended flagship: Chat.** Rationale — it is (a) already wired end-to-end in the runtime (`ainxt-chat`: cache → conversation-intelligence → grounded-retrieval → prompt-engine → Engine with StrongRedactor + RBAC + failover), (b) the **most measurable** surface (intent cascade, referent resolution, quality-eval-able), and (c) the lowest-risk proof that the spine + gates + quality gates actually work end-to-end under a real surface.

**Alternative: SDLC.** Higher enterprise value and already validated in Python — but a large, high-risk surface to make "flawless" as a *first* proof. Better as the **second** composition once the spine is proven by Chat.

*(This is the one open decision inside this doc — see §8.)*

**Flagship Definition of Done (both gates, non-negotiable):**
- Quality-eval suite green (helpfulness/completeness/format/tone + no quality-drift regression).
- The **Breaker** (adversarial) passed: injection, PII/PAN, over-privilege, output-quality edge cases.
- Runs on the runtime under the Python gateway in **shadow mode** with parity vs. the current Python path *before* any cutover.

---

## 7. Strangler-fig integration path (for the flagship, when we start code)

1. Runtime runs as a **separate service** called from `gateway.py` (do not disturb Python).
2. Feature-flag the flagship surface to the runtime path; default OFF.
3. **Shadow mode**: send the request to both paths, compare outputs, log divergence — no user impact.
4. Parity green → flip the flag for a canary cohort (`ainxt-canary` + auto-rollback).
5. Full cutover for that one surface. Python code for it retires only after.
6. Repeat per surface. Fragmentation is impossible — there is one spine.

---

## 8. Plan of record & open decisions

**Sequence:** (1) this doc ✔ → (2) pick + spec the flagship → (3) shadow-wire it under the Python gateway → (4) drive legal Gate #0 in parallel → (5) live-infra scale proof → (6) extract OSS runtime repo + SDK + CLI, keep NPCI plugin + Desktop private.

**Explicitly NOT doing:** re-planning from the v2 doc; refactoring crates into 4 planes; open-sourcing the platform or Desktop; disturbing the Python production path before shadow parity.

**Open decision:** confirm the flagship — **Chat (recommended)** vs SDLC.
