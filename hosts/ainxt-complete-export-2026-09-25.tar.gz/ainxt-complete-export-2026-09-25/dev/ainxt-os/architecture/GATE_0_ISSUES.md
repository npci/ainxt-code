# Gate #0 — Legal/OSS Clearance: hand-off issues

Copy-paste-ready issues for the tracker / legal. Each is scoped so a non-engineer can action it.
Companion to `GATE_0_CHECKLIST.md` (status) and `RUNTIME_SCORECARD.md` (build state).

**Priority key**
- **P0 — REQUIRED before any public push.** Legally load-bearing; publishing without it is an IP/copyright defect.
- **P1 — Strongly recommended.** Not a hard legal blocker, but a payments-adjacent OSS project should not go public without it (or should consciously accept the risk).
- **P2 — Deferrable.** Only bites once you accept external contributors; can land after the first public tag.

Engineering status as of 2026-07-20: license = Apache-2.0; `cargo deny` FULLY green (advisories + licenses + bans + sources, incl. the reviewed `Apache-2.0 WITH LLVM-exception`); third-party inventory generated; core/enterprise split enforced by construction. So the items below are the **human/legal** remainder.

---

## P0 — Required before the repo goes public

### GATE0-1 — Authorize the OSS release + set the copyright holder
- **Owner:** Project Owner + Legal
- **Why:** An OSS release needs an entity that (a) owns/controls the copyright and (b) authorizes releasing it under Apache-2.0. `NOTICE` currently says `[COPYRIGHT HOLDER — set at Gate #0]`. Without this the release is legally incoherent.
- **Acceptance:**
  - [ ] Legal confirms which entity owns the copyright in the `runtime/` code and may license it.
  - [ ] That entity formally approves an Apache-2.0 public release.
  - [ ] `runtime/NOTICE` and per-file headers set to the real copyright holder + year.
- **Refs:** `runtime/NOTICE`, `runtime/LICENSE`, ADR-007.

### GATE0-2 — Extract `runtime/` into its own standalone repository (no proprietary leak)
- **Owner:** Eng (execution) + Legal (sign-off)
- **Why:** The OSS tree currently lives **inside the proprietary monorepo**. Publishing from here risks leaking NPCI PCI/DSS rules, AD-RBAC, and IP-embedding connectors. The core/enterprise split must be verified *at the extracted repo*, not just asserted.
- **Acceptance:**
  - [ ] `runtime/` moved to a fresh standalone repo with clean git history (no proprietary commits carried over).
  - [ ] Automated scan confirms **zero** NPCI-specific PCI/DSS / AD-RBAC / IP-connector code or secrets in the extracted tree.
  - [ ] `cargo deny check`, `cargo clippy --workspace --all-targets`, and `cargo test --workspace` all green in the standalone repo's CI.
  - [ ] Legal signs off that the extracted tree contains only OSS-cleared material.
- **Refs:** ADR-028 (core/enterprise split), `GATE_0_CHECKLIST.md` §D.

### GATE0-3 — Final third-party license + provenance review
- **Owner:** Legal (review) — Eng has prepared the evidence
- **Why:** The dependency tree must be legally clean. Engineering has the gate green; legal should do the formal review, incl. the two reviewed exceptions.
- **Acceptance:**
  - [ ] Legal reviews `THIRD_PARTY_LICENSES.md` (machine-generated inventory).
  - [ ] Legal confirms the `deny.toml` exceptions are acceptable: `CDLA-Permissive-2.0` (webpki-roots CA-data) and `Apache-2.0 WITH LLVM-exception` (wasmtime/cranelift).
  - [ ] Confirm no copyleft (GPL/LGPL/AGPL/MPL/EPL/CDDL/BUSL/SSPL) anywhere in the tree (currently enforced by the permissive-only allow-list).
- **Refs:** `runtime/THIRD_PARTY_LICENSES.md`, `runtime/deny.toml`.

### GATE0-4 — Clean-room provenance attestation
- **Owner:** Legal + Eng
- **Why:** The runtime is a clean-room rewrite (the prior Claude-Code-derived CLI was scrapped for IP reasons). Legal should attest the provenance record is sufficient.
- **Acceptance:**
  - [ ] Legal reviews the ADRs + vendor-studies as the clean-room evidence trail.
  - [ ] Confirm no vendor identifiers/prompts/layouts survive (the `deny.toml` denylist for vendor tokens is a mechanical check; legal makes the call).
- **Refs:** `docs/architecture/adr/`, `docs/architecture/vendor-studies/`, VENDOR_SYNTHESIS.md.

---

## P1 — Strongly recommended (or consciously accept the risk)

### GATE0-5 — Trademark clearance for the "AiNxt" name — OR publish under a neutral name
- **Owner:** Legal
- **Why:** Publishing under a brand you haven't cleared risks a trademark conflict. **Cheap alternative:** publish under a neutral/placeholder name and defer branding — this de-risks without blocking.
- **Acceptance:**
  - [ ] Legal clears "AiNxt" for public use, **or**
  - [ ] Owner picks a neutral public name and it's applied across `Cargo.toml`, docs, README.
- **Refs:** `GATE_0_CHECKLIST.md` §B.

### GATE0-6 — Liability / indemnity / responsible-use posture
- **Owner:** Legal
- **Why:** Apache-2.0 already disclaims warranty (§7) and limits liability (§8), so the *license* covers the baseline. For a **payments-adjacent** project a bank will still want an internal risk sign-off + a responsible-use note (this is prudence, not a license gap).
- **Acceptance:**
  - [ ] Legal confirms the Apache-2.0 disclaimer is sufficient, or adds a responsible-use / "not certified for production payment authorization without your own validation" note.
  - [ ] Internal risk owner signs off on releasing payments-adjacent infra as OSS.
- **Refs:** ADR-019, ADR-011.

### GATE0-7 — Real repository URL + monitored security contact
- **Owner:** Owner + Eng
- **Why:** `Cargo.toml` says `repository = "https://example.invalid/ainxt-runtime"` and `SECURITY.md` uses an unmonitored placeholder. Running an OSS security process needs a real, monitored inbox.
- **Acceptance:**
  - [ ] Set the real repo URL in `runtime/Cargo.toml` (`[workspace.package].repository`).
  - [ ] Set a monitored security address in `SECURITY.md` (a real inbox someone watches).
- **Refs:** `runtime/Cargo.toml`, `runtime/SECURITY.md`.

---

## P2 — Deferrable until you accept external contributors

### GATE0-8 — Contribution governance: DCO vs CLA + real maintainer teams
- **Owner:** Legal + Owner
- **Why:** Only matters once you take external PRs. DCO is the documented default; a bank may prefer a CLA. The `@ainxt-*` CODEOWNERS handles are placeholders.
- **Acceptance:**
  - [ ] Legal confirms DCO (default) or switches to a CLA; `CONTRIBUTING.md` updated.
  - [ ] Real teams behind `CODEOWNERS` / `MAINTAINERS.md` / `GOVERNANCE.md`.
  - [ ] Pre-receive PII/secret gate (ADR-026 §10) installed on the git host.
- **Refs:** `runtime/CONTRIBUTING.md`, `runtime/CODEOWNERS`, `runtime/GOVERNANCE.md`, `runtime/MAINTAINERS.md`.

---

## Bottom line for the owner

**Genuinely required before a public push:** GATE0-1 (copyright + authorization), GATE0-2 (standalone-repo extraction + no-leak audit — the big one), GATE0-3 (final license review), GATE0-4 (provenance attestation). Everything else is stage-able. If you want the *fastest* legal path: clear GATE0-1..4, publish under a neutral name (defers GATE0-5), lean on the Apache-2.0 disclaimer (defers most of GATE0-6), set the two real addresses (GATE0-7), and defer GATE0-8 until the first external contributor.
