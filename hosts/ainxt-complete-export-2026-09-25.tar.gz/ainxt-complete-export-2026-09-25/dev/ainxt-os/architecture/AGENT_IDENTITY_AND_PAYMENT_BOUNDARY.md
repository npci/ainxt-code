# Agent Identity & the Payment Boundary — design to 10/10

**Status:** Design (no code). Two net-new P0 ADRs embedded as the two halves of one doc, because they answer the two halves of one question.
**Closes:** Pass-5 gaps **[1]** (agent-initiated-payment / agentic-commerce authorization boundary — new P0 **ADR-016**), **[16]** (non-human/agent identity lifecycle — new **ADR-022**), and hardens **[AI]** (confused-deputy / on-behalf-of authz) and **[17]** (compromised agent forges a peer's approval) at the *identity* layer that TOOLING solved only at the grant layer.
**Relates to / extends:** ADR-002 (Tool+MCP Runtime / one `CapabilityRegistry` — where `effect_class` lives), ADR-003 (Policy/Approval/Compliance seam + OBO — the per-turn authz engine), ADR-007 (execution Event-Log / tamper-evident audit — where the *actor* is recorded), ADR-012 (data-class → model routing — the other non-overridable exclusion), ADR-013 / `TOOLING §1.2–1.4` (Side-Effect Ledger / saga / two-phase commit — the substrate the payment class sits atop), ADR-020 / `SERVING_OPS.md` (the fleet that drains under a kill-switch), ADR-021 (Hardware-Trust / TEE — the root the attestation chains to), ADR-023 (Crypto-Agility / PQC — the rotation abstraction identity keys use), ADR-025 (evidentiary admissibility — the actor record must be court-grade), ADR-026 (Control-Plane Git-Native — where the *policy* half of both ADRs is authored), ADR-027 (Long-Horizon Programs — the source of the long-lived Run actors §20 watches).
**One line:** the runtime knows exactly **who** every agent is — a per-Run, individually-revocable, attested machine identity, never a shared token — and there is exactly **one thing that "who" can never be wired to do**: move value. Identity is designed so attribution is always a specific actor; the payment boundary is designed so that no actor, role, skill, tool, plugin, program, or harness can ever cross it, because there is no code path on the other side.

---

## 0. Why these two ADRs are one document

Agent identity and the payment boundary are the *subject* and the *predicate* of the same sentence a regulator will ask: **"which non-human actor did this, under whose authority, and could it ever have moved money?"** Answering the first half requires ADR-022 (a real, attributable, revocable identity per agent); answering the second requires ADR-016 (a structurally uncrossable value-movement boundary). Split across two docs they leave a seam; together they close it: **every action is attributed to an attested identity (ADR-022), and the one action-class that identity can never reach is payment initiation (ADR-016).** The identity makes the boundary *auditable* (we can prove who tried); the boundary makes the identity *safe to grant* (the worst a compromised identity can do is bounded below "moved settlement").

Both are **P0 go-live blockers, not enhancements** (`GAP_ANALYSIS_PASS5.md` §A, `IMPLEMENTATION_PLAN.md` P0): ADR-016 must be decided *before any workforce-action code exists*, and ADR-022 must be decided before any agent acts under a credential of its own.

### Cross-cutting decisions honored (binding)

Both ADRs are written to sit *inside* the two architecture-defining decisions already accepted, not beside them.

- **[Q2 — Control-Plane is Git-Native, ADR-026].** Everything in these ADRs that is a **definition** — the payment-boundary policy, the CODEOWNERS payments-council, the `payment_boundary` front-matter class, the identity-issuance policy, SoD rules, kill-switch authority, anomaly thresholds — is a **versioned file in the git control plane**, governed by CODEOWNERS + branch protection + signed commits, PII-free, never a DB row and never hardcoded. Everything that is **operational state** — issued credentials, revocation lists, live Run identities, anomaly baselines, mandate instances — is **data-plane** (Postgres/Redis), erasable/rotatable per ADR-015, never in git. §7 and §21 state this split explicitly for each ADR. The rule ADR-026 already added — a `payment_boundary != none` definition requires the payments-council CODEOWNERS group *and* an `ad_level<=3` signed commit — is the **authoring** catch that ADR-016's **execution** catch (§4) sits orthogonally beneath, exactly as ADR-026 §8 separates RBAC-on-author from RBAC-on-execute.
- **[Q1 — Long-Horizon Programs, ADR-027].** A Program is thousands of Runs across weeks: the highest-value, longest-exposure non-human actors in the system. ADR-022's **JIT, short-TTL, renew-with-re-attestation** identity model (§15) and its **anomaly detection on long-lived Run actors** (§20) are designed specifically for these Program Runs; the **workforce kill-switch** (§19) drains a running Program by ceasing identity renewal, and its hooks are wired to ADR-027's anomaly checkpoint (§8) and poison-node quarantine (§9). A Program never becomes a soft path around the payment boundary: §7 states that a Program's Runs inherit the same non-dispatchable `PaymentInitiating` class as any other Run.

*(ADR-numbering note: an earlier draft of `TOOLING_MCP_PLUGINS_ROUTING.md` provisionally used "ADR-016" for the WASM Plugin Runtime; the Pass-5 renumbering — reflected in `IMPLEMENTATION_PLAN.md` P0 and `ADR-026` — makes **ADR-016 = Agent-Payment-Initiation Boundary** canonical. The plugin runtime keeps its design in TOOLING; only the number moved.)*

---

# PART 1 — ADR-016: The Agent Payment-Initiation Hard Boundary

**Status:** Accepted (P0). Design only.
**Decision class:** Architecture-defining and *irreversible-by-intent*. It reserves an apex class in the Side-Effect Ledger's type system that the runtime is built with **no dispatch path for** — a deliberate hole where a capability would otherwise go.
**Position, stated once:** the AiNxt agent runtime — the internal engineering platform NPCI's staff and its digital workers run on — **never initiates, authorizes, instructs, or irreversibly commits the movement of value.** Not through UPI/IMPS/NEFT/RTGS/NACH/RuPay/FASTag, not through a ledger post that settles, not through any 2026 agent-payment protocol (AP2 / ACP / Trusted-Agent / Agent-Pay / x402), not through a funded wallet, card credential, or signed payment mandate. This is not a policy toggle; it is the absence of a code path (§4).

## 1. Context — why payment initiation is a categorically harder class than "side-effecting"

The Side-Effect Ledger (`TOOLING §1.2`) already makes *side-effecting* actions safe: exactly-once via idempotency keys, saga compensation for multi-step, two-phase commit for `HighRisk`. That machinery answers *"don't do it twice"* and *"undo it if the saga fails."* **Payment initiation breaks both assumptions and one more:**

- **It is often non-compensable.** A completed inter-bank settlement, a released NACH mandate debit, an on-chain stablecoin transfer — these have no `compensate()` that un-happens them. The ledger's honest `FAILED_PARTIAL` (`TOOLING §1.3`) is the *right* behavior for a sent email; for moved money it is a catastrophe reported politely.
- **It is the exact action NPCI's mission is to keep correct for the whole country.** NPCI *is* the switch. An engineering agent that could initiate a settlement is not a "risky tool" — it is a second, ungoverned path into the rails the entire org exists to protect. The blast radius is not one user; it is systemic.
- **It is the target an attacker most wants and an insider most fears (Pass-5 [8]).** Prompt-injection (ADR-009), a poisoned MCP tool (Pass-5 [2]), a compromised team member forging a peer's approval (Pass-5 [17]), or an authorized user weaponizing an authorized agent all converge on the same prize: *get the agent to move money.* Every other defense (egress DLP, OBO, injection guards) reduces the *probability*; only a categorical boundary reduces the *possibility* to zero.

`TOOLING §4.2` already established the template: **data-class → model eligibility is a non-overridable exclusion that runs before ranking and cannot be reached by user selection or failover.** ADR-016 applies the identical shape to *actions*: **payment initiation is a non-overridable exclusion in the effect-class type system that no grant, role, program, or harness can reach.** The router taught us the pattern; ADR-016 is that pattern for the one action that matters most.

## 2. Definitions — the boundary must be unambiguous or it is not a boundary

The whole ADR turns on one line being crisp. Two classes, defined by **whether value moves**, not by which system is touched.

**PAYMENT-INITIATING (forbidden, apex class).** Any action that causes, instructs, authorizes, schedules, or irreversibly commits the movement of funds, value, or settlement position — for NPCI, a member bank, a merchant, or an end user. Concretely: submitting or approving a UPI/IMPS/NEFT/RTGS/NACH/AePS/FASTag transaction; posting to a ledger whose post effects settlement; triggering, releasing, or approving a settlement batch or netting cycle; releasing held funds; issuing a value-moving refund, reversal, or chargeback; creating, signing, or presenting a payment mandate/authorization on a payer's behalf (an AP2 Cart Mandate, an ACP Shared Payment Token, a Mastercard/Visa agentic token, an x402-funded request); minting, transferring, or spending any token/stablecoin/credential that carries value.

**PAYMENT-ADJACENT (allowed only under §6's mandate model + HITL).** Actions that touch payment systems but move **no** value: reading/querying settlement, ledger, or dispute data (governed by data-class routing + OBO); *simulating* a settlement or netting run in a sandbox with no live effect; drafting a dispute/chargeback response for a human to send; generating a reconciliation or exception report; and — the largest category by far — **authoring, reviewing, and testing payment-system code** through the normal SDLC, where the code is deployed to the money path *by humans through change control*, never by the agent itself.

**The bright line:** *does executing this action, by itself, move value or commit a settlement position?* If yes → PaymentInitiating → forbidden. If no → at most payment-adjacent → governed but possible. Writing the code that will one day move money is adjacent; **running** that code against live rails is initiating. The agent lives entirely on the adjacent side.

## 3. Decision — a reserved, non-dispatchable apex class + five independent structural denials

1. **Extend the Ledger's `effect_class` with an apex value, `PaymentInitiating`, and build the runtime with no dispatch arm for it.** `TOOLING §1.1`'s enum becomes `Pure | Idempotent | SideEffecting | PaymentInitiating`. The dispatcher's match over `effect_class` has arms for the first three and a single arm for the fourth that is a **hard, logged, incident-raising denial** — never an execution. `PaymentInitiating` exists in the type system precisely so it can be *recognized and refused*, the way a lock exists to be shut. It is a tripwire, not an enabler.
2. **The `CapabilityRegistry` refuses to register any capability that is — or resolves to — `PaymentInitiating`.** Registration is where native, MCP, and plugin capabilities all funnel (`TOOLING §0`, one registry). A capability whose manifest declares `PaymentInitiating`, or whose static signature matches a payment-initiation pattern (§4.5), is **rejected at registration** with a structured error. There is no "register but disabled" state; the capability never enters the registry, so nothing downstream can select, rank, plan, or dispatch it.
3. **No OBO grant tuple can express it.** The Policy Engine's grant vocabulary (`TOOLING §1.6`) has **no** grant that authorizes a `PaymentInitiating` capability, so even a fully-privileged human's OBO context cannot carry the authority to the agent — because the authority is not representable. Confused-deputy (Pass-5 [AI]) is closed here for this class specifically: there is nothing to be confused *into*.
4. **The network egress boundary denies value-movement destinations categorically.** Egress DLP (`TOOLING §1.7`) is extended with a **settlement-perimeter deny-list**: the rails endpoints, core-banking/ledger settlement APIs, and every agent-payment-protocol endpoint (AP2/ACP/TAP/Agent-Pay/x402 networks) are **not on any capability's egress allow-list and cannot be added** (the allow-list schema treats the settlement perimeter as a reserved, un-allow-listable range). Even a capability that lied about its effect class and tried to make the HTTP call is stopped at the wire.
5. **A runtime effect-classifier tripwire inspects the *actual* effect of every dispatch.** Independent of what a capability *declared*, a pre-execution classifier examines the resolved destination, `resource_key`, and payload semantics; if it matches a payment-initiation signature that slipped past registration (a mis-declared or dynamically-constructed call), it **aborts the turn, quarantines the capability, revokes the acting identity (ADR-022 §17), and raises a security incident** (ADR-017 breach clock). This is the defense against a capability that *lies* about its `effect_class`.

**These five are independent and each is individually sufficient to deny.** An attacker must simultaneously defeat the type system, the registry, the grant vocabulary, the network perimeter, and the runtime classifier — and even then the classifier + egress catch the attempt in flight and burn the identity. This is the "enforced structurally — no code path bypasses it" the brief demands, made concrete as five code paths that would each have to be *rewritten*, reviewed by the payments-council, and shipped through the git control plane (ADR-026) to weaken — which is itself the point.

## 4. Enforcement, layer by layer (the "no bypass" claim, discharged)

| # | Layer | Where it lives | What it denies | Why it can't be quietly removed |
|---|---|---|---|---|
| 1 | **Type system** | `effect_class::PaymentInitiating` in the Ledger crate (ADR-002/013) | dispatch — the match arm is a denial, not a call | removing the arm is a source change through ADR-026 review; the code review shows a payment-dispatch path being *added* — the most-scrutinized diff in the repo |
| 2 | **Registration** | `CapabilityRegistry::register` (`TOOLING §0`) | the capability ever existing to be chosen | native/MCP/plugin all register here; there is no second registration door (`TOOLING §0` one-registry) |
| 3 | **Grant vocabulary** | Policy Engine grant schema (`TOOLING §1.6`, ADR-003) | any OBO context carrying the authority | the authority is *not representable* — you cannot grant a verb the schema has no word for |
| 4 | **Control-plane manifest** | `payment_boundary` front-matter (ADR-026 §5) | authoring a definition that even *claims* to initiate | `payment_boundary: payment-initiating` fails CI + pre-receive; only `none`/`payment-adjacent` merge (§7) |
| 5 | **Egress / network** | settlement-perimeter deny-list (`TOOLING §1.7`) | the outbound value-moving call, regardless of caller | the perimeter is a reserved, un-allow-listable range; adding to it is an ADR-026 policy diff through the security-council CODEOWNERS |
| 6 | **Runtime tripwire** | pre-dispatch effect-classifier | a mis-declared / dynamically-built payment call at execution | fail-closed: on match it aborts + revokes identity + incidents; it does not "allow and log" |

The boundary is therefore enforced at **authoring time** (layer 4, git), **wiring time** (layers 2–3, registry + grants), and **execution time** (layers 1, 5, 6, dispatcher + wire + classifier) — the same three-time defense-in-depth ADR-026 §8 uses, applied to the one action that can never be allowed at *any* of the three.

**§4.5 — the payment-initiation signature (how layers 2 and 6 recognize it without a declaration).** A deterministic, reviewed classifier (not an LLM) matches on: destination in the settlement perimeter; `resource_key` naming a settlement account / netting batch / ledger-settlement table; payload carrying a rails message type (ISO 20022 `pacs.*`, UPI request-to-pay/collect, NACH mandate execution) or an agent-payment-protocol credential; or a two-phase `commit` whose `dry_run` preview showed a value delta. The signature list is a **git-controlled policy definition** (ADR-026) under the payments-council + security-council CODEOWNERS, versioned and diff-reviewed — so "what counts as payment initiation" is itself an audited, evolvable artifact, not a buried constant.

## 5. Position on 2026 agent-payment protocols (AP2 · ACP · Trusted-Agent · Agent-Pay · x402)

The brief requires a stated position on each. The honest frame first: **NPCI is not a merchant, consumer, issuer, or wallet — it is the rails operator.** Nearly all of these protocols sit at the consumer↔merchant↔issuer layer and ride *on top of* payment rails. So there are two distinct questions, and conflating them is the trap.

**Question A — does the agent runtime become a participant in any of these? No, categorically, forever.** The AiNxt runtime never holds a funded wallet, a card credential, a mandate-signing key, or an issued agentic token; it never signs an AP2 Cart Mandate, never presents an ACP Shared Payment Token, never enrolls as a Visa Trusted Agent or a Mastercard Agent-Pay agent, never makes an x402-funded request. **All five are on the §4.4 settlement-perimeter deny-list and are `PaymentInitiating` by definition (§2).** No exception, no pilot, no "just for the sandbox with real value."

**Question B — should India's *rails* interoperate with, or offer a sovereign equivalent to, these protocols? Not the runtime's decision — and explicitly out of scope here.** Whether UPI should support an agent-mandate analog, or RuPay should issue agentic tokens, is a **product + regulatory decision** for NPCI's payment-systems organization and the RBI, made through their governance — the AiNxt agent runtime neither decides it nor executes it. The runtime may *help build* such a rail feature (write code, review, simulate) through normal SDLC (payment-adjacent, §2); the running agent never *operates* it.

| Protocol (2026) | What it is | AiNxt position |
|---|---|---|
| **AP2** (Google Agent Payments Protocol; open, ~60 partners) | Verifiable-credential **Mandates** — Intent Mandate (delegated, human-not-present) → Cart Mandate (human-present); rail-agnostic; non-repudiable user→agent→merchant proof chain | **Not integrated.** But we *adopt its Mandate shape* — cryptographically-signed, human-issued, scoped, expiring, verifiable delegation — as the model for our payment-**adjacent** authorization (§6). We take the authorization primitive, never the value-movement. |
| **ACP** (OpenAI + Stripe Agentic Commerce Protocol; ChatGPT Instant Checkout) | Delegated **Shared Payment Token** — scoped, single-use; merchant stays merchant-of-record | **Not integrated.** The SPT is a payer-side credential; the runtime is never a payer. Noted as the clearest example of *why* value-moving credentials never enter the runtime — a scoped token is still a value token. |
| **Trusted Agent Protocol** (Visa Intelligent Commerce) | Lets merchants cryptographically recognize/enroll trusted agents; distinguishes good agents from bots | **Not integrated as a payer.** Its *identity* idea (a cryptographically-attested, enrolled agent) is convergent with ADR-022 (§11–17) — evidence our per-agent attested identity is the right direction — but we enroll agents for *our* audit/authz, not to transact on a card network. |
| **Mastercard Agent Pay** (Agentic Tokens) | Tokenized agent payments + agent identity + programmable guardrails | **Not integrated.** Same as ACP/Visa: a value-bearing token is `PaymentInitiating`. Its "programmable guardrails" idea is subsumed by our stronger stance — the guardrail is *categorical*, not configurable. |
| **x402** (Coinbase; HTTP 402 stablecoin micropayments) | Per-request machine-native USDC payments via HTTP headers | **Not integrated; explicitly hostile fit.** A funded wallet making per-request on-chain payments is exactly the non-compensable, off-rail value movement §1 forbids; the x402 endpoint range is on the settlement-perimeter deny-list. |

**Standards-maturity judgment (honest, and NPCI-specific).** As of early 2026 these are young, overlapping, competing, and — critically — **without an RBI framework for agentic payments in India**, with unresolved liability, dispute, and chargeback semantics. For the operator of a national switch, wiring any value-bearing agent credential into the *engineering* runtime would be reckless regardless of the protocol's technical merit. We **track them as external ecosystem developments** (they will shape how NPCI's *rails* eventually expose agentic features — a Question-B matter) and **borrow only their authorization *shape*** (§6), never their value-movement.

## 6. The mandate model — *if* payment-adjacent actions are ever allowed

The apex (value movement) is never mandate-able — no mandate can authorize it, because §2 puts it in a class the runtime can't dispatch and §4 gives it no representable grant. But for **payment-adjacent** actions that are more than pure reads (e.g., *simulate* a settlement against a sandbox, *draft-and-queue* a dispute response for human send), the design uses a **Payment-Adjacent Mandate (PAM)** — AP2-mandate-shaped, deliberately incapable of expressing value movement:

- **Human-issued, never agent-issued.** A PAM is signed by a human with `can_approve` and `ad_level <= 3` (the same authority ADR-026 §5 requires for the payment-boundary front-matter class). The agent can *request* a PAM; only a human can *sign* one.
- **Scoped, bounded, expiring, single-purpose.** A PAM names exactly one action verb, one resource, a hard expiry, and a use-count of one (or a small N), mirroring AP2's Intent-Mandate constraints. It is a verifiable credential recorded in the Event Log and bound to the requesting Run's identity (ADR-022 §14), so it is non-repudiable and non-transferable.
- **Structurally incapable of value movement.** The PAM schema has **no field** that could express an amount, a payee, a settlement instruction, or a payment credential. It is not that value movement is "disallowed" in a PAM — it is *unrepresentable*, the same design move as §3.3's grant vocabulary. A PAM can authorize "simulate netting for batch B, read-only, once, expires in 1h"; it cannot even *spell* "settle batch B."
- **Verified at dispatch, alongside OBO.** The Policy Engine checks the PAM's signature, scope, expiry, and identity-binding *in addition to* the three OBO layers (`TOOLING §1.6`) — a PAM is a *fourth* gate for adjacent-write actions, never a *substitute* for the first three.

This is the concrete answer to "mandate/authorization model if payment-adjacent actions are ever allowed": borrow AP2's proven, non-repudiable, human-anchored, scoped-and-expiring delegation *shape*, and make the value-moving apex unrepresentable within it.

## 7. Interaction with the git-native control plane (Q2 / ADR-026) and long-horizon programs (Q1 / ADR-027)

**Git-native (Q2).** The `payment_boundary` front-matter field (ADR-026 §5) is the **authoring** enforcement of this ADR. Its permitted values are `none` (default) and `payment-adjacent`; **`payment-initiating` is a reserved value that CI + the pre-receive hook reject** — you cannot even merge a definition that claims to initiate payment. A `payment-adjacent` definition requires the **payments-council CODEOWNERS group + a signed `ad_level<=3` commit** (ADR-026 §5/§8), so the *authoring* of anything that touches the payment perimeter is caught at review, and the *execution* denial (§4) sits orthogonally beneath it — a definition can be fully git-approved as `payment-adjacent` and still be denied a specific value-moving dispatch at runtime, exactly the RBAC-on-author vs RBAC-on-execute separation ADR-026 §8 mandates. The §4.5 signature list and the §4.4 settlement-perimeter deny-list are themselves git-controlled policy definitions under payments-council + security-council CODEOWNERS.

**Long-horizon (Q1).** An ADR-027 Program is thousands of Runs; every one inherits the identical non-dispatchable `PaymentInitiating` class — a Program is *not* a privileged actor and gains no payment authority by being long-running or autonomous. A migration Program touching settlement/ledger modules hits ADR-027's **critical-path checkpoint** (§8, forced `assisted` + human commit approval) for the *code change*, while this ADR guarantees the Program's Runs can never *execute* against live rails. The two compose: humans gate the code that will move money; the boundary guarantees the agent never runs it against production value.

## 8. Acceptance / scenario tests

| # | Scenario | Setup | Expected | Proves |
|---|---|---|---|---|
| 1 | Registration refusal | A native capability declares `effect_class: PaymentInitiating` | `CapabilityRegistry::register` rejects it; it never enters the registry; process logs a governance error | Layer 2 — the class can't be wired in |
| 2 | Undeclared payment call | A capability declares `SideEffecting` but its resolved destination is a UPI settlement endpoint | The §4.6 tripwire aborts the turn pre-dispatch, quarantines the capability, revokes the acting identity, raises an incident | Layer 6 — mis-declaration doesn't slip through |
| 3 | Egress perimeter deny | A capability with a valid allow-list tries to POST to a core-banking settlement API | Egress DLP denies; the destination is on the un-allow-listable settlement perimeter | Layer 5 — the wire is the last hard stop |
| 4 | No grant exists | A fully-privileged admin's OBO context is inspected for a payment-initiation grant | No such grant tuple is representable; the Policy Engine cannot carry the authority | Layer 3 — confused-deputy closed for this class |
| 5 | Git can't author it | A PR sets `payment_boundary: payment-initiating` | CI + pre-receive hook reject; it never merges | Layer 4 — authoring caught (ADR-026) |
| 6 | Adjacent needs council + PAM | A PR sets `payment_boundary: payment-adjacent`; a Run then requests a settlement *simulation* | Merge requires payments-council + `ad_level<=3` signed commit; the sim runs only with a valid, human-signed, scoped, expiring PAM | §6/§7 — adjacent is possible but heavily gated |
| 7 | PAM can't spell value | A crafted PAM attempts to encode an amount + payee | The PAM schema has no such field; the credential is malformed and rejected | §6 — value movement is unrepresentable, not just disallowed |
| 8 | Protocol integration blocked | A plugin bundles an AP2 Cart-Mandate signer / an x402 wallet | The signer's egress is on the settlement perimeter; its effect classifies `PaymentInitiating`; registration + egress both deny | §5 — no agent-payment protocol enters as a payer |
| 9 | Injection → payment attempt | A poisoned document instructs the agent to "release the held settlement for batch B" | No capability exists to select; if a look-alike is attempted, egress + tripwire deny; egress DLP also redacts any exfil | ADR-009 + §4 compose; the categorical boundary backstops the probabilistic defenses |
| 10 | Program inherits the boundary | An ADR-027 migration Program's Run reaches a settlement-touching module | The code change hits the critical-path human checkpoint; the Run still cannot execute against live rails | §7 — long-horizon autonomy grants no payment authority |
| 11 | Reserved-arm audit | Static analysis of the dispatcher | The `PaymentInitiating` match arm is a denial with no call site reaching an executor | The "no code path on the other side" claim is checkable in source |
| 12 | Signature list is governed | The §4.5 signature policy is edited | Change requires a payments-council + security-council reviewed, signed git diff (ADR-026) | "What counts as payment" is an audited artifact, not a buried constant |

## 9. Consequences

**Positive.** The one systemic, non-compensable, mission-defining risk is reduced from "low-probability" to "no code path" — five independent structural denials, each individually sufficient, none removable without the most-scrutinized diff in the repo. The boundary backstops every probabilistic defense (injection, OBO, egress) so a *breach* of those becomes an *attempt*, not a settlement. NPCI can honestly tell RBI "an engineering agent cannot move money, by construction." It reuses existing spine — the Ledger's `effect_class`, egress DLP, the git control plane — rather than a bespoke system.

**Negative / cost.** The classifier (§4.5/§4.6) is a real component with real recall obligations; a payment-initiation pattern it doesn't recognize is a gap (mitigated by defense-in-depth — egress perimeter catches by destination even when the classifier misses by semantics). Legitimate future payment-*adjacent* automation (simulations, dispute drafts) carries heavy PAM + council friction by design — teams will feel it, and that friction is the intended cost of the boundary. Question-B (rails-level agentic features) is deferred to NPCI/RBI governance and is genuinely unresolved.

**Neutral.** The runtime can still be enormously useful on the *adjacent* side (read/analyze/simulate/build payment-system code) — the boundary constrains one verb, not the domain.

## 10. Residual risks (honest)

1. **Classifier recall.** §4.5 is only as good as the signature list; a novel rails message type or a cleverly-obfuscated destination could evade the *semantic* match — the *destination* perimeter (§4.4) is the belt to that suspenders, but a genuinely novel egress path is the residual. Named, not hidden.
2. **Definition of "value movement" drifts.** New rails, new tokens, new protocols (Question B evolves) mean §2's list needs continuous, council-governed maintenance; a stale list is a stale boundary. Mitigated by making it a git-controlled, reviewed artifact — but maintenance is a standing obligation.
3. **Adjacent-to-initiating creep.** The riskiest gray zone is a "simulation" or "draft" capability that, through a config or integration error, points at a live endpoint. §4.4/§4.6 are designed for exactly this, but the gray zone is where vigilance must stay highest.
4. **Human PAM-signer social-engineering.** A human tricked into signing a PAM is out of ADR-016's scope for the *apex* (a PAM can't spell value) but is a real risk vector for adjacent actions — routed to ADR-022's SoD (§18) and anomaly detection (§20), not solved here.

---

# PART 2 — ADR-022: Non-Human / Agent Identity Lifecycle

**Status:** Accepted (P0). Design only.
**Decision class:** Architecture-defining. Establishes a new identity subject — the *non-human actor* — as a first-class, individually-attributable, individually-revocable principal, distinct from both the human user (whose JWT it acts on behalf of) and the process (which merely hosts it).
**Position, stated once:** every agent action is performed under a **short-lived, cryptographically-verifiable, per-Run machine identity** issued only after **attestation**, bound to the *definition* it runs, the *code* it is, and the *human* it acts for — **never a shared service token.** The identity is the actor of record in the audit trail, is rotated automatically, is revocable individually and en masse, is JIT rather than standing, and is watched for anomaly across its whole (possibly multi-week) life.

## 11. Context — why a shared token is the wrong answer, precisely

The failure the platform must not ship is the one every early agent system ships: **all agents authenticate as one shared service account.** Its consequences are all disqualifying for a payment operator:

- **Attribution collapses.** The audit trail says "the platform service account did X" — useless to a regulator asking *which* agent, running *which* definition, on *whose* behalf. (Pass-5 [16] names this directly; the CLAUDE.md SDLC rule that `add_run_event` `actor` must be a real string is the same instinct at Python scale.)
- **Revocation is all-or-nothing.** Compromise one agent and your only lever is killing the shared token — which kills *every* agent. There is no "revoke this one Run."
- **Least-privilege is impossible.** A shared identity accumulates the union of every agent's permissions; the confused-deputy surface (Pass-5 [AI]) is maximal.
- **SoD is impossible.** If producer and approver share an identity, a compromised producer *is* an approver (Pass-5 [17], the forged-Judge-approval attack).

The fix is not "more tokens" but **a real identity per actor, issued the way modern workload identity is issued** — SPIFFE/SPIRE-style attested SVIDs or Entra-Agent-ID-style per-agent identities — adapted to the agent runtime's unit of work (the Run) and to NPCI's regulated, air-gap-capable, TEE-backed substrate.

## 12. The identity model — a composite, per-Run, attested workload identity

An agent's identity is not one flat name; it is a **composite of three facets**, minted fresh per Run:

1. **Definition identity** — *what role/agent is this?* A stable, versioned identity for the definition, rooted in the git control plane (ADR-026): `def:<kind>/<id>@<version>@<content_hash>@<control_commit_sha>`. Because the definition lives in git and is content-addressed, the definition identity is *provably* "role X exactly as reviewed and approved at commit SHA Y."
2. **Workload identity** — *which running instance is this?* An ephemeral per-Run identity: the specific Run instance, its host/TEE, its start time and expiry.
3. **Delegation facet (OBO)** — *on whose behalf?* The human OBO context (`TOOLING §1.6`): `{user_id, role, department, ad_level, can_approve}`, threaded from the JWT and inherited by sub-agents.

These compose into a single **Agent Workload Credential (AWC)** — a short-lived, SPIFFE-SVID-shaped credential (X.509-SVID for mTLS between services, JWT-SVID for API calls) whose identity URI is a clean-room trust-domain name:

```
ainxt-id://npci/agent/<def-kind>/<def-id>/v<version>/run/<run-id>
   claims: { def_content_hash, control_commit_sha, obo: {user_id, dept, ad_level},
             attestation_ref, issued_at, expires_at (short TTL), key_id (ADR-023) }
```

**Not a shared token, by construction.** Every Run gets its own AWC; two Runs of the same role have *different* `run-id`s and *different* credentials. Revoking one AWC (§17) touches exactly one Run. The AWC is the thing the Policy Engine (ADR-003) evaluates and the Event Log (ADR-007) records as **actor** — so "who did this" is always the full composite: *Run r of role X (git SHA Y), acting for human H*.

**Issued by an in-zone authority.** The **Agent Identity Authority (AIA)** — a SPIRE-server-shaped component deployed inside the trust zone (air-gap-clean, ADR-026 §12 discipline) — is the sole issuer. Its own root is the only standing agent-side identity in the system (§15); everything else is JIT.

## 13. Attestation before issuance — external cryptographic attestation (ADR-021)

The AIA never issues an AWC on a mere request. It issues **only after attestation**, in the SPIRE node-attestation shape, hardened with the hardware root-of-trust:

- **Workload attestation.** The requesting process proves *what it is* — its binary/image measurement and the **control-plane commit SHA it loaded** (ADR-026 §6.1). An AWC's `def_content_hash`/`control_commit_sha` claims are therefore *attested facts*, not self-asserted — the identity cryptographically states "this is role X exactly as approved, running the code that was reviewed."
- **TEE remote attestation (external, ADR-021).** Where the Run executes in a confidential-computing enclave (regulated-data Runs), the AIA verifies a **remote-attestation quote** rooted in the hardware root-of-trust *before* minting the AWC, and embeds the quote reference in the credential. "External" is the load-bearing word: the quote is verifiable by a party **outside** the runtime — an auditor or regulator can independently check that the identity was issued only to attested, unmodified, approved code, without trusting the runtime's own say-so.
- **Transparency-log inclusion (ADR-023/ADR-025).** Issuance events are recorded to an append-only transparency log; an inclusion proof lets an external party verify *that* an identity was issued, *to what measurement*, *when* — a court-grade, externally-checkable attestation chain (ADR-025 admissibility).

Attestation is what makes the identity *trustworthy* rather than merely *unique*: a stolen credential is short-lived (§15), and a forged issuance is impossible without defeating the hardware root-of-trust and the transparency log.

## 14. Audit attribution — the actor of record (ADR-007 + ADR-026's two-trail model)

Every Event-Log entry for an agent action records the **full AWC as actor** — not a service account, not a bare role name. This completes ADR-026 §9's two-trail audit model:

- **git history = the *authoring* audit** — who wrote/approved the definition (ADR-026).
- **Event Log = the *execution* audit** — and now its **actor is a verifiable composite identity**: *which Run, of which git-SHA'd definition, on whose behalf, attested how.*

A regulator's "who did this?" is answered end-to-end: the AWC names the definition (→ git shows who authored/approved it) and the OBO human (→ who it acted for) and the attestation (→ proof the code was the approved code). The mandate instances (§6) and every OBO decision are logged beside the AWC, reconstructable years later (ADR-007 replay). The AWC identity *material* is data-plane (§21), but its *reference* in the log is immutable and content-addressed.

## 15. Standing vs JIT — no standing agent credentials, and the long-lived-Run answer (Q1)

**There are no standing agent credentials.** The only standing agent-side secret is the AIA's own issuing key (rotated per ADR-023). Every AWC is **JIT**: minted at Run start, **short TTL** (minutes), auto-rotated for the Run's duration. A leaked AWC is worthless within one TTL; there is no long-lived bearer token to steal.

**Long-lived Runs (ADR-027 Programs) do not get a long-lived credential.** A Program Run that lives for hours or days gets a **short-TTL AWC that is *renewed*, and every renewal re-checks**: (a) the definition is still valid and non-deprecated in the control plane; (b) the kill-switch state (§19) permits continued operation; (c) the anomaly monitor (§20) has not flagged the actor; (d) — for TEE Runs — a fresh attestation quote. Renewal is *conditional continuation*, not a standing grant. This is the crucial Q1 tie-in: a multi-week Program is not a single long-lived actor holding one token for weeks; it is a **chain of short-lived, continuously-re-attested, continuously-re-authorized identities**, so a kill-switch or an anomaly flag drains it within one TTL window even mid-Program (§19/§20).

**Renewal reads are from an in-memory projection, never the git repo or its loader.** Checks (a) and (b) are latency-critical and run on *every* renewal of *every* live Run — at Program scale (capacity model below) that is a sustained, high-frequency read, not an occasional one. The AIA therefore never opens the control-plane git repo or invokes ADR-026's definition-loader on the renewal hot path; it evaluates against a **fast, hot-reload-synced, in-memory projection** of the control-plane registry (definition validity/deprecation state) and the kill-switch state — the same materialized-projection discipline `SERVING_OPS.md §1` uses for QoS/placement policy and `PROMPT_ENGINEERING.md §3` uses for the prompt registry: git remains the single source of truth and the *only* place the policy is authored, reviewed, or changed (ADR-026); the runtime's read path is a local, versioned, watch-updated cache that a git outage, a slow clone, or a large-repo directory walk can never put on the renewal critical path. The projection is rebuilt incrementally on every control-plane change notification (ADR-026 §6.2's hot-reload hook) and is content-addressed to the commit SHA it reflects, so a renewal's `control_commit_sha` claim (§12) is always attributable to a specific, verifiable git state even though the read itself never touches git. **Fail-closed on staleness:** if the projection's sync lag exceeds a bounded freshness threshold (a git-controlled parameter, ADR-026), the AIA treats affected definitions as deprecated for renewal purposes — deny and drain at TTL — never fail-open on a stale cache.

**Renewal-throughput capacity model (Program scale).** A Program (ADR-027) holds thousands of Runs concurrently, each carrying a short-TTL AWC that must renew before expiry; the renewal path (in-memory projection lookup + kill-switch check + anomaly-monitor check +, for TEE Runs, a fresh attestation) is therefore *sustained* load on the AIA and Policy Engine, not occasional load. Illustrative model, to be tuned against real NPCI load (§24.4): for **N** concurrent Runs with TTL **T**, sustained renewal rate ≈ N/T, spread across the TTL window by per-Run renewal-time jitter (never all renewing on the same tick — the same jitter discipline used for cron scheduling elsewhere in the corpus) to avoid a thundering-herd spike at T-boundaries, with a retry/margin multiplier (e.g. ×1.3) for the practical target. For N=5,000 concurrent Runs and T=5 minutes: ≈17 renewals/sec sustained, ≈22/sec with margin — a rate cheap for an in-memory projection lookup and exactly why this section requires the projection rather than a git read (a git-backed check at that rate would be either infeasible or would need its own caching layer, reinventing the projection anyway). The model is exercised, not just asserted, by the **renewal-throughput load test (§22 #16)**.

## 16. Rotation & crypto-agility (ADR-023)

- **Credential rotation is a non-event** because AWCs are ephemeral: the SPIRE-style agent rotates the Run's mTLS SVID on its short TTL automatically; nothing carries a credential long enough to *need* a rotation event.
- **Signing-key rotation** for the AIA root and the transparency-log keys uses ADR-023's crypto-agility abstraction — algorithms and keys rotate behind a versioned `key_id` (embedded in every AWC), so a compromised or deprecated algorithm is rolled forward without re-issuing history and PQC migration is a config, not a rewrite (harvest-now-decrypt-later mitigated).
- **Attestation-root rotation** (TEE keys, ADR-021) is likewise versioned; an AWC records which root attested it, so an old credential's attestation remains *verifiable* after a root rolls.

## 17. Deprovisioning & individual revocation

Three revocation granularities, all mechanical:

- **Revoke a definition (deprovision a role/agent).** Deprecate/remove it in the git control plane (ADR-026): the AIA checks the **in-memory control-plane projection** (§15) — synced from git via ADR-026 §6.2 hot-reload, never read from the repo/loader directly on this path — at *issuance and every renewal*, so a deprecated `def-id` gets **no new AWC and no renewal** — the role drains within one TTL. No new Runs of it can start; running Runs expire. Because the projection sync is hot-reload-driven rather than poll-on-demand, the deprecation is visible to the next renewal check within the sync's bounded propagation delay, not merely "eventually."
- **Revoke a single Run.** Push the AWC's `run-id` to a **short-lived revocation set** the Policy Engine consults per dispatch (so in-flight calls are denied immediately) *and* deny its renewal (so it drains at TTL even if the push lags). Individually revocable — one Run, zero collateral.
- **Revoke a human's delegated authority.** If the OBO human is disabled/de-scoped, every AWC carrying that `user_id` is denied at the next dispatch/renewal — the delegation facet (§12) makes this a targeted query, not a guess.

Because AWCs are short-TTL, revocation *degrades safe*: even if a revocation push is delayed, the credential expires on its own and renewal is denied.

## 18. Producer/approver Separation of Duties + signed handoffs (Pass-5 [17])

SoD is enforced at the **identity** layer, not merely the model layer:

- **Producer ≠ approver, by identity.** The AWC that *produced* an artifact (a Coder Run) is recorded on it; the Policy Engine **refuses an approval/merge/commit action from an actor whose AWC is the producer of that same artifact.** This is stronger than the cross-model producer≠judge discipline (`RUNTIME_FEATURE_FLOWS §4.1`, ADR-027 §10): even the *same model* running as two Runs cannot self-approve, because the two Runs have distinct AWCs and the SoD check keys on identity.
- **Signed handoffs (the forged-Judge-approval fix).** When one team member hands work to another (LOOP handoff contracts, ADR-027 seams), the handoff artifact is **signed by the producer's AWC**; the receiver **verifies the signature and checks SoD** before acting. A compromised Coder cannot forge a Judge's approval because it cannot produce the Judge's AWC signature, and the SoD check rejects a self-produced approval regardless. Pass-5 [17] is closed structurally.
- **SoD policy is git-controlled (Q2).** Which action-pairs require SoD, and which roles may approve which, are policy definitions in the control plane (ADR-026), reviewed and versioned.

## 19. Workforce-wide kill-switch (a hierarchy, not a single button)

A single authenticated control that halts non-human actors — designed as a **scoped hierarchy** so it is both a precision instrument and a big red button:

| Scope | Effect | Drain mechanism |
|---|---|---|
| **Single Run** | revoke one AWC (§17) | immediate deny + no renewal |
| **Role / definition** | AIA stops issuing/renewing for a `def-id` | drains within one TTL |
| **Department** | halt all AWCs carrying a department (delegation facet) | drains within one TTL |
| **Data-class** | halt all Runs operating on a data class (e.g., all regulated-payment Runs) | drains within one TTL |
| **Workforce-wide** | AIA stops issuing/renewing **all** agent AWCs + global Policy-Engine deny + Serving-Ops drain/preempt signal (ADR-020) | drains within one TTL even if the deny-push lags |

The **workforce-wide halt** does three things at once: (a) the AIA ceases all issuance and renewal, so the entire non-human workforce drains within one TTL *by expiry alone* — the kill-switch degrades safe and does not depend on reaching every process; (b) a global revocation is pushed to the Policy Engine to deny in-flight dispatches immediately; (c) Serving-Ops (ADR-020) is signalled to preempt/drain program Runs (ADR-027 §7 preemption — a halted Program Run checkpoints to `PENDING` and does not resume, losing nothing). Kill-switch **authority** is a git-controlled policy (Q2): who may pull which scope, gated to `ad_level<=3` + `can_approve`, master-switch-style (consistent with the computer-use master switch discipline). The kill-switch's own use is itself audited to the Event Log with the pulling human's identity.

## 20. Anomaly detection on long-lived Run actors (Q1 / Pass-5 [8])

Long-lived Program Runs (ADR-027) are the highest-value, longest-exposure actors; they get a **UEBA-style Run-Actor Anomaly Monitor**:

- **Per-role behavioral baseline.** Each definition has an expected behavioral envelope — capability mix, resource footprint, egress destinations, action rate, cost velocity, working-set pattern — learned from its own history and its role charter (WORKFORCE §2).
- **Deviation flags on the actor, not just the task.** A Run whose *actor behavior* deviates (a triage role suddenly enumerating settlement tables; a migration Run's egress destinations drifting; a cost-velocity spike) is flagged — this is the insider-threat / weaponized-agent surface (Pass-5 [8]) that compliance's I/O checks never see.
- **Graduated response, wired to existing seams.** Flag → (a) raise an **ADR-027 anomaly checkpoint** (§8) with the evidence trail; (b) optionally **suspend AWC renewal** (§15) so the Run drains at next TTL without a hard kill; (c) escalate to **poison-node quarantine** (ADR-027 §9) or the **kill-switch** (§19) for severe cases. Because identity renewal is the choke point (§15), the anomaly monitor's strongest lever — *stop renewing this actor's identity* — is already built.
- **Long-horizon is the point.** A Run that lives for weeks is exactly where a slow, low-and-slow compromise or drift hides; watching the *actor's* behavior across its whole renewed-identity chain (not just per-turn) is the design's answer to "anomaly detection on long-lived Run actors."

## 21. The Q2 split, applied to identity (policy in git, material in the data plane)

Honoring ADR-026's control-plane/data-plane invariant precisely for identity:

| Artifact | Plane | Store | Erasable? |
|---|---|---|---|
| Identity-issuance policy, attestation requirements, TTLs | Control | git (ADR-026) | No (versioned, reviewed) |
| SoD rules, approver matrices | Control | git | No |
| Kill-switch authority, anomaly thresholds/baselable envelope | Control | git | No |
| The §4.5 payment-signature + settlement-perimeter lists | Control | git | No |
| AIA renewal-check in-memory projection (definition validity, kill-switch state — §15/§17) | Data (hot-reload-synced cache of control) | AIA in-process memory, watch-updated from git | Rebuildable (rehydrated from git on restart/reconnect; never the read path itself) |
| Issued AWCs / SVIDs (live credential material) | Data | in-zone secret store | Yes (rotate/revoke) |
| Revocation sets | Data | Redis/Postgres | Rebuildable |
| Learned anomaly baselines | Data | Postgres | Rebuildable |
| PAM instances (§6) | Data | Postgres + Event Log | Per ADR-015 + legal-hold |
| Attestation quotes / transparency-log entries | Data (append-only) | log store | No (audit record) |

**The subtle line:** the *rules* for identity are PII-free, reviewed, versioned definitions → git; the *credentials and behavioral state* are high-write, per-Run, rotatable/erasable operational state → stores. This is the exact §3 invariant of ADR-026, applied so neither is ever in the wrong plane.

## 22. Acceptance / scenario tests

| # | Scenario | Setup | Expected | Proves |
|---|---|---|---|---|
| 1 | Per-Run identity, not shared | Two Runs of the same role act concurrently | Distinct AWCs (`run-id`), distinct Event-Log actors; no shared token anywhere | §12 — not a shared identity |
| 2 | No issuance without attestation | A process requests an AWC without a valid workload/TEE attestation | AIA refuses issuance | §13 — attestation-gated |
| 3 | External verifiability | An auditor is given an AWC + its attestation-ref + transparency-log proof | The auditor independently verifies the code measurement + issuance without trusting the runtime | §13 — external cryptographic attestation |
| 4 | Actor attribution | Any agent action | Event Log records the full composite AWC (def@sha + run + OBO), not a service account | §14 — attribution is specific |
| 5 | JIT / short TTL | Steal an AWC and replay after its TTL | Replay is rejected; the credential expired | §15 — no standing credential |
| 6 | Long-lived Run renewal re-checks | A Program Run runs for days; mid-run its role is deprecated in git | Next renewal is denied; the Run drains within one TTL | §15/§17 — conditional continuation |
| 7 | Individual revocation | Revoke one Run's AWC while 3 sibling Runs run | Only that Run is denied; siblings continue | §17 — individually revocable |
| 8 | Producer can't self-approve | The same model runs as producer Run and approver Run | SoD check rejects the approval — distinct AWCs, producer==approver denied | §18 — SoD at identity layer |
| 9 | Forged handoff blocked | A compromised Coder emits a "Judge-approved" handoff | Signature verify fails (no Judge AWC signature) + SoD rejects self-approval | §18 — Pass-5 [17] closed |
| 10 | Workforce kill-switch drains safe | Pull the workforce-wide halt; a deny-push to one node is dropped | That node's Runs still drain by AWC expiry within one TTL; issuance/renewal stopped globally | §19 — degrades safe |
| 11 | Scoped kill-switch | Halt only `data-class: regulated-payment` | Regulated Runs drain; internal/public Runs continue | §19 — precision scope |
| 12 | Anomaly on a long Run | A long-lived Run's actor behavior deviates from its baseline | ADR-027 anomaly checkpoint raised; renewal optionally suspended; evidence logged | §20 — long-lived-actor UEBA |
| 13 | Rotation is a non-event | Force an AIA signing-key rotation mid-workforce | New AWCs use the new `key_id`; existing short-TTL AWCs verify then expire; no outage | §16 — crypto-agility |
| 14 | Policy in git, material in store | Inspect where SoD rules vs live AWCs live | SoD rules in git (reviewed); AWCs in the secret store (rotatable/revocable) | §21 — Q2 split honored |
| 15 | OBO inheritance keeps identity | A Run delegates to a sub-agent | Sub-agent's AWC carries the parent's OBO facet; cannot present broader authority | §12 + `TOOLING §1.6` |
| 16 | Renewal-throughput load test (Program scale) | Synthetic load harness spins up 5,000 concurrent Program Runs with 5-minute-TTL AWCs, jittered renewal schedule, sustained for ≥2 TTL cycles; git control repo is disconnected/frozen for the duration | All renewals resolve against the in-memory projection only (zero git reads observed on the renewal path); sustained rate meets the §15 capacity model (~17–22 renewals/sec) within the SLO latency budget with no queueing backlog; a definition deprecated mid-run drains within one TTL purely via projection sync, with git disconnected | §15 — capacity model holds under load; renewal never depends on a live git read |

## 23. Consequences

**Positive.** Attribution becomes exact ("which Run of which git-SHA'd role, for whom, attested how"); revocation becomes surgical and also total; SoD and the forged-approval attack are closed at the identity layer; the kill-switch drains the whole non-human workforce *safely by expiry*; long-lived Program Runs — the scariest actors — are the ones most tightly watched and most easily drained. It converges with where the payment industry's own agent-identity efforts (Visa Trusted-Agent, Mastercard Agent-Pay identity) are heading, which is validation, not coincidence. Everything reuses the spine (Event Log, Policy Engine, git control plane, TEE, crypto-agility, Serving-Ops).

**Negative / cost.** A real identity-authority component (AIA/SPIRE-shaped) plus attestation infrastructure (TEE, transparency log) is genuinely new operational surface — the AIA's own availability and root-key protection become critical-path (a down AIA stops issuance = the workforce drains, which is fail-safe but also fail-*stopped*). Short-TTL renewal adds churn the fleet must absorb. Anomaly baselines need data and tuning before they're trustworthy.

**Neutral.** Human identity/JWT/RBAC is unchanged; ADR-022 adds the *non-human* subject beside it, not instead of it.

## 24. Residual risks (honest)

1. **AIA availability = a new critical dependency.** Fail-safe (drains) but fail-stopped (no new work); needs HA + a break-glass issuance path that is itself attested and audited — under-specified here.
2. **Attestation is only as strong as the hardware root-of-trust (ADR-021).** A firmware/silicon supply-chain compromise undermines the "attested code" guarantee; this ADR chains to ADR-021 and inherits its residuals.
3. **Anomaly baselines can be poisoned or evaded.** A patient adversary can drift a baseline slowly (the classic UEBA weakness); the renewal choke point and human checkpoints mitigate but don't eliminate it.
4. **TTL tuning is a real trade-off.** Too short = renewal churn + fleet load; too long = wider stolen-credential and slower-drain window. Illustrative defaults only until tuned on real NPCI load (same class of unknown as ADR-027's thresholds). §15's capacity model and the §22 #16 load test give a starting point and a way to *measure* churn before committing a default, but the tuned value for NPCI's actual Program sizes remains open until that load test runs against production-shaped traffic.
5. **SoD is only as good as the role taxonomy.** If producer and approver roles are mis-modeled in git, the identity-layer SoD check enforces a wrong separation faithfully — garbage-in.

---

## 25. Why this earns a 10 — and an honest self-score

**Every clause of the brief has a concrete enforcement mechanism, not a principle.** PART 1: the payment boundary is not a rule an implementer must remember — it is a **reserved apex `effect_class` with no dispatch arm**, backed by **five independent structural denials** (type system, registration, grant-vocabulary, git manifest, egress perimeter) plus a **runtime tripwire**, each individually sufficient, none removable without the most-reviewed diff in the repo; the **position on all five 2026 protocols** is stated with an NPCI-rails-operator frame that separates "the runtime never transacts" (categorical) from "should the rails offer agentic features" (deferred to NPCI/RBI), and **borrows AP2's mandate *shape* without its value-movement** for the payment-adjacent case; it is wired into Q2 (the `payment_boundary` front-matter, payments-council CODEOWNERS) and Q1 (Programs inherit the boundary). PART 2: identity is a **composite, per-Run, attested AWC** (SPIFFE-SVID-shaped, never shared), **externally verifiable** via TEE remote attestation + a transparency log, **JIT with short-TTL renew-and-re-attest** so long-lived Program Runs are a chain of re-authorized identities not a standing token, the **actor of record** completing ADR-026's two-trail audit, **individually and en-masse revocable**, with **producer≠approver SoD + signed handoffs** closing the forged-approval attack at the identity layer, a **safe-draining scoped kill-switch hierarchy**, and **UEBA anomaly detection aimed squarely at long-lived Run actors** — with policy in git and credential material in the data plane per Q2. Twenty-seven scenario tests across the two ADRs exercise exactly the properties that matter: a payment can't be initiated by any path, a mis-declared one is caught in flight, an agent's identity is always specific and attested, and the whole workforce drains safely on one switch.

**Self-score: design 9.5 / 10 (honest).** It is a genuine, artifact-backed 10 on the parts fully in the runtime's control — the payment boundary's structural denials and the identity lifecycle's issuance/rotation/revocation/SoD/kill-switch are complete, enforced, and testable. It is held to **9.5** because two hard realities are *managed and surfaced, not solved*: (1) the payment boundary's *semantic* recognizer (§4.5) leans on classifier recall — the destination perimeter is the belt to that suspenders, but a novel obfuscated egress path is a real residual (ADR-016 residual 1); and (2) the identity model's trustworthiness ultimately roots in the hardware attestation (ADR-021) and in anomaly baselines that can be slowly poisoned — enforcement surfaces this design specifies but cannot itself prove hold until ADR-021 and the eval/UEBA data exist. A design claiming a flat 10 here would be claiming it had solved adversarial semantic classification and unpoisonable behavioral baselines, which it has not. **Build maturity: 0 / 10** — no code exists, consistent with the whole corpus. The ceiling is set correctly so implementation can only descend from a real 10-shaped target, and the two half-points are named, not hidden.
