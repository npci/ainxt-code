# AiNxt Evaluation Platform — design to 10/10

**Status:** Design (no code). The mechanism behind **ADR-010 (Evaluation is a Gate, not a Dashboard)** — the keystone the corpus's design-10s silently assume (`RUNTIME_SCORECARD.md` Keystone note 1).
**One line:** a change to a prompt, a model, a retrieval config, or a skill/agent/role is a *scientific claim* ("this is at least as good as what it replaces"), and this platform is the apparatus that tests that claim with enough statistical validity, judge calibration, and anti-contamination governance that a payment regulator's model-risk function would sign the result — and refuses to ship the change if the claim fails.
**Closes gaps:** **C** (eval-as-a-continuous-gate), **AQ** (contamination/overfitting/holdouts), **X** (behavioral reproducibility / behavioral diffing), **BF/BT** (answer-quality + quality-drift), **AS** (canary + auto-rollback), **G** (RAG evals, with `STRUCTURED_FEDERATED_RETRIEVAL.md`), Pass-5 **[40]** (statistical methodology), **[41]** (rater calibration / IRR / κ), and the eval-loop half of **[23]** (postmortem→regression).
**Companion docs:** `AGENT_TESTER.md` (the Breaker — the adversarial half of "done"; mints cases into this platform), `SCENARIO_MATRIX.md` (the 1,000+-scenario safety/correctness rig), `PROMPT_ENGINEERING.md` §8 (the first consumer — eval-gated prompt deployment), `TOOLING_MCP_PLUGINS_ROUTING.md` §4.3/§4.6 (the router's quality scoreboard + live quality circuit-breaker this platform feeds), `ENTERPRISE_MEMORY_LEARNING.md` §4 (the flywheel that proposes eval-case candidates), `ADR-026` (control-plane git-native — eval sets are definitions), `ADR-012` (data-class routing — eval data + Judge routing), `ADR-014` (model risk — an eval run is model-validation evidence).

---

## 1. Why this exists, precisely

Two roles, one apparatus:

1. **The Gate.** No in-scope change reaches `env/prod` without a non-regressing, statistically valid **Eval Delta** (ADR-010 D1). This is the merge-blocking CI check + the online canary gate.
2. **The Instrument.** A continuously-running measurement system whose outputs *other subsystems consume*: the Model Router's per-`(model, task_type)` quality scoreboard (`TOOLING` §4.3), its live quality circuit-breaker (§4.6), the prompt drift monitor (`PROMPT_ENGINEERING.md` §8), the flywheel's eval-case curation (`ENTERPRISE_MEMORY_LEARNING.md` §4), and Model-Risk reporting (ADR-014).

The design problem is not "run some evals." It is: **make the measurement trustworthy enough to be a gate.** A gate you can pass by luck (gap [40]), by memorization (gap AQ), or by an uncalibrated judge (gap [41]) is worse than no gate — it manufactures confidence. Everything below is in service of *trustworthy measurement*.

**The division of labor with the Breaker, stated once (it recurs):**

| | **The Breaker** (`AGENT_TESTER.md`) | **The Eval Platform** (this doc) |
|---|---|---|
| Question | *How does it break?* (find failures) | *Is it good, and did this change make it worse?* (measure quality) |
| Method | adversarial, exploratory, novelty-seeking | curated sets, fixed metrics, statistics |
| Output | minimized repros → regression cases | scored deltas → gate verdicts + trends |
| DoD role | the *safety/correctness* half | the *quality* half |
| Handoff | mints cases into the **Regression Vault** (§10) and the **Scenario Matrix** | runs those cases + quality sets as the permanent gate |

Both are required to ship (`AINXT_OS.md` §130: "nothing ships until it passes **both** gates"). They are not the same thing and neither substitutes for the other: the Breaker finds the bug you didn't write an assertion for; the Eval Platform proves the fix didn't cost you quality elsewhere and keeps it from silently returning.

---

## 2. What is gated, and which suite each change triggers

The Gate applies to every **quality-bearing definition kind** (ADR-026). Each change class binds to the eval suite(s) that measure exactly its blast radius, so the gate is scoped, not a blanket re-run of everything:

| Change class | Triggering artifact | Eval suite(s) run | Baseline compared against |
|---|---|---|---|
| **Prompt** (L1–L4 layer, any model variant) | `prompts/*/definition.md` + `variant.*.md` | the Role's quality suite: correctness, steerability, format, tone/verbosity, groundedness, guard-integrity | the compiled body live at `env/prod` for that `(id, model_family)` |
| **Model** (new model onboarded; routing policy edit; detected provider silent-update) | `policies/data-class-routing`, model registry entry | per-`(model, task_type)` capability suite + the Model-Risk validation suite (ADR-014) | the incumbent model for that task type |
| **Retrieval** (chunking, embedding model/version, index config, metrics catalog) | `policies/*`, embedding config, `STRUCTURED_FEDERATED_RETRIEVAL.md` catalog | the RAG suite: groundedness, context precision/recall, recall@k, answer relevance, citation faithfulness (§6) | the retrieval config live at `env/prod` |
| **Skill / Agent / Role / Team / Workflow** (a composition) | `skills/*`, `agents/*`, `roles/*`, `teams/*`, `workflows/*` | the composition's quality suite (auto-generated per `AINXT_OS.md` Step 6) **+ the Breaker gate** (Step 7) + the relevant slices of the Scenario Matrix | the composition version live at `env/prod` |
| **Judge** (the instrument itself) | `evals/judges/*` | the **Judge calibration suite** against the human Gold Set (§4) | the incumbent Judge version |
| **Eval set** (the measuring stick itself) | `evals/*/definition.md` | meta-checks: power ≥ MDE, no contamination, rotation compliance (§3, §9) | n/a — this gates the *set*, not a product change |

**The recursive case is deliberate.** The Judge and the eval sets are themselves gated (they are definitions), so the instrument cannot silently drift or rot without a reviewable, measured change — the eval platform evaluates itself.

---

## 3. Offline eval suites

### 3.1 Structure — set / case / oracle

- **Eval Suite** — a versioned collection of Eval Sets for one target (a Role, a model task-type, a retrieval config). Bound to the target via front-matter (`eval_set: { id, version }`, `PROMPT_ENGINEERING.md` §3).
- **Eval Set** — cases for **one measured dimension** (correctness, steerability, groundedness, …), each dimension scored and gated *separately* (ADR-010 D3: per-cell, never one aggregate).
- **Eval Case** — one `{input, context-fixtures, oracle(s), pre-registered expectation}`. A case declares which **oracle(s)** decide pass/fail (the layered-oracle taxonomy from `AGENT_TESTER.md` §2: crash / spec / invariant / metamorphic / differential / visual / performance) plus the quality dimension it scores.

### 3.2 Measured dimensions (shared with `PROMPT_ENGINEERING.md` §8, `AINXT_OS.md` Step 6)

| Dimension | Scoring | Why this scorer |
|---|---|---|
| **Correctness** | task ground-truth where it exists; else Judge-scored against a reference | the core "is the answer right" |
| **Steerability / instruction-following** (BG) | **mechanical** wherever possible — bullet counts, forbidden/required terms via regex, length bounds, schema-valid structure (`PROMPT_ENGINEERING.md` §9) | cheap, scale-safe, judge-drift-immune |
| **Format adherence** | deterministic schema/grammar validation | objectively checkable |
| **Tone / voice** (BL), **verbosity** (BM) | Judge-scored against the Role persona, with length as a controlled covariate | genuinely semantic |
| **Groundedness** (B/AA) | RAG suite (§6) | supported-by-context is checkable against the retrieved set |
| **Guard integrity** (AM) | the Breaker's leak/injection matrix run *as part of this gate* | security is not a separate optional pass |
| **Numeric correctness** (BH) | **server-side re-derivation diff** (`STRUCTURED_FEDERATED_RETRIEVAL.md` §5) — never a Judge | a confidently-wrong ledger sum is a payment incident |

**Principle: prefer a deterministic oracle to a Judge whenever the property is objectively checkable.** The Judge is reserved for genuinely semantic judgments (correctness-vs-reference, tone, holistic groundedness). This bounds Judge cost and judge-drift exposure (residual 1) and is why steerability and numerics are mechanical, not judged.

### 3.3 How cases are authored (never one source, never hand-only)

- **Curated seed cases** — domain experts write the gold cases for a Role (the highest-value, lowest-volume source).
- **Breaker-generated** — the adversarial agent generates boundary/combinatorial/i18n/injection cases (`AGENT_TESTER.md` §3) at volume.
- **Flywheel-proposed** — real corrections/abandonment become case *candidates* in a staging set (`ENTERPRISE_MEMORY_LEARNING.md` §4), human-promoted only, contamination-guarded (§9).
- **Synthetic-realistic** — for regulated distributions, synthetic-but-valid data (test-range Luhn PANs, valid-but-fake IFSC) so cases carry the right *shape* without real PII.

Every case records provenance (`human:{expert}` | `system:breaker` | `system:flywheel` | `system:synthetic`), so the corpus's composition is auditable and a bad batch is traceable (mirrors `ENTERPRISE_MEMORY_LEARNING.md` §7 lineage).

---

## 4. The Judge — a calibrated, versioned, pinned instrument (gap [41])

`PROMPT_ENGINEERING.md` §12 residual 1 defers this here explicitly: *"needs judge-model pinning + periodic judge-calibration audits."* This section is that design.

### 4.1 The Judge is a definition, not a call site

A `judge` is a control-plane kind (ADR-026): `{ base_model, model_version, params (temp=0, seed), rubric_body (content-hashed), scoring_scale, dimension }`. It is pinned, versioned, and **gated like any other definition** (§2). "The Judge" is never "whatever model we called that day" — a turn's Event-Log record names the exact Judge version that scored it, so a score is reproducible from SHA (§12).

### 4.2 Calibration against a human Gold Set (the core of trustworthiness)

- **Gold Set.** A human-labeled reference set of cases per dimension, produced by a **Calibration Panel** of ≥3 qualified raters (domain experts for the Role in question).
- **Inter-rater reliability is quantified.** The panel's agreement is measured with **Cohen's κ** (pairwise) / **Fleiss' κ** (n-rater) for categorical judgments and **Krippendorff's α** for ordinal scales. A Gold Set whose *human* κ is below a documented floor (e.g., κ < 0.6) is **not fit to calibrate a Judge** — you cannot calibrate a machine against a reference humans themselves don't agree on. Low κ triggers **rubric refinement + adjudication** (a rubric humans can't apply consistently is a defective rubric), then re-rating — the panel calibrates *itself* first (gap [41]).
- **Judge admission.** A candidate Judge is admitted only if its **agreement with the adjudicated Gold labels clears a documented floor** — reported as Judge-vs-human κ *and* balanced accuracy (κ alone hides class imbalance) *and* the confusion matrix (so a Judge that's great at "good" and blind to "bad" is caught). A Judge below the floor never gates a change.
- **Re-calibration cadence.** Judge-vs-Gold agreement is re-audited on **every Judge version bump** and **periodically in production** (a scheduled ADR-027 Program). This is the defense against **silent judge drift** — a provider updating the model behind a cloud Judge shifts scores independent of the prompts being judged (`PROMPT_ENGINEERING.md` §12 residual 1); the periodic re-audit detects the agreement drop and quarantines the Judge before its drift is mistaken for product drift.

### 4.3 Structural bias controls (not "we told it to be fair")

Known LLM-judge pathologies are engineered out, not prompted away:

- **Position bias** → all pairwise (A/B) scoring is **order-randomized and averaged over both orders**; a Judge that flips its verdict on order is flagged as unreliable for that case.
- **Self-preference** → a Judge **never scores output produced by its own base model family** (ADR-010 D2; ties `RUNTIME_FEATURE_FLOWS.md` §4.1 cross-model review). Producer=Claude → Judge≠Claude; for regulated data, producer=Qwen → Judge=GLM (two different in-house OSS models).
- **Verbosity/length bias** → length is a **controlled covariate** in the model that estimates the score, and a length-matched control slice detects a Judge rewarding verbosity per se.
- **Rubric grounding** → the Judge scores against an explicit, versioned rubric with **required justifications** (reason-then-score), and justification quality is itself sampled against the Gold Set — an unjustifiable "score" is discarded.

### 4.4 Judge panels + escalation

For high-stakes dimensions, scoring is an **ensemble**: N pinned, model-diverse Judges vote; **disagreement is a first-class signal** — a case where the panel splits is (a) not counted as a confident pass/fail and (b) routed to a human for adjudication and, if systematic, into the Gold Set. This turns judge uncertainty into calibration signal instead of hiding it behind a majority vote. Single-Judge scoring is used only for low-stakes/high-volume dimensions where the calibration floor is comfortably met.

---

## 5. Statistical methodology — the gate is a decision, not a mean (gap [40])

Pass-5 gap [40] states the failure bluntly: *"the gate can be satisfied by noise."* A gate that blocks on `candidate_mean < baseline_mean` blocks on coin-flips. This section makes the gate a **pre-registered, powered, corrected statistical decision.**

### 5.1 Pre-registration (anti-p-hacking)

Before a run, the eval-set definition declares (in git, reviewable, ADR-026): the **metrics**, each metric's **direction** and **non-inferiority margin** (how much worse is "not a regression" vs "noise"), the **primary vs secondary** metric split, the **power (default 0.8)** and **α (default 0.05)**, and the **analysis method**. You cannot see the results and *then* choose which metric or subgroup to report — metric-shopping is structurally prevented because the analysis is fixed before the data exists.

### 5.2 Framing: non-inferiority, not superiority

A change usually needs to prove it is **not meaningfully worse** (non-inferiority) rather than strictly better. The gate blocks when the candidate is worse than baseline by more than the pre-registered margin, at significance — a change that is statistically indistinguishable from baseline **passes** (it didn't regress), and one that is worse beyond the margin **blocks**. An "improvement" claim (for canary promotion between two candidates) uses the stricter superiority test. This distinction is why a null change (test #2 in ADR-010) yields "no measured effect," not a regression.

### 5.3 Power + MDE (an underpowered set is a defect)

Each eval set is sized so it can **detect its pre-registered MDE at the declared power**. If the set is too small to detect the effect it claims to gate, the platform **fails the set as underpowered** (ADR-010 test #4) rather than emitting a falsely-confident pass — a gate that cannot see the thing it gates is surfaced, never trusted. **Paired designs** (the same cases through baseline and candidate) are the default because they slash variance vs unpaired, and **CUPED-style covariate adjustment** (using pre-period per-case difficulty) further reduces variance so smaller sets reach adequate power.

### 5.4 Multiple-comparison correction (both directions matter)

The gate watches many cells: `metric × model_family × category`. Uncorrected, "some cell looks worse" is guaranteed by multiplicity. The platform controls the false-discovery rate with **Benjamini-Hochberg (FDR)** across the cell family (with a **Bonferroni/Holm** family-wise option for the small **hard-safety subset** — data-class-leak, redaction-correctness, RBAC — where any false negative is unacceptable and the stricter control is worth the power cost). Correction protects both ways: it prevents a **false block** from pure multiplicity *and* prevents a **real regression from hiding** in the noise of many cells.

### 5.5 Effect sizes, not p-values alone

Every cell reports **effect size + confidence interval**, not just significance. A "significant" but sub-MDE change is reported as **no material effect**; an improvement not distinguishable from noise is reported as **no measured improvement** — never "better." This is what stops a 10,000-case set from flagging a trivially-tiny, practically-meaningless difference as a "regression" and flapping the gate.

### 5.6 Sequential testing — the honest resolution of "no peeking"

- **Offline gate = fixed-sample.** Pre-registered N (§5.3); analyzed once. Classic, clean, no peeking problem because you don't peek.
- **Online canary = always-valid.** You *cannot* tell operators not to look at a live rollout, so the online monitor uses **anytime-valid inference — confidence sequences / mixture-SPRT-family / α-spending** — under which continuous monitoring and early stopping **do not inflate the false-positive rate**. Operators may watch and stop the moment a confidence sequence crosses, safely (ADR-010 test #5). This is the correct engineering answer to gap [40]'s "sequential testing / no peeking," not a policy asking humans not to peek.

---

## 6. RAG evals (gap G; with `STRUCTURED_FEDERATED_RETRIEVAL.md`)

Retrieval changes are gated exactly like prompt/model changes. The RAG suite decomposes quality so a regression is *localized* (retrieval vs generation), because "the answer got worse" is useless without "…because recall dropped" vs "…because the model stopped citing":

| Metric | What it measures | Scorer |
|---|---|---|
| **Context recall** | did retrieval fetch the chunks needed to answer? | against a labeled relevant-set per case |
| **Context precision** | are the top-ranked chunks the relevant ones (not padding)? | rank-aware, against the labeled set |
| **Recall@k / MRR** | classic retrieval quality at the k the pipeline uses | deterministic |
| **Groundedness / faithfulness** | is every claim in the answer supported by the retrieved context (no hallucination)? | Judge, claim-decomposed |
| **Answer relevance** | does the answer address the actual question? | Judge |
| **Citation faithfulness** (AA) | does each cited source *actually support* the specific claim it's attached to? | Judge + span-check |

**Load-bearing gates this makes possible:**
- **Embedding-migration gate (gap AN).** Changing the embedding model/version means re-embedding the corpus; a half-migrated corpus silently degrades retrieval (`GAP_ANALYSIS` AN — "this alone can sink a RAG system"). The RAG suite gates the migration: context recall must not regress, and a mixed-version index is caught as a recall drop, not discovered in production.
- **Chunking/catalog change gate.** A chunking-strategy or metrics-catalog change (`STRUCTURED_FEDERATED_RETRIEVAL.md` §2) runs the RAG suite before it can ship.
- **Global/sensemaking mode** (`STRUCTURED_FEDERATED_RETRIEVAL.md` §6/§7.2, residual) gets its **own eval set** — map-reduce over a sparse postmortem corpus can produce noisy communities; its answer quality is measured, not assumed.
- **Data-class-aware.** RAG cases over regulated corpora stay in-boundary and are Judge-scored by an in-house model (ADR-012); the security filter (pre-rank chunk-level ACL, gap AJ) is itself a scored property — a case where a restricted chunk *appears* in retrieved context is a hard-safety-cell failure, not a quality nit.

---

## 7. Online A/B / canary + auto-rollback (gap AS)

Offline evals approximate; only live traffic reveals real-distribution shift, latency, cost, and guardrail-trigger-rate. So a tagged, offline-passing version enters **canary** before 100% (the exact env-ref traffic split from `PROMPT_ENGINEERING.md` §3/§8, and the same progressive-delivery pattern as `SERVING_OPS.md`'s model-weight rollout — **one canary discipline, not three**):

- **Traffic split by env-ref.** `canary.weight_pct` of turns route to `env/prod-canary`; the rest to `env/prod`. Not a DB flag — a git-ref-pinned split (ADR-026).
- **Same metrics, computed online**, plus latency/cost/guardrail-trigger-rate, monitored with **always-valid inference** (§5.6) so continuous watching is safe.
- **A/B and multi-arm** live here: two candidate tags run concurrently, scored on the same suite plus online metrics; the winner is promoted (its tag becomes the new `env/prod`), the loser's ref resets and its tag stays reachable but DEPRECATED (`PROMPT_ENGINEERING.md` §8).
- **Auto-rollback on established regression.** A regression that clears the always-valid bound on any watched metric **flips the pointer back** (ADR-026 §6.2) — instant, exact, byte-for-byte — and **notifies a human, doesn't page one** (gap AS). The same "a bad push never touches the live pointer" discipline as hot-reload, applied to a percentage of traffic.
- **Interaction with the router.** A canary that trips the **live quality circuit-breaker** (`TOOLING` §4.6) is handled by the router as a route quarantine *and* mints a Regression Vault case (§10) — the online gate and the router breaker are the same signal wired to two consumers.

---

## 8. Quality-drift detection (BF/BT/X) — evals that never stop

A change that passed its gate can still degrade later: the provider silently updates a cloud model, the retrieval mix shifts (new docs indexed, embedding migration), or usage moves off-distribution into cases the set never covered (`PROMPT_ENGINEERING.md` §8). The **Drift Monitor** runs continuously in PRODUCTION:

- **Sampled, not full-traffic** (cost-bounded): a sampled stream of live turns is Judge-scored on the same dimensions, per `(Role, model_family, artifact_version)`.
- **Distribution monitoring, not pass/fail.** It tracks the *score distribution over time* and behaviorally-diffs against the eval-set baseline distribution (gap X) — so a "still passes pass/fail" prompt whose *answer distribution* quietly worsened is caught, not just a hard failure.
- **Change-point detection.** **CUSUM / sequential change-point** methods flag a statistically-significant shift (not single-turn noise), tuned to the sampling volume so it neither flaps nor sleeps.
- **Provider-silent-update tripwire.** A frozen canary tripwire set is re-run on a schedule against each cloud model; a shift with *no control-plane change* on record isolates "the provider changed the model under us" from "we changed something" — the exact ambiguity `TOOLING` §4.3 needs the eval platform to resolve.
- **On confirmed drift:** auto-open a ticket against the current artifact and (per policy) auto-rollback to last-known-good pending investigation (`PROMPT_ENGINEERING.md` §8) — the same mechanism as a canary regression, triggered by a slower signal.

---

## 9. Eval integrity — sealed holdouts, contamination, rotation (gap AQ)

Evals rot in three ways; each has a mechanism (not a hope):

### 9.1 Sealed holdouts (the reconciliation with ADR-026)

Fully detailed in **ADR-010 §5**. In brief: the eval-set **manifest** (id/version/taxonomy/pre-registration/`content_commitment` Merkle root) is a PII-free git definition; the **case corpus + gold labels** live **sealed in a data-plane store readable only by the eval-runner machine identity** (ADR-022) + an audited break-glass quorum — *never* by the authors of the definitions the set gates. This preserves git-native governance of the set's existence/versioning while keeping the answer key out of the graded party's eyes (contamination defense) and out of the boundary when regulated (data-class). The manifest is content-addressed to the sealed corpus, so a swapped corpus is caught exactly like the ADR-026 `control.lock` check.

### 9.2 Contamination scanning

Before a candidate ships, the platform scans for overlap between eval-case content and the candidate's **prompts / retrieved context / fine-tune corpus** (n-gram + embedding-similarity overlap). A hit **fails the gate as a platform defect** (ADR-010 test #11) — a memorized eval is a false-positive pass, tracked at the same severity as a quality defect (`PROMPT_ENGINEERING.md` §8). Fine-tune corpora are additionally checked against holdouts *before training* (ties `ENTERPRISE_MEMORY_LEARNING.md` §4/§9), because a holdout leaked into a fine-tune poisons every future gate that model faces.

### 9.3 Rotation + tripwires + flywheel hygiene

- **Rotation.** Holdouts rotate on a schedule so a set can't quietly become memorized-by-familiarity; refreshed cases are drawn from the seed/Breaker/flywheel pipelines (§3.3).
- **Tripwires.** A small set of cases **never used for tuning** detects overfitting — a candidate that aces the visible set but drops on the sealed slice is caught (`PROMPT_ENGINEERING.md` PE10).
- **Flywheel staging→promotion.** Flywheel-derived candidates land in a **staging set**, never auto-added to the live/holdout set; a human explicitly promotes, contamination-guarded (`ENTERPRISE_MEMORY_LEARNING.md` §9 acceptance). The flywheel *proposes* eval cases; it never *legislates* them into the gate.

---

## 10. The Regression Vault — postmortem→permanent regression (gaps [23], X)

**A bug found once is tested forever.** The Vault is a frozen, ever-growing, sealed eval set the gate runs on every relevant change. Three sources feed one sink:

1. **Breaker findings** (`AGENT_TESTER.md` §6): every verified, minimized repro auto-mints a Vault case.
2. **Live quality circuit-breaker trips** (`TOOLING` §4.6): the exact turns that scored below baseline are frozen; a recovered route must pass *that case*, not merely re-climb the live threshold.
3. **Incident postmortems** (`ENTERPRISE_MEMORY_LEARNING.md` §4, `IncidentPostmortem` OKI): a confirmed AI-incident's reproducing input becomes a Vault case, through human-gated curation, contamination-guarded into the sealed store.

Every Vault case carries the **Event-Log id + control-plane commit SHA** it was born from → reproducible-from-SHA (gap X; ADR-026 §17; admissible per ADR-025). This is what makes the platform **monotonic in safety**: the set of failures that can never silently return only grows. A model/prompt/route that regressed is not "restored" by beating a live threshold — it is restored only by passing the frozen case that caught it. This is the concrete closure of gap [23]'s "postmortem→regression-eval loop."

---

## 11. Where it runs (architecture)

Split cleanly along ADR-026's control/data axis:

- **Control plane (git, reviewed):** eval-set manifests (`ainxt-control/evals/`), Judge specs (`evals/judges/`), pre-registration, canary policy, rotation policy, CODEOWNERS on each. Changing what/how we measure is a reviewed, diffable, signed git operation.
- **Data plane (stores):** the **sealed case corpora + gold labels** (encrypted, runner-only), **eval-run results** (scores, effect sizes, verdicts — high-write, queryable, per the `RUNTIME_SCORECARD`/`EvalsDashboard` read view), the **drift score stream**, and the **Regression Vault** corpus. All erasable/retained per ADR-015; none in git.
- **The eval runner** is a **dogfooded harness on the runtime** (same agent loop, tools, sandbox, governance, machine identity — `AGENT_TESTER.md` §intro) — the ultimate dogfood, and the reason it can drive the real product at scale.
- **Budget + scale:** Judge-at-scale and corpus-wide re-evals are budget-bounded (`AGENT_TESTER.md` §5); a full re-eval (e.g., after an embedding migration across the whole corpus) runs as an **ADR-027 Long-Horizon Program** — thousands of bounded runs with durable state, not one unbounded loop.
- **CI wiring:** the offline gate is a **required, merge-blocking status check** on the PR (ADR-026 §7.1 branch protection); the online gate is the canary controller reading `env/prod` vs `env/prod-canary` (§7).

---

## 12. Reproducibility, data-class, and audit (X, ADR-012, ADR-025)

- **Reproducible from SHA.** Every gate verdict, canary decision, and Vault-case origin records the eval-set version, Judge version, candidate SHA, params, and seed on the Event Log — a verdict from two years ago replays to the same result (gap X; ADR-026 §17). This *is* the ADR-014 model-validation record and is exportable as ADR-025 admissible evidence.
- **Data-class throughout.** Regulated eval data + its Judge stay in-boundary (ADR-012); a cloud Judge is never attempted on a `regulated-payment` set (§7 of ADR-010). Eval embeddings of regulated data are regulated data (gap AJ) — sealed and in-boundary.
- **The gate is compliance-safe.** Eval I/O traverses the same Compliance Gate; a redaction-correctness eval tests the gate *through* the gate.
- **No side effects.** An eval of a `SideEffecting`/`initiates-settlement` capability runs against a ledgered stand-in (ADR-013/016) — the eval platform can never move value.

---

## 13. Acceptance / quality-eval tests

These are the platform's own DoD (mirrors the `PROMPT_ENGINEERING.md` §10 / `AGENT_TESTER.md` §6 convention). The ADR-010 §8 table covers the *decision-level* proofs; these cover the *mechanism*:

- **EP1 (per-cell gate).** A change that lifts aggregate correctness while dropping one category blocks on that category's cell — the aggregate never masks it (§5.4).
- **EP2 (null change → no effect).** Re-running the identical definition many times never yields a "regression" or "improvement" verdict after FDR correction (ADR-010 test #2).
- **EP3 (underpowered set flagged).** A set too small for its MDE fails as underpowered, not as a pass (§5.3).
- **EP4 (paired + CUPED power).** A paired/CUPED-adjusted set reaches the target power at a materially smaller N than the unpaired equivalent — verified on a synthetic effect (§5.3).
- **EP5 (Judge calibration floor).** A Judge below the κ / balanced-accuracy floor is not admitted; a low-human-κ Gold Set triggers rubric refinement before any Judge is calibrated to it (§4.2).
- **EP6 (position-bias control).** A Judge that flips verdict on A/B order is flagged; order-averaged scoring is stable (§4.3).
- **EP7 (self-preference block).** A Judge is never paired with its own base-model-family producer; the pairing is refused (§4.3).
- **EP8 (judge-drift detection).** A simulated provider model-swap behind a cloud Judge is caught by the Judge-vs-Gold re-audit before it corrupts a gate (§4.2).
- **EP9 (RAG localization).** A retrieval regression is attributed to context-recall (not generation) by the decomposed RAG suite; an embedding half-migration is caught as a recall drop (§6).
- **EP10 (always-valid online).** Continuous canary monitoring with early stop holds the declared false-positive rate; a fixed-sample analysis of the same stream would not (§5.6).
- **EP11 (sealed holdout).** An author cannot read the gold answers for the set gating their PR; the manifest is readable, the corpus is not (§9.1).
- **EP12 (contamination block).** A candidate containing lifted holdout text fails the gate as a platform defect despite a perfect score (§9.2).
- **EP13 (tripwire overfit).** A visible-set-overfitted candidate shows a measurable drop on the sealed/tripwire slice (§9.3).
- **EP14 (Vault monotonicity).** A route that tripped the circuit-breaker, then "recovered," is still blocked until it passes the exact frozen Vault case that caught it (§10).
- **EP15 (reproduce-from-SHA).** A 90-day-old gate verdict replays to the same result from its Event-Log record (§12).
- **EP16 (data-class Judge).** A `regulated-payment` eval is scored only by an in-house Judge; a cloud Judge is never attempted (§12).
- **EP17 (drift, no false page).** Injecting a synthetic quality regression behind the drift sampler alerts within the window; steady-state noise does not (CUSUM tuning, §8; `PROMPT_ENGINEERING.md` PE8).

---

## 14. Why this is now a 10

It converts "we have a dashboard" into "a change is a claim the platform tests before it can ship," with every place eval programs actually die designed *out*: the gate is **satisfiable-by-noise-proof** (pre-registered, powered, FDR-corrected, effect-size-reported, always-valid online — gap [40]); the Judge is a **calibrated, versioned, bias-controlled instrument** with a documented human κ and periodic drift re-audit rather than an oracle taken on faith (gap [41]); holdouts are **sealed** so git-native governance (ADR-026) and contamination-resistance (gap AQ) coexist via the same authorization-vs-data split ADR-026 itself uses; RAG changes are **gated with localized retrieval-vs-generation metrics** including the embedding-migration trap that sinks RAG systems (gaps G/AN); quality is **watched continuously** for drift (BF/BT/X) and, most importantly, every failure — from the Breaker, from a live circuit-breaker trip, from an incident — is **minted into a permanent, reproducible-from-SHA Regression Vault case** so the platform is monotonic in safety (gaps [23]/X). It is the engine the router's quality scoreboard, the prompt drift monitor, the flywheel's eval curation, and Model-Risk reporting all consume — one measurement discipline, not five — and it holds itself to the same boundaries it enforces (no side effects, compliance-through-the-gate, data-class-routed, budget-bounded). That is what makes the corpus's other 10s real instead of assumed.

---

## 15. Residual risks (honest)

1. **Judge cost + irreducible judge imperfection.** Calibration, pinning, ensembles, and mechanical-oracle-first *reduce* but do not eliminate judge error or cost; the semantic core is a calibrated-but-imperfect instrument, and Judge-at-scale is a real budget line (`AGENT_TESTER.md` §5). Named, not hidden.
2. **Cold-start / underpowered gates.** A brand-new capability has too little data to power a gate; until it does, its gate is honestly *advisory* — a window in which a regression could ship. Mitigation: Breaker + synthetic seeding, and loud "advisory-only" labeling so an advisory gate is never mistaken for enforced. This is the same "small-N" honesty `RUNTIME_SCORECARD.md` §58 applies to new artifacts.
3. **The human calibration panel is load-bearing.** The whole edifice rests on a human panel whose own κ must stay high; fatigue/turnover degrades the reference the Judge is calibrated against. Mitigation: rotation, κ monitoring, and funding the panel as an owned role — not a favor squeezed between sprints.
4. **Gate-latency → side-door pressure.** A slow gate invites a "quick publish" bypass — the DB-status-field failure mode returning in eval clothing (ADR-026 §17.4). Mitigation: fast/pre-warmed eval infra + a structural "no bypass" (A1 invariant), never a fast lane that skips measurement.
5. **Contamination scanning is recall-bounded.** A paraphrased leak of a held-out case can evade the scanner and quietly overfit. Rotation + sealed corpora + tripwires are the defense-in-depth; the residual is that no single scanner is complete — the same detector-recall honesty ADR-026 §17.1 states for PII-at-entry.
6. **Metric validity is a standing question.** A gate is only as meaningful as its metrics correlate with real user value; a suite that measures the wrong thing passes changes that feel worse. Mitigation: the flywheel's real-feedback correlation (`ENTERPRISE_MEMORY_LEARNING.md` §4) is periodically checked against eval scores — a metric that diverges from feedback is itself a defect to fix, not a truth to defend.
