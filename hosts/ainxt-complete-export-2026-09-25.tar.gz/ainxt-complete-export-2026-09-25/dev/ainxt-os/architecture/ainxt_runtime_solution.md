AiNxt Enterprise AI Runtime

Master Architecture Specification (v1.0)

Purpose

Build an enterprise-grade AI Runtime that serves as the single execution spine for every AiNxt product. Every capability is implemented once and exposed consistently through CLI, APIs, web applications, desktop applications, workflows, and enterprise integrations.

⸻

1. Vision

AiNxt is not a CLI.

AiNxt is not a chat application.

AiNxt is not an SDK.

AiNxt is an Enterprise AI Runtime Platform.

Every interface (CLI, Chat, API, Buddy, Document Generation, SDLC Automation, IDE extensions, future mobile apps) consumes the same Runtime.

⸻

2. High-Level Architecture

                       ┌───────────────────────────┐
                       │      AiNxt Runtime        │
                       └─────────────┬─────────────┘
                                     │
 ┌──────────────┬──────────────┬─────┼─────┬──────────────┬──────────────┐
 │              │              │           │              │              │
CLI         Web Chat       REST API   Desktop App     IDE Plugin    Buddy
 │              │              │           │              │              │
 └──────────────┴──────────────┴───────────┴──────────────┴──────────────┘
                                     │
                           Shared Runtime Services

No business logic is duplicated across clients.

⸻

2A. Current Reality & Migration Strategy (Strangler-Fig)

This document describes the TARGET state. It is not a from-scratch rewrite of a blank repository — AiNxt already runs a substantial, production platform, and that platform is not to be disturbed while the Runtime is built.

Today's platform:

* Backend: Python / FastAPI (`gateway.py`, :8000) — the current execution spine (orchestrator, compliance engine, model router, hybrid retriever, SDLC pipeline, RQ workers).
* Frontend: React 19 + Vite + Tailwind (`ai-ui/`).
* Data: PostgreSQL + pgvector, Redis, Ollama.
* Ops: PM2 (prod), Docker sandboxing.

Migration principle — coexist, then converge:

1. The AiNxt Runtime is built in Rust as a SEPARATE service, deployed alongside the Python gateway.
2. The Python gateway CALLS the Rust Runtime service (HTTP/gRPC over localhost, same pattern as the existing embed_svc / llm_proxy sidecars). Python is the caller; Rust is the callee.
3. Capabilities move into the Runtime one module at a time (strangler-fig). The Python implementation for a given capability is retired only after its Rust equivalent is stable and verified in production.
4. Do NOT modify or refactor the existing Python code to accommodate the Runtime. The Runtime adapts to the current contracts, not the reverse.
5. End state: once every capability is served by the Rust Runtime, it becomes the single, final execution spine and the Python gateway is decommissioned.

This keeps the live platform (chat, agents, SDLC, connectors, doc-generation) uninterrupted throughout the transition.

⸻

3. Runtime Modules

* API Gateway
* Authentication & Authorization
* Session Manager
* Prompt Engine
* Context Engine
* Model Router
* Agent Runtime
* Tool Runtime
* Workflow Runtime
* Plugin Runtime
* Skill Runtime
* Connector Runtime
* Memory Runtime
* Artifact Runtime
* Scheduler
* Event Bus
* Security & Policy Engine
* Telemetry & Observability

⸻

4. Client Applications

AiNxt CLI

Purpose:

* Interactive AI terminal
* Code generation
* Repository operations
* Git workflows
* Shell execution
* Streaming responses
* Authentication
* Session management
* Local configuration
* Local cache
* MCP client
* Offline settings

The CLI must not contain business logic. It invokes Runtime APIs or embeds the same Runtime libraries where appropriate.

⸻

AiNxt Web Chat

* Enterprise chat experience
* Streaming
* Voice (future)
* File upload
* Image generation
* Document generation
* Multi-agent conversations
* Workspace awareness

⸻

AiNxt REST API

Provides programmatic access to every Runtime capability.

Examples:

* /chat
* /agents
* /tools
* /skills
* /plugins
* /artifacts
* /workflows
* /memory
* /models
* /sessions

⸻

Buddy

Enterprise automation interface. Glossary: CoWorker = Buddy, a Surface Profile on the Runtime — "Cowork" names the mode, "Buddy" is the profile (see `AINXT_OS.md`, `RUNTIME_FEATURE_FLOWS.md` §2.6). Server-side connectors only, so Buddy is identical across web and desktop.

Responsibilities:

* Microsoft Graph
* Outlook
* Teams
* Calendar
* SharePoint
* Enterprise tasks
* Scheduling
* Notifications

⸻

SDLC Platform

Enterprise development automation.

Examples:

* PR Review
* Test Generation
* Code Analysis
* Security Scan
* Architecture Review
* Deployment Automation
* CI/CD Assistance

⸻

Document Platform

Responsible for

* DOCX
* PPTX
* PDF
* Excel
* Markdown
* HTML
* Architecture diagrams
* Reports

⸻

5. Runtime Services

Prompt Engine

* Prompt templates
* Dynamic rendering
* Variables
* Guard prompts
* Versioning

⸻

Context Engine

Combines

* Conversation
* Repository
* User preferences
* Workspace
* Enterprise knowledge
* Memory
* RAG
* Connector data

⸻

Model Router

Supports

* OpenAI
* Anthropic
* Gemini
* Azure OpenAI
* Ollama (local/dev convenience only — not a production serving path)
* Self-hosted OSS fleet (Qwen / GLM / Gemma / Kimi, served via vLLM)
* NVIDIA NIM
* Amazon Bedrock
* OpenRouter
* Custom providers

Routing based on

* Cost
* Latency
* Capability
* Context size
* Enterprise policy

Enterprise model policy is a hard constraint, not advisory: a canonical model registry defines tier→model mappings (simple / medium / complex / vision / etc.), a BLOCKED_MODELS list the router must refuse, and a set of user-selectable-only models that are never auto-routed. AiNxt is multi-model by design (Anthropic + OpenAI + Gemini + local) — no capability may hardcode a single provider; everything routes through the Model Router.

Data-class → model-eligibility (ADR-012, `TOOLING_MCP_PLUGINS_ROUTING.md` §4.2) makes self-hosting the OSS fleet MANDATORY, not optional: `regulated-payment` and `PII`-classified turns may be served ONLY by the in-house OSS fleet (Kimi/GLM/Gemma/Qwen) behind vLLM — for those data classes the eligible set is empty without it, so this is not a preference among providers, it is the only legal path. `Ollama` is a local/dev convenience and is explicitly NOT a production serving path; production OSS serving runs the same models behind vLLM, fronted by the Rust-native Serving-Ops orchestration layer (`SERVING_OPS.md` — capacity planning, placement, QoS, node attestation), never bare Ollama. Enforcement: the router's `class_eligible` filter (`TOOLING_MCP_PLUGINS_ROUTING.md` §4.1 step 2) is applied before ranking and is non-overridable by user model selection. Acceptance test: a `regulated-payment`-classified turn must never reach a cloud or Ollama-backed endpoint — it is served by the in-house vLLM fleet or fails closed with an explicit low-confidence flag.

⸻

Agent Runtime

Responsibilities

* Planning
* Reasoning
* Task decomposition
* Tool invocation
* Recovery
* Scheduling
* Collaboration

⸻

Tool Runtime

Responsible for

* Registration
* Discovery
* Permissions
* Sandboxing
* Execution
* Validation
* Timeouts

⸻

Skill Runtime

Reusable enterprise capabilities.

Examples

* RCA generation
* Test generation
* Architecture review
* Compliance review
* Settlement investigation
* Release notes

⸻

Workflow Runtime

Supports

* Sequential execution
* Parallel execution
* Conditions
* Loops
* Human approval
* Scheduling

⸻

Plugin Runtime

Supports

* Installation
* Versioning
* Isolation
* Permissions
* Marketplace integration

⸻

Connector Runtime

Supports

* Microsoft Graph
* GitLab (NPCI's sole SCM — GitHub is intentionally excluded; all SCM integrations use GitLab REST API v4)
* Jira
* Azure DevOps
* Jenkins
* ServiceNow
* SAP
* Oracle
* Databases
* Kafka
* MCP Servers
* REST APIs

⸻

Memory Runtime

* User memory
* Workspace memory
* Enterprise knowledge
* Semantic retrieval
* Vector search

⸻

Artifact Runtime

Generates

* DOCX
* PPTX
* PDF
* Excel
* Images
* Markdown
* HTML
* Source code

⸻

Security Runtime

* Authentication
* RBAC
* ABAC
* Policy engine
* Secrets management
* Encryption
* Audit logging
* Data masking
* PCI/DSS Compliance Engine (NON-NEGOTIABLE) — runs on all input and output before/after every model call. Detects PAN, CVV, EXPIRY, PIN block, INDIA_PAN, AADHAAR, account/IFSC, secrets/keys/tokens, UPI, mobile, email via regex + Luhn + entropy. Policy is REDACT-and-PROCEED, never hard-block. This gate cannot be bypassed by any client or capability.

⸻

6. Marketplace

Supports publishing and versioning of:

* Skills
* Plugins
* Agents
* Connectors
* Workflow templates
* Prompt templates

⸻

7. Recommended Technology Stack

Core Runtime

* Rust (stable)
* Tokio
* Axum
* Tower
* Serde
* Reqwest
* SQLx
* Tonic (gRPC where needed)

CLI (DECIDED — Rust, headless-only)

* Rust
* Clap
* Tokio
* A minimal readline (single blocking prompt only — see below; not a TUI library)

No interactive-TUI stack ships in the CLI — Ratatui, Crossterm, and Reedline are deliberately not dependencies, to align this spec with the headless-only CLI decision. The CLI is a thin, pipe-friendly renderer of the same typed event stream every surface consumes (streaming text / `--json` / exit codes); Desktop and Web are the full-fidelity interactive renderers of that protocol. The one narrow, explicitly-designed exception is `ainxt run --interactive-approvals`: a single blocking `y/n/feedback` readline prompt per Approval Gate event, for a human at a bare SSH terminal with no GUI reachable — one synchronous prompt over the same protocol event a Desktop dialog answers, not a rendering engine. See `INTERACTION_REPL_COMMANDS.md` §1 for the full justification (why no interactive TUI, and the REPL-use-case coverage table showing every other job already lives elsewhere in the protocol). Enforcement: the CLI crate's dependency manifest is checked in CI; a diff adding `ratatui`, `crossterm`, or `reedline` fails the build. Acceptance test: `cargo tree -p ainxt-cli` must contain none of those three crates.

Rationale (ADR to be written): the CLI is a thin client that links the Runtime's own Rust crates directly (agent loop, model router, tools) rather than reimplementing them — "implement once, expose everywhere". Rust also gives a clean-room break from the scrapped TypeScript/Ink CLI (whose stack was the source of pattern/name leakage and the yoga-WASM memory leak), and ships as a single static binary per platform (Windows + Mac).

Web Frontend

* React
* Vite
* Tailwind CSS
* TanStack Query
* React Router

Desktop

* Tauri (Rust + Web UI)

API

* REST (primary)
* WebSocket
* Server-Sent Events
* gRPC (internal)

Database

* PostgreSQL
* pgvector

Control-plane / data-plane split (ADR-026 — binding): PostgreSQL/Redis/pgvector above hold OPERATIONAL state only — sessions, user memory/PII, the event log, telemetry, budgets, connector tokens — anything erasable-on-request or high-write-per-user. DEFINITIONS (prompts, skills, agents, workflows, policies) are NOT rows in these stores; they are the source of truth as versioned files in the git-native control repo — branch = DRAFT, PR + CI = PENDING_APPROVAL, merge = APPROVED, a signed tag on the `env/prod` ref = PRODUCTION, CODEOWNERS = authoring RBAC + named owner, git history = the audit trail, tag/SHA = versioning and rollback — loaded into the Runtime at startup and hot-reloaded on change. RBAC-on-EXECUTE (who may run a definition right now, as opposed to who was allowed to author it) is a separate, per-turn decision enforced at run time by the Security & Policy Engine reading the definition's manifest front-matter — git governs authoring, never execution. The Marketplace (§6) is correspondingly a federation of pinned git repositories (TOFU hash-pin — trust-on-first-use, then pin by content hash), not a DB table of blobs. Enforcement: the control-repo loader re-hashes every definition's checked-out bytes against `control.lock` at load time and refuses on mismatch. Acceptance test: a definition edited outside a merged, CODEOWNERS-approved PR — or a marketplace dependency whose pinned content hash no longer matches its upstream tag — must fail to load into the Runtime, not silently execute.

Cache

* Redis

Message Bus

* NATS JetStream (preferred for lightweight eventing)
* Kafka (if very high-volume streaming/event processing is required)

Current reality: the Python platform uses Redis (RQ queues + Redis Streams for SSE token delivery) plus a Kafka consumer for async SDLC event writes. During coexistence the Rust Runtime interoperates with these; NATS is a target-state choice, adopted per ADR, not a day-one requirement.

Object Storage

* S3-compatible storage (MinIO for self-hosted deployments)

Search

* PostgreSQL + pgvector (HNSW), with Postgres BM25/tsvector for hybrid retrieval + reranking. This is the standing choice — the platform is already all-in on pgvector and ChromaDB was fully removed; do not reintroduce a separate vector DB (Qdrant) without an ADR justifying it.

Authentication

* OAuth2
* OIDC
* SAML (enterprise)
* Microsoft Entra ID
* Keycloak (optional)

Observability

* OpenTelemetry
* Prometheus
* Grafana
* Loki
* Jaeger

Packaging

* Docker
* Kubernetes
* Helm

⸻

8. Non-Functional Requirements

* Horizontal scalability
* High availability
* Stateless services where possible
* Streaming-first APIs
* Zero-downtime deployment
* Structured logging
* Distributed tracing
* Backward-compatible APIs
* Plugin isolation
* Rate limiting
* Quotas
* Multi-tenancy
* Disaster recovery
* Performance testing
* Security testing

Target throughput:

* ≥ 2,000 requests/second (baseline, horizontally scalable)

⸻

9. Engineering Principles

1. Runtime-first architecture.
2. Implement once, expose everywhere.
3. Clean APIs before UI.
4. Provider-agnostic by design.
5. Enterprise security by default.
6. Test before merge.
7. Performance is a feature.
8. Backward compatibility is mandatory.
9. Public extension points instead of private hacks.
10. Documentation is part of the deliverable.

⸻

10. Reference Projects (Architecture Study Only)

Study these projects for ideas and trade-offs:

* Grok Build
* OpenCode
* OpenHands
* Aider
* Goose
* Continue
* Cline

Avoid copying:

* Source code
* Internal identifiers
* File layouts
* Comments
* Prompts
* Branding
* Project-specific terminology
* Unique implementation details

Instead, create AiNxt Architecture Decision Records (ADRs) documenting why AiNxt chose its own implementation.

⸻

11. Long-Term Goal

AiNxt Runtime becomes the enterprise AI backbone for:

* CLI
* Web Chat
* REST API
* Desktop
* IDE Extensions
* Buddy
* Document Generation
* SDLC Automation
* Skills
* Plugins
* Marketplace
* Agents
* Future enterprise AI products

Every capability is built once, tested once, secured once, and reused everywhere.


“I want AiNxt to be legally mine. I want to study the best projects, but I don’t want anyone to later say AiNxt is just a fork of Grok Build, Claude Code, or OpenCode.”

Yes—and this is actually the part I would not leave out. Based on everything you’ve told me over the last year, your biggest concern isn’t technical. It’s this:

“I want AiNxt to be legally mine. I want to study the best projects, but I don’t want anyone to later say AiNxt is just a fork of Grok Build, Claude Code, or OpenCode.”

That deserves its own section in the architecture document.

I would add something like this:

⸻

12. Legal & Intellectual Property Strategy

Objective

AiNxt shall be an independently developed, enterprise-grade AI platform.

Existing open-source projects are used only as engineering references unless code is intentionally incorporated in compliance with their licenses.

The long-term objective is for AiNxt to have its own architecture, terminology, implementation, and brand.

⸻

Engineering Rules

Rule 1 – Study, don’t mirror

Every external project is treated as a reference implementation.

Understand:

* Architecture
* Trade-offs
* Algorithms
* User experience
* API design

Do not reproduce them verbatim.

⸻

Rule 2 – Never copy

Do not copy:

* Source code
* Comments
* README content
* Prompt templates
* Documentation
* Tests
* Folder structures solely because another project uses them
* Internal naming
* Class names
* Variable names
* Constants
* Enums
* Error messages
* Logos
* Icons
* Branding
* Screenshots

⸻

Rule 3 – Own terminology

Never use project-specific terms such as:

* gboom
* tengu
* SuperGrok
* Claude Code internal terminology
* OpenCode internal terminology

AiNxt defines its own vocabulary.

⸻

Rule 4 – Own architecture

Every subsystem must have an AiNxt Architecture Decision Record (ADR).

Example:

ADR-001 Runtime
Why this architecture?
Alternatives studied
Pros
Cons
Reason chosen

This creates evidence of independent engineering decisions.

⸻

Rule 5 – Independent implementation

Before implementing a feature:

1. Study 3–5 projects.
2. Write an ADR.
3. Close all reference code.
4. Implement AiNxt’s own design.

This is a stronger clean-room process than coding while directly following one project’s source.

⸻

Rule 6 – License compliance

If AiNxt intentionally includes third-party code:

* Preserve required licenses.
* Preserve copyright notices.
* Preserve NOTICE files when required.
* Document third-party components.
* Track versions.

⸻

Rule 7 – Trademark protection

Never use another project’s:

* Name
* Logo
* Product identity

AiNxt maintains its own brand.

⸻

Rule 8 – Documentation ownership

All documentation must be written specifically for AiNxt.

Do not reuse upstream documentation.

⸻

Rule 9 – Prompt ownership

All system prompts

Agent prompts

Workflow prompts

Planning prompts

Tool prompts

must be authored specifically for AiNxt.

⸻

Rule 10 – Public APIs

Public APIs should be designed for AiNxt’s needs.

Avoid copying another project’s API surface simply because it exists.

⸻

Open Source Policy

The project should maintain:

LICENSE
NOTICE
THIRD_PARTY_LICENSES/
THIRD_PARTY_NOTICES.md
SECURITY.md
CONTRIBUTING.md
CODE_OF_CONDUCT.md
PATENTS.md (optional)
ARCHITECTURE.md
ADR/

⸻

License Strategy

If the project is completely independently implemented:

Choose:

* Apache 2.0

or

* MIT

based on community and business goals.

If third-party code is included:

Maintain the required obligations for those components.

⸻

Third-party Inventory

Maintain a machine-readable inventory including:

* Component name
* Version
* License
* Repository
* Usage
* Modified? (Yes/No)

⸻

Contributor Policy

Every contributor certifies:

“I have the right to contribute this code.”

This is commonly done through a Developer Certificate of Origin (DCO) or a Contributor License Agreement (CLA), depending on how you want to run the project.

⸻

One thing I want to challenge

There is one sentence you said that I think is unrealistic:

“I don’t want this to be caught.”

If by “caught” you mean “I don’t want anyone to know I studied Grok Build”, that’s not a realistic or necessary goal. Many successful open-source projects are openly inspired by earlier work.

The stronger goal is:

“I want AiNxt to be independently engineered, legally compliant, and recognized for its own architecture.”

That is achievable.

If, in two years, someone compares AiNxt to Grok Build, they should be able to say:

* The concepts are similar because they solve similar problems.
* The architecture reflects AiNxt’s own design decisions.
* The code is independently written (or any reused code is properly attributed and licensed).
* The branding, terminology, APIs, and documentation are AiNxt’s own.

That’s a much more defensible position than trying to make it appear no inspiration ever existed.