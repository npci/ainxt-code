# AiNxt Harness SDK — How an Engineer Builds Their Own Harness

**Status:** Design doc (no code — API shapes are illustrative, to be finalized in ADR-002/ADR-004).
**Audience:** NPCI engineers who want to ship their *own* AI product (a "harness") on the shared runtime without forking it.
**v1 scope:** DECLARATIVE-FIRST (compose from existing capabilities). Programmatic custom capabilities + WASM plugins + custom renderers are Phase 5. Plugin isolation will be WASM/WASI.

---

## 1. What a "harness" is

A harness is a **configured agent experience** over the runtime. Formally:

```
Harness = {
  persona          # system prompt / role
  capabilities     # which tools/skills/connectors are exposed (from the shared registry)
  model_policy     # tier or explicit model (resolved via model_registry)
  context          # retrieval namespace / repo scope / memory strategy
  autonomy         # none | assisted (HITL on writes) | autonomous (judge-audited)
  rbac             # visibility (private/department/public) + capability permissions
  renderer         # default = chat; custom renderer is Phase 5
}
```

The products AiNxt ships — Chat, Code, Buddy, SDLC — are *themselves* harnesses. "Let engineers build harnesses" means giving them the same authoring surface we use.

**Agent vs Harness:** an *agent* is a harness with the default chat renderer. A *harness* can additionally bundle its own renderer (Phase 5). In v1 they are effectively the same authoring act.

---

## 2. Two authoring paths (v1)

### 2.1 Declarative (primary) — a manifest, no code

```yaml
# settlement-investigator.harness.yaml
kind: harness                    # ADR-026 manifest key — definition type
id: settlement-investigator      # ADR-026 manifest key — stable identifier
version: 1.0.0                   # ADR-026 manifest key — bumped on every publish
owner: settlement-ops-team       # ADR-026 manifest key — CODEOWNERS entry; authoring RBAC
persona: |
  You are an NPCI settlement operations analyst. You investigate why a
  settlement batch failed, cite the exact records, and never speculate.
model_policy: complex            # -> tier -> model_registry (multi-provider)
capabilities:                    # ADR-026 manifest key
  - kb.search                    # RAG over a docs namespace
  - connector.postgres.query     # a governed, read-only settlement DB connector
  - artifact.generate_report     # doc-gen (Artifact Runtime)
context:
  namespace: docs_kb:settlement
autonomy: assisted               # HITL approval on any write/side-effect
execute_rbac:                    # ADR-026 manifest key — RBAC-on-EXECUTE, read by the Policy Engine at run time
  visibility: department         # scoped to the settlement dept via AD org tree
  permissions:                   # least-privilege; Policy Engine must grant these
    - connector.postgres.query:read-only
data_class_ceiling: internal     # ADR-026 manifest key — max data classification this harness may touch (never PAN/PCI-scoped)
payment_boundary: none           # ADR-026 manifest key — none | read-only | write; gates any live payment-rail access
depends_on: []                   # ADR-026 manifest key — pinned repo@tag@content_hash refs this harness requires
```

There is no `governance` or `status` field: per ADR-026, status is a **git position**, not a file property — DRAFT is the branch, PENDING_APPROVAL is an open PR under CI, APPROVED is the merge, and PRODUCTION is a signed tag on the env/prod ref (see §3).

Register it → it becomes a first-class agent invocable from Chat, CLI, REST, or a connector trigger. No code written.

**Manifest keys (ADR-026) — enforcement + acceptance test:**

| Key | Meaning | Enforced by | Acceptance test (house bar) |
|---|---|---|---|
| `kind`, `id`, `version` | definition type, stable identity, semver | control-repo CI schema validator | CI job `manifest-lint` fails a PR whose manifest is missing `kind`/`id`/`version` or reuses an `id` already tagged in the repo |
| `owner` | named CODEOWNERS entry — authoring RBAC | GitLab CODEOWNERS + branch protection | a PR touching this manifest cannot merge without an approving review from `owner`'s CODEOWNERS group |
| `execute_rbac` | RBAC-on-EXECUTE (visibility + capability permissions) | Policy Engine, read from manifest front-matter at run time | integration test: a user outside `execute_rbac.visibility` invokes the harness → Policy Engine returns 403 before the agent loop starts |
| `data_class_ceiling` | max data classification the harness may process | Compliance Gate, cross-checked against Policy Engine at run time | integration test: harness with `data_class_ceiling: internal` is fed a PAN/PCI-scoped input → Compliance Gate blocks the run rather than executing it |
| `payment_boundary` | declared live payment-rail access (`none`/`read-only`/`write`) | Policy Engine gates any payment-rail connector call against this field | integration test: a harness declaring `payment_boundary: none` attempts a payment-rail connector call → Policy Engine rejects the call |
| `depends_on` | pinned `repo@tag@content_hash` refs this harness requires | Marketplace resolver, TOFU-verified on install (see §3) | install test: mutating a pinned dependency's content after first pin causes a content-hash mismatch and the install fails closed |

### 2.2 Programmatic — the SDK (for orchestration + Phase-5 custom capabilities)

```python
from ainxt import Runtime, Harness

rt = Runtime(base_url="https://ainxt.npci.internal", token=OIDC_TOKEN)

inv = Harness(
    name="settlement-investigator",
    persona="You are an NPCI settlement operations analyst...",
    model_policy="complex",
    capabilities=["kb.search", "connector.postgres.query", "artifact.generate_report"],
    context={"namespace": "docs_kb:settlement"},
    autonomy="assisted",
)

# Stream a turn — you receive TYPED events, not raw text
for ev in inv.run("Why did batch NEFT-2026-07-18 fail to settle?"):
    match ev.type:
        case "text.delta":        print(ev.text, end="")
        case "tool.call":         log(f"calling {ev.name}({ev.args})")
        case "approval.request":  ev.approve()          # or ev.reject("not allowed")
        case "artifact":          save(ev.artifact)     # the generated report
        case "usage":             meter(ev.tokens, ev.cost)
```

The SDK is a thin, ergonomic client over the runtime **protocol** (REST/gRPC/SSE). Python ships first (NPCI's ecosystem), TypeScript second (powers the IDE extension + web tooling). The **headless CLI is itself a thin wrapper over this SDK** — build once.

---

## 3. The local development loop

```
ainxt harness dev ./settlement-investigator.harness.yaml
   → runs the harness LOCALLY against the runtime (dev tenant), hot-reload on save
   → full event stream in the terminal; step through tool calls + approvals
   → runs the harness's scenario tests:  ainxt harness test ./settlement-investigator/
   → commit the manifest to a feature branch in the control repo — the branch IS the DRAFT (ADR-026)
ainxt harness publish ./settlement-investigator.harness.yaml
   → opens a PR against the control repo — PR open + CI running IS PENDING_APPROVAL (ADR-026)
   → CI runs manifest-lint + Policy Engine dry-checks; CODEOWNERS (the manifest's `owner`) must approve
   → merge to the target ref IS APPROVED; a signed tag on the env/prod ref IS PRODUCTION (ADR-026)
   → the Marketplace and every consumer install/discover by pinned repo@tag@content_hash, TOFU-verified
     on first pin — never by floating branch or "latest"
   → now callable by permitted users on any surface
```

An engineer iterates locally with real runtime semantics, tests against scenarios, then publishes via a PR through the control repo — never touching the spine directly (ADR-026: control plane is git-native).

---

## 4. What the engineer gets for free (and cannot break) — safety lives in the spine

This is the guardrail that keeps engineer-built harnesses from becoming the next generation of PoCs. **No matter what a harness author does**, the runtime enforces:

| Guarantee | Enforced by | Author can disable? |
|---|---|---|
| PCI/DSS compliance on all model I/O + tool results | Compliance Gate (pipeline) | ❌ never |
| RBAC + department scoping + multi-tenancy | Identity/Policy Engine | ❌ |
| Least-privilege capability grants | Policy Engine (declared permissions) | ❌ (must be granted) |
| Budget / rate-limit / backpressure | Runtime middleware | ❌ |
| Cancellation / timeout / retry / stuck-detection | Agent loop | ❌ (inherited) |
| Audit trail + telemetry | Event Log + OTel | ❌ |
| Sandbox for any custom code (Phase 5) | WASM/WASI runtime | ❌ |

The author owns *what the harness does* (persona, capabilities, flow). The runtime owns *that it stays safe, compliant, scoped, and observable*. You **cannot** author a non-compliant or over-privileged harness — the safety is not in your code.

---

## 5. What each capability an engineer can compose from looks like

Capabilities in the shared registry (native or MCP — indistinguishable to the author):
- **Knowledge:** `kb.search`, `graph.query` (code+docs knowledge graph)
- **Code:** `code.edit`, `code.read`, `bash.run` (sandboxed), `sast.scan`
- **SCM/ALM:** `connector.gitlab.*`, `connector.jira.*`
- **Office:** `connector.graph.*`, `connector.outlook.*`, `connector.teams.*`
- **Data:** `connector.postgres.query`, `connector.kafka.*` (governed, permissioned)
- **Artifacts:** `artifact.generate_document`, `artifact.generate_report`
- **Meta:** `agent.invoke` (call another agent as a sub-agent), `compare.fanout`

An engineer composes these; in Phase 5 they can register new ones as WASM plugins under the same permission model.

---

## 6. Why this is the enterprise multiplier
- Turns AiNxt from "a fixed set of products" into "a **platform** where NPCI teams ship their own governed AI products."
- Each team's domain harness (settlement, fraud, ops, risk) reuses the *same hardened spine* — so a team's harness is production-grade the day it's written, because it inherits compliance/RBAC/scale/audit.
- Marketplace + git-native governance (ADR-026) means harnesses are **discoverable** (pinned `repo@tag`, federated via TOFU hash-pin), **versioned** (signed tags/SHA on the env/prod ref, never a floating branch), **reviewed** (PR + CODEOWNERS history is the audit trail), and reusable across departments.
