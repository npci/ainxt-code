# AiNxt Runtime — Development Execution Plan, Model Strategy & Per-Feature UX

**Status:** Execution plan (design→build transition). Companion to `IMPLEMENTATION_PLAN.md`, `AINXT_OS.md`, `RUNTIME_SCORECARD.md`.

---

## 0. Are we ready to start? — Yes, to start P0. Not yet to feature code.
- **Design ceiling = a genuine 10** (scorecard). That's the prerequisite, and it's met.
- **Ready to start = P0 foundations.** We are NOT ready to write feature Rust until P0's load-bearing contracts + the eval keystone exist.
- **Build the keystone first:** the Eval Platform + Scenario Harness. Without it, "done" has no teeth and several design-10s silently degrade.

---

## 1. How development STARTS and ENDS (the arc)

### START — P0 Foundations (design→build gate)
1. **ADRs 001–015** — the load-bearing decisions frozen (Runtime, Protocol, Tool+MCP, Compliance/Guardrails/Injection, Data-residency/classification, Idempotency, Model-risk, Data-lifecycle, Licensing…).
2. **Rust workspace + crate skeleton + vocabulary lock** — the decomposition, own terminology, clean public interfaces.
3. **The Protocol contract** — typed commands/events (the seam every renderer + SDK depends on). Load-bearing; freeze early.
4. **Eval Platform + Scenario Harness (KEYSTONE)** — the 1,000+-scenario rig + quality-eval + the Breaker substrate. Built *before* features so DoD has teeth from turn one.
5. **OSS scaffolding** — LICENSE (Apache-2.0), NOTICE, THIRD_PARTY, SECURITY, CONTRIBUTING, CODE_OF_CONDUCT, ADR/, DCO.
6. **CI/CD** — build, clippy, coverage, cargo-audit, SAST, reproducible builds.

### MIDDLE — P1→P4 (each gated by eval + Breaker; shadow-mode vs Python)
- **P1 Runtime core spine + the Chat-done-right vertical slice** (the flagship rides P1).
- **P2 Connector Runtime** (unblocks web connectors).
- **P3 Surface profiles + RAG/quality** (Chat fully, then Code, Buddy, SDLC as profiles).
- **P4 Client layer** (Python SDK → TS SDK → headless CLI → IDE ext; point Desktop/Web at the runtime directly).

### FIRST "END" — v1 launch
**Runtime + thin Studio + Chat-done-right, flawless, both gates green.** One surface at 100%, not six at 60%.

### FINAL "END" — the platform is self-sustaining (P5 + ongoing)
- Studio (conversational factory), Marketplace, WASM plugins, more roles (Code/SDLC/Buddy) as compositions.
- Python retired per-capability as each Rust equivalent proves out.
- There is no hard "end" — it's an OS. The *program's* definition-of-done: all core surfaces live on the runtime, eval+Breaker-gated, teams authoring their own roles, the flywheel improving it.

### Definition of "done" for ANY feature
Green scenario matrix **+** green quality-evals **+** shadow-parity **+** cut over behind a flag with rollback. Never from a demo.

---

## 2. Model strategy for the BUILD (used wisely)
Default to the cheapest model that clears the bar; escalate only for genuine difficulty (per `feedback_model_tiering`).

| Model | Used for (build-time) |
|---|---|
| **Opus** | ADRs + protocol design; security-critical subsystems (injection, OBO authz, idempotency); the Breaker's oracle reasoning; adversarial verification; cross-doc synthesis; hardest algorithm/architecture calls |
| **Sonnet** | The bulk: most subsystem implementation, code generation, tests, standard design, routine agent tasks |
| **Haiku** | Mechanical: classification, formatting, docstrings, simple refactors, lint-fixes, cheap eval pre-filters |

(Distinct from the *runtime's* model policy, which routes end-user turns by complexity + data-class per `core/model_registry`.)

---

## 3. The user experience of each feature (quality-first, no compromise)

### Chat (flagship)
Type a vague question → fast first token, a "thinking" indicator on hard ones → a **grounded** answer with **inline clickable citations** to NPCI sources. Follow-ups just work ("generate this as pdf" → PDF of the *prior* answer, never the instruction). Rich rendering (tables/code/artifacts in a side panel, not walls of text). Smart model routing by default (data-class enforced silently); a model picker for power users. Calibrated clarification only when genuinely ambiguous. Remembers you across sessions, with a "what do you remember about me" control.

### Code (Desktop)
Open a workspace (file tree + editor + agent panel). Ask in natural language → agent searches (ripgrep + semantic), edits via **semantic/AST-aware editing**, shows **inline diffs for approval**. Every edit runs the **code-review pipeline** before commit; you see the confidence score + what passed/failed; **"done" is proven, not claimed**. Runs code in a sandbox; self-heals failures. MCP servers + tools available with approval gates. (No interactive TUI — headless CLI covers servers/CI; Desktop is the rich surface.)

### SDLC
Triggered by a Jira/GitLab webhook or from the UI. You watch the run: exploration → **plan (you approve the design at a HITL gate)** → coding by the role team (Architect→Planner→Coder→Reviewer→Breaker) → verify → independent judge → **solution approval** → MR created. Full transparency via the Event Log; honest complete-vs-capped; the agent never opens an MR it can't defend.

### Agents
Create one **by conversation in Buddy** — *"I need an agent that drafts release notes from merged MRs."* The runtime decomposes intent, assembles the spec, **Breaker-tests it**, then **authors a `definition.md` and opens a PR to the git-native control repo** — merge is APPROVED, a signed tag on `env/prod` is PRODUCTION (ADR-026). Not node-wiring. Then invoke it from chat, CLI, a workflow step, or a connector trigger — identically.

### Skills
Same conversational authoring: describe a **behavioral** skill (an SOP) or an **execution** skill (code that runs before the LLM). The runtime helps author and validates it, then opens a PR to the control repo — branch=DRAFT, PR+CI=PENDING_APPROVAL, CODEOWNERS-reviewed merge=APPROVED, signed tag on `env/prod`=PRODUCTION (ADR-026 git-native lifecycle, not a DB status column). The skill becomes a capability any agent/role can use.

### Buddy (Cowork)
The office surface: connectors (Outlook/Teams/Graph/SharePoint) work in **web and desktop** identically (tokens server-side). Ask it to do office work; it acts via connectors + doc-gen; computer-use is desktop-only and gated. **The conversational factory lives here** — "build me a role/skill/agent" — and it **emits a reviewable PR, not a DB row**: the runtime authors the `definition.md` (manifest + body) and opens the PR to the git-native control repo; the human reviews/merges like any other change (ADR-026). The Studio is a git client, not a form that writes a table.

---

## 4. MCP & Tools — not missed; here's where they live + the UX
Design is in `TOOLING_MCP_PLUGINS_ROUTING.md`. What matters for UX:
- **One capability surface.** Native tools, MCP-discovered tools, and (P5) plugins are indistinguishable to the user and the agent — all just "capabilities," all governed the same way.
- **Adding an MCP server** = config or one click in the Marketplace → tools **auto-discovered, ranked, and governed**; **approval on first use**; per-user OAuth for remote servers; a dead server never blocks the rest (lazy parallel connect).
- **Tool discovery at scale** = retrieval-based ranking surfaces only the relevant capabilities per turn (so hundreds of tools don't degrade the model's choice) + a `capability.search` escape valve.
- **Safety the user feels as trust, not friction:** side-effecting tools are **idempotent** (no double-execution), run under **on-behalf-of authority** (the tool can only do what *you* may do), and pass **egress DLP** before any outbound call. Risky actions hit the **approval gate**.
- **Users never see plumbing** — they see capabilities the agent can use, gated by approval; admins manage the catalog + policy.

---

## 5. Adoption, sustainability & executive accountability (Pass-5 gaps 29, 31, 44, 47)
Design quality doesn't save a platform that nobody adopts, that leaks users to shadow tools, or that a sponsor defunds for lack of proof. Each of the four gaps below gets a concrete mechanism + acceptance test — the house bar — not just a callout.

### Shadow-AI / BYO-AI displacement (gap 29)
Engineers already pasting payment code into personal ChatGPT/Copilot is a Day-1 audit finding, not a hypothetical — winning displacement takes a carrot **and** a stick, not a policy memo.
- **Carrot — parity + low-friction import.** A living, published **parity checklist** (feature-by-feature vs. the tool being displaced, refreshed every release) proves AiNxt is never behind; a **one-click "import my prompt/chat history"** path (from common export formats) removes the switching-cost excuse. If starting over is harder than staying, the mandate alone won't hold.
- **Stick — egress DLP, measured not assumed.** The existing egress-DLP gate (TOOLING §1.7 / compliance engine) is paired with a **DLP telemetry signal** — corporate network/endpoint DLP flagging payment-code-shaped content leaving to a non-approved AI domain.
- **Mechanism:** a monthly **Shadow-AI Displacement Score** = (DLP-flagged external-AI attempts) ÷ (AiNxt DAU), trended per department; a rising score triggers a parity-gap review.
- **Acceptance test:** a synthetic DLP event for a payment-code paste to a non-approved external AI domain updates the score within one reporting cycle and names the offending department — the signal is live telemetry, not a survey.

### Sustainability, monetization & Apache-2.0 irreversibility (gap 31)
Apache-2.0 release is a one-way door — a hyperscaler can host a rival managed offering of the same code, and no license clause claws that back. The design accepts this explicitly rather than hoping it doesn't happen.
- **Mechanism:** before Apache-2.0 release, the sponsoring body signs a **multi-year funding commitment** as a precondition, because the moat is *operational*, not legal — the eval keystone, regulated-FI compliance ops, and NPCI-specific connectors/data. Per ADR-026's control-plane/data-plane split, the **control repo (definitions) and the eval corpus stay NPCI-private** even though the runtime engine is Apache-2.0 — the license covers the engine, not the institution's accumulated capability.
- **Acceptance test:** a tabletop exercise — "a hyperscaler announces a managed fork tomorrow" — must be answerable today with a named funding line and a named non-portable asset (control repo + eval corpus), not a shrug.

### IDE-embedded UX (gap 44)
An extension that's a thin SDK wrapper plateaus fast — engineers won't leave the IDE to get review-pipeline value.
- **Mechanism — four concrete surfaces, native to the IDE, not a chat panel bolted on:**
  1. **Inline code-lens** — a lens above any function/class an open agent run touches, showing live status without switching to CLI/Desktop.
  2. **Quick-fix-from-SAST** — a `CODE_REVIEW_PIPELINE.md` finding surfaces as a native quick-fix action; one click accepts the agent's patch, no copy-paste round-trip.
  3. **In-editor diff parity** — the same semantic/AST-aware diff Desktop renders (`SEMANTIC_EDITING.md`) renders identically in the IDE's native diff view, never a degraded text-only diff.
  4. **Handoff surfacing** — when a multi-role run hands off (Architect→Coder→Reviewer→Breaker), the IDE shows which role is active and why, inline.
- **Acceptance test:** a SAST-flagged line fixed via the IDE quick-fix action alone (no terminal, no Desktop panel) reaches the same passing code-review-pipeline state as the Desktop flow — the IDE is a first-class surface, not a wrapper.

### Executive adoption / ROI dashboard (gap 47)
Platforms get defunded when a sponsor can't prove value — independent of whether the platform is actually good.
- **Mechanism:** an executive dashboard (data-plane telemetry, never control-plane) tracking, per department: **DAU/WAU**, **time-saved** (sampled task-time-before vs. measured task-time-after), and a **pilot-purgatory early-warning** — a department whose WAU trend is flat-to-declining for 2 consecutive months post-onboarding is flagged *before* the annual budget review, not discovered at it.
- **Acceptance test:** given synthetic WAU flat for 8 weeks post-onboarding, the dashboard raises the pilot-purgatory flag before the next scheduled budget review — early-warning fires on trend, not on a sponsor asking.

**Budget & adoption-erosion — added to the risk framing.** Feeds the Part C risk register (`IMPLEMENTATION_PLAN.md`): a platform can be architecturally sound and still die from unmeasured shadow-AI leakage (29), an unfunded post-Apache-2.0 fork threat (31), an IDE-adoption plateau (44), or a sponsor blind to ROI until too late (47). Each now carries a named metric and an early-warning trigger above, so this risk is monitored continuously, not discovered at the next budget cycle.

---

## 6. Bottom line
We are **ready to start P0**. The arc: freeze the contracts + build the eval keystone → P1 runtime core carrying Chat-done-right → widen to Code/Buddy/SDLC as governed compositions → Studio + workforce. Every step gated by eval + the Breaker; models used wisely (opus for hard/critical, sonnet for the bulk, haiku for mechanical); MCP/tools are a first-class, governed, uniform capability surface across every feature; and adoption/ROI/budget risk (§5) is tracked with the same rigor as the technical gates — the platform must be *seen* to work, not just *actually* work.
