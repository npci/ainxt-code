# P5 Exit — Definition-of-Done Status

**Status (2026-07-19):** P5 **Extensibility Platform** foundation BUILT + increment-tested. The
declarative-first extensibility model — engineer-authored harnesses + programmatic plugins, governed
git-natively, confined by capability-based security — is implemented with its safety-invariant
acceptance matrix green locally. The WASM/WASI sandbox, live git-host integration, and the
`harness dev/test/publish` UX loop remain — see "Not yet proven" (stated honestly per
`feedback_enterprise_grade_no_poc`).

## What is built (3 crates)

`ainxt-harness` (Harness API + capability-permission core) · `ainxt-governance` (git-native lifecycle
+ marketplace) · `ainxt-plugin` (plugin isolation seam).

The whole phase exists to run **untrusted, engineer-authored** extensions safely. The governing
principle — *safety lives in the spine, not the extension* — is enforced structurally:

```
Harness:  effective authority = requested ∩ granted ∩ principal   (least privilege, per step)
          hard budget (steps / tokens / tool-calls, fail-closed)
          NO manifest field can disable compliance/RBAC/audit  (deny_unknown_fields)
Governance: DRAFT(branch) → PENDING_APPROVAL(PR+CI) → APPROVED(signed merge) → PRODUCTION(signed tag)
          publish emits a PULL REQUEST, never a DB row;  pre-receive gate BLOCKS a PII push
          marketplace = pinned git repos, trust-on-first-use hash pin (mismatch rejected)
Plugin:   capability-based security — no ambient authority; only granted capabilities reachable
          output size-limited; trap/panic isolated (host survives); memory/time limits declared
```

## Evidence (all green: per-crate `cargo test` + `clippy -D warnings`)

- **`ainxt-harness` 8 tests** — happy path; **cannot** use an ungranted / unrequested / unauthorized
  capability; budget caps steps/tokens/tool-calls; RBAC floor; and the manifest schema **rejects a
  gate-bypass field** (deny_unknown_fields).
- **`ainxt-governance` 7 tests** — full lifecycle + PR-rejection-back-to-draft; invalid transitions
  refused; **publish emits a PR (not a DB row)**; pre-receive gate **blocks** a PII push (never
  redacts); marketplace TOFU pins then rejects a hash/URL mismatch.
- **`ainxt-plugin` 8 tests** — a plugin runs with a granted capability; an **ungranted capability is
  denied** (no ambient authority); effective = requested ∩ granted; output over limit refused; a
  **panicking plugin is isolated** and the host survives; unknown-plugin + bypass-field rejection.
- **P5 acceptance matrix** (`ainxt-harness/tests/dod_p5_matrix.rs`): **10 scenarios** across the P5
  categories — declarative harness E2E; the four harness safety invariants (no gate bypass, no
  permission escalation, no budget overrun, RBAC floor); git-native lifecycle to production + publish
  emits a PR; pre-receive gate blocks PII; marketplace TOFU rejects a tampered hash; plugin
  capability-confinement; plugin panic isolation — layered oracles + JUnit.

### Enterprise safety invariants proven (the P5 acceptance headline)
- An author **cannot disable compliance/RBAC** — the manifest schema has no field for it and rejects
  one; the authz + audit seams are required constructor args.
- An author **cannot exceed granted permissions** — effective authority is the triple intersection
  `requested ∩ granted ∩ principal`, checked per step, fail-closed.
- An author **cannot exceed budget** — steps/tokens/tool-calls are hard caps enforced by the runtime.
- An author **cannot escape isolation** — a plugin has no ambient authority (only its granted
  capabilities are reachable), its output is bounded, and a trap/panic is caught.
- **Governance is git, not a DB** — publishing emits a reviewable PR; nothing becomes authoritative
  without CI + CODEOWNERS + a signed merge; a PII-bearing push is blocked before it reaches history.
- **Supply chain is pinned** — a marketplace source's hash/URL is trust-on-first-use; a later
  mismatch is rejected.

## Not yet proven here (needs infra / a legal exception)

- **WASM/WASI sandbox (wasmtime)** — the capability-confinement + output + panic **contract** is
  enforced + tested via the native host; the hard **memory/time isolation** for third-party code is
  wasmtime's job, a deferred impl of the same `PluginHost` trait. Its `Apache-2.0 WITH LLVM-exception`
  license needs a **reviewed `deny.toml` exception** — a Gate-#0 legal item — which is why it isn't
  wired yet (keeping the license gate green).
- **Live git-host integration** — the lifecycle state machine + `publish`→PR + pre-receive gate are
  modeled + tested; wiring them to a real GitLab (branch/PR/merge/signed-tag, CODEOWNERS, branch
  protection, signed-tag verification) is go-live infra (ADR-026 risk register).
- **Enterprise pre-receive detector** — the gate uses the OSS marker detector; production plugs the
  full PCI/DSS detector behind the same seam.
- **`harness dev`/`test`/`publish` UX loop** — the `publish`→PR primitive is done; the developer loop
  is a CLI feature over the P4 CLI (follow-up).
- **Real marketplace federation** — TOFU pin logic is done; fetching/verifying real remote repos is
  infra.
- **Human Gate #0 (legal/OSS sign-off + real copyright entity + model-weight license clearance, and
  now the wasmtime license exception)** remains the standing P0 blocker before any public OSS release.
