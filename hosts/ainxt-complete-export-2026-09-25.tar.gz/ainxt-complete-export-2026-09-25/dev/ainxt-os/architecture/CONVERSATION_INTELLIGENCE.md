# Conversation Intelligence — Intent, Routing, Follow-ups & Referent/Content Resolution

**Status:** Design doc (no code). Companion to `SUBSYSTEM_DEEP_DIVES.md` (§7), `RUNTIME_FEATURE_FLOWS.md`, `IMPLEMENTATION_PLAN.md`.
**Why this doc exists:** the conversation-intelligence layer is where chat quality is won or lost. It must be model-agnostic (identical behavior on cloud Claude/GPT and in-house Kimi/GLM/Gemma/Qwen) and it must never confuse an *instruction* with *content*.

---

## 0. Governing principles

1. **The runtime owns control-flow; the model does understanding + content.** Weak models must never be relied on to "decide to call a tool." The runtime decides *what to do*; the model classifies and produces content under constrained output.
2. **Instruction ≠ content.** The current user message is an *instruction*. The *content* of any artifact (PDF, docx, summary, email) is **resolved from conversation context**, never set equal to the instruction text.
3. **Deterministic first, model second, ask third.** Cheapest and most reliable signals first; a model call only when needed; a clarifying question when ambiguous — never a silent wrong guess.

---

## 1. Turn inputs (what the layer reasons over)
- **Current message** — the instruction/intent for this turn.
- **Conversation history** — the Event-Log projection (prior user turns and assistant answers, each addressable by id).
- **Referents** — anaphora in the message ("this", "that", "it", "the above", "the report", "your last answer") pointing at prior content or artifacts.

---

## 2. Intent detection — 4-stage cascade (model-agnostic)

**Stage 1 — Deterministic signals (no model).**
- Explicit UI affordance: "Generate document" action, mode toggle, slash command (`/pdf`, `/doc`, `/ppt`, `/xlsx`). If present, intent is known — skip classification.
- Lexical pre-filter: "create/make/export/download … pdf/docx/deck/report/spreadsheet".

**Stage 2 — Constrained classifier (any model).**
When Stage 1 is inconclusive, one cheap call:
`intent ∈ {chitchat, qa, task, doc_generation, code, comparison}` and `output_format ∈ {text, docx, pptx, pdf, xlsx}`, with a confidence.
Robust on weak models via **grammar/JSON-schema-constrained decoding** (see §5).

**Stage 3 — Clarify if ambiguous.**
Low confidence → ask: *"Do you want this as a downloadable document, or here in chat?"* One tap beats a wrong guess.

**Stage 4 — Execute** the resolved intent (see §4 for how content is sourced).

---

## 3. Follow-up detection + query rewrite
- **Is this a follow-up?** A short message, or one containing anaphora ("this/that/it/the above"), or lacking a standalone subject ⇒ follow-up.
- **Rewrite to standalone.** Using history, rewrite the turn into a self-contained form for retrieval/action.
  - "generate this as pdf" ⇒ *"Generate a PDF of the UPI growth analysis provided in the previous answer."*
- Wrong here = the #1 cause of "it forgot what we were talking about." This step is mandatory for any turn flagged as a follow-up.

---

## 4. Referent & content resolution (THE fix for the "generate this as pdf" bug)

When an action needs **content** (doc-gen, summarize, email, translate, "save this"), the runtime runs a **content resolver** to determine *what* the content is. It NEVER defaults to the instruction text.

**Resolution order:**
1. **Explicit content in the message** — the message itself carries the subject matter ("write a PDF titled X with these points: …") → use it.
2. **Anaphoric referent** — the message is a bare instruction + anaphora ("this / that / it / the above / the report / your last answer") → resolve to the **most recent substantive assistant answer** (or the specifically named prior turn/artifact).
3. **Referenced artifact/turn id** — user points at a specific earlier message or artifact → use that.
4. **Unresolvable / ambiguous** — ask: *"Which content should I put in the PDF — the UPI growth analysis above?"*

**"Substantive assistant answer"** = the last assistant turn that produced real content (skip acknowledgements, clarifying questions, and the current instruction itself).

**Invariant:** the instruction verb phrase ("generate this as pdf") is a command and is **excluded** from the content. Content = the resolved referent.

---

## 5. Model-agnostic extraction (why it works on Kimi/GLM/Gemma/Qwen)
Keyed off capability flags in the model registry (native-tool-calling? grammar-constrained? context size?):
- **Grammar / JSON-schema-constrained decoding** (GBNF via vLLM / llama.cpp / Outlines / lm-format-enforcer) guarantees valid labels/JSON regardless of model strength — the key enabler for self-hosted OSS models.
- **Enumerated single-label classification** — smallest, most robust output; few-shot boosted.
- **Capability-aware control-flow** — frontier models may drive tool-choice; OSS models: the runtime drives control-flow, the model only classifies + produces content.
- **Bounded repair loop** as backstop (rare under constrained decoding).
Same cascade, same pipeline; only the extraction technique differs per model. Chat quality does not degrade when switching to an in-house model.

---

## 6. Worked example — the failure and the fix

**Turns:** (1) "UPI growth?" → assistant answer **A** (UPI content). (2) "generate this as pdf".

**Before (bug):** intent left to tool-choice; doc-gen `content` = literal current message ⇒ PDF body = "generate this as pdf". ❌

**After (design):**
1. Stage-1 lexical + Stage-2 classifier ⇒ intent=`doc_generation`, format=`pdf`.
2. Follow-up detected (anaphora "this", no standalone subject) ⇒ rewrite: "PDF of the UPI growth analysis in the previous answer."
3. Content resolver: message is a bare instruction + anaphora ⇒ resolve referent = answer **A**.
4. Doc-gen invoked with `{format: pdf, content: A}` ⇒ PDF body = the UPI growth analysis. ✅

---

## 7. Acceptance / scenario tests (must pass — part of the matrix)
- **T1 (this bug):** [answer A about UPI] then "generate this as pdf" ⇒ PDF contains A, NOT the instruction.
- **T2:** "make it a deck" after an answer ⇒ PPTX of the prior answer.
- **T3:** "write a PDF about NEFT limits with these 3 points: …" ⇒ content from the message (Stage-1/order-1), not history.
- **T4:** bare "export this" with no prior substantive answer ⇒ system asks which content.
- **T5:** "summarize the above and email it" ⇒ content = resolved referent, action = email; instruction excluded from body.
- **T6 (model-agnostic):** T1–T5 pass identically on a self-hosted model (Qwen/Gemma) via constrained decoding.
- **T7 (over-trigger guard):** "can you summarize this, I'll make a doc later" ⇒ NO doc generated (intent=qa/task, not doc_generation).
