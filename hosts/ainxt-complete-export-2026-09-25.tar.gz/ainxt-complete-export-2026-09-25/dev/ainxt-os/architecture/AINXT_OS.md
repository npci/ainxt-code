# AiNxt OS — The Unifying Capstone (Runtime + Studio + Workforce)

**Status:** Capstone design. Binds together `IMPLEMENTATION_PLAN.md`, `RUNTIME_FEATURE_FLOWS.md`, `SUBSYSTEM_DEEP_DIVES.md`, `CONVERSATION_INTELLIGENCE.md`, `AGENT_TESTER.md`, `GAP_ANALYSIS_VS_AI_PLATFORMS.md`, `WORKFORCE_AND_OS.md`, and the existing `Build_Studio_*` docs.
**Purpose:** state, in one place, **what AiNxt OS is and what we launch** — and why this succeeds where the previous platform (chat, Buddy, SDLC, Workflow Studio, agents) failed.

---

## 0. Identity, ownership, and the two creation paths (read first — resolves the confusion)

**What we build = the Runtime.** One word. "AiNxt OS" is the *positioning* for the runtime + everything running on it (not a separate codebase). A "harness/role" is a *unit that runs on* the runtime, not a separate product. We build the engine; everything else runs on it.

**The visual Agent Studio (LangGraph + n8n-style DAG) is being built by an EXTERNAL VENDOR as a separate project. We do NOT build or own it, and we do NOT duplicate it.** It becomes one *external authoring client* that publishes specs to our runtime via the Studio spec/protocol. Its legitimate niche = the **deterministic** path (scheduled ETL, compliance pipelines, fixed integrations) where an explicit, auditable, node-by-node graph is *wanted* and model improvisation is *not*.

**Our creation path is different — and it is our moat: INTELLIGENCE, not configuration.**
- A **worker** needs configuration (nodes/loops/prompts). Non-engineers will not wire that. Brittle.
- **Intelligence** takes a *vague prompt*, infers intent, plans, selects tools, clarifies when unsure, self-corrects, and delivers.
- Therefore the **skill/role factory is a conversational capability inside Buddy (and Chat/Code)** — you *describe* what you want and the runtime's intelligence runs the Role-Studio flow *for* you (decompose → assemble → propose → Breaker-test → deploy). **Creation-by-conversation, not a canvas.**

So there are two paths, both publishing to the one runtime:
| Path | Who | For | Owner |
|---|---|---|---|
| **Intelligence-first (default)** | non-engineers, everyone | open-ended agentic work; describe-it-and-it-builds | **us (runtime)** |
| **Explicit visual DAG** | power users | deterministic, auditable, scheduled pipelines | **external vendor Studio** |

The commodity is the node editor; **the moat is the intelligence that removes the need for one.** We build the moat.

---

## 1. Why the previous platform failed — the honest diagnosis

Every failure had the **same root cause**, and it wasn't the individual feature:

- **Fragmentation.** Four overlapping subsystems (Agents, Skills, Tools, Workflows) on **three execution models** (orchestrator loop, AgentRunner, WorkflowEngine). Each product re-implemented its own shallow loop → each was shallow, and only ever one was hardened at a time.
- **PoC depth.** Happy-path loops, no cancellation/backpressure/partial-failure, hardcoded prompts/tools, "done" from one manual run. → messy output, breaks under real use.
- **No quality measurement.** No eval gate, no quality regression → "generate this as pdf" ships the instruction as content and nobody catches it.
- **No real testing.** No adversarial system-breaker → edge cases surface in prod, as failures.
- **Client coupling.** Buddy welded to the CLI; connectors client-side → web parity impossible.

**Conclusion:** the platform failed because it was *a pile of features*, not *a system*. You cannot fix that by rebuilding the features. You fix it by building the **one system underneath them** and making features be *compositions* on it.

## 2. What AiNxt OS is — one runtime, one studio, governed compositions

```
                          ┌───────────────────────────────────────┐
   AUTHORING (humans) →   │        AiNxt STUDIO  (the Factory)      │  ← Build Studio, unified
                          │  Skill · Agent · Role · Team · Workflow │
                          │  visual canvas + declarative specs      │
                          └───────────────────┬─────────────────────┘
                                              │ publishes governed specs (git-native control plane = source of truth; ADR-026)
                                              ▼
                          ┌───────────────────────────────────────┐
   EXECUTION (kernel) →   │           AiNxt RUNTIME (Rust)          │
                          │  one turn pipeline · one loop · gates:  │
                          │  identity/RBAC/OBO · compliance ·       │
                          │  guardrails+injection · model router    │
                          │  (data-class aware) · tool+MCP · context│
                          │  · memory/event-log · sandbox · audit   │
                          └───────────────────┬─────────────────────┘
                                              │ one Protocol (typed events)
                                              ▼
   SURFACES (renderers) → Chat · Code(Desktop) · Buddy · SDLC · IDE · Headless CLI · REST/SDK
                                              │
   QUALITY/SAFETY GATES →  Eval-as-gate (quality) + the Breaker (adversarial) — nothing ships without both
```

Three layers, each keeping the quality of its own technique:
1. **Runtime (kernel):** the single hardened agentic turn — every technique we designed (event-enum streaming, actor-per-session, data-class-aware routing, guardrails+injection defense, idempotent actions, OBO authz, context engine, condensation, tamper-evident audit) lives here, once.
2. **Studio (factory):** the single authoring surface — **replaces the four fragmented subsystems** (Build Studio's core bet). One place to compose a Skill, Agent, Role, Team, or Workflow — visual canvas for non-engineers + declarative specs, all versioned files in the git-native control repo, governed via CODEOWNERS + branch protection + signed commits (ADR-026).
3. **Surfaces (renderers):** Chat/Code/Buddy/SDLC/IDE/CLI/SDK are **not products** — they're renderers of *compositions* the Studio produced, running on the runtime. This is the anti-fragmentation move: one loop, many faces.

**AiNxt OS = the runtime kernel + the Studio factory + the governed compositions (roles/surfaces) that run on it, gated by quality + the Breaker.**

## 3. The unification — nothing loses its quality

| Old thing | Becomes | Quality preserved |
|---|---|---|
| Agents subsystem | Studio → Agent spec on the runtime loop | governance + RBAC + compliance intact |
| Skills subsystem | Studio → Skill (behavioral/execution), control-plane-sourced (git) | injection point + governance intact |
| Tools + MCP | one Tool Runtime (native == MCP) | schema-from-struct, approval, idempotency |
| Workflow Studio (failed) | Studio workflows on the runtime scheduler/event-bus (NOT the scrapped engine) | review/edit canvas over auto-assembled specs (the node-and-wire DAG stays the external vendor's); execution unified |
| SDLC | a **Role** (Developer) = Code profile + judge-loop | validated pipeline preserved, invoked as capability |
| Chat (failed) | a surface with the full conversation-intelligence layer | intent cascade + referent resolution + quality evals |
| Buddy (failed w/o CLI) | a Role/profile; connectors server-side | web == desktop parity |

Every good technique from every prior doc is retained — but re-hosted on the one spine instead of in a silo.

---

## 4. Role Studio — the concrete authoring flow

Building an example digital worker: **"L1 Support Engineer."** UX law throughout: *the Factory does the heavy lifting; the human curates. Every step previews, is reversible, and shows a live Quality + Safety status.*

**Step 0 — Start.** "Create → Role." Pick a template (Developer / Tester / Ops / Support / Analyst) or blank. Templates are pre-vetted golden paths (kills the blank-page problem = adoption gap AZ).

**Step 1 — Describe the job (plain language).** The creator writes a job description: *"Triage L1 tickets, answer from the KB, resolve password resets and access requests, escalate everything else."* The Factory's own agent turns this into a **structured Role Spec** (responsibilities, tasks, inputs, outputs, escalation rules, KPIs) and shows it back to confirm. *(This is intent detection applied to role-building.)*

**Step 2 — Auto-assembled draft (review, don't build).** The Factory proposes: capabilities (`connector.ticketing`, `kb.search`, `connector.email`), skills (triage SOP, response templates), model policy, knowledge sources, autonomy. The creator edits on a **review/edit canvas** — a spec-review surface for the auto-assembled Role/Agent spec, *not* a node-and-wire DAG editor (that DAG Studio is the external vendor's) — see the whole worker at a glance.

**Step 3 — Grant & govern (least-privilege by default).** Each capability must be justified; sensitive ones need approval. Set: data-class access (N/O), RBAC visibility, **on-behalf-of authority** — *the role acts AS whom?* (AI, prevents confused-deputy), model-risk class (P), retention (Q). Governance is baked in, not optional.

**Step 4 — Autonomy dial, per task.** The innovation: autonomy is **per-task, not per-role**. Password reset → *auto*; access request → *assisted (HITL)*; anything unrecognized → *escalate to human*. Escalation thresholds wired to **uncertainty/abstention (U)** — the role knows when it doesn't know.

**Step 5 — Knowledge.** Attach KB/RAG namespaces + runbooks. The Factory runs a **retrieval-quality check** on the attached knowledge and flags gaps (RAG quality G).

**Step 6 — KPIs & evals.** Define success (resolution rate, accuracy, escalation-appropriateness, CSAT). The Factory **auto-generates a quality-eval set** for this role (BF/BT) — this is how you'll know it's actually good.

**Step 7 — The Breaker gate (cannot skip).** Before publish, the adversarial Test Agent stress-tests the role: edge cases, adversarial inputs, **injection/PII/over-privilege**, and **output quality** (helpful/format/tone). Returns a verified report. **The role cannot be published until it passes.** *(This is the anti-PoC gate — the reason it won't be shallow.)*

**Step 8 — Shadow run.** Deploy in shadow beside the human team: it observes real tickets and drafts decisions **without acting**; KPIs compared to humans. Trust is earned with evidence, not claims.

**Step 9 — Governed publish (git-native; ADR-026).** The lifecycle is re-hosted on git primitives, not DB state: **DRAFT = a branch**, **PENDING_APPROVAL = a PR + CI**, **APPROVED = merge to the control repo**, **PRODUCTION = a signed tag on the env/prod ref**. The **CODEOWNERS** group on the manifest path is both the authoring RBAC and the **named human owner** held accountable; git history is the audit trail; tag/SHA is the version and the rollback handle. Note: the conversational Studio **emits a PR, not a DB row** — the role definition is a versioned file and the merge is the deploy. Once tagged, it appears in the **Marketplace = a federation of pinned git repos (TOFU hash-pin)**.

**Step 10 — Run, monitor, improve.** Live as a digital worker: KPIs, quality-drift, cost monitored; the feedback flywheel (E) improves it; **pause / rollback instantly**. Autonomy can be dialed up as trust grows.

Result: authoring a digital worker feels like *hiring and onboarding*, not programming — and it is safe, measured, and reversible by construction.

---

## 5. What we launch — narrow, but perfect (the anti-failure strategy)

We do **not** re-launch ten features. Repeating "ship many shallow things" repeats the failure. Instead:

**Launch = AiNxt OS v1 = the Runtime + the Studio + ONE flagship experience executed to world-class quality.**

- **The Runtime** (P0–P1): the one hardened spine, with the safety + quality gates real (compliance, guardrails+injection, data-class routing, idempotency, OBO authz, quality-eval + the Breaker).
- **The Studio** (thin v1): compose Skill/Agent/Role declaratively + the visual canvas; governed; control-plane-sourced (git).
- **ONE flagship** proven end-to-end — the highest-confidence, most-measurable surface — done *flawlessly* (all conversation-intelligence + quality gaps closed, Breaker-passed, quality-evals green). Not six at 60%; one at 100%.
- Then **expand via the Studio**: every next "product" (Buddy, SDLC, more roles) is a *composition* on the proven spine — each one Breaker-tested and quality-gated before it ships. Fragmentation is impossible because there is only one spine.

**The non-negotiable rule:** nothing ships until it passes **both** gates — the **quality-eval** suite *and* **the Breaker**. Quality of output and user experience are gates, not aspirations. If it isn't world-class on both, it does not launch.

## 6. Why this succeeds where the platform failed
1. **One system, not a pile of features** → depth is possible and shared.
2. **Quality is a gate** (eval + Breaker) → "messy output" cannot ship.
3. **Compositions, not silos** → new products can't re-fragment.
4. **Narrow-but-perfect launch** → we prove one thing flawlessly, then scale it.
5. **Safety makes the workforce possible** → roles are governed by construction.

**One line:** we stop shipping features and launch an **operating system** — one runtime, one studio, one flawless first experience — where quality and UX are enforced gates, and everything after is a governed composition on a spine that actually works.
