# P4 Exit — Definition-of-Done Status

**Status (2026-07-19):** P4 **Client Layer** foundation BUILT + increment-tested. The Rust protocol
client (the SDK every language binding wraps), the headless CLI, and the protocol versioning /
backward-compat contract are done with their acceptance matrix green locally. The Python + TypeScript
SDKs, the network transport against a live server, the IDE extension, and desktop-direct integration
remain — see "Not yet proven" (stated honestly per `feedback_enterprise_grade_no_poc`).

## What is built (2 crates + protocol versioning)

`ainxt-client` (Rust SDK — protocol client over a transport seam) · `ainxt-cli` (headless binary
`ainxt`). Plus `ainxt-protocol` gained a versioning policy + `is_compatible` + backward-compat tests.

```
Client (bound to a Principal)
  → Transport seam:  InProcessTransport (embeds SessionManager — CLI/desktop talk to the runtime
                     DIRECTLY, inheriting compliance/RBAC/backpressure/cancel)  |  HTTP/SSE (feature)
  → ChatStream (typed Event stream; recv() to stream, collect() to assemble text/usage/status)
  → Backpressure from the spine surfaces as ClientError::Backpressure (shed / HTTP 503)
```

The **headless** CLI (`ainxt run`): stdin or positional prompt · `--print` (final text) / `--json`
(NDJSON one event per line) · `--continue` (session resume via a state file) · `--session` ·
`--data-class` · deterministic exit codes (`0` ok / `1` turn error / `2` usage / `3` at-capacity) ·
an **offline provider** so it runs air-gapped with no network.

## Evidence (all green: per-crate `cargo test` + `clippy -D warnings`)

- **`ainxt-client` 5 tests** — chat streams + collects (text + usage + Done); incremental `recv`;
  backpressure → typed error under the session cap; cancel is safe/idempotent; protocol version pin.
- **`ainxt-protocol` 5 tests** — version + `is_compatible`; request round-trip; an **additive field
  from a newer peer is ignored** (forward-compat); an older request missing an optional field still
  loads (backward-compat); every event variant round-trips.
- **`ainxt-cli` 14 tests** — arg parsing (flags, subcommand, implicit-run, help/version/empty, error
  cases); input resolution (prompt / stdin / `-`); session resolution (explicit / `--continue` /
  default); NDJSON event rendering; and end-to-end runs over the offline provider for `--print`,
  `--json`, stdin, help, version, usage-error, and empty-input exit codes.
- **P4 acceptance matrix** (`ainxt-cli/tests/dod_p4_matrix.rs`): **8 scenarios** — SDK chat, SDK
  backpressure, CLI `--print`/`--json`/stdin/usage-exit-code, and protocol additive-compat +
  version-bump detection — with layered oracles + JUnit, all offline.

### Enterprise invariants proven
- **Clients talk to the runtime directly** (in-process transport embeds the SessionManager); there is
  no CLI-as-plumbing — the CLI *is* a client, and so is (eventually) the desktop app.
- **Backpressure is a first-class typed outcome** all the way to the CLI exit code (`3`), not a hang.
- **The protocol is additive-within-a-version** — new optional fields are ignored by older peers
  (no `deny_unknown_fields` on the wire types; `#[serde(default)]`), so a newer server and an older
  SDK interoperate; a breaking change bumps `VERSION` and `is_compatible` rejects the mismatch.
- **The CLI is headless-only** (no interactive TUI), with a stable exit-code contract for CI, and it
  runs air-gapped via the offline provider.

## Not yet proven here (language/infra follow-ups)

- **Python SDK (first) + TypeScript SDK** — these mirror the exact wire contract proven here, but
  they are separate language packages tested in Python/JS CI (pytest / vitest), not cargo. The Rust
  client is the reference implementation of the contract they wrap.
- **Network HTTP/SSE transport** — the in-process transport is done + tested; the `http`-feature
  transport (reqwest + SSE parse to `ainxt-server`) is a live-tested path against a running server
  (no server/keys in this workspace run).
- **IDE extension** — built over the TypeScript SDK (follow-up).
- **Desktop-direct integration** — repointing Web Chat + Desktop Code at the runtime directly and
  removing any CLI wrapper is an architectural change in those apps.
- **Real providers in the CLI** — the offline provider ships for air-gap/CI; production wires real
  providers from `RuntimeConfig` at the composition binary (`ainxt-runtimed`, plan L6).
- **A real protocol version bump** — the compat *mechanism* + `is_compatible` are proven; an actual
  v1→v2 cross-version contract test lands when a v2 exists.
- **Human Gate #0 (legal/OSS sign-off + real copyright entity + model-weight license clearance)**
  remains the standing P0 blocker before any public open-source release.
