# AiNxt Runtime — Cross-Vendor Architecture Synthesis

**Status:** Reference synthesis (input to ADR-001 and the greenfield AiNxt Runtime design).
**Date:** 2026-07-18.
**Method:** Six open-source agent CLIs were studied clean-room (architecture and behavior only — no code, identifiers, prompts, comments, file names, folder layouts, or project-specific terminology were copied). Per-vendor write-ups live in `docs/architecture/vendor-studies/`.

This document extracts **convergent patterns** — designs that appear *independently* in multiple codebases. Convergence matters twice over: (1) it is strong engineering evidence the pattern is correct, and (2) an idea arrived at independently by many projects is architecture, not any one project's protectable expression, so adopting it (re-implemented originally) is clean-room-safe.

Everything below is to be **re-implemented from first principles in Rust with AiNxt's own vocabulary** — this file records *what* to build and *why*, never *how anyone else wrote it*.

---

## 0. Vendors studied

| Vendor | Lang | License | Primary lesson |
|---|---|---|---|
| codex | Rust | Apache-2.0 (vendors LGPLv2 bubblewrap ⚠, MIT wezterm) | Crate layering, protocol-first client, provider generalization |
| grok-build | Rust | Apache-2.0 © SpaceXAI (ports tool code from 2 other CLIs ⚠) | Terminal UX, streaming pipeline, approval UI, stagnation retry |
| opencode | Go | MIT | Monolith-by-default, provider trait, event-bus permission gate |
| aider | Python | Apache-2.0 | Edit-application discipline, symbol-granular repo map, git safety |
| OpenHands (SDK) | Python | MIT (studied SDK pkgs, not the `enterprise/` dir) | Event-log-as-truth, autonomous execution tiers, sandbox-as-server |
| kimi-cli | Python | Apache-2.0 | MCP-as-adapter, declarative agents, tri-state approval |

---

## 1. Convergent patterns → AiNxt runtime modules

### 1.1 Model Router / Provider layer
- **Provider-neutral typed streaming event enum** as the ONLY seam between core and any vendor. Independent in codex, grok-build, opencode. Three layers: raw HTTP/SSE transport → per-provider normalization → shared event enum (content-delta, reasoning-delta, tool-call start/delta/stop, usage, error). *This is the mechanism that makes AiNxt genuinely model-agnostic — the agent loop never sees a vendor wire format.*
- **One generic, config-driven provider implementation** covers the entire OpenAI-schema-compatible family (Groq/OpenRouter/xAI/Azure/local inference) by swapping base-URL + headers; write a bespoke implementation ONLY for a provider with incompatible auth/shape. Independent in codex + opencode.
- **Data-driven model registry**: (id → vendor, wire-model-string, context window, price fields, capability flags). Selection is pure config lookup; zero vendor-name branching in business logic. → maps onto our existing `core/model_registry.py` policy (tiers, BLOCKED_MODELS, user-selectable-only).
- **Tool calls are always native structured JSON**, never freeform-text parsing (codex, grok-build).

### 1.2 Agent Runtime (the loop)
- **Actor-per-session, single-writer**: one task drains a *bounded* inbound command channel serially; per-turn a child task holds a **cancellation token** shared by the model stream and all concurrent tool futures. Independent in codex + grok-build. This is the concurrency baseline (clean cancel on ESC/ctrl-c; no shared mutable session state across tasks). Bounded channels also satisfy AiNxt's 2,000-user backpressure mandate.
- **Need-driven loop**, not a fixed iteration count: loop while tool calls are unanswered or new input is queued.
- **Two independent circuit breakers**: (a) hard iteration/step cap; (b) a *deterministic, scaffold-level* stuck/repeat detector — canonicalized-argument dedup + repetition-pattern matching over a bounded window. NEVER a model self-report. Independent in OpenHands, kimi-cli, grok-build, codex.
- **Soft tool failures are fed back to the model as ordinary results**, not turn-aborts (codex, kimi-cli; aider's reflection is the same idea for edits).
- **Per-file locking** for tool concurrency: same-file edits serialize, everything else runs in parallel (grok-build).

### 1.3 Tool Runtime + MCP Runtime (one system, not two)
- **One `Tool` trait, one name-keyed registry. Native tools and MCP-discovered tools are indistinguishable to the dispatcher.** Independent in codex, grok-build, kimi-cli — the single strongest convergence in the study. MCP is an *adapter that registers wrapped tools*, not a special code path; approval/dedup/hooks/telemetry then apply uniformly to everything.
- **Schema derived from the same typed struct that is deserialized** (grok-build via schemars; codex) — the model-facing JSON schema and the argument parser cannot drift.
- **Uniform structured tool result**: model-facing content + human-facing message + typed UI display blocks + error flag (kimi-cli).
- **MCP servers connect lazily and in parallel at turn-start** (not process-start), each an independent status state machine so one failure doesn't block the rest (kimi-cli). Remote-server **OAuth stored per-user/per-server-URL, decoupled from model-provider auth**, checked pre-flight (unauthenticated → soft-skip).
- Pre/post tool-use hooks; pre-hook can veto (kimi-cli).

### 1.4 Security / Policy Engine (approval + sandbox)
- **Approval is a decoupled, blocking gate**, tool-agnostic of who answers it: the tool requests permission; a separate service publishes to a bus the UI subscribes to; the tool blocks on a response channel (opencode). Enterprise fit: the "approver" can be a UI dialog, an SDLC HITL gate, or a policy auto-decision — same seam.
- **Tri-state decision**: approve / approve-for-session / reject-with-feedback; the rejection text becomes model-visible tool output (kimi-cli, grok-build). Never binary allow/deny.
- **Token-aware, parsed approval**: parse the bash command (tree-sitter) and offer graduated "always-allow" scopes, don't just show a raw string (grok-build).
- **Sandbox behind one facade, per-OS** (macOS profiles / Linux namespaces+seccomp / Windows restricted-token) + a *declarative* command-approval policy layer separate from the sandbox mechanism (codex). ⚠ Do not vendor copyleft sandbox helpers — shell out to an installed binary.
- **Strongest isolation model: run the whole runtime as an HTTP/WS server *inside* the sandbox** exposing a narrow API (files/git/bash/exec), so local and remote execution are structurally identical (OpenHands). This generalizes our current `sandbox/docker_executor.py`.
- **AiNxt-specific, non-negotiable and NOT present in any vendor:** the PCI/DSS compliance engine (redact-and-proceed) must wrap every model input/output and every tool result. This is a first-class runtime seam we add, not borrow.

### 1.5 Context Engine
- **Symbol-granularity repo map**: tree-sitter definition/reference tags → cross-file reference graph → personalized PageRank biased toward in-context symbols → binary-search inclusion to a measured token budget (aider). Pairs with — does not replace — our pgvector hybrid retriever.
- **Context condensation as ONE pluggable component** consulted from two sites (proactive size check; reactive overflow recovery); hard vs soft urgency triggers (explicit / token-budget / event-count); strictest cut wins; minimum-progress guard rejects near-empty condensations; a *degrading* last-resort fallback (progressively more aggressive), never one all-or-nothing attempt. Convergent: OpenHands, kimi-cli, grok-build (three compaction strategies).

### 1.6 Memory / Session Runtime
- **Event log is the source of truth.** OpenHands: an *immutable, tree-shaped* event log; actions and observations correlate by id (not position) so parallel/branched tool calls survive; a movable "active branch head" makes edit/resume/fork cheap; the model input is a **cached incremental projection** of the active branch (extend the tail on append; full rebuild only on branch-switch) — a real fix for very long conversations.
- **Two-tier persistence**: durable append-only log (JSONL) + a rebuildable SQL index for query (codex). → aligns with AiNxt's Redis trace store + Postgres episodic memory.

### 1.7 Autonomous execution / SDLC
- **Three layers**: reactive inner loop → optional per-step critic → an outer **judge-model-audited goal loop** that re-prompts with specific "what's missing" feedback until an independent judge confirms completion or a cap is hit, returning a typed complete-vs-capped outcome (OpenHands). Maps cleanly onto AiNxt's SDLC HITL approval gates.

### 1.8 Client architecture (the runtime-first payoff)
- **Protocol-first: every UI is "just a renderer."** codex defines one big protocol crate of client↔engine commands/events; the TUI depends only on the client/protocol crates (same as external integrations), taking an in-process branch; daemon and in-process modes are one trait. opencode reaches the same end via an event bus every UI subscribes to; kimi-cli reuses one runtime for both terminal and IDE (ACP) modes. **This is exactly AiNxt's "implement once, expose everywhere" thesis** — CLI, Web Chat, REST API, Desktop, IDE, CoWorker all become renderers over one protocol.
- **Declarative agents** (YAML spec: prompt template + tool refs + MCP servers + subagents, single-level inheritance), not hardcoded classes (kimi-cli). → aligns with AiNxt's git-native control-plane rule (definitions-as-versioned-files; ADR-026).

### 1.9 CLI / Terminal UX
- **Elm-style Action → dispatch → Effect** state model (grok-build, opencode).
- **Dedicated OS thread for terminal input** bridged via channel (avoids a known async event-stream wakeup-drop pitfall); explicit park/handshake before handing the TTY to `$EDITOR`/pager (grok-build).
- **Batched/rate-limited redraws**, never per-token.
- **Scrollback-commit rendering**: commit *finished* history straight into native terminal scrollback via escape sequences and repaint only the live streaming region each frame (codex) — the key to flicker-free streaming.
- **Edit-application discipline** (aider, codex custom patch formats): parse → dry-run classify against an in-memory snapshot → write only safe edits; exact + whitespace-tolerant matching, NO silent semantic-fuzzy fallback; unmatched anchors become structured errors with a "did you mean" hint, fed back for a bounded same-turn self-correction (succeeded edits excluded from retry). Edit-format choice is tied to the model, never global.
- **Conservative git**: scope auto-commits to touched files (commit pre-existing dirty state separately first); LLM-generated commit messages; undo limited to session-tracked, non-merge, non-pushed commits (aider).

---

## 2. Consolidated clean-room & licensing register

**Global rule:** study only. Re-implement in Rust with AiNxt's own names, module layout, prompts, and error messages. Do not reuse any vendor's identifiers, crate-prefix conventions, folder layouts, model-id/pricing tables, MCP client-identity strings, prompt text, or comments.

Specific flags found during the study:

| Source | Flag | Action |
|---|---|---|
| codex | Vendors **bubblewrap (LGPLv2)** in the sandbox helper | Do NOT vendor. Shell out to an installed sandbox binary; keep our sandbox facade original. |
| codex | Custom patch-format naming/markers | Design our own edit envelope + markers. |
| grok-build | Tool crate **ports/translates tool code from two other agent CLIs** (Apache + MIT), with THIRD_PARTY_NOTICES | Do NOT extend that provenance chain — implement tools from behavior specs, not from grok's ported source. |
| grok-build | Internal jargon: "yolo mode", "doom loop", "roster", "leader", "pager" | Coin our own terms (see §3). |
| opencode | Bash tool **description string copied near-verbatim from another coding assistant's system prompt** (incl. a commit trailer naming that product) | Author all tool descriptions + system prompts originally for AiNxt. |
| all | Model-id/pricing tables, config filenames, MCP client identity strings | Define AiNxt's own. |

**Provenance evidence to keep:** these vendor studies + ADRs are the "design notes showing independent implementation" that strengthen AiNxt's legal position. Retain them.

---

## 3. AiNxt vocabulary (own terminology — placeholder, refine in ADR-001)

Deliberately NOT: gboom, tengu, SuperGrok, "doom loop", "yolo", "roster", "leader", or any vendor crate prefix.

Candidate AiNxt terms: Runtime, Execution Engine, Session Actor, Turn, Provider Gateway, Model Router, Capability (tool), Capability Registry, Extension (plugin), Skill, Connector, Workflow, Planner, Critic, Reviewer (judge), Context Engine, Condenser, Event Log, Projection, Approval Gate, Policy Engine, Compliance Gate, Sandbox Host, Artifact, Renderer (any client). Finalize in ADR-001.

---

## 4. Anti-patterns to avoid (called out by the studies)

- Monolithic app/view-state god-struct + one giant command-dispatch match (grok-build) — fights modularity and our scaling mandate.
- Unbounded channels crossing session boundaries (grok-build) — violates 2,000-user backpressure.
- No hard iteration cap on the agent loop (opencode) — runaway cost risk.
- Silent semantic-fuzzy edit matching (aider disables it) — corrupts code.
- Restructuring core logic around the UI — invert it: core publishes, UIs render.
- Vendoring copyleft dependencies (codex/bubblewrap) — shell out instead.

---

## 5. Next artifacts

1. **ADR-001 — AiNxt Runtime** (why Rust; actor-per-session; protocol-first client; provider event-enum seam; alternatives considered).
2. **ADR-002 — Tool + MCP Runtime** (one trait, one registry, MCP-as-adapter, schema-from-struct).
3. **ADR-003 — Approval + Policy + Compliance seam** (blocking gate, tri-state, PCI/DSS wrap).
4. **`ainxt_runtime_solution.md`** — the greenfield, first-principles master spec (produced under this name), citing this synthesis as reference-only.
5. **OSS/IP scaffolding** — LICENSE, NOTICE, THIRD_PARTY_LICENSES/, ADR/ (per ainxt_runtime_solution.md §12).
