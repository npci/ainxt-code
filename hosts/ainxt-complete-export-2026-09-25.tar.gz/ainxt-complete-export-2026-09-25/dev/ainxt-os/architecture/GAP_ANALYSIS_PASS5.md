# Gap Analysis — Pass 5 (deep multi-lens research, 162-agent workflow)

**Status:** Findings of record. Method: a 10-lens deep-research workflow (web + reasoning), deduped against the entire A–BT corpus + subsystem docs, each candidate adversarially verified on two axes (genuinely-new AND material), plus a completeness critic. 162 agents, 0 errors. **47 verified new gaps.**

*Note: 47 distinct gaps are enumerated below (numbering skips [39]).*

## The verdict (honest, and it reframes the scorecard)
The 19-dimension scorecard hit a genuine design-10 **on the axis it measured**: AI-runtime *intelligence* + single-org software-engineering *quality*. That surface is real and near-complete. **But the axis itself was too narrow for "the runtime of India's payment switch."** Pass 5 surfaces gaps that are *structural* — entire net-new subsystems and governance disciplines no lens in the A–BT framing owned. They cluster on the three things that make this **regulated national infrastructure**, not a generic enterprise AI platform:

1. **Regulated-FI legal/compliance OPERATIONALIZATION** — statutory breach clocks, RBI outsourcing governance, DPDP-SDF duties, PCI-DSS scoping, legal-hold vs erasure, evidentiary admissibility, liability/insurance. Institutional frameworks, mostly **go-live blockers**.
2. **Infra / hardware / identity SUBSTRATE beneath the model layer** — serving-ops (a whole subsystem, not one gap), confidential-computing/TEE + hardware root-of-trust, non-human agent identity, crypto-agility/PQC.
3. **NPCI's mission-differentiating DATA SURFACES** — structured NL-to-SQL over ledger/settlement data, federated cross-member-bank intelligence, global sensemaking, multimodal evidence.
Plus sharp **security categories no lens ran**, and **the agent-payment-authorization boundary** — architecture-defining for the operator of the rails.

**Net:** the intelligence core is design-complete; the platform is **materially incomplete** on the FI-operationalization, infra-substrate, and mission-data-surface layers. Build-maturity stays 0/10; the eval platform stays the keystone. These need **their own deep-dive docs + net-new ADRs (016+)**, not tweaks. Recommended reframe: **"runtime as regulated national infrastructure," not "runtime as AI platform."**

---

## The 47 verified new gaps (grouped by cluster)

### A. Agent-payment boundary (mission-defining)
- **[1] 🔴 Agent-initiated payment / agentic-commerce authorization boundary** — nothing structurally marks payment-initiation as a categorically harder-blocked class; a role/skill/tool could be wired to a settlement action. Needs a non-overridable class in the side-effect ledger. → **new P0 ADR-016**.

### B. Regulated-FI legal/compliance operationalization (mostly go-live blockers)
- **[3] 🔴 Statutory AI-incident breach-notification engine** — CERT-In 6h / DPDP / RBI clocks as first-class SLOs; agentic incident taxonomy. → ADR-011 ext.
- **[5] 🔴 OSS weight licensing / field-of-use** — Gemma/GLM/Kimi custom licenses, pass-through, zero indemnity; bundling under one brand may breach terms. → ADR-007 ext + routing gate.
- **[6] 🔴 Liability / indemnity / insurance chain** — every layer disclaims; residual loss lands on NPCI with no framework. → new P0 ADR.
- **[10] 🟠 PCI-DSS scope / CDE segmentation** — the Rust sidecar risks pulling the whole runtime into PCI scope. → new P0 ADR.
- **[11] 🟠 RBI IT/cloud outsourcing governance** — every cloud LLM call is IT outsourcing; needs board policy, right-to-audit, exit plan, register. → ADR-014 ext.
- **[12] 🟠 DPDP Significant-Data-Fiduciary duties** — DPIA-per-feature, algorithmic due diligence, India DPO, independent audit. → ADR-011/015 ext.
- **[13] 🟠 Statutory-retention vs erasure + legal-hold override** — RBI/PMLA retention can legally override a DPDP erasure; cascade needs hold state. → ADR-015 ext.
- **[14] 🟠 Nation-of-origin / sovereignty routing gate** — Qwen/GLM/Kimi are PRC-origin; a signed weight is still PRC-origin; national-security veto risk. → ADR-006 ext.
- **[33] 🟡 Evidentiary admissibility (Bharatiya Sakshya Adhiniyam 2023)** — tamper-evident ≠ court-admissible; certificate + chain-of-custody needed.
- **[34] 🟡 Supervisory audit-readiness** — India-resident 180-day logs, NTP to NIC/NPL, empanelled-auditor evidence export.
- **[42] 🟡 Crypto agility / PQC roadmap** — all signing/audit-chain primitives lack rotation abstraction; harvest-now-decrypt-later. → new crypto-lifecycle ADR.

### C. Infra / hardware / serving / identity substrate
- **[7] 🔴 Disaggregated prefill/decode serving** — same-GPU interference stalls interactive latency under mixed workloads. → Serving-Ops doc.
- **[9] 🟠 Hardware root-of-trust / TEE for regulated data in GPU memory + firmware/silicon supply chain** — plaintext PII in GPU memory exposed to operator/hypervisor. → ADR-012 ext + hardware-trust ADR.
- **[16] 🟠 Non-human/agent identity lifecycle** — per-agent revocable machine identity, SoD, workforce kill-switch, attestation (not a shared token). → ADR-003 ext + agent-identity ADR.
- **[26] 🟠 GPU bin-packing/placement scheduler** — heterogeneous OSS fleet co-residency/eviction; cold reload = minutes. → Serving-Ops.
- **[27] 🟠 SLO-aware QoS admission / priority scheduling** — incident query must not queue behind a 20-min SDLC run; current 503 sheds blindly. → Serving-Ops.
- **[37] 🟡 Multi-GPU shard-level health** — tensor/pipeline-parallel replica hangs/corrupts silently, invisible to process liveness. → Serving-Ops.
- **[38] 🟡 Zero-downtime integrity-verified weight rollout** — staged/blue-green multi-GB checkpoint push; "instant rollback" is false for VRAM reload. → Serving-Ops.
- **[18] 🟠 Inference cache isolation / side-channels** — prompt-cache timing, cross-tenant answer/KV cache, GPU residue defeat dept scoping. → TOOLING/caching.
- **[19] 🟠 microVM (not container) isolation for LLM-generated code** — container escape near PCI services; frontier moved to Firecracker/gVisor. → sandbox ADR.
- **[32] 🟡 Clock skew across the two-runtime fleet** — skewed saga/idempotency timers can fire premature compensation = double-execution. → infra ADR.

### D. Mission-differentiating data surfaces (NPCI's crown jewels)
- **[4] 🔴 Structured/relational retrieval (NL-to-SQL + semantic metrics + row-level security)** over ledger/settlement/dispute data — the Context Fabric can't answer "how many failed settlements did bank X have last Tuesday." → new Context Fabric layer / deep-dive.
- **[15] 🟠 Federated privacy-preserving cross-member-bank retrieval** — single-org RBAC can't do network-wide fraud/systemic-risk without leaking bank-to-bank. → new federation dimension.
- **[24] 🟠 Global/sensemaking query mode (GraphRAG map-reduce)** — only point-lookup today; risk committees ask thematic questions.
- **[25] 🟠 Multimodal evidence retrieval** — cheque images, KYC docs, call recordings as a retrieval tier (most PII-dense artifacts).

### E. Security categories no lens had run
- **[2] 🔴 MCP server supply chain** — tool-description poisoning, rug-pull, tool-shadowing; remote MCP trusted on connect. → TOFU hash-pin + diff-and-re-approve + spotlighting + namespace isolation.
- **[8] 🟠 Insider-threat / dual-use** — an authorized user weaponizing a correctly-authorized agent; compliance checks I/O, never fraud-intent. → UEBA + SoD.
- **[17] 🟠 Compromised agent within a team** — no signed/role-bound handoffs; a subverted Coder forges a Judge approval. → signed handoffs + confinement.
- **[20] 🟠 Algorithmic-complexity DoS on the compliance gate** — ReDoS/entropy/Luhn over unbounded tool outputs pins the one un-skippable component. → size caps + RE2-class matching.

### F. Correctness seams between already-design-10 subsystems
- **[21] 🟠 Idempotency in-doubt reconciler** — lost-ack PENDING has no resolution; downstreams may not accept idempotency keys → double debit / dropped settlement. → ADR-013 fix.
- **[22] 🟠 Budget-fit-before-model tokenizer/window mismatch** — context fit at step 4, model chosen at step 5 → silent truncation/overflow on OSS routes, dropping evidence. → fix step ordering.
- **[36] 🟡 Reasoning-trace portability** — mid-session provider switch strips/invalidates thinking-blocks/encrypted-reasoning-items silently.
- **[35] 🟡 Bi-temporal memory** — replay gives transaction-time, not valid-time (what rule was in force on the transaction's date).
- **[23] 🟠 AI-incident operational taxonomy + quality circuit-breaker** — auto-contain a degraded skill/route on live judge-score drop; postmortem→regression-eval loop.
- **[40] 🟡 Eval statistical methodology** — power, multiple-comparison correction, sequential testing; the gate can be satisfied by noise.
- **[41] 🟡 Human-rater calibration (IRR)** — gold labels have no documented kappa/calibration; model-risk review will ask.

### G. Adoption / sustainability / human-factors
- **[28] 🟠 Citizen-authored artifact lifecycle** — decay, orphaning, ownership succession (author leaves → stale agent gives wrong answers).
- **[29] 🟠 Shadow-AI / BYO-AI displacement** — engineers already use personal ChatGPT on payment code = Day-1 audit finding; need carrot+stick.
- **[30] 🟠 External Studio vendor risk** — non-OSI (n8n fair-code / LangGraph commercial) primary authoring surface; no exit/escrow/license-compat.
- **[31] 🟠 Sustainability / monetization + Apache-2.0 irreversibility** — who funds a decade; hyperscaler could host a rival; fork risk.
- **[43] 🟡 Automation complacency / deskilling** — maker-checker degrades silently under automation bias; measure override-rate→0.
- **[44] 🟡 IDE-embedded UX** — extension is a thin SDK wrapper; adoption plateaus if engineers must leave the IDE.
- **[45] 🟡 Async notification / attention budget** — careless paging gets the channel muted; digests, quiet hours, escalation.
- **[46] 🟡 Feedback loop-closure** — "you told us X, we changed Y"; without it, feedback dies.
- **[47] 🟡 Executive adoption/ROI dashboard** — platforms get defunded when sponsors can't prove value; add to risk register.
- **[48] 🟡 Real-time duplex voice** — batch STT→text→TTS vs 2026 realtime (barge-in, <300ms).

---

## Closure status (updated 2026-07-18, post closure-2)
The subsystem docs + ADRs 016–027 below were **built** (self-scored 9–9.5). The gaps previously listed here as "hardening into existing docs" are **now designed**, with mechanism + acceptance test, in their target docs: **[2] MCP tool-manifest trust**, **[20] detector-DoS hardening**, **[21] lost-ack reconciler**, **[23] quality circuit-breaker** → `TOOLING_MCP_PLUGINS_ROUTING.md`; **[22] budget-fit ordering** → `CONTEXT_FABRIC.md` §3; the 4 Q1/Q2-induced gaps → `ADR-026`/`LONG_HORIZON_PROGRAMS.md`/`AGENT_IDENTITY_AND_PAYMENT_BOUNDARY.md`. Remaining adoption/seam gaps (28,29,31,35,43–48) are designed or explicitly deferred in `DEV_EXECUTION_AND_UX.md` / `WORKFORCE_AND_OS.md` / `INTERACTION_REPL_COMMANDS.md`. See `RUNTIME_SCORECARD.md` for honest scores. Build maturity: 0/10 (design only).

## Recommended closure (to restore a true design-10 on the fuller scope)
**New subsystem deep-dive docs** (design each to 10, same bar as Pass-4 docs):
1. `SERVING_OPS.md` — prefill/decode, GPU scheduler, QoS admission, shard health, weight rollout (gaps 7,26,27,37,38 + W).
2. `STRUCTURED_FEDERATED_RETRIEVAL.md` — NL-to-SQL + metrics + RLS + federation + global mode + multimodal (gaps 4,15,24,25).
3. `REGULATED_FI_COMPLIANCE_OPS.md` — breach clocks, RBI outsourcing, DPDP-SDF, PCI scoping, legal-hold, admissibility, audit-readiness (gaps 3,10,11,12,13,33,34 + P,Q).
4. `AGENT_IDENTITY_AND_PAYMENT_BOUNDARY.md` — payment hard-boundary + agent identity lifecycle (gaps 1,16 + AI).

**New ADRs (016+):** 016 Agent-Payment-Boundary · 017 Regulated-FI-Compliance-Ops · 018 Model-Governance (licensing + origin gate) · 019 Liability/Indemnity/Insurance · 020 Serving-Ops · 021 Hardware-Trust/TEE · 022 Agent-Identity · 023 Crypto-Agility/PQC · 024 microVM-Sandbox · 025 Evidentiary-Admissibility.

**Hardening into existing docs:** security seams (2,8,17,18,20) → TOOLING; correctness seams (21,22,32,36) → the relevant subsystem docs; SRE-for-AI (23) → observability/memory; adoption band (28–31,43–48) → DEV_EXECUTION/WORKFORCE/INTERACTION + Part C risk register.

Only after these does the design fairly earn "complete" as **regulated national infrastructure**.
