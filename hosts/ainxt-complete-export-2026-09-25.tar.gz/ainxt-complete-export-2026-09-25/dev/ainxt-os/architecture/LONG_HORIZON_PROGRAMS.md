# ADR-027 — Long-Horizon Program Execution

**Status:** Accepted (Q1 decision). Design only — no code.
**Closes:** gap **AG** (long-horizon task management — the honest self-critique was "no unit above a Run; a Run is minutes-to-hours, single-window, transient") and the Pass-5-class structural hole "can the runtime actually *do* a multi-week, thousands-of-task program at 1M-LOC scale, or only a good single Run." Net-new subsystem doc + ADR in the 016+ series.
**Layers on (does not re-implement):** `LOOP_AND_AGENT_TEAMS.md` (the base agent loop = the *worker* this ADR schedules), `CONTEXT_FABRIC.md` (the module/import/architecture graphs decomposition reads from), `SUBSYSTEM_DEEP_DIVES.md` §6 + `CODE_REVIEW_PIPELINE.md` §9 (the durable, hash-chained Event Log program state lives on), `CODE_REVIEW_PIPELINE.md` (per-module + per-edge verification, unchanged), `SEMANTIC_EDITING.md` (per-module atomic editing), `TOOLING_MCP_PLUGINS_ROUTING.md` §1.2–1.4 (Side-Effect Ledger / saga / two-phase commit — the rollback substrate), `AGENT_TESTER.md` §6/§8 (shadow-differential migration oracle), `ENTERPRISE_MEMORY_LEARNING.md` (program-scoped conventions as OKIs), `SERVING_OPS.md`/ADR-020 (the GPU fleet the program's Runs are scheduled onto), `RUNTIME_FEATURE_FLOWS.md` §7b (the Approval Gate seam every human checkpoint reuses).

**One line:** a complete migration of a ~1,000,000-LOC codebase is **not a bigger agent loop** — it is a durable, resumable *Program* that decomposes the goal into a dependency-ordered graph of window-sized modules and executes it as **thousands of ordinary, bounded base-loop Runs**, one module at a time, with the program's state living on the Event Log so it survives restarts, model swaps, and multi-week wall-clock, and with correctness proven compositionally (per-module → per-edge → periodic program sweep), never as one impossible 1M-LOC verification.

---

## 0. The problem, stated precisely — why the base agent loop cannot

The base loop (`LOOP_AND_AGENT_TEAMS.md`) is a **Run**: a goal, a planner, a *transient* task graph that is deliberately "scoped to a single Run and discarded (or folded into the Learning record) at Run end" (LOOP §0, §3), one shared cancellation token, one budget slice, one context window, one terminal outcome (`complete | capped`). Every one of those properties is correct for a Run and *disqualifying* for a 1M-LOC program:

| Base-loop property (correct for a Run) | Why it breaks a multi-week program |
|---|---|
| Task graph is **transient**, discarded at Run end | A program's plan must survive weeks, restarts, and model retirements — it cannot evaporate when a process dies. |
| Context is **one window** | 1M LOC ≈ 10–30M tokens — two to three orders of magnitude over any model's window. It never fits, not with any condenser. |
| One **cancellation token / budget / actor** | A program is thousands of Runs across many days; a single token/budget/actor is the wrong lifetime and the wrong blast radius. |
| Terminal outcome `complete | capped` | A program that "caps" cannot just stop — it must **checkpoint durably and resume**, and it must be able to ship the 60% that is done. |
| Verification is **per-edit / per-goal** | A migration needs *cross-module integration* + *program-scale regression*, not only per-edit gates. |
| State lives in the **live session** | A model swap or a Friday-to-Monday pause must lose *nothing*; session-resident state loses everything. |

The naive fix — "make the loop bigger, give it a huge window, let it plan the whole migration" — fails on all six rows and re-imports the scrapped `workflows/engine.py` failure mode. The correct fix is a **new unit of work at a higher altitude**, whose *job* is durability, decomposition-at-scale, checkpointing, and program-scale verification, and whose *unit of execution* is exactly one bounded, unmodified base-loop Run per module.

---

## 1. Decision

Add a first-class **Long-Horizon Program subsystem** — the **Program Supervisor** — layered above the agent loop. A **Program** is a durable aggregate that:

1. **Decomposes** a program-goal into a **Module Task Graph (MTG)**: a dependency-ordered graph of *migration units* sized to fit a single Run's window, derived from the Context Fabric's real module/import/architecture graphs — never human-wired.
2. Persists its entire state (MTG + per-node state machine + committed commit-SHAs + cost/progress counters) as an **append-only, hash-chained stream on the Event Log**, so it is **durable and resumable** across restarts, model swaps, and multi-day runs.
3. Executes **module-by-module**: each READY node spawns one ordinary base-loop Run scoped to that module + its 1-hop interface context. **No node ever exceeds a window — the graph is sized to the window, not the codebase.**
4. **Verifies at three scopes** through the existing Code-Review Pipeline: per-module (node), per-edge (integration across a committed seam), and a periodic **program regression sweep** — a program reaches `COMPLETED` only when all three plus an independent program-level Judge are green.
5. Runs its Runs as a **low-priority, preemptible, elastic** workload class on the GPU fleet (Serving-Ops/ADR-020) — it consumes idle capacity and is preempted by interactive traffic, with a **program budget** above the per-Run budget that forces a human checkpoint on threshold crossings.
6. Gates on **staged human checkpoints** (start / phase-boundary / budget / critical-path / anomaly) via the existing Approval Gate seam, tracks progress on a durable dashboard, and reports **partial completion** as a first-class, honest, *deployable* outcome — never a silent "done."
7. **Isolates failure per node** (bulkhead) and **rolls back a single module** (git + saga compensation) without losing the rest of the program's committed progress; a poison module is **quarantined and routed around**, not allowed to stall the whole program.
8. Edits every module through the **Semantic Editing engine** (AST/LSP, atomic per module) and reviews every node **cross-model** (producer ≠ judge; two OSS models for regulated modules).

The base loop is unchanged. The Program is the durable orchestrator *above* it.

---

## 2. The principle — a Program is not a big Run, and its graph is not the scrapped engine

Two boundaries must be held explicitly, because both are load-bearing against corpus contradictions:

**(a) MTG vs the Run's transient task graph — different objects, different altitudes.** LOOP §0/§3 insist the *intra-Run* task graph is transient and discarded. That remains true and unchanged. The **MTG is a different artifact at a different altitude**: it is the durable *program-of-Runs*, not an intra-Run plan. A single MTG node, when it executes, spins up one base-loop Run that authors *its own* transient, discarded intra-Run task graph to do that one module's work. So there is no contradiction: the transient graph is *inside* a Run; the durable MTG is the graph *of* Runs. The MTG's durability is exactly the property the Run graph deliberately lacks, because their lifetimes differ by three orders of magnitude.

**(b) Durable ≠ human-authored.** `AINXT_OS.md` §0 and LOOP §3 forbid re-creating the vendor's human-wired visual DAG (`workflows/engine.py`). The MTG does not violate this: **every MTG edge is derived by the agent from a real dependency-graph edge in the Context Fabric**, evidence-grounded, and revised as reality is discovered (a completed module can reveal a coupling the static graph missed → the Supervisor re-derives affected edges, same change-justification discipline as LOOP §9). Humans **approve and checkpoint** the MTG; they never **wire** it. The three anti-`workflows/engine.py` properties from LOOP §3 hold, restated at program altitude: the graph is agent-derived not canvas-drawn; it is a revisable hypothesis not a frozen commitment; and it is grounded in the codebase's actual structure, not a human's mental model. What differs from the Run graph — and *only* what differs — is that it is **durable and human-checkpointed** rather than transient, because a multi-week program needs a plan that outlives any process, model, or day.

---

## 3. Program decomposition — the Module Task Graph (point 1)

**Input:** a program-goal (e.g., "migrate the UPI switch from Java 8 → Java 21 + re-platform off the legacy framework, behavior-preserving"). **Output:** the MTG.

**Decomposition procedure (the Program Planner = an Architect-role invocation at program altitude):**

1. **Read the real structure, not a guess.** Query the Context Fabric: `architectureAround(module)` (layer 7), `deps(module)` (layer 6 import/dependency), the repository/file graph (layer 2), and `whoCalls`/`refsOf` (layers 3/5) to build the candidate module set and the dependency edges between them. **Nodes are migration units** (a package / bounded context / cohesive file cluster); **edges are dependency-order constraints** copied from real import/call edges.
2. **Size every node to the window (the invariant that makes 1M-LOC a non-issue).** A node is *admissible* only if its **working-set estimate** — the module's own source + the *interface slices* (signatures/contracts, not bodies) of its 1-hop neighbors — fits within a configured fraction (default ≤ 50%) of the target model's *measured* context budget, leaving headroom for instructions, retrieved exemplars, and the reactive loop's growing history. A node that exceeds the budget is **automatically split** by the Planner along sub-package / call-graph-community / change-coupling-cluster boundaries until every leaf fits. Consequence: **no node ever overflows a window by construction; total repo size only affects the *number* of nodes, never any single Run's context.**
3. **Order by dependency (Kahn topological sort)** over the dependency graph — reusing the same Kahn scheduler as LOOP §3, but at module granularity and durable. Leaf dependencies migrate before their dependents; where strangler-fig demands reverse order (migrate a consumer first), a **compatibility-shim node** is inserted so the consumer compiles against the old provider until the provider's node runs, and a **shim-cleanup node** is scheduled after.
4. **Handle cycles explicitly (Tarjan SCC), never arbitrarily.** Legacy monoliths have mutual imports. Strongly-connected components are detected; an SCC is either collapsed into a single **migration super-node** (migrated together) or, if the super-node itself exceeds a window, a **decoupling-refactor prerequisite node** is inserted *before* it and the SCC is raised to a human checkpoint ("these N modules are circularly coupled and cannot be migrated independently — approve joint migration or approve a decoupling refactor first"). Circular coupling is **surfaced**, never silently linearized. When the decoupling refactor itself is program-scale (its own dependency graph, its own window-sizing problem), the prerequisite node is authored as a `child-program` node instead of a single Run — see §4 for the parent/child composition mechanics that make nesting a Program inside a Program safe.

**Node contract** — every MTG node carries the LOOP §2 decomposition-contract fields (`task_id`, `description`, `role`, `inputs`, `acceptance_criteria`, `dependencies`, `budget`) plus program-specific fields:

| Field | Purpose |
|---|---|
| `module_ref` | the migration unit (package/context/cluster) this node owns |
| `working_set_estimate` | measured tokens for this module + its 1-hop interface context (drives the §3.2 admissibility check) |
| `blast_radius` | dependents resolved from the call/import graph — the seam integration (§6) and rollback cascade (§9) read this |
| `verification_plan` | which per-module tests + which integration seams gate this node (§6) |
| `checkpoint_class` | `none | phase-boundary | critical-path | anomaly` — drives §8 human gates |
| `edit_ladder_floor` | minimum acceptable Semantic-Editing rung for this node (critical-path modules forbid text-patch, §10) |
| `node_class` | `migration-run | shim | shim-cleanup | integration | characterization-test | decoupling-refactor | deterministic-codemod | child-program` (§4, §11) |
| `state` | the per-node program state machine value (§4) |

**Enforcement + acceptance:**
- *Agent-derived, not human-wired:* a test asserts every MTG edge maps to a real dependency-graph edge **or** to an agent-emitted constraint carrying a triggering signal (LOOP §9 change-justification); an edge with neither is rejected at the API boundary.
- *Topological correctness:* given a repo with a known dependency structure, the schedule never runs a dependent before its dependency unless a shim node is present; a synthetic cyclic import yields an SCC super-node or a decoupling prerequisite, never an arbitrary linearization.
- *Window sizing:* on a synthetic 1M-LOC repo, every leaf node's `working_set_estimate` ≤ the configured window fraction; a deliberately oversized module is auto-split until all leaves fit.

---

## 4. Durable, resumable program state — Event Log + state machine + checkpoints (point 2)

This is the heart of "the base loop cannot." The Program depends on **no** session/window/reasoning continuity.

**The Program is an append-only Event-Log aggregate.** The MTG and all progress are persisted as hash-chained events on the same durable, incrementally-projected Event Log the rest of the runtime uses (`SUBSYSTEM_DEEP_DIVES.md` §6; hash-chaining per `CODE_REVIEW_PIPELINE.md` §9). The MTG is **projected** from the log (extend-the-tail incremental cache; full rebuild only on branch), never held as in-memory Run state. Event types:

```
ProgramCreated       { program_id, goal, data_class, budget }
ProgramDecomposed    { mtg_hash, node_count, scc_report, working_set_report }
ProgramApproved      { approver, mtg_hash }                       # human start-gate
NodeStateChanged     { node_id, from, to, cause, evidence_ref }   # never in-place mutation
ChildProgramSpawned  { node_id, child_program_id }                # node_class = child-program
ChildProgramOutcomeMapped { node_id, child_program_id, outcome, mapped_state }
NodeCommitted        { node_id, commit_sha[], pipeline_outcome_ref, ledger_key }
IntegrationResult    { edge, verdict, evidence_ref }
RegressionSweep      { checkpoint_id, verdict, attributed_node? }
ProgramCheckpoint    { checkpoint_id, event_offset, mtg_hash, committed_shas[], cost, progress }
CheckpointReview     { checkpoint_id, reason, human_decision? }
ProgramOutcome       { COMPLETED | CAPPED_PARTIAL(report) | ABANDONED }
```

**The program state machine (two levels):**

- **Per-node:** `PENDING → READY (deps satisfied) → IN_PROGRESS (a Run holds it) → VERIFYING → VERIFIED → COMMITTED`, with off-ramps `→ ROLLED_BACK`, `→ BLOCKED_ON_HUMAN`, `→ FAILED_ISOLATED` (§9), `→ BLOCKED_ON_CHILD_PROGRAM` (a `child-program`-class node awaiting a nested Program's terminal outcome — see "Parent/child Program composition" below).
- **Per-program:** `DRAFT → DECOMPOSED → APPROVED → RUNNING → PAUSED → CHECKPOINT_REVIEW → { COMPLETED | CAPPED_PARTIAL | ABANDONED }`.

Every transition is an event; state is *never* mutated in place, so point-in-time replay (`ENTERPRISE_MEMORY_LEARNING.md` §7 discipline) works for a program as it does for a turn.

**Checkpoints are durable, self-describing snapshots.** A checkpoint = `(Event-Log offset, MTG projection hash, set of COMMITTED commit-SHAs, aggregate cost/progress counters, open human-gates)`, written on **every node COMMIT** and on a wall-clock/token cadence. **Resume = replay to the last checkpoint offset, reproject the MTG, and continue scheduling READY nodes.** No in-memory state is load-bearing across a restart.

**Survives model swaps — the crucial honesty.** The durable state is *committed code + typed node contracts + Event-Log trace* — **not** any model's context window or reasoning trace. Each module Run is **stateless with respect to prior Runs** except through committed code and typed artifacts. So when the runtime restarts, or a coder model is retired mid-program (a real multi-week risk), the next node's Run is a *fresh base-loop invocation* that rebuilds its context from the Context Fabric + the node contract — it never needs a prior model's session. (This is precisely why the Program sidesteps Pass-5 gap [36] *reasoning-trace portability*: it never carries reasoning across Runs, only committed code and contracts.)

**Idempotent resume — no double-commit.** Each `NodeCommitted` records a Side-Effect Ledger key (`TOOLING §1.2`) = `f(program_id, node_id, edit_content_hash)`. A resume that re-attempts an already-committed node hits the ledger's unique constraint and **skips** — no duplicate commit, no duplicate MR. An interrupted `IN_PROGRESS` node (crash mid-Run) is safe to restart because its partial work was never committed (Semantic Editing is atomic-or-nothing, `SEMANTIC_EDITING §5`) and the ledger slot for the *attempt* was `PENDING`, not `COMMITTED`.

**Parent/child Program composition — nested programs for recursive migrations.** A node whose `node_class` is `child-program` (§3) does not spawn a base-loop Run — it spawns an entire nested **Program**: its own MTG, its own Event-Log aggregate, its own budget and human checkpoints, scoped as a program-in-its-own-right rather than a module-in-its-own-right. This is the composition mechanism the §3.4 decoupling-refactor case (or any other prerequisite whose own dependency graph is itself program-scale) uses when a single Run cannot hold it. On spawn (`ChildProgramSpawned{node_id, child_program_id}`), the parent node transitions `IN_PROGRESS → BLOCKED_ON_CHILD_PROGRAM`; the parent Program does not advance past that node's dependents while it waits. The child runs under its own Supervisor instance and its own Event-Log stream (its `ProgramCreated` event carries `{parent_program_id, parent_node_id}` to link it back); the parent is otherwise inert with respect to the child's *internal* state — same bulkhead discipline as §9. The child's terminal `ProgramOutcome` maps back onto the parent node **deterministically**, never ambiguously:

| Child `ProgramOutcome` | Parent node transition |
|---|---|
| `COMPLETED` | `BLOCKED_ON_CHILD_PROGRAM → READY` (the parent node becomes schedulable again — ready to resume) |
| `CAPPED_PARTIAL(report)` | `BLOCKED_ON_CHILD_PROGRAM → BLOCKED_ON_HUMAN`, with the child's `report` attached verbatim to the parent node's evidence trail |
| `ABANDONED` | `BLOCKED_ON_CHILD_PROGRAM → BLOCKED_ON_HUMAN`, with the child's report (or abandonment reason) attached verbatim |

This mapping (`ChildProgramOutcomeMapped{node_id, child_program_id, outcome, mapped_state}`) is the **only** sanctioned exit from `BLOCKED_ON_CHILD_PROGRAM` — the parent never infers success from the child's intermediate/partial commits and never polls the child's live state; it acts strictly on the child's terminal, event-logged `ProgramOutcome`, the same "never claimed, only proven" discipline as §6's `COMPLETED` gate. Per **ADR-026**'s data-plane/control-plane split, spawning a child Program creates no control-plane definition file — the parent's and the child's MTG/state both remain data-plane Event-Log aggregates; only a program *goal* (data) is created, never a new skill/agent/workflow *definition* in the git control repo.

**Enforcement + acceptance:**
- *Crash recovery:* `kill -9` the runtime after 200/1000 nodes committed → on restart the committed set is byte-identical, READY nodes are re-derived, and only the one interrupted `IN_PROGRESS` node restarts (idempotent-safe). Post-crash committed set == pre-crash; no node committed twice.
- *Model swap:* retire the coder model mid-program and deploy a new version → the next node's Run uses the new model; the program completes with no manual intervention and no orphaned state.
- *Multi-day pause:* a program `PAUSED` Friday resumes Monday from the exact checkpoint via incremental projection (no full replay of thousands of events).
- *Child-program mapping is deterministic:* spawn a child Program from a parent node and drive it to each terminal `ProgramOutcome` in turn → `COMPLETED` always resolves the parent node to `READY`; `CAPPED_PARTIAL`/`ABANDONED` always resolve it to `BLOCKED_ON_HUMAN` with the child's report attached; no other parent-node transition is reachable from `BLOCKED_ON_CHILD_PROGRAM`.

---

## 5. Incremental module-by-module execution (point 3)

The Program **never loads the whole codebase into anything.** Each READY node spawns **one unmodified base-loop Run** (`LOOP_AND_AGENT_TEAMS.md`) scoped to that module.

- **Interface-not-implementation context.** The Run's Context Optimizer (`CONTEXT_FABRIC §3`) assembles only: the target module's own source + the *interface slices* (signatures/contracts) of its 1-hop neighbors + the program-scoped migration conventions (§10) + relevant exemplars. Neighbor *implementation bodies* are excluded unless a specific dependency query pulls one in. This is what keeps a module's Run inside the window regardless of the codebase's total size.
- **Dependency order makes incremental work sound.** Because leaf dependencies migrate first (or a shim is inserted), a module's Run always executes against dependencies that are *already in their target form and verified* — it works against real, stable interfaces, not a moving target. Reverse-order (strangler-fig) work compiles against the shim until the provider migrates.
- **Shadow-differential correctness oracle for behavior-preserving migrations.** For the common migration case ("same behavior, new language/framework"), each migrated module runs in **differential/shadow mode against the original** — the Rust-migration comparator pattern (`AGENT_TESTER §6/§8`), generalized: same inputs → outputs must match the pre-migration module within tolerance. This is the strongest per-module oracle a migration has, and it is already a designed primitive.

**Enforcement + acceptance:**
- *Bounded per-Run context regardless of repo size:* instrument per-Run context tokens across a synthetic 1M-LOC program; assert p100 per-Run context ≤ the configured window fraction, and that total-repo LOC never appears in any single Run's assembled context. A 10k-LOC and a 1M-LOC program have the *same* per-Run ceiling; only the node count differs.
- *Interface-only neighbor context:* assert a migrating module's assembled context contains neighbor signatures but not neighbor bodies unless an explicit dependency query justified pulling a body.

---

## 6. Verification-at-scale — never "done" unproven (point 4)

Three verification scopes, all through the **existing** typed `PipelineOutcome` (`CODE_REVIEW_PIPELINE.md`) — no new verification code, just new scopes and a program-level gate.

1. **Per-module (node-level).** Every module Run's edits pass the full risk-scaled Code-Review Pipeline. Migration modules touching a critical-path tag (settlement/ledger/compliance) are Tier-3 → full 12 stages + mandatory Judge + (for behavior-preserving) the shadow-differential run. **A node reaches VERIFIED only on a `Complete` PipelineOutcome.** `Capped`/`Blocked` → `BLOCKED_ON_HUMAN` or `FAILED_ISOLATED` (§9), never a silent pass.
2. **Per-edge (integration).** When a node commits, the Supervisor auto-inserts an **integration node** on each edge to an already-committed neighbor and runs the integration suite scoped to that seam (blast radius from the call/import graph). This catches "module A migrated fine alone but broke its contract with already-migrated B." The integration node is itself gated by the pipeline's regression-detection stage over the *cross-module* blast radius.
3. **Program regression sweep (program-scale).** The Program maintains a **program-wide regression baseline** — the full suite's last-known-green state, versioned per checkpoint. On a cadence (every N committed nodes, and always before a phase-boundary checkpoint) a sweep runs the accumulated suite against all committed work. A regression is **attributed** to the introducing node (via git-history graph + the Event Log) and that node re-opens (`ROLLED_BACK → READY`). Per `AGENT_TESTER §6` ("a bug found once is tested forever"), a program-scale regression becomes a **permanent regression scenario** for the rest of the program.

**The `COMPLETED` gate.** A program reaches `COMPLETED` only when **all** hold: (a) every MTG leaf node is `COMMITTED` with a `Complete` PipelineOutcome; (b) every edge integration node is green; (c) the final program regression sweep is green; (d) an **independent program-level Judge** (fresh-context Architect, cross-provider where the data-class allows) confirms the *program goal* — not per-module self-reports — is met. Any red → `CAPPED_PARTIAL` with an honest report (§8). This is the LOOP §7 "three non-substitutable proofs" and `CODE_REVIEW` typed-outcome discipline, lifted to program altitude: **"done" for a program is proven compositionally, never claimed.**

**Enforcement + acceptance:**
- *Contract break caught at the seam:* inject a migration that passes its own tests but breaks an already-migrated dependent's contract → the edge integration node fails, the offending node is attributed and re-opened, and the program state does **not** reach `COMPLETED`.
- *Late regression attributed correctly:* commit node 5; later, node 400 reintroduces a regression in node 5's area → the sweep flags it and re-opens **400** (the introducer), not 5.
- *No silent completion:* a program with one `BLOCKED` leaf can never emit `COMPLETED`; it emits `CAPPED_PARTIAL` naming the blocked node.

---

## 7. Cost, time & parallelism across the GPU fleet (point 5)

**Parallelism = the width of the dependency graph.** The durable Kahn scheduler admits all READY nodes (no unmet deps) up to a **program fan-out ceiling**, executing independent modules as concurrent base-loop Runs. This is what makes 1M-LOC *time*-feasible: a wide dependency graph parallelizes massively across the fleet; a deep, narrow chain does not (honest limit, §11).

**Fleet integration (ties to `SERVING_OPS.md` / ADR-020).** Each module Run is a workload Serving-Ops schedules onto the GPU fleet. The Program is a **bulk, latency-tolerant, preemptible** workload class:
- It submits Runs at **low QoS priority** (Serving-Ops SLO-aware admission, Pass-5 gap [27]). **Interactive traffic always preempts program Runs**, never the reverse — an incident RCA or a chat query must not queue behind a migration.
- A **preempted program Run checkpoints its node back to `PENDING` and re-queues** — safe because node execution is idempotent (§4) and no partial edit was committed. Preemption costs the tokens spent so far but never corrupts state.
- The fan-out ceiling is **elastic**: it scales up to consume idle fleet capacity (nights/weekends) and scales down under interactive load, driven by Serving-Ops bin-packing/QoS signals (gaps [26], [27]) — not a static number.

**Cost governance.** The program carries a **program budget** (tokens / dollars / wall-time) *above* the per-Run budget. Per-Run costs roll up (LOOP §4 cost roll-up) into the program aggregate; a **running cost-per-module estimate** from completed nodes projects total program cost. Crossing a budget threshold (e.g., 25/50/75%) forces a `CHECKPOINT_REVIEW` human gate ("projected total is ₹X for the remaining N nodes — continue?"). The program budget is a **hard ceiling**: crossing 100% pauses the program, never silent continuation.

**Time/throughput.** Completed-node velocity (nodes/day, LOC/day) projects an ETA surfaced in progress tracking (§8), recomputed each checkpoint.

**Enforcement + acceptance:**
- *Interactive never starves:* drive interactive traffic during a running program → interactive p95 latency is unaffected; program Runs are the ones preempted (verified via Serving-Ops QoS class on each Run).
- *Budget gate:* a program crossing 50% of its dollar budget pauses at a `CHECKPOINT_REVIEW` with a projected total and does not continue without a human decision; crossing 100% hard-pauses.
- *Parallel scaling:* a wide-graph program's wall time falls with fleet size; a deep-chain program's does not (measured and reported honestly, not asserted).

---

## 8. Staged human checkpoints, progress tracking & partial-completion (point 6)

**Checkpoints are first-class MTG milestones, not interruptions**, and they reuse the existing Approval Gate seam (`RUNTIME_FEATURE_FLOWS §7b`) — no new HITL machinery. Classes:

| Checkpoint class | Trigger | Gate |
|---|---|---|
| **Start** | `DECOMPOSED → APPROVED` | Human approves the MTG + migration strategy + program budget **before any code**. |
| **Phase-boundary** | a major architectural layer / bounded-context is fully committed **and** integration-green | Human signs off before the next phase begins. |
| **Budget** | crossing a budget threshold (§7) | Human "continue / adjust / stop" with a projected total. |
| **Critical-path** | any node touching a settlement/ledger/compliance-tagged module | Autonomy forced to `assisted`; human approves the commit **regardless of PipelineOutcome score** — reuses `CODE_REVIEW §3` Tier-3 rule verbatim. |
| **Anomaly** | a spike in cap/rollback rate, a newly-discovered large SCC, a budget-estimate blowout | Auto-raised gate with the evidence trail. |

Gating at **phase/risk granularity, not per-node**, is deliberate — per-node human gates would make the humans the stall (honest residual, §12).

**Progress tracking** is a renderer over the durable program projection (same pattern as every other surface): the MTG rendered as a **burn-down over the dependency graph** — per-node state, nodes committed/verifying/blocked/rolled-back, LOC migrated / total, velocity + ETA, cost spent / budget + projection, open human-gates, and a drill-in to any module's full Code-Review trail via `pipelineHistory(commit_sha)`.

**Partial-completion is a first-class, honest, *deployable* outcome** (`CAPPED_PARTIAL`), mirroring the loop's `capped`. A program that stops (budget exhausted, human abandon, an un-passable module) reports: exactly which modules are `COMMITTED` and production-safe; which are `BLOCKED`/`FAILED_ISOLATED` and *why* (the specific gap, like the pipeline's gap report); what fraction of the goal is done; and — critically — whether the committed subset is **coherent and deployable**. Because migration is dependency-ordered with shims, **the committed subset is always a consistent, compiling, test-green system** (strangler-fig at module granularity): you can ship the 60% that is done and resume the remaining 40% later. The report is generated from the durable MTG state + the last green regression sweep and asserts the committed subset is green before calling it deployable.

**Enforcement + acceptance:**
- *Critical-path never auto-commits:* a settlement-module node forces an Approval Gate regardless of Confidence Score (reuses the Tier-3 rule; verified the gate cannot be bypassed by a high score).
- *Phase gate blocks advance:* the program cannot enter phase 2 without a human approval event on the Event Log.
- *Deployable partial:* a program abandoned at 60% produces a report listing the 60% committed (green, deployable) and the 40% remaining with reasons; the committed subset compiles and passes the regression suite.

---

## 9. Failure isolation & single-module rollback (point 7)

**Bulkhead per node** (reuses LOOP §4 failure isolation). Each module Run executes under its own child cancellation token + budget slice. A Run that throws / times out / caps returns a **typed failure** to the Supervisor — it does **not** propagate to sibling module Runs already in flight (a parallel module on an unrelated branch keeps going) and does **not** crash the program. The failed node → `FAILED_ISOLATED`; its *dependents* → `BLOCKED`; *independent* branches continue.

**Single-module rollback = git-level + ledger-level reversal of just that node.** Because each node commits atomically (`SEMANTIC_EDITING §5` all-or-nothing) with its commit-SHA(s) recorded in the Event Log + Side-Effect Ledger, rolling back a node = revert its SHA(s) + run its **saga compensation** (`TOOLING §1.3` — e.g., `compensate` un-creates its MR), set the node to `READY` or `BLOCKED_ON_HUMAN`, and re-project. **All other `COMMITTED` nodes are untouched — program progress is preserved.** Rollback is honest about non-compensable steps (`FAILED_PARTIAL` per the ledger design). If a *later* node already built on the rolled-back one, the rollback **cascades to those dependents** (computed from the dependency graph → they re-open too) — never a silent orphan pointing at reverted code.

**Poison-node quarantine.** A node that repeatedly fails (caps N times across re-attempts, detected by a **program-level stuck-detector** distinct from the Run-level one) is quarantined to `FAILED_ISOLATED` and escalated to an anomaly checkpoint with the full failure trail. The program **routes around it** — continues every branch that does not depend on it — rather than stalling the whole program on one hard module. This is the honesty mechanism a real 1M-LOC migration requires: some modules the agent cannot do; the program **isolates and continues**, delivering the 990k it can, not stalling at 100%.

**Enforcement + acceptance:**
- *Sibling isolation:* one module Run throws while 3 sibling Runs are in flight → the 3 continue and commit; the failed node isolates; its dependents block; the program does not crash (LOOP acceptance #5 at program scale).
- *Clean single-module rollback:* roll back node 200 after commit → 200's SHA is reverted, its MR compensated, nodes 1–199 and all independent nodes stay committed; nodes that depended on 200 re-open; a committed-set query returns `{all committed} − {200 and its dependents}`.
- *Route-around:* a poison module caps 3 times → quarantined, human-escalated; the program completes all independent branches; the final report lists it `FAILED_ISOLATED` with the trail.

---

## 10. Semantic/AST editing at scale + cross-model review (point 8)

**Every module edit goes through the Semantic Editing engine** (`SEMANTIC_EDITING.md`), never raw text patching — at 1M-LOC scale text patching is catastrophic (import drift, silent call-site breakage). The edit ladder (LSP → AST → structured-patch → text) makes cross-file renames/signature changes *within a module* atomic and reference-complete; the known import-restore, method-preservation, and field-rename guards apply on every node. Migration work is dominated by AST transforms (translate constructs) + signature/import rewrites — the engine's core operations. A node's `edit_ladder_floor` (§3) forbids the text-patch rung for critical-path modules.

**Atomicity is per-module; cross-module consistency is per-edge verification — not a global lock.** A migration that changes a shared interface is a node whose blast radius is *all consumers*; the engine resolves call sites *within that node's scope* atomically, and consumers in *other* modules are handled by their own dependent nodes that the dependency graph already orders after this one. The engine **never** attempts a single atomic transaction across the whole codebase (it would exceed any window and any safe atomic-write boundary). Cross-module propagation is **scheduled and integration-verified** (§6), which is the only tractable form of consistency at 1M-LOC scale.

**Cross-model review at scale** (reuses `RUNTIME_FEATURE_FLOWS §4.1`). Producer and judge run on **different models** per node (e.g., Coder=Qwen → Judge=GLM). At program scale this matters *more*, not less: thousands of modules by one model with a same-model judge would share systematic blind spots that compound across the whole migration. For **regulated modules** (settlement/ledger), data-class routing (`TOOLING §4.2`) constrains both producer and judge to in-house OSS models — cross-model = two different OSS models. The program-level final Judge (§6) is likewise cross-provider where the goal's data-class allows.

**Enforcement + acceptance:**
- *Rung recorded, floor enforced:* every node logs its edit-engine rung; a critical-path node cannot reach VERIFIED on a text-patch rung without an explicit human gate.
- *Cross-model per node:* inspect node traces → `producer_model ≠ judge_model` for every node; a same-model node is rejected by policy; regulated nodes use only fleet OSS models for both roles.

---

## 11. What makes 1M-LOC feasible — and where it honestly stalls

**Why it is feasible (the load-bearing reasons):**
1. **You never operate on 1M LOC.** The window-sizing invariant (§3.2) guarantees you operate on one window-sized module, thousands of times. Total repo size sets the node *count*, never any Run's context.
2. **Durability decouples the program from any Run/model/session.** It is a durable graph of committed code + typed contracts, replayable from the Event Log (§4) — multi-week, restart-surviving, model-swap-surviving, because it carries *code and contracts*, not reasoning.
3. **Parallelism scales with graph width × fleet size** (§7).
4. **Verification is compositional and bounded** — per-module, per-edge, periodic sweep — never one impossible 1M-LOC verification (§6).
5. **Partial completion is coherent and deployable** — strangler-fig at module granularity means you never need 100% to capture value (§8).
6. **Failure isolates and routes around poison modules** (§9) — one impossible module doesn't sink the program.

**Where it stalls (honest — these are not hand-waved):**
- **Deep, narrow dependency chains serialize.** A monolith that is essentially one long import chain has no parallelism; wall time is dominated by the critical path regardless of fleet size (Amdahl on the dependency graph). Fleet money doesn't buy speed here.
- **Large SCCs (circular coupling) are the single biggest legacy stall.** A big mutually-recursive module cluster cannot be migrated incrementally; if the SCC super-node exceeds a window, a **human-led decoupling refactor must precede it**. The design *surfaces* this (Tarjan → human checkpoint) instead of pretending it away — but it is a genuine stall, and on a badly-coupled legacy monolith it can dominate the whole program.
- **Cross-cutting concerns are anti-incremental.** A change touching every module (a logging/auth/error-handling pattern) is better done as a **deterministic codemod node** (a uniform AST transform, `node_class = deterministic-codemod`) than an LLM-per-module program. The design routes those to a deterministic transform class and is honest that LLM-per-module is the wrong tool there.
- **Verification is capped by the existing test suite.** The program's correctness proof is only as strong as the existing tests + shadow-differential coverage. A poorly-tested legacy codebase gives weak per-module oracles. The program can insert **characterization-test nodes** first (generate tests that pin current behavior), but those are added cost and imperfect — on an untested monolith, confidence is bounded by how good the generated characterization tests are, and that is a real ceiling, not a solved problem.
- **Semantic drift across weeks.** Conventions, target-framework idioms, and even the model version change mid-program; later modules could diverge stylistically from earlier ones. Mitigation: pin migration conventions as **program-scoped OKIs** (`ENTERPRISE_MEMORY_LEARNING.md`) read into every node's context. This *manages* drift; it does not eliminate it.
- **Human-checkpoint throughput.** Too many gates re-creates a human bottleneck; the design gates at phase/risk granularity, but gate calibration is a real tuning problem (same class as LOOP's threshold tuning).
- **The eval/verification platform is the keystone — amplified.** A program commits at scale and at speed; if per-module verification is weak, it confidently ships wrong migrations *faster than a human would*, which is worse than slow-and-manual. The Program amplifies verification quality in both directions — it is the highest-leverage dependency and the highest-leverage risk.

**Bottom line honesty:** a well-factored 1M-LOC codebase with a wide dependency graph and a decent test suite is **genuinely feasible** — thousands of bounded Runs, durable, parallel, compositionally verified, resumable. A badly-coupled, poorly-tested legacy monolith is **feasible only after human-led decoupling and characterization-test investment** — and the design's job there is to *surface exactly where and why* it will stall (SCCs, coverage gaps), not to claim it won't.

---

## 12. Acceptance / scenario tests

| # | Scenario | Exercises | Pass condition |
|---|---|---|---|
| 1 | Decompose a 1M-LOC repo with a known dependency structure | §3 decomposition, window sizing | Every leaf node's working-set ≤ window fraction; topological order never runs a dependent before its dependency (or a shim is present); total LOC never enters a single Run's context |
| 2 | Circular import cluster among N modules | §3.4 SCC handling | An SCC super-node or a decoupling-refactor prerequisite is produced and raised to a human checkpoint — never an arbitrary linearization |
| 3 | `kill -9` the runtime after 200/1000 nodes committed | §4 durability/resume | Committed set byte-identical post-restart; READY nodes re-derived; only the interrupted node restarts; no node committed twice |
| 4 | Retire the coder model mid-program, deploy a new version | §4 model-swap survival | Program continues on the new model with no manual step, no orphaned state |
| 5 | Pause Friday, resume Monday | §4 checkpoint + incremental projection | Resumes from the exact checkpoint without a full event replay |
| 6 | Per-Run context measured across the whole program | §5 incremental execution | p100 per-Run context ≤ window fraction; neighbor bodies excluded unless a dependency query pulled one |
| 7 | Module passes its own tests but breaks a committed dependent's contract | §6 per-edge integration | Edge integration node fails; offending node attributed + re-opened; program not `COMPLETED` |
| 8 | Node 400 reintroduces a regression in node 5's area | §6 program regression sweep + attribution | Sweep flags it; re-opens **400** (introducer), not 5 |
| 9 | Interactive chat + incident RCA during a running program | §7 QoS / preemption | Interactive p95 unaffected; program Runs preempted (checkpointed to PENDING + re-queued), never the reverse |
| 10 | Program crosses 50% then 100% of dollar budget | §7 budget governance | 50% → `CHECKPOINT_REVIEW` with projected total, no auto-continue; 100% → hard pause |
| 11 | Settlement-module node at Confidence Score 100 | §8 critical-path gate | Forces `assisted` + human commit approval regardless of score; cannot be bypassed |
| 12 | Abandon the program at 60% complete | §8 partial-completion | Report lists 60% committed (green, deployable) + 40% remaining with reasons; committed subset compiles + passes regression suite |
| 13 | One module Run throws while 3 siblings are in flight | §9 bulkhead isolation | 3 siblings continue + commit; failed node isolated; dependents block; program does not crash |
| 14 | Roll back node 200 after commit; node 250 depended on it | §9 single-module rollback + cascade | 200 reverted + MR compensated; 1–199 and independent nodes intact; 250 re-opens; no orphan |
| 15 | A module caps 3 times across re-attempts | §9 poison-node quarantine | Quarantined `FAILED_ISOLATED`; human-escalated; program routes around it and completes independent branches |
| 16 | Every node's producer vs judge model | §10 cross-model review | `producer_model ≠ judge_model` per node; regulated nodes use two OSS models; same-model node rejected |
| 17 | Deep narrow dependency chain vs wide graph, same fleet | §7 + §11 honesty | Wide graph's wall time falls with fleet size; deep chain's does not — measured and reported, not asserted |
| 18 | Cross-cutting concern (uniform logging change) requested as a program | §11 codemod routing | Routed to a `deterministic-codemod` node class, not thousands of LLM Runs |
| 19 | Untested legacy module scheduled for migration | §11 characterization tests | A `characterization-test` node is inserted first; the module's confidence is honestly discounted to the generated tests' coverage |
| 20 | Two-year-later audit of the whole program | §4 Event-Log + `pipelineHistory` | Full hash-chained trail reconstructs every node's decomposition, state transitions, PipelineOutcome, rollbacks, and human decisions from the log alone |
| 21 | A `child-program` node spawns a nested decoupling-refactor Program; the human abandons the child at 40% complete while the parent has other branches already committed | §4 parent/child composition, outcome mapping | Parent node transitions `BLOCKED_ON_CHILD_PROGRAM → BLOCKED_ON_HUMAN` with the child's `ABANDONED` report attached verbatim; the parent Program does not advance past the blocked node's dependents and does not infer success from the child's partial commits; the parent's own already-`COMMITTED` nodes (independent branches) are untouched; the parent cannot reach `COMPLETED` while the node remains blocked |

---

## 13. Consequences

**Positive.**
- The runtime gains a *unit of work above the Run* — the missing altitude that gap AG named — without touching the base loop.
- 1M-LOC migration becomes a **durable, resumable, compositionally-verified, partially-shippable** program, not a heroic single Run that cannot exist.
- Everything reuses existing spine machinery (Event Log, Code-Review Pipeline, Semantic Editing, Side-Effect Ledger/saga, Approval Gate, Serving-Ops, cross-model review) — the Program is an **orchestration + durability layer**, not a second execution stack. Anti-fragmentation (`AINXT_OS §3`) holds.
- Partial completion is *always deployable* (strangler-fig at module granularity), so value lands continuously, not only at 100%.

**Negative / cost.**
- A genuinely new subsystem to build, test, and operate (state machine, durable projection, program scheduler, program dashboard, regression-baseline management).
- It **amplifies** the eval-platform keystone risk: weak verification now ships wrong code at scale and speed.
- Gate/threshold calibration (fan-out ceiling, budget thresholds, poison-node cap, checkpoint granularity) is unproven until real NPCI programs run — illustrative defaults only.

**Gap closure & integration.** Closes gap **AG**. Ties to: ADR-020/`SERVING_OPS.md` (fleet scheduling of program Runs), ADR-013/`TOOLING §1` (idempotent resume + single-module rollback), `CODE_REVIEW_PIPELINE.md` (all three verification scopes), `SEMANTIC_EDITING.md` (per-module atomic edits), `LOOP_AND_AGENT_TEAMS.md` (each node = one Run), `ENTERPRISE_MEMORY_LEARNING.md` (program-scoped convention OKIs + a terminal program Learning Record feeding the flywheel), `AGENT_TESTER.md` (shadow-differential migration oracle + "found once, tested forever" at program scale).

---

## 14. Why this earns a 10 — and an honest self-score

Every clause of the brief has a concrete enforcement mechanism, not a principle statement: decomposition is a **window-sized, dependency-ordered graph derived from real Context-Fabric edges** with Tarjan SCC handling (not a human DAG, not an arbitrary linearization); durability is an **append-only, hash-chained Event-Log aggregate with idempotent, model-swap-surviving resume** (because it carries committed code + typed contracts, never reasoning); incremental execution is guaranteed by a **working-set-fits-the-window admissibility invariant** that makes total repo size irrelevant to any Run; verification is **three compositional scopes through the existing typed PipelineOutcome** plus an independent program-level Judge, with a `COMPLETED` gate that cannot be reached with any red; fleet management makes the program a **preemptible low-QoS elastic workload** that can never starve interactive traffic, under a hard program budget with human gates on threshold crossings; human oversight is **phase/risk-granular checkpoints on the existing Approval Gate seam** with a durable progress dashboard and a first-class *deployable* partial-completion report; failure handling is **per-node bulkhead isolation + single-module git/saga rollback with dependent-cascade + poison-node route-around**; and editing is **Semantic-Editing-at-module-granularity with per-edge (not global-lock) cross-module consistency and mandatory cross-model review**. Twenty scenario tests exercise exactly the properties that decide whether 1M-LOC is real: a Run never overflows a window, a crash loses nothing, a model swap is a non-event, interactive latency is untouched, a bad module rolls back alone, a poison module is routed around, and the committed 60% ships green.

**Self-score: design 9/10 (honest), not 10.** It is a genuine, artifact-backed 10 on *orchestration, durability, and compositional verification* — the parts fully in the runtime's control. It is held to **9** because the two hardest realities of a 1M-LOC legacy migration are *managed and surfaced, not solved*: (1) **large SCCs / deep chains** can force human-led decoupling and serialize the program — the design exposes exactly where, but cannot make a badly-coupled monolith parallel; and (2) **verification confidence is bounded by the existing test suite** — characterization-test generation helps but does not manufacture ground truth an untested legacy system never had. A design that claimed 10 here would be claiming it had solved legacy-monolith decoupling and test-oracle generation, which it has not. The honest 10 is "the best possible orchestration of a problem whose floor is set by the codebase's own structure and tests" — and the mark of the design's quality is that it makes that floor **visible and reportable** (SCC checkpoints, coverage-discounted confidence, deployable partials) rather than hiding it behind a confident "done."

## 15. Residual risks / open questions
- **Fan-out ceiling & budget thresholds are guesses** until real programs run — too high starves interactive traffic despite preemption overhead; too low wastes idle fleet.
- **Working-set estimation accuracy** — the §3.2 admissibility check depends on estimating a module's + neighbors'-interface token cost *before* running it; a bad estimate under-splits (overflow at run time → forced mid-program re-split) or over-splits (needless node count + integration overhead).
- **Program regression sweep cost** grows with committed-node count; on a huge program the full-suite sweep every N nodes may itself dominate fleet time — needs incremental/affected-only sweep tuning, and the "affected set" is only as good as the test graph.
- **SCC decoupling is off-critical-path but on the human** — the design surfaces the SCC, but the decoupling refactor it demands is itself a hard engineering task that may need its own (recursive) program. §4 now specifies the composition mechanism (`child-program` node class, `BLOCKED_ON_CHILD_PROGRAM`, deterministic `ProgramOutcome` mapping), but the decoupling work itself remains genuinely hard engineering, and recursion beyond one level (a child spawning its own child) is unexercised.
- **Nested-program state-corruption risk** — a parent node's `BLOCKED_ON_CHILD_PROGRAM` wait is resolved *only* by the child's terminal, event-logged `ProgramOutcome`; the parent's own Event-Log has no visibility into the child's intermediate state. If the child's Event-Log stream is corrupted, its hash-chain broken, or its terminal-outcome event lost or never durably observed by the parent (a partition between the two Supervisor instances), the parent node can sit `BLOCKED_ON_CHILD_PROGRAM` indefinitely with no local signal for *why*, and — worse — a parent that incorrectly treats a missing terminal event as an implicit success would silently corrupt its own state machine. Cross-log referential integrity between a parent and a spawned child (as opposed to each log's own internal hash-chain, which §4 already guarantees) is a *new* correctness dependency this design introduces and does not yet prove at recursive depth.
- **Characterization-test trust** — generated tests pin *current* behavior including current *bugs*; a behavior-preserving migration will faithfully preserve a bug, and distinguishing "preserved bug" from "must-fix" needs human judgment the design routes to a checkpoint but does not resolve.
- **Poison-node cap tuning** — too eager quarantines modules a retry or a model-tier bump would have solved; too lax burns budget on a dead module before routing around it.
