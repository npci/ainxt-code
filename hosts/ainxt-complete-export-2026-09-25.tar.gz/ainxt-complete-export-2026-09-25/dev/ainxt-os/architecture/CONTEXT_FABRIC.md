# Context Fabric — multi-graph context engineering, design to 10/10

**Status:** Design (no code). Closes the scorecard gap (was 7/10: retrieval + symbol map only). Target: not one context window — a **fabric of graphs** compiled into the model's window by an optimizer.

## 1. The principle
Context is not "top-k RAG chunks." It is a **queryable fabric of layered graphs** about the work, from which a **Context Optimizer** compiles exactly the right slice into the token budget for each turn — relevance-ranked, position-aware, freshness-aware, conflict-arbitrated, RBAC- and data-class-filtered.

## 2. The graph layers (the fabric)
1. **Conversation** — the immutable Event-Log projection (this + related turns).
2. **Repository/file** — files, dirs, ownership.
3. **Symbol graph** — definitions ↔ references.
4. **AST graph** — syntax structure (from tree-sitter), for precise navigation.
5. **Call graph** — who calls what.
6. **Import/dependency graph** — module + package dependencies.
7. **Architecture graph** — services/modules/boundaries/contracts (the "shape" of the system).
8. **Git-history graph** — blame, change-coupling (files that change together), churn.
9. **Runtime/observability** — logs, traces, metrics as *context* (e.g., "this function errors in prod").
10. **Test graph** — tests ↔ code coverage mapping (what covers what).
11. **Enterprise docs** — hybrid RAG (pgvector HNSW + BM25 → RRF → rerank).
12. **Memory** — episodic + semantic + structured org-knowledge (conventions, approved libs, postmortems).

All layers unify into one **Knowledge Graph** (extends the existing KG project) with **node/edge-level RBAC + data-class labels**.

## 3. The Context Optimizer (the "compiler" graphs → window)
Given a task, it produces the context window by:
- **Query planning** — decide which graphs to draw from ("refactor X" → symbol+call+import+test+git; "why did settlement fail" → docs+runtime-logs+data).
- **Cross-graph relevance ranking** — score candidate nodes across all graphs against the (rewritten) query and in-scope entities (personalized PageRank over the unified graph).
- **Budget fitting — resolved against the *eligible* model set, not an assumed one (closes Gap [22]).** The naive ordering — fit to a default/assumed window, *then* let the Model Router pick the model (`RUNTIME_FEATURE_FLOWS.md` step 4 before step 5) — lets an OSS/in-house failover target with a narrower tokenizer/window silently truncate evidence that was already fit to a wider assumption. The fix: the Model Router's `tier_eligible ∩ class_eligible` candidate set (`TOOLING_MCP_PLUGINS_ROUTING.md` §4.1–§4.2) is resolved **before** Budget Fitting runs — cheap, since it needs only the turn's task-type and data-class, both already known at Context Engine entry, not the fully-assembled context or the final cost/latency/quality rank. Budget Fitting is then **two-phase**: (1) fit to the **narrowest tokenizer/window among the eligible set** (the fit-to-eligible-floor), so the assembled window is never wider than what the eventual model can accept; (2) **re-fit** once the Model Router confirms the specific model at step 5 (its exact window typically only widens the floor) and **re-fit again on any failover** across the chain (`TOOLING_MCP_PLUGINS_ROUTING.md` §4.4), since a failover target can be narrower than the primary. The per-task-type tier→window table this floor is computed from is itself a versioned Surface Profile / control-plane definition (ADR-026) — never a hardcoded runtime constant that can drift from what the router actually enforces.
- **Acceptance test (Gap [22]):** for every model in the `class_eligible` failover chain of a policy tier, assemble context at the platform's largest configured evidence set, force failover to that route, and assert the emitted prompt's measured token count (on that route's *actual* tokenizer) is ≤ its real window, with **zero silently dropped or truncated evidence nodes** — every included/excluded node is accounted for in the lineage record via the ranked binary-search cut, never a raw string truncation. Run as a CI regression on every new OSS model onboarding and every window-size change; a failing route blocks the merge.
- **Position-aware assembly** — most-relevant at the edges of the window ("lost-in-the-middle" mitigation), not just fitting.
- **Freshness + conflict** — prefer fresh sources; arbitrate conflicts by recency/authority; attach provenance/lineage.
- **Security filter** — pre-rank **chunk/node-level ACL** + **data-class** filter (regulated content never enters a cloud-model prompt). Filtering happens *before* ranking so existence never leaks.
- Output: the context window **+ a lineage record** (which nodes contributed) for audit, citations, and erasure.

## 4. Incremental maintenance (so it never rots)
- Graphs update on **file change / index / commit / runtime event** (event-driven, not batch).
- **Staleness tracking** per node; re-index/re-embed triggers.
- **Embedding-model lifecycle**: version-tracked embeddings + a re-embed pipeline (no silent mixed-version degradation).
- Vector index recall/latency tuned + monitored.

## 5. Query interface (used by the Intelligence Layer + Semantic Editing)
The agent asks structured questions, not just "search":
`whoCalls(sym)` · `refsOf(sym)` · `architectureAround(module)` · `changedWith(file)` · `testsCovering(fn)` · `runtimeErrorsFor(fn)` · `deps(module)` — each returns graph slices the optimizer can fold into context.

## 6. Integration
- **Semantic Editing** reads the symbol/call/import graphs (shared substrate).
- **Conversation Intelligence** uses it for grounding + referent resolution.
- **Code-Review Pipeline** uses architecture/dependency graphs for architecture + regression review.
- Every assembled context carries a **lineage record** → citations, audit, right-to-erasure.

## 7. Why this is now a 10
It implements the full rubric context stack — conversation, repo, symbol, AST, architecture, dependency, git-history, runtime, tests, docs, memory — unified into one RBAC/data-class-aware graph, with an **optimizer** that plans, ranks across graphs, fits to budget, positions for attention, arbitrates conflicts, and records lineage — and keeps itself fresh with an embedding-lifecycle pipeline. It is context *engineering*, not context *stuffing*.
