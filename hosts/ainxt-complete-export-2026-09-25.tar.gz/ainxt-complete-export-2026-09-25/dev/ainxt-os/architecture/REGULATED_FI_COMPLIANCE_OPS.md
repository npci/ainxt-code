# Regulated-FI Compliance Operations — design to 10/10

**Status:** Design (no code). Closes Pass-5 gaps **[3]** statutory AI-incident breach-notification engine, **[10]** PCI-DSS scope / CDE segmentation, **[11]** RBI IT/cloud-outsourcing governance, **[12]** DPDP Significant-Data-Fiduciary duties, **[13]** statutory-retention-vs-erasure + legal-hold override, **[33]** evidentiary admissibility, **[34]** supervisory audit-readiness, plus the load-bearing halves of **[P]** model-risk class and **[Q]** data lifecycle (`GAP_ANALYSIS_PASS5.md`). These are **go-live blockers**, not enhancements — a design-10 AI runtime that cannot pass an RBI IT-examination or an RBI/DPDP breach clock does not launch inside India's payment switch.

**Embeds two ADRs as sections:** **ADR-017 — Regulated-FI Compliance Operations** (§1, the governing decision) and **ADR-025 — Evidentiary Admissibility** (§7).

**Relates to / extends:** ADR-003 (Policy/Approval/Compliance seam — the runtime authz + compliance gate this doc drives), ADR-007 (Event Log / tamper-evident hash-chain — the substrate every register and clock lives on), ADR-011 (incident management — extended here into a *statutory* breach engine), ADR-012 (data-class → model routing — the outsourcing register becomes its eligibility input), ADR-015 (retention / DPDP erasure — legal-hold overrides its cascade here), ADR-016 (agent-payment boundary — a settlement action is a categorically harder incident class here). Companion subsystem docs: `ENTERPRISE_MEMORY_LEARNING.md` §5 (the erasure cascade this doc gates), `CODE_REVIEW_PIPELINE.md` §5/§9 (SAST for CHD-in-code + hash-chained journaling), `TOOLING_MCP_PLUGINS_ROUTING.md` §1.7/§2 (egress DLP + supply-chain TOFU discipline reused for sub-processors), `CONTEXT_FABRIC.md` §3 (pre-rank existence-hiding filter reused for auditor scope), `AGENT_TESTER.md` §6/§8 (shadow-differential — the exit-rehearsal oracle).

**Two binding cross-cutting decisions are honored throughout, and stated once here so every section can lean on them:**

- **[Q2 — Control Plane is Git-Native, ADR-026].** This doc's recurring structural move: **a compliance *policy* is a control-plane definition (a PII-free, reviewed, versioned git file); a compliance *instance* is data-plane operational state (an erasable-or-legal-held Postgres row + hash-chained Event-Log projection).** The RBI outsourcing register schema, the incident taxonomy, the report templates, the retention-policy table, the DPIA form, the legal-hold *scope rules*, the BSA certificate template, the PCI scoping decision, and CODEOWNERS-as-authoring-RBAC all live in git and are governed by PR review + signed commits + the pre-receive compliance gate. The *actual* incidents, DSARs, legal-hold matters, audit exports, and clock states are data-plane, on the Event Log, subject to retention/erasure/hold. Conflating the two is the single most likely way to get this wrong; §1.2 makes the split mechanical.

- **[Q1 — Long-Horizon Programs, ADR-027].** Any multi-week compliance obligation that must survive restarts, model swaps, and partial completion is executed as a durable, resumable, checkpointed **Program**, not a big Run: the RBI **tested exit plan** is a rehearsable Program (§3.4), the PII-slipped-into-git break-glass and a provider-forced-exit remediation are Programs (§6.5, §3.4), and a breach-remediation campaign is a Program with partial completion as a first-class deployable outcome.

---

## 0. The principle — compliance is a *runtime subsystem with SLOs*, not a binder

The last platform (and every generic enterprise-AI platform) treats regulatory compliance as **documentation adjacent to the system**: a policy PDF, a spreadsheet register, a runbook someone opens during an incident. For India's payment switch that posture fails on first contact with a regulator, for one structural reason: **the statutory obligations are real-time control loops with hard deadlines and provable-evidence requirements, and a binder has no clock, no enforcement teeth, and no admissible record.** CERT-In gives you **6 hours** from *noticing* a cyber incident to file — a runbook does not start a timer. RBI treats **every cloud LLM call as IT outsourcing** — a spreadsheet register does not stop the model router from selecting an ungoverned provider. DPDP's Significant-Data-Fiduciary duties require a DPIA *before* a feature processes personal data — a policy document does not block a merge. A hash-chained log is tamper-evident but **not court-admissible** without a Bharatiya Sakshya Adhiniyam §63 certificate — integrity is necessary but insufficient.

So the design principle is: **every statutory obligation is re-expressed as a first-class runtime object with (a) a concrete enforcement mechanism the runtime cannot route around, and (b) an acceptance test that exercises exactly the property a regulator will examine.** A statutory deadline is an **SLO with a durable countdown**. A governance register is the **eligibility input the router reads**, not a report generated after the fact. A DPIA is a **CI gate on promotion**, not a form. Admissibility is an **export capability that produces the certificate**, not a hope. This is the same discipline the rest of the corpus already applies to quality (`CODE_REVIEW_PIPELINE.md`: "an agent may never say done except through a typed outcome") — applied to *law*: **the runtime may never take a compliance-relevant action except through a gate that is itself the compliance control.**

This doc is an **operational overlay**: it does not re-implement the compliance gate (ADR-003), the Event Log (ADR-007), the router's data-class exclusion (ADR-012), or the erasure cascade (ADR-015 / `ENTERPRISE_MEMORY_LEARNING.md` §5). It **wires those existing mechanisms to the statutory obligations** and adds the pieces that have no home yet: the clocks, the registers, the DPIA gate, the legal-hold override, the admissibility certificate, and the auditor mode.

---

## 1. ADR-017 — Regulated-FI Compliance Operations (the governing decision)

**Status:** Accepted (embedded ADR). **Decision class:** Institutional / go-live-blocking. Establishes compliance operations as a runtime subsystem and fixes the control-plane/data-plane split for compliance artifacts.

### 1.1 Context

NPCI is a Significant Data Fiduciary-class operator of critical financial market infrastructure. The AiNxt runtime, the moment it processes a customer query about a settlement or ships context to a cloud model, becomes subject — simultaneously — to the IT Act 2000 + CERT-In Directions (2022), the DPDP Act 2023 + Rules, the RBI Master Direction on Outsourcing of IT Services (2023) and the RBI payment-data-localisation regime, PCI-DSS v4.0, the PMLA record-retention regime, and the Bharatiya Sakshya Adhiniyam 2023 (evidence). These are not a "compliance sprint" after launch; **several are conditions of being allowed to launch at all**, and all of them impose *runtime* obligations (clocks, routing constraints, provable erasure/retention, admissible evidence) that cannot be satisfied by an off-system document.

The prior gap-analysis passes (A–BT, 19-dimension scorecard) scoped *intelligence* and *software-engineering quality* to a genuine design-10 but never owned this layer. Pass 5 named it the largest structural hole.

### 1.2 Decision

**Compliance operations is a first-class runtime subsystem — the "Compliance Control Plane" — built on three commitments:**

1. **Every statutory obligation is a runtime object with an enforcement mechanism**, per the taxonomy below. No obligation exists only as prose.

   | Obligation | Runtime object | Enforcement mechanism (§) |
   |---|---|---|
   | CERT-In 6h / DPDP / RBI breach clocks | **Statutory Clock** (durable SLO countdown) | §2 — clock armed by deterministic policy on classified incident; breach-without-filing raises a meta-incident |
   | RBI IT/cloud-outsourcing governance | **Outsourcing Register** (control-plane) | §3 — the register *is* the router's eligibility input; no route without an entry can be selected |
   | DPDP-SDF DPIA-per-feature | **DPIA gate** (control-plane CI check) | §4 — a personal-data feature cannot promote to `env/prod` without an approved, current DPIA |
   | DPDP algorithmic due diligence + model-risk [P] | **Model-Risk Record** (control-plane) | §4.2 — promotion checklist backed by the eval scoreboard |
   | DPDP DSAR (access/correction/erasure/grievance) | **DSAR workflow** (data-plane, governed Role) | §4.4 — SLA clock + cross-tier lineage resolution |
   | PCI-DSS scope / no-CDE-persistence | **Write-path CHD sink-guard** + segmentation | §5 — CHD redacted before any durable sink; store swept to prove it |
   | Retention floor vs erasure + legal-hold | **Retention/Hold decision function** on the cascade | §6 — deterministic precedence; held records deferred-with-record, never deleted |
   | Evidentiary admissibility (BSA §63) | **Evidentiary Export** + certificate | §7 (ADR-025) |
   | Supervisory audit-readiness | **Auditor evidence-access mode** (read-only) | §8 — India-resident 180-day logs, NIC/NPL NTP, chain-of-custody on every pull |

2. **The control-plane/data-plane split (Q2/ADR-026) is applied to compliance, exactly.** This is the structural spine of the whole subsystem:

   | Compliance *policy* → **git control plane** (PII-free, reviewed, versioned, signed) | Compliance *instance* → **data plane** (Event Log + Postgres; erasable-or-held) |
   |---|---|
   | Incident taxonomy + clock-arming table (§2.2) | An actual incident record (t0, affected-principal count, filings) |
   | CERT-In / DPDP / RBI report **templates** (§2.4) | A **filled** report draft + the filing acknowledgment |
   | RBI outsourcing register **entries** (provider, permitted-class, sub-processors, exit-plan ref) (§3) | Per-turn routing decisions + concentration metrics computed over them |
   | DPIA **form** + a completed DPIA **assessment** (data classes + purposes, no data) (§4.1) | — |
   | Model-Risk records (§4.2) | The live eval scores that back them |
   | Retention-policy table + legal-hold **scope rules** (§6.2) | Legal-hold **matters** (custodian, date range, the record-sets held) |
   | BSA §63 certificate **template** (§7) | A **signed** certificate for a specific export |
   | PCI scoping decision + connected-systems list (§5) | The write-path redaction events + store-sweep results |
   | CODEOWNERS (DPO / security-council / board-delegate as authoring-RBAC) | Auditor sessions + every auditor query |

   The reason this split is load-bearing and not cosmetic: **a policy must be reviewed, diffed, versioned, rolled back, and must never be erased — that is git.** **An instance contains PII, must be erasable-on-request (except under hold), and is written thousands of times — that is a store.** Putting a legal-hold *matter* (which names a data principal) in git would make it un-erasable (a DPDP violation); putting the retention *policy* in a mutable DB would let one actor silently change the org's retention posture without review. The split assigns each artifact to the store whose defining property is *correct* for it.

3. **The compliance gate is never routed around, and is hardened against being the attack surface.** The gate (ADR-003 / `compliance_engine`) already runs on all input and output. This doc makes it *also* the write-path sink-guard (§5), the incident-detection source (§2.1), and the DSAR-lineage anchor (§4.4) — which makes it even more load-bearing, so it inherits the Pass-5 gap [20] hardening from `TOOLING_MCP_PLUGINS_ROUTING.md`: **size-caps + RE2-class linear-time matching on all detectors**, so making the gate more central does not reopen an algorithmic-complexity DoS on the one un-skippable component.

### 1.3 The three redaction regimes (reconciling the corpus rules, stated once)

The corpus carries three rules that appear to conflict about redaction; this doc holds all three because they apply to *different sinks*:

| Sink | Rule | Source | Applied in |
|---|---|---|---|
| **User-facing content** | REDACT and PROCEED — never hard-block the user | `feedback_redact_dont_block.md` | the runtime I/O gate (unchanged) |
| **Durable data-plane store** (Event Log, memory, vectors, traces, exports) | REDACT/tokenize **before the write** so the store is structurally CHD/PII-light | this doc §5, §6.6 | write-path sink-guard |
| **A definition entering git** | **BLOCK** at commit-entry (redacting a definition would corrupt it) | ADR-026 §10 | pre-receive compliance gate |
| **Code** (a PAN pattern inside source) | **flag as a SAST finding**, never redact (would corrupt syntax) | `feedback_doc_build_audit_not_block.md`, `CODE_REVIEW_PIPELINE.md` §5 | code-review pipeline |

There is no contradiction: block a definition (it never needs PII), flag code (redaction corrupts it), redact user output (never abandon the user), and redact-before-persist for durable stores (so PCI/DPDP hold structurally). The *same detector set* drives all four; only the *action* differs by sink, and the action is a property of the sink, declared once.

### 1.4 Consequences

**Positive:** compliance becomes examinable by a regulator as a live system, not a claim; every obligation has a test; the git-native split makes policies portable/air-gap-safe (they are PII-free) while instances stay in-zone. **Negative/cost:** requires Legal/DPO to become CODEOWNERS and author policy through PR review (a UX obligation on the Studio, inherited from ADR-026); the DPDP Rules' exact clock values are still settling, so clocks are config-driven (§2.3) and must be re-pinned when the Rules finalize. **Neutral:** none of this removes an existing mechanism; it wires them.

---

## 2. Statutory AI-Incident Breach-Notification Engine (gap [3])

**Target:** from the instant the runtime *notices* a reportable event, a durable statutory clock is running, an accountable owner is paged, a filled report draft exists within minutes, and it is **structurally impossible to miss a deadline silently.**

### 2.1 Detection — where an incident candidate comes from

An `IncidentCandidate` is raised by any of these typed sources, each already present in the runtime:

- **The compliance gate** — a regulated class (PAN/AADHAAR/ACCOUNT_NUMBER/SECRET/…) that *egressed* where policy says it must not (e.g., reached a cloud-model prompt against the data-class exclusion, or left via a connector past the egress DLP, `TOOLING` §1.7). This is the AI-specific breach class no generic IR plan has.
- **The write-path sink-guard** (§5) — CHD detected reaching a durable store (a redaction that *should not have been needed* is itself a signal).
- **The quality circuit-breaker** (Pass-5 gap [23]) — a live judge-score collapse on a regulated route (a degraded model on payment queries is a reportable operational-risk event under RBI).
- **The Side-Effect Ledger / payment boundary** (ADR-013/016) — an anomalous or attempted settlement-class action.
- **Serving-Ops** (ADR-020) — a material service disruption of a critical route (RBI reportable).
- **The store-sweep + NTP-skew monitor** (§5.4, §8.2) — defense-in-depth detectors.
- **An operator declaration** or **an inbound CERT-In/RBI advisory** — a human-raised candidate.

Every candidate is written to the Event Log with a **`t0` = time of first notice** (the legally operative instant) — a hash-chained event, NTP-sourced (§8.2), so t0 itself is later admissible (§7).

### 2.2 The agentic incident taxonomy — model classifies, policy arms

The taxonomy is a **control-plane definition (git, Q2)**: a versioned decision tree mapping an incident class to *which statutory clocks fire and which templates apply*. A **triage Role** (a governed AiNxt Role) reads the candidate + Event-Log context and **proposes** a classification; but the **clock-arming decision is a deterministic function of the classified class**, not model judgment — the model does the messy natural-language classification; a policy table (not the model) decides "this class ⇒ arm CERT-In + DPDP." This keeps a sycophantic or confused model from *disarming* a clock.

The arming policy is **fail-safe (arm early, disarm only on authenticated human confirmation):** the moment a candidate is *plausibly* reportable, the relevant clocks are **provisionally armed**. Downgrading a provisionally-armed clock to "not reportable" requires an authenticated, reason-coded action by an accountable owner (DPO/CISO) and is itself a logged event — you can never *drift* into a missed deadline, only *decide, on the record,* that a clock does not apply.

Illustrative class → clock mapping (the actual table is the git artifact, Legal/DPO-owned):

| Classified incident class | CERT-In 6h | DPDP breach clock | RBI outsourcing/ops clock | Payment-boundary escalation (ADR-016) |
|---|---|---|---|---|
| Confirmed personal-data breach (data-principal PII exposed) | if also a cyber incident | ✅ | if via an outsourced route | — |
| Cyber security incident (per CERT-In categories: unauthorized access, data breach, etc.) | ✅ | if PII involved | if outsourced infra | — |
| Material outsourced-service disruption / provider failure | if cyber-caused | — | ✅ | — |
| Attempted/actual agent-initiated settlement action | ✅ (if unauthorized access) | if PII | ✅ | ✅ hard-class review |
| Quality-degradation on a regulated route (no data exposure) | — | — | ✅ operational-risk log | — |

### 2.3 The Statutory Clock — an SLO with a durable countdown

A clock is **not a cron reminder** — it is a durable object on the Event Log with:

- **`t0`** (immutable, NTP-sourced) and a **`budget`** (config-driven, per-statute). Defaults, tunable: **CERT-In = 6h** (from the 2022 Directions under IT Act §70B); **DPDP-to-data-principal = "without undue delay"** rendered as a config target; **DPDP-detailed-report-to-Board = 72h** (per the DPDP Rules; config, re-pinned when the Rules finalize); **RBI = per contract/direction**. Every clock value is a config field, never a constant, because the DPDP Rules timelines are still settling as of this design — a regulator changing "72h" must be a config change, not a code change.
- **A countdown + escalation ladder**: paging at **50 / 75 / 90 %** of budget to the incident owner → DPO → CISO → board-delegate. Escalation targets are the CODEOWNERS groups (Q2).
- **Durability across a crash — the crucial property.** The clock state lives on the Event Log, not in a process. A runtime restart *re-projects the running clocks and continues the countdown from the real elapsed wall-clock* — because **an incident during an outage is exactly when you cannot afford to lose the timer.** A clock is never reset by a restart.
- **No silent pause.** "Pausing" a clock (suppressing paging) requires an authenticated reason-coded action and **does not stop the wall-clock or move t0** — the record always shows true elapsed time. There is no operation that rewinds t0.

**Enforcement teeth:** a clock that crosses its statutory budget **without a recorded filing** automatically raises a **P1 compliance meta-incident** (a "we may have missed a statutory deadline" incident), which itself is logged and escalated to the board-delegate. Missing a deadline is therefore *itself* a first-class, un-hideable event — the system cannot fail quietly.

### 2.4 Pre-templated report generation — spend the 6 hours on judgment, not data-gathering

The report **templates** (CERT-In incident-report format, DPDP breach-notification to the Board and the separate notice to affected data principals, RBI incident report) are **control-plane definitions in git (Q2)** — PII-free forms, versioned, owned by Legal/DPO via CODEOWNERS. A **drafting Role** fills the template *from the incident register's structured facts + the Event-Log evidence slice*, producing a **draft within minutes** of t0. The draft is never auto-filed — the DPO/CISO reviews and files (the filing is the legal act; automating it would be reckless). The point is that the human's 6-hour budget is spent on *judgment and verification*, not on assembling facts under time pressure.

Because the template is git-versioned, "which version of the CERT-In form did we file against on that date" is answerable by the control-plane commit SHA (ADR-026 §6) — itself an evidentiary particular (§7).

### 2.5 The Incident Register

The **operational** record (data-plane): one record per incident — `{id, t0, class, clocks_armed[], affected_data_classes[], affected_principal_estimate, systems_involved, control_plane_sha, actions[], filings[](template_version, submitted_at, ack_ref), status}`. It is **append-only + hash-chained** (evidentiary; ties to §7) and **subject to legal-hold** — an incident record is never erasable while its matter is open or under a retention floor (§6). It projects the live dashboard (§9).

### 2.6 Acceptance tests

1. Inject a synthetic PAN-egress to a cloud route → the gate raises a candidate; triage classifies "personal-data breach + cyber"; the policy table arms CERT-In(6h)+DPDP; t0 is a hash-chained NTP event; a draft CERT-In report exists < N minutes.
2. Advance wall-clock to 90% of the CERT-In budget with no filing → paging escalates owner→DPO→CISO; at breach, a P1 meta-incident is raised automatically.
3. `kill -9` the runtime at 3h into a 6h clock → on restart the clock re-projects and shows ~3h elapsed continuing to count; t0 unchanged.
4. A provisionally-armed clock is downgraded → requires an authenticated reason-coded action, logged; a *drift* to "not reportable" without that action is impossible.
5. Two years later, reconstruct the incident package by id → t0, class, template version (by control-plane SHA), evidence slice, and filing acks are all recoverable and hash-verify (§7).

---

## 3. RBI IT / Cloud-Outsourcing Governance & Register (gap [11])

**The reframe with teeth:** RBI's Master Direction on Outsourcing of IT Services treats **every call that ships context to an external provider as IT outsourcing** — every cloud LLM route (Claude/GPT/Gemini), every external connector (Jira Atlassian Cloud, M365/Graph), every remote MCP server, any externally-hosted embedding/rerank. A spreadsheet register is inert. **Here the register is the router's eligibility input**, so governance is not describable-after-the-fact — it is a precondition of a route being selectable at all.

### 3.1 The Outsourcing Register — a control-plane definition (Q2)

One git file per outsourcing arrangement (`outsourcing/<provider-route>/definition.md`), front-matter schema (CI- and loader-validated, per ADR-026 §5):

```yaml
kind: outsourcing-arrangement
id: outsourcing.cloud.<provider>.<route>
provider_legal_entity: "<name, jurisdiction>"
contract_ref: "<CLM id>"                 # board-approved outsourcing contract
board_approval_ref: "<minute/resolution id>"   # RBI: board-approved outsourcing policy
permitted_data_class: internal           # MAX class this route may ever carry → feeds ADR-012
data_residency: "<region>"               # e.g. in-country inference zone / provider region
sub_processors:                          # declared chain (RBI chain-outsourcing control)
  - { name: "<sub>", jurisdiction: "<x>", pinned_list_hash: "<sha256>" }
right_to_audit_clause: "<contract §>"    # RBI + RE auditors' right to audit
exit_plan_ref: program.exit.<provider>   # §3.4 — a rehearsable Program (Q1), not a doc
concentration_tag: "<capability-group>"  # for §3.5 concentration analysis
last_exit_rehearsal: "<date|never>"      # freshness; 'never'/stale ⇒ treated as no exit
```

CODEOWNERS for `/outsourcing/` = the outsourcing-governance group **+ board-delegate** — a new provider cannot be wired in without a reviewed, signed PR (authoring-RBAC per ADR-026 §8).

### 3.2 The register *is* the router's eligibility input — the enforcement teeth

The model router's **non-overridable data-class exclusion step** (ADR-012 / `TOOLING` §model-router) is modified to read the **register** as its authority: for each candidate external route, the router looks up the arrangement's `permitted_data_class`; **a route with no register entry, or whose `permitted_data_class` is below the request's data class, is excluded before ranking and before failover.** Consequences:

- **No ungoverned outsourcing can ever occur** — a cloud provider with no register file is invisible to the router. Wiring a new provider without a PR is not "a policy violation caught later"; it *cannot route*.
- **Data-residency is enforced at selection** — a route whose `data_residency` violates the request's residency label (RBI payment-data-localisation) is excluded, same mechanism.
- This unifies with the existing "regulated data never reaches an ineligible model" invariant — the register simply becomes *where eligibility is declared and governed*.

### 3.3 Right-to-audit + sub-processor supply chain

- **Right-to-audit** is a first-class field; the auditor mode (§8) can enumerate every arrangement and its audit clause, and export the routing evidence for any period.
- **Sub-processor chain** is pinned by hash (`pinned_list_hash`) — the exact **TOFU hash-pin + diff-and-re-approve** discipline the platform already uses for MCP/plugin supply chain (`TOOLING` §2, ADR-026 §11). A provider changing its published sub-processor list is a **diff the register PR must adopt and re-approve**; until re-approved, the arrangement can be auto-restricted to a lower `permitted_data_class` (fail-safe). A silent sub-processor change (RBI's chain-outsourcing risk) is thus caught, not trusted.

### 3.4 Tested exit plan — a rehearsable Long-Horizon Program (Q1/ADR-027)

RBI requires a *documented and tested* exit strategy. A document is not an exit; **the exit plan is a Long-Horizon Program spec (git control-plane)** that, when executed, re-routes all traffic of the arrangement's data-class onto an in-house/alternative *eligible* route and verifies the fallback:

- **Periodic exit-rehearsal** runs the Program in **shadow** (no prod cutover): it stands up the fallback route, replays representative traffic, and uses the **shadow-differential oracle** (`AGENT_TESTER.md` §6/§8) to prove the fallback meets the quality/SLO bar. It produces a rehearsal report + a fresh `last_exit_rehearsal` date.
- **An untested exit plan is treated as no exit plan** — a `last_exit_rehearsal` that is `never` or older than the configured cadence flags the arrangement `exit_untested` → a §3.5 concentration/governance finding to the board-delegate.
- Because it is a Program (Q1), a *real* forced exit (provider outage, contract termination, a sovereignty veto) survives restarts, checkpoints progress, and can **ship partial cutover** as a first-class outcome rather than an all-or-nothing scramble.

### 3.5 Concentration risk

The register is queryable: "what fraction of regulated-payment-class traffic depends on a single provider / single region / single sub-processor / an `exit_untested` arrangement." A threshold breach raises a governance finding to the board-delegate (RBI concentration-risk duty). The metric is a data-plane projection computed over the git register + live routing events — one source, no separate spreadsheet.

### 3.6 Acceptance tests

1. A cloud route with no register file → the router **excludes** it for every request (never selected), proving "no ungoverned outsourcing."
2. A route whose `permitted_data_class: internal` is asked to carry `regulated-payment` → excluded before ranking; the request routes to an eligible in-house model or is refused with a data-class reason.
3. A request labelled residency=in-country against a route whose `data_residency` is foreign → excluded (localisation enforced).
4. A provider publishes a new sub-processor → the pinned-hash check fails at load / register-diff; the arrangement is auto-restricted until a re-approving PR lands.
5. Exit rehearsal executes as a shadow Program → produces a quality-delta report vs the primary and a fresh `last_exit_rehearsal`; a stale rehearsal flags `exit_untested` and escalates.
6. Concentration threshold breached → board-delegate finding raised, with the exact dependent-traffic fraction.

---

## 4. DPDP Significant-Data-Fiduciary Duties (gap [12], with [P])

NPCI operating at scale is an SDF-class fiduciary; DPDP §10 layers extra duties: DPO in India, an independent data auditor, periodic DPIA, periodic audit, and **algorithmic due diligence**. Each becomes a runtime mechanism.

### 4.1 DPIA-per-feature — a CI gate on promotion (Q2)

A DPIA is not a form filed once; it is a **precondition of a personal-data feature reaching production**, enforced in the control repo's CI (ADR-026):

- A DPIA is a control-plane definition (`dpia/<feature>/definition.md`) — PII-free (it describes *data classes*, *purposes*, *lawful basis*, *risks*, *mitigations*, not actual data), reviewed by the **DPO CODEOWNERS group**, versioned.
- **The gate:** any definition (Role/agent/skill/workflow) whose `data_class_ceiling` reaches personal data, or whose `capabilities` touch a personal-data connector, **must reference a `dpia:` artifact whose status is `approved` for the current feature version.** No reference, or a DPIA whose approval predates a material data-processing change → **CI blocks the merge; the promotion job blocks `env/prod`.** This reuses the ADR-026 promotion machinery exactly — a DPIA is just another required, owned, versioned dependency.
- **Diff invalidates approval:** a change to the feature's `data_class_ceiling`, `capabilities`, or declared purpose **invalidates** the referenced DPIA (a content-hash mismatch, same discipline as the marketplace diff-and-re-approve) and forces a re-assessment before re-promotion. A feature cannot silently expand its data processing beyond what the DPO assessed.

### 4.2 Algorithmic due diligence + Model-Risk [P]

DPDP §10's "verify that algorithmic software does not pose a risk to the rights of data principals" is met by a **Model-Risk Record** per model route / per Role (control-plane): provenance (in-house vs cloud; OSS weights origin, feeding the sovereignty gate ADR-006-ext), permitted data-class, evaluation results (quality/fairness/bias where applicable), known limitations. Before an SDF-relevant feature promotes, an **algorithmic due-diligence checklist** (control-plane, DPO-reviewed) must be satisfied, and the **eval platform's continuous quality scoreboard** (the corpus keystone) provides the live "does not pose a risk to rights" evidence. This is where gap [P] model-risk plugs in: the model-risk register is control-plane; the scores backing it are data-plane. A route whose scoreboard drops below the due-diligence bar triggers the quality circuit-breaker (§2.1) — model-risk is *monitored*, not certified-once.

### 4.3 India DPO + independent auditor as first-class principals

The **India-resident DPO** and the **empanelled independent data auditor** are runtime principals with the read-only **auditor evidence-access mode** (§8): they query the incident register, outsourcing register, DPIA coverage, DSAR fulfillment, retention/hold ledger, and scoped Event-Log slices **without an engineer in the loop** — self-service supervisory access is itself a duty. The DPO is a named CODEOWNERS accountable owner for the compliance control-plane paths (Q2), so "who owns the compliance policy" is answerable and non-orphaned (closes the succession decay class, Pass-5 gap [28], for compliance artifacts).

### 4.4 DSAR workflow — access / correction / erasure / grievance / nomination

A **governed Role** (data-plane operation) with an **SLA clock** (the §2.3 clock machinery, config budget per the DPDP response window):

1. **Authenticate** the data principal (no self-service data leak — identity proofing gates every DSAR).
2. **Resolve all their data across every tier** via the data-lineage/provenance already mandated (`ENTERPRISE_MEMORY_LEARNING.md` §5, §7): Redis session, Postgres episodic, KG `MemoryFact` nodes, derived embeddings, traces, incident/DSAR registers. Lineage is what makes "find *everything* about this person" complete rather than best-effort.
3. **Fulfill:** *access/portability* → a machine-readable export via the evidentiary path (§7); *correction* → a governed write; *erasure* → the cascade **through the legal-hold check (§6)**; *grievance* → routed to the DPO with an SLA.
4. **Log** every DSAR in a hash-chained DSAR register (data-plane) — fulfillment is *provable*, which the auditor mode (§8) can demonstrate.

### 4.5 Acceptance tests

1. A Role gains a personal-data connector with no approved DPIA → CI blocks the merge; the promotion job refuses `env/prod`.
2. An approved DPIA'd feature changes its `data_class_ceiling` → the DPIA is invalidated (hash mismatch); re-promotion is blocked until re-assessed.
3. A model route's scoreboard drops below the due-diligence bar → circuit-breaker fires; the route is contained; a §2 operational-risk incident is raised.
4. The DPO logs into auditor mode and pulls DPIA coverage + DSAR SLA compliance with **no engineer** involved; the session is read-only and every query is chain-logged.
5. A DSAR access request returns a complete cross-tier export within the SLA window; a post-export lineage query confirms nothing about the principal was missed.
6. A DSAR erasure against records under legal-hold → deferred-with-record per §6, not deleted; the principal receives the "honored to the extent legally permissible" notice; the deferral is logged.

---

## 5. PCI-DSS Scoping & CDE Segmentation (gap [10])

**The decision (control-plane, documented): the AiNxt runtime is architected *out of* the Cardholder Data Environment.** The Rust sidecar and the Python gateway must not, by their mere presence, pull the whole runtime into "stores/processes/transmits CHD" scope. The scoping boundary and connected-systems list are a control-plane artifact, refreshed on the PCI annual cadence.

### 5.1 No-CDE-persistence guarantee — the load-bearing mechanism

**The runtime never persists cardholder data (PAN/CVV/SAD).** Enforcement: a **write-path CHD sink-guard** sits before every durable sink — Event Log, memory, vector index, traces, DSAR exports, incident register. The compliance engine's deterministic PAN detector (regex + **Luhn validation** + entropy) and SAD patterns run on the write path; a detected PAN/SAD is **redacted/tokenized to a non-reversible placeholder before the bytes land** (the durable-store regime of §1.3 — redact-before-persist, distinct from user-facing redact-and-proceed and from git block-at-entry). Because CHD is redacted before every durable write, **the durable stores are structurally CHD-free → they fall out of the "stores CHD" PCI scope by construction**, not by audit luck.

This mirrors ADR-026 §10's "PII cannot enter git," applied to the data plane's durable sinks: the *entry point* is gated, so the store's defining property (CHD-free) holds mechanically.

### 5.2 Segmentation

The runtime runs in its **own network segment**; the only path toward the CDE is via **governed connectors through the egress boundary** (LLM-proxy/web02 in prod) — there is **no ambient network route** from the runtime into the CDE. Segmentation is validated on the PCI segmentation-penetration-test cadence (a control-plane-tracked freshness date, like §3.4's rehearsal freshness). The Rust sidecar's deployment (ADR-001 strangler-fig) is placed so it shares the runtime's segment, not the CDE's.

### 5.3 CHD-in-code is a SAST finding, not a redaction

If model-generated or human code contains a PAN pattern, the code-review pipeline's SAST stage (`CODE_REVIEW_PIPELINE.md` §5) flags it as a hard finding — **never** redacts it (redaction corrupts syntax, per `feedback_doc_build_audit_not_block.md`). This is the "code" regime of §1.3.

### 5.4 Defense-in-depth: the store sweep

A periodic scanner sweeps every durable store for any CHD pattern (proving the write-path redaction held). **Any hit is a §2 incident** (a CHD-in-store finding means the sink-guard was bypassed — a reportable control failure), and the offending record is quarantined + remediated. This turns "we believe the stores are clean" into "we continuously prove it, and a miss auto-raises a breach clock."

### 5.5 Acceptance tests

1. A chat message containing a Luhn-valid PAN → the PAN is redacted/tokenized **before** it reaches the Event Log, memory, vector index, and any trace; a post-write scan of all four returns **zero** CHD.
2. The runtime network segment has **no route** into the CDE except the governed connector path (validated by segmentation test); an attempted direct connection is denied and logged.
3. A PAN pattern in generated code → SAST hard-finding, code blocked; the PAN is *not* silently redacted inside the source.
4. The store-sweep injects a synthetic PAN into a durable store out-of-band → the sweep detects it, quarantines the record, and raises a §2 CERT-In+DPDP incident.

---

## 6. Statutory-Retention vs Erasure + Legal-Hold Override (gaps [13], [Q])

The tension is three-way: **DPDP right-to-erasure** (the cascade, `ENTERPRISE_MEMORY_LEARNING.md` §5) vs **statutory retention floors** (RBI record retention, PMLA multi-year retention, CERT-In 180-day logs) vs **legal-hold** (a litigation/investigation preservation obligation that overrides erasure). A naive erasure cascade either violates a retention floor (erasing what RBI/PMLA requires kept) or violates a legal-hold (spoliation) or violates DPDP (retaining what must go). The design resolves this with a **deterministic precedence function applied at the head of the cascade.**

### 6.1 The precedence rule (deterministic, not model-judged)

On any erasure trigger (DSAR erasure, account offboarding, TTL expiry), the cascade's **first step** is a Retention/Hold decision function evaluated per target record:

1. **Legal-hold (highest precedence).** If a record falls within an **active legal-hold matter's scope**, it is **preserved, not erased**. The erasure is *deferred and recorded*: an auditable "honored to the extent legally permissible; records within matter #X retained until release" entry. A "forget everything" **cannot** delete held records. Legal-hold is explicit, authorized, reason-coded — it never silently swallows an erasure; it produces a legible deferral.
2. **Statutory-retention floor.** A record within a statutory minimum-retention window (RBI/PMLA/CERT-In durations, from the retention-policy table) is **retained until the floor elapses**, and the erasure request is **queued to fire at floor-expiry** — dropped from neither the record nor the person's request.
3. **Otherwise → erase now** (the existing cascade runs unchanged: Redis immediate, Postgres episodic, KG `MemoryFact`, derived embeddings re-indexed to exclude, fine-tune lineage flagged — all per `ENTERPRISE_MEMORY_LEARNING.md` §5).

Precedence is **deterministic** — no model adjudicates whether to keep regulated data. The model may *classify* a record; the *keep/erase/defer* decision is a policy-table function.

### 6.2 Where the policy vs the instance live (Q2 — the exact split)

- **Control-plane (git):** the retention-policy table (per class × tier durations) and the legal-hold **scope rules** (the predicate that defines what a matter *covers* — e.g., "all records touching account X between dates D1–D2"). These are PII-free rules, reviewed by Legal/DPO CODEOWNERS, versioned.
- **Data-plane (Event Log + Postgres):** the legal-hold **matters** themselves — matter #X's custodian, its date range, the concrete record-sets it currently holds. A matter names data principals and specific records → it is PII-bearing → it **must not** go in git (git can't erase; a matter must be closeable). This is the §1.2 split at its sharpest: **the *rule* is git, the *matter* is data-plane.**

### 6.3 Applying the override at the cascade — mechanically

The erasure job (`ENTERPRISE_MEMORY_LEARNING.md` §5) is modified so its **first operation** is the §6.1 decision function; a held record is **skipped-with-record**, never deleted. When a matter is **released** (an authorized, reason-coded action), the **deferred-erasure queue** fires for the now-unheld records (and for records whose retention floor has since elapsed). Erasure remains **provable** (a signed Event-Log entry per the existing design) — and now **retention and deferral are equally provable**, which is what an auditor asking "why is this person's data still here?" needs.

### 6.4 Reconciling "retain the log" with "erase the person" — retain the record, minimize the PII

The CERT-In **180-day log-retention floor (§8.1)** cannot be overridden by a DPDP erasure — you may not take a security log below 180 days. This *appears* to conflict with erasure. It is reconciled by the write-path PII-minimization (§1.3, §5.1): **security/audit logs are PII-light at write** (PAN/PII redacted before persistence), so erasing a person's PII does not require destroying the (already-minimized) evidentiary record. **Erasure erases the PII payload; retention keeps the redacted record.** The two obligations stop competing because the retained artifact never held the erasable PII in the first place.

### 6.5 Break-glass, if PII/CHD ever slips a floor or a hold boundary (Q1)

If a detector miss lands erasable PII inside a record under a retention floor or a hold (a rare, honest residual), remediation is a **controlled program** — a scoped, authorized redaction of just the PII payload while preserving the record's evidentiary hash-chain (a redaction-with-attestation, logged), or, for git (ADR-026 §10), the history-rewrite + rotation incident. Because such a remediation can span systems and time, it runs as a **Long-Horizon Program (Q1)** with checkpoints and partial-completion, not a one-shot script.

### 6.6 Acceptance tests

1. A DSAR erasure against records within an active legal-hold matter → those records are **deferred-with-record**, not deleted; the "forget everything" also cannot touch them; the deferral is a signed event.
2. Releasing the matter → the deferred-erasure queue fires for the now-unheld records; a post-run query shows them gone; a signed erasure event exists.
3. An erasure against records within the RBI/PMLA floor → queued to fire at floor-expiry, not now; at expiry it fires automatically.
4. An attempt to erase a security log below the 180-day floor → refused; the log stays; but the *person's PII within it* was already redacted at write, so the erasure of their PII is still complete.
5. Every keep/erase/defer decision is a hash-chained Event-Log entry → an auditor can prove, for any record, why it was kept, erased, or deferred.

---

## 7. ADR-025 — Evidentiary Admissibility (gap [33])

**Status:** Accepted (embedded ADR). **Decision class:** Go-live-blocking for any evidentiary use. **Extends:** ADR-007 (hash-chained Event Log).

### 7.1 Context — tamper-evident ≠ court-admissible

The Event Log is hash-chained (ADR-007) — that proves *integrity*. But under Indian law, for an electronic record to be **admitted as evidence**, integrity is necessary and **not sufficient**: the **Bharatiya Sakshya Adhiniyam 2023 (BSA)** — which replaced the Indian Evidence Act 1872, in force from **1 July 2024** — requires, at **§63** (the successor to the old §65B), a **certificate** accompanying the electronic record. The certificate must (a) identify the electronic record and describe the **manner of its production**, (b) give **particulars of the device/system** that produced it, and (c) be **signed** by the person in charge of the system **and** an expert. A perfect hash-chain with no §63 certificate can still be ruled inadmissible.

### 7.2 Decision — an Evidentiary Export capability that produces the certificate

The runtime provides an **Evidentiary Export** for any specified record-set (a turn, an incident, a program run, a DSAR fulfillment, an outsourcing/routing decision, a retention/hold decision). It produces a package of three parts:

1. **The record-set** — the hash-chained Event-Log slice + referenced evidence blobs by content-hash (the bytes, plus their chain position and the chain root).
2. **A chain-of-custody manifest** — every hop the evidence took: who accessed it, who exported it, when (from the auditor-access mode §8, which is itself logged). The custody chain is unbroken because *every access is a hash-chained event*.
3. **A BSA §63-shaped electronic-record certificate** — auto-populated with every **machine-knowable particular**: the runtime version, the **control-plane commit SHA that was live** (Q2/ADR-026 — "which definitions produced this record"), the hash-chain root and the per-record hashes, the **NTP-synced timestamps and their NIC/NPL source + last-sync offset** (§8.2), and the production method. The certificate is presented as a **draft with all particulars filled, for signature** by the designated person-in-charge and the designated expert — **the human signatures are the legal act and are deliberately not automated**; everything a human would otherwise hand-transcribe (and get wrong under deadline) is machine-filled and machine-verifiable.

The certificate **template** is a control-plane definition (git, Legal-reviewed via CODEOWNERS, Q2) so its legal form is versioned and its evolution auditable — "which certificate form did we use on that date" is a control-plane SHA.

### 7.3 Integrity verification is part of the certificate

The export re-verifies the hash-chain end-to-end; the certificate carries the verification result. **Tampering with any exported blob breaks its content-hash → the certificate's integrity attestation fails verification.** So the certificate is not a paper assertion — it is a machine-checkable claim whose failure is detectable by anyone who re-runs the verification against the chain root.

### 7.4 Consequences / residual

**Positive:** the runtime's records become *admissible*, not merely tamper-evident; the two-year-later reconstruction (ADR-026 test 17) now yields a *court-usable* package. **Residual:** the certificate's legal sufficiency is ultimately a matter for counsel and evolving case law under the BSA — the design fills every technical particular and versions the form, but cannot itself guarantee a court's acceptance; that is why the human signature (person-in-charge + expert) remains in the loop and the template is Legal-owned.

### 7.5 Acceptance tests

1. Evidentiary export of a specific incident → produces a §63-shaped certificate with runtime version, control-plane SHA, chain root + record hashes, and NTP source **auto-filled and correct**; only the two human signatures are blank.
2. Tamper with one exported blob → its content-hash mismatches; the certificate's integrity attestation **fails** on re-verification.
3. The chain-of-custody manifest lists **every** access to the record-set (including the auditor's own pull) with actor + timestamp.
4. A two-year-later export of a turn reconstructs the full admissible package (record + custody + certificate) with no gaps, and the certificate's particulars match the historical control-plane SHA that was live.

---

## 8. Supervisory Audit-Readiness (gap [34])

**Target:** an RBI examiner, the empanelled DPDP independent auditor, or CERT-In can be given **self-service, read-only, chain-of-custody-backed** access to exactly the evidence in scope, with the statutory logging/timekeeping guarantees already met and provable.

### 8.1 India-resident 180-day logs (CERT-In)

All ICT logs are retained for a **rolling ≥180 days** (a retention *floor*, §6.4 — not overridable by erasure) and stored **within Indian jurisdiction**. Enforcement: every log store carries a **data-residency label**; a residency verifier asserts no log store resolves outside India (a failure is a §2 incident). The 180-day floor is encoded in the retention-policy table (control-plane, Q2).

### 8.2 NTP to NIC / NPL (CERT-In) + clock-skew (Pass-5 gap [32])

All runtime clocks synchronize to **NIC or NPL** NTP servers (or servers traceable to them), per the CERT-In Directions. Enforcement:

- The timestamp source is a configured NIC/NPL NTP pool; **every evidentiary timestamp records its NTP source and last-sync offset** (feeding the §7 certificate's particulars — a timestamp's provenance becomes provable).
- **Clock-skew monitoring** alarms on drift beyond a threshold. Skew is doubly dangerous — it can fire premature saga compensation → double-execution (Pass-5 gap [32], ADR-013) **and** it undermines evidentiary timestamps — so **skew beyond threshold is a §2 incident**, not a warning.

### 8.3 Auditor evidence-access mode — read-only by construction

A dedicated, RBAC-gated mode for empanelled auditors / RBI / the DPDP independent auditor / the DPO:

- **Exposes:** the incident register, the outsourcing register (+ concentration, exit-rehearsal freshness), DPIA coverage, DSAR fulfillment records, the retention/legal-hold ledger, PCI segmentation-test + store-sweep freshness, NTP-skew status, 180-day residency status, and scoped Event-Log slices — **all through the §7 evidentiary-export path**, so everything an auditor pulls arrives with a chain-of-custody manifest + a §63 certificate draft.
- **Read-only by construction:** the mode grants *no* capability that can mutate state (enforced by the Policy Engine, ADR-003 — the mode's capability set contains only reads). A mutation attempt is denied and logged.
- **Every auditor query is a hash-chained event** — the auditor's own access is part of the record (the custody chain), so "who looked at what, when" is itself admissible.
- **Clearance/scope filtering with existence-hiding:** an auditor sees only what their empanelment scope permits; the pre-rank existence-hiding filter (`CONTEXT_FABRIC.md` §3) applies, so out-of-scope records do not leak *even by their absence*.

### 8.4 Acceptance tests

1. Every log store resolves to an India region (residency verifier green); a deliberately mis-located store raises a §2 incident.
2. The NTP source is a NIC/NPL pool; injected skew beyond threshold fires a §2 incident and every evidentiary timestamp still records its source + offset.
3. An auditor session can pull the full evidence pack **self-service, no engineer**, and is **read-only** — a mutation attempt is denied and logged; every query is chain-logged and appears in the custody manifest.
4. An out-of-scope record is invisible to an auditor whose empanelment doesn't cover it — not even its existence leaks.

---

## 9. Composition — the Compliance Control Plane, one source each

Everything above composes into a single **Compliance Control Plane**, and its coherence is exactly the two binding decisions applied consistently:

- **Registers, taxonomies, templates, DPIA forms, retention/hold rules, the BSA certificate form, the PCI scoping decision, and CODEOWNERS = control-plane (git, Q2).** They are PII-free, reviewed, versioned, signed, rolled-back-by-pointer, and — because they are PII-free — **portable across the sovereignty/air-gap boundary** (ADR-026 §12): the compliance *policy* is safe to move; the compliance *instances* never leave the in-zone stores.
- **Clocks, incident/DSAR/hold ledgers, routing decisions, audit exports, and the dashboard = data-plane (Event Log + Postgres),** subject to retention/erasure/hold, hash-chained for admissibility.
- **Long-horizon obligations (Q1)** — tested exits, break-glass remediations, breach campaigns — are durable Programs with partial completion as a first-class outcome.

A single **dashboard** (data-plane projection off the Event Log + control-plane git — *no third source of truth*) shows the whole posture live: armed statutory clocks + countdowns, outsourcing concentration + exit-rehearsal freshness, DPIA coverage (features vs approved DPIAs), DSAR queue + SLA, legal-hold matters + deferred-erasure queue, retention-floor compliance, PCI segmentation-test + store-sweep freshness, NTP skew, and 180-day residency status. Because it is a projection, "prove the posture as of 90 days ago" is a replay to an offset, not a screenshot someone kept.

---

## 10. Consolidated acceptance / scenario tests

| # | Scenario | Expected | Proves (gap) |
|---|---|---|---|
| 1 | PAN egresses to a cloud route | candidate raised; classified breach+cyber; CERT-In(6h)+DPDP armed at NTP-sourced t0; draft report < N min | [3] detection→clock→draft |
| 2 | CERT-In clock reaches breach with no filing | P1 compliance **meta-incident** auto-raised; board-delegate paged | [3] no silent miss |
| 3 | `kill -9` mid-clock | clock re-projects, continues from real elapsed; t0 unchanged | [3] durable clock |
| 4 | Cloud route with no register entry | router **excludes** it for every request | [11] no ungoverned outsourcing |
| 5 | `permitted_data_class` below request class | excluded before ranking; routes to eligible in-house or refuses | [11] register = router eligibility |
| 6 | Provider changes sub-processors | pinned-hash check fails; route auto-restricted until re-approving PR | [11] chain-outsourcing supply chain |
| 7 | Exit rehearsal | runs as shadow Program; quality-delta report; fresh `last_exit_rehearsal`; stale ⇒ `exit_untested` escalation | [11]+Q1 tested exit |
| 8 | Personal-data feature, no approved DPIA | CI blocks merge; promotion refuses `env/prod` | [12] DPIA-per-feature gate |
| 9 | DPIA'd feature expands `data_class_ceiling` | DPIA invalidated (hash); re-promotion blocked | [12] diff invalidates approval |
| 10 | DPO/auditor pulls evidence | self-service, read-only, chain-logged; no engineer | [12][34] auditor mode |
| 11 | DSAR access request | complete cross-tier export within SLA; lineage confirms nothing missed | [12] DSAR |
| 12 | PAN in chat message | redacted/tokenized before Event Log/memory/vectors/traces; post-write scan = zero CHD | [10] no-CDE-persistence |
| 13 | Runtime→CDE network path | none except governed connector; direct attempt denied+logged | [10] segmentation |
| 14 | Store-sweep finds injected CHD | record quarantined; §2 incident raised | [10] defense-in-depth |
| 15 | Erasure vs active legal-hold | deferred-with-record, not deleted; "forget everything" can't touch it | [13] legal-hold override |
| 16 | Matter released | deferred-erasure queue fires; records gone; signed event | [13] deferral fires on release |
| 17 | Erasure within RBI/PMLA floor | queued to floor-expiry; fires automatically at expiry | [13][Q] retention floor |
| 18 | Erase security log below 180d | refused; but the person's PII in it was redacted at write | [13][34][Q] retain-record-minimize-PII |
| 19 | Evidentiary export of an incident | §63 certificate with version/control-plane-SHA/chain-root/NTP auto-filled; signatures blank | [33] admissibility |
| 20 | Tamper with exported blob | content-hash mismatch; certificate integrity attestation fails | [33] integrity is machine-checkable |
| 21 | Log-store residency | all India-region; mis-located store ⇒ §2 incident | [34] 180-day India-resident |
| 22 | NTP skew beyond threshold | §2 incident (double-exec + evidentiary risk); source+offset still recorded | [34]+[32] NIC/NPL NTP |
| 23 | Two-year-later reconstruction | full admissible package + correct historical control-plane SHA; no gaps | [33]+Q2 reproducibility |

---

## 11. Residual risks (honest, not deferred silently)

1. **Detector recall is the floor under everything.** The breach engine (§2), the no-CDE-persistence guarantee (§5), and the retain-record-minimize-PII reconciliation (§6.4) all assume the compliance classifier *catches* the PAN/PII. A miss can both fail to arm a clock and land CHD/PII in a store or a retained log. Mitigation is defense-in-depth (write-path guard + periodic store-sweep + break-glass Program) and treating classifier recall as a continuously-evaluated, top-priority component (the corpus's standing residual) — but the residual is real and named.
2. **DPDP Rules timelines are still settling.** The 72h/"without-undue-delay" values are config, not constants, precisely so a final Rule text is a config re-pin, not a code change — but until the Rules finalize, the exact clock budgets are provisional.
3. **BSA §63 sufficiency is ultimately a court's call.** The design fills every technical particular, versions the form, and keeps human signature in the loop — it cannot guarantee admissibility against evolving case law (§7.4). Counsel owns the template.
4. **Legal-hold correctness is only as good as a matter's scope predicate.** A too-narrow predicate could let a held record be erased; a too-broad one could over-retain and create its own DPDP exposure. The predicate is Legal-owned, reviewed, and versioned (Q2), but a wrong predicate is a wrong outcome — the mechanism enforces the rule faithfully, it cannot author the rule correctly for you.
5. **The register-as-eligibility teeth depend on the router honoring it with no side path.** If any code path could select an external route without consulting the register (a bug, a "quick" bypass), the "no ungoverned outsourcing" guarantee (§3.2) is silently false. This must be a design-review invariant and an acceptance test on every routing change — the same discipline the idempotency-key and OBO no-fallback rules already demand elsewhere.
6. **Auditor-mode scope filtering is a confidentiality surface.** A misconfigured empanelment scope could over-expose or (via existence-hiding failure) leak record existence. The read-only-by-construction and chain-logging properties bound the blast radius, but scope configuration is a reviewed control-plane artifact whose correctness must be tested per §8.4.
7. **Clock-skew and residency depend on infra the runtime doesn't fully own.** NIC/NPL NTP reachability and India-region storage are operational guarantees from the substrate (Serving-Ops/ADR-020, infra) — the runtime monitors and alarms (§8), but cannot itself provision the NTP source or the region; a substrate failure surfaces as a §2 incident rather than being prevented here.

---

## 12. Why this is a 10 — and self-score

**Every statutory obligation is a runtime object with a concrete, un-routable enforcement mechanism and an acceptance test that exercises exactly what a regulator will examine** — the house bar, applied to law instead of to code quality:

- The **breach engine** makes a missed deadline *structurally impossible to hide* (durable clock that survives a crash; breach-without-filing auto-raises a meta-incident) and spends the human's 6-hour budget on judgment, not data-gathering (git-templated draft in minutes).
- The **outsourcing register is the router's eligibility input**, so "every cloud call is governed IT outsourcing" is enforced by *selection*, not asserted after the fact — an ungoverned provider cannot route.
- **DPIA is a CI gate on promotion**, algorithmic due diligence is a scoreboard-backed checklist, DSAR is an SLA-clocked cross-tier lineage workflow, and the DPO/auditor are first-class read-only principals.
- The **no-CDE-persistence guarantee** is mechanical (redact-before-persist + prove-by-sweep), keeping the runtime out of PCI scope by construction.
- **Legal-hold overrides erasure by a deterministic precedence function** at the head of the cascade, and the retain-record/minimize-PII move dissolves the retention-vs-erasure conflict instead of picking a loser.
- **Admissibility** is an export capability that produces a BSA §63 certificate with every particular auto-filled and machine-verifiable, not a hope.
- **Audit-readiness** is self-service, read-only, chain-of-custody-backed, with 180-day India-resident logs and NIC/NPL NTP as monitored, incident-raising guarantees.
- The whole subsystem is coherent because it **applies the two binding decisions consistently**: **Q2** (policy=git control-plane, instance=data-plane) is the structural spine that makes every register portable/air-gap-safe and every instance erasable-or-held; **Q1** (long-horizon Programs) is how the tested exit, the break-glass, and the breach campaign survive weeks and ship partial.

**Design ceiling: 9.5 / 10.** Every claim has a mechanism and a test; the hardest constraints (retention-vs-erasure-vs-hold; tamper-evident-vs-admissible; model-agnostic-vs-outsourcing-governance) are met head-on rather than finessed. The missing half-point is honest and concentrated in two places the design *specifies* but cannot itself *prove* until built: **detector recall** is the floor under the breach engine, the no-CDE guarantee, and the retain-minimize reconciliation (residual 1), and the **no-side-path** guarantees (register-as-eligibility, read-only auditor mode) are enforcement surfaces a determined implementer could subvert (residuals 5, 6) — plus the genuinely external unknowns of unsettled DPDP Rule values (residual 2) and BSA judicial sufficiency (residual 3), which no design can close. **Build maturity: 0 / 10** — no code exists, consistent with the entire corpus. The ceiling is set correctly so implementation can only descend from a real 10-shaped, go-live-blocker-clearing target.
