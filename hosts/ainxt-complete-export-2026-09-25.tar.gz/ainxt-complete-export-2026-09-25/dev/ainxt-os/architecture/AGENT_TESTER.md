# AiNxt Adversarial Test Agent ("the Breaker")

**Status:** Design brainstorm (no code). Companion to `IMPLEMENTATION_PLAN.md` (test infra, Part A3) and `HARNESS_SDK.md`.
**One line:** an autonomous, adversarial, exploratory testing agent that launches a real product, forms hypotheses about how it could fail, drives it end-to-end, and *proves* failures with minimized, reproducible bug reports — thinking like the best tester in the world, not executing a fixed script.

**Two roles:**
1. **Product QA** — point it at any AiNxt product (or external app) and it finds edge cases, breaks it, and reports.
2. **The DoD engine** — it generates + runs the 1,000+-scenario matrices, shadow-mode parity checks, and regression suites the runtime's "done" depends on.

It is itself a **harness on the runtime** (dogfooding): same agent loop, tools, sandbox, governance.

---

## 1. What separates a real tester from a script runner

A script runner asserts known outputs on known inputs. A world-class tester:
- **Has an adversarial mindset** — asks "how do I break this?", not "does the happy path work?".
- **Explores** — forms hypotheses, observes, adapts (session-based exploratory testing), instead of following a fixed list.
- **Understands intent** — reads the spec/PRD/tickets and derives what *should* happen (the oracle), so it can catch *wrong* behavior, not just crashes.
- **Knows techniques** — boundary values, equivalence classes, combinatorial/pairwise, state-transition, negative testing, race conditions, resource exhaustion, i18n/unicode/RTL, security, accessibility.
- **Produces clean repros** — minimizes the failing case, captures exact steps, files a report a dev can act on.
- **Drives toward the unknown** — coverage/novelty-seeking; goes where it hasn't been.

The agent gets these from: an **adversarial persona + a rich toolset + layered oracles + a coverage/novelty drive**, with the LLM supplying creative hypotheses ("what if I upload a 10 MB RTL-unicode filename while a second session edits the same record?") and the tools making them real.

---

## 2. The crux: the Oracle Problem

"It didn't crash" ≠ "it's correct." **How the agent knows something is wrong is the hardest and most differentiating part.** Use *layered* oracles — a finding is stronger the more oracles agree:

| Oracle | How it decides "bug" | Example |
|---|---|---|
| **Crash/error** | exception, 5xx, panic, hang/timeout | doc-gen throws on empty spec |
| **Spec** | behavior contradicts requirements/PRD (RAG over the spec) | "generate this as pdf" ⇒ PDF of the instruction, not the prior answer |
| **Invariant** | a property that must ALWAYS hold is violated | compliance ever emits a PAN; RBAC returns out-of-scope data; balance goes negative |
| **Metamorphic** | a required relation between inputs/outputs breaks | ask same question twice ⇒ materially different answer; translate→back ⇒ meaning drift |
| **Differential** | new version ≠ reference (old version, or another impl) | shadow-mode: Rust output diverges from Python |
| **Visual** | a vision model judges the rendered UI "broken" | overlapping text, empty panel, cut-off diff |
| **Performance** | latency/memory/cost crosses a threshold | turn p95 > SLA; memory grows unbounded (the yoga/WASM class) |

Invariant + metamorphic + differential oracles are what let it find *silent* correctness bugs — the ones no assertion was written for. For a payment org, the **compliance/RBAC invariants are the highest-value oracles.**

---

## 3. Capabilities (tools the agent drives the world with)

- **App drivers (real, not mocked):** browser automation (Playwright/CDP), native computer-use, HTTP/API client (OpenAPI-aware), CLI driver (pty), DB inspector.
- **Observation:** screenshot + vision, DOM/accessibility tree, network capture, log tailing, OTel trace/metric reader, output diffing.
- **Fault injection / chaos:** kill process, drop/latency network, throttle CPU/mem, corrupt state, clock skew — **test-env only, gated**.
- **Input generation:** boundary/mutation/fuzz generators, combinatorial (pairwise) generator, unicode/RTL/emoji/huge-payload builders, **synthetic compliant test data** (test-range PANs that pass Luhn, fake but valid IFSC, etc.).
- **State & repro:** record/replay, snapshot, deterministic seeds, **delta-debugging minimizer** (shrink a failing case to its smallest form).
- **Reporting:** structured bug report + repro + auto-generated regression test.

---

## 4. How it runs — single loop, then a fleet

**Single exploration loop (per charter):**
```
read spec + API/UI model → build a test model (features, states, inputs, invariants, oracles)
loop (budget-bounded):
  pick a strategy (technique × target × oracle), biased to untested + high-risk areas
  drive the real app → observe all signals
  apply layered oracles
  anomaly?  → minimize repro (delta-debug) → verify it reproduces → file finding
  update coverage/novelty map → next hypothesis
```

**The fleet (multi-agent — maps to the workflow patterns):**
- **Diverse-lens explorers** fan out, each with a distinct adversarial lens: functional, **security** (injection/authz/SSRF), **compliance** (PII/PAN leakage), performance/soak, concurrency/races, i18n/a11y, chaos. Each is blind to the others (multi-modal sweep).
- **Adversarial verifier** re-runs each candidate finding to confirm it reproduces and isn't a flake or expected behavior — **kills false positives** (the thing that makes testers get ignored). Confidence + dedup.
- **Synthesizer** dedups, ranks by severity × confidence, writes the report + regression tests.
- **Loop-until-dry:** keep exploring until K rounds surface nothing new; log what was left uncovered (never silently claim "fully tested").

---

## 5. Enterprise guardrails (so the Breaker is safe)
- **Environment isolation:** runs against staging/sandbox; destructive/chaos actions are hard-gated to test envs with a kill-switch; never prod without explicit, bounded authorization.
- **Compliance:** uses only synthetic data; its own actions pass the compliance gate; real PII never generated.
- **Budget-bounded:** exploration runs under a token/cost ceiling (loop-until-budget); no runaway.
- **Low-noise:** verified findings only, deduped, severity-ranked — a report devs trust.
- **Auditable + reproducible:** deterministic seeds + full trace per finding.

---

## 6. Outputs (what "done" looks like)
1. **Ranked, verified findings** with severity × confidence.
2. **Minimized, deterministic repros** per finding.
3. **Auto-generated regression tests** added to the permanent matrix (a bug found once is tested forever).
4. **Coverage + gap report** (what was and wasn't exercised — honest).
5. For migrations: a **shadow-parity report** (Rust vs Python divergences).

---

## 7. Hard problems & how we handle them
- **Oracle problem** → layered oracles (§2); invariants/metamorphic/differential catch silent bugs.
- **Flakiness / non-determinism** → deterministic seeds, record/replay, verifier re-runs before filing.
- **Infinite input space** → risk-prioritized (payment/compliance/authz first), novelty-guided, past-failure clustering.
- **False positives** → adversarial verifier + spec oracle + confidence gating; noise is a first-class enemy.
- **Realism** → drive the *real* app (browser/computer-use/API/CLI) and read real signals (logs/traces/screenshots), never mocks.

---

## 8. Where it fits the plan
- **P0:** the scenario-matrix harness *is* this agent's substrate; the Breaker generates cases into it.
- **Every phase DoD:** the Breaker runs the phase matrix + shadow parity; a phase isn't done until it's clean.
- **P5:** shipped as a first-class **harness** in the Marketplace so any NPCI team can point it at their product.
- It tests the runtime itself — the ultimate dogfood.
