# AiNxt Runtime — Implementation Plan (Enterprise-Grade, Open Source)

**Status:** Plan of record (design only; no code committed yet). **Phase 0 progress (2026-07-18):** all P0 ADRs (001–015, 007, 016–028) now exist as standalone or embedded artifacts, and the Phase 0 keystones — the Protocol contract (`PROTOCOL.md`) and the eval-platform + scenario-harness keystone (`EVAL_PLATFORM.md` + `SCENARIO_MATRIX.md`) — are delivered as design docs. Design gates 3+4 are complete (incl. `CRATE_ARCHITECTURE.md`). The OSS scaffolding is present under `runtime/`, and the **first code is written + verified**: the **clearance-gate CI** (`.gitlab-ci.yml` + `ci/*.sh` + `deny.toml` + `gitleaks.toml` — ADR-028) and the **scenario-matrix runner** (`crates/ainxt-scenario`, `cargo test` green, gates proven to catch violations). The HUMAN Gate #0 legal sign-off + contract sign-off (license/entity/model-weights/liability + Protocol/config/capability seams) remain outstanding but are proceeding in parallel. **P1 increment 1 (runtime core vertical slice) is BUILT + VERIFIED** (per user direction to proceed assuming sign-offs clear): crates `ainxt-types` / `ainxt-protocol` / `ainxt-runtime` implement the full turn pipeline (authz → compliance-IN → data-class routing → provider event-enum → compliance-OUT → audit) with the mandatory gates as **required constructor args** and **non-overridable data-class routing**, wired to the `ainxt-scenario` DoD harness. **14 tests green, 0 warnings.** Next increment: async + real HTTP providers, network transport, and the conversation-intelligence layer (referent resolution) carrying Chat-done-right. See "Phase 0 delivery status" below.
**Scope:** The clean-room Rust runtime spine and its clients, delivered as an open-source project with its own license, deployed via strangler-fig alongside the existing Python platform.
**Non-negotiable:** Every deliverable is enterprise-grade and proven against a 1,000+-scenario matrix. No PoC, no boilerplate, no happy-path stubs. "Done" = the phase's scenario matrix passes, compliance + RBAC are enforced, and observability is live.

Companion docs: `ainxt_runtime_solution.md` (spec), `VENDOR_SYNTHESIS.md`, `RUNTIME_FEATURE_FLOWS.md`, `HARNESS_SDK.md`, `SUBSYSTEM_DEEP_DIVES.md`.

---

## Part A — Foundational principles (apply to every phase)

### A1. Configuration model — "config-first, safety-invariant"
Everything is declarative and configurable; a small set of safety gates are architecturally mandatory.

**Configurable (declarative, schema-validated, versioned, hot-reload where safe):**
models & providers, routing rules, capabilities/tools, skills, agents, connectors, surface profiles, context/retrieval strategy, autonomy levels, prompts, sandbox limits, budgets, rate limits, telemetry sinks.

**Config layering (deterministic merge, most-specific wins):**
`built-in defaults → deployment config → tenant/org config → surface profile → per-request overrides`

**Mandatory invariants — configurable *provider*, never configurable *off*:**
| Gate | You configure | You cannot |
|---|---|---|
| Compliance | which ruleset/engine (trait impl) | remove the gate from the pipeline |
| Authorization / RBAC | which provider (AD, Keycloak, default) | skip the authz check |
| Audit | sink/format | disable audit emission |

Enforced structurally: the turn pipeline takes these as required trait objects; there is **no build of the runtime without them**. Defaults ship in the OSS core; enterprises supply their own (NPCI → PCI/DSS engine + AD-RBAC plugins).

### A2. Open source & licensing
- **License:** **Apache-2.0** (recommendation): permissive + explicit patent grant (matters for an enterprise/payments context), matches the permissive projects we studied, widely trusted. (Overridable — MIT is the alternative; decision recorded in ADR-007.)
- **Core vs enterprise split:** the OSS core = the runtime, gates-as-traits, generic default providers, protocol, SDK. **NPCI-specific compliance rules, AD integration, and connectors that embed NPCI IP live in a separate private plugin repo** — never in the OSS tree.
- **Repo hygiene files (P0):** `LICENSE`, `NOTICE`, `THIRD_PARTY_LICENSES/`, `THIRD_PARTY_NOTICES.md`, `SECURITY.md`, `CONTRIBUTING.md`, `CODE_OF_CONDUCT.md`, `ARCHITECTURE.md`, `ADR/`, `PATENTS.md` (optional), DCO sign-off.
- **Clean-room provenance:** the vendor studies + ADRs are retained as evidence of independent implementation. Machine-readable third-party inventory (name/version/license/repo/usage/modified?).
- **Absolute rules:** no copied identifiers/prompts/comments/layouts/terminology; no vendored copyleft deps (shell out instead); own vocabulary throughout.

### A3. Testing & Definition of Done (every phase)
1. **Unit** — per crate, ≥ high coverage on logic.
2. **Integration** — cross-crate, real Postgres/Redis in CI containers.
3. **Scenario matrix (the 1,000+ rig)** — adversarial/real-world categories: malformed model output, provider failover, cancellation mid-turn, concurrency (N sessions), backpressure/503, huge & unicode/RTL inputs, auth expiry/refresh races, compliance redaction correctness, RBAC deny/scope-leak, air-gap/network loss, resume/crash recovery. Each phase adds its feature-specific cases.
4. **Load & soak** — sustained ≥ 2,000 concurrent sessions; memory-leak soak (the yoga/WASM class of bug must be impossible).
5. **Chaos** — kill workers/providers/connectors mid-turn; verify graceful degradation.
6. **Security** — `cargo audit`, SAST, secret scanning, fuzzing on parsers (tool-call, edit envelope, config).
7. A phase is **not done** until its matrix is green in CI, compliance+RBAC verified, telemetry emitting, and an ADR records the decisions.

### A4. Migration strategy (strangler-fig, Python untouched)
- Rust runs as a **sidecar the Python gateway calls** (same pattern as embed_svc/llm_proxy).
- Per-capability cutover behind **feature flags**.
- **Shadow mode:** mirror production traffic to the Rust path, compare outputs against Python offline, cut over only when parity + scenario matrix hold. Instant rollback via flag.
- A capability's Python implementation is retired **only after** its Rust equivalent is stable and verified in production.
- End state: Rust is the single spine; Python decommissioned incrementally.

---

## Part B — Phases

> Phases are sequential in dependency but work parallelizes within a phase. Every phase inherits Part A.

### Phase 0 — Foundations & Contracts
**Objective:** lock the load-bearing contracts + OSS + test infra *before* feature code.
**Deliverables:**
- **GATE #0 — LEGAL / OSS CLEARANCE (FIRST — before the eval keystone or any Rust; standing rule `feedback_legal_first_oss`).** Non-negotiable, per the user's #1 directive: the code must never carry a single legal issue when open-sourced. Requires, before any subsystem is implemented: license locked (**Apache-2.0**) + the full OSS file set (LICENSE / NOTICE / THIRD_PARTY_LICENSES / THIRD_PARTY_NOTICES / SECURITY / CONTRIBUTING / CODE_OF_CONDUCT / ADR/ + DCO/CLA); a **dependency-license CI gate** that fails the build on any disallowed/unknown license (permissive-only in the OSS tree; **no vendored copyleft** — shell out); the **model-weight license register + nation-of-origin routing gate** (ADR-018); **output-ownership** + **liability/indemnity** cleared (ADR-019); the **core/enterprise split enforced in CI** (NPCI-specific IP cannot land in the OSS tree); clean-room provenance recorded (ADRs = independent-design evidence). **No subsystem may be implemented until it passes this checklist.** (ADR-007 owns the license decision; ADR-028 owns the clearance-gate + CI enforcement.)
- ADRs (core): 001 Runtime · 002 Tool+MCP · 003 Approval/Policy/Compliance · 004 Config model · 005 Protocol · 006 Provider/Model-Router · 007 Licensing/OSS.
- ADRs (safety & quality foundations — from gap analysis A–D): **008 Guardrails Framework** (rails: jailbreak/toxicity/topic/groundedness; PCI is one rail) · **009 Agentic Security & Prompt-Injection Defense** (indirect-injection, instruction/data separation, tool allow-listing per trust context) · **010 Evaluation & Experimentation Platform** (offline eval-as-gate, LLM-judge, online A/B, RAG evals) · **011 Responsible-AI Governance** (model/system cards, bias/fairness, explainability, AI incident response).
- ADRs (regulated-FI & action-safety foundations — from deeper gap analysis, §Part 2): **012 Data Residency, Sovereignty & Data Classification** (data-class → model routing; RBI in-country) · **013 Action Idempotency & Transactionality** (exactly-once for side-effecting tools; saga/compensation) · **014 Model Risk Management & AI Regulatory Governance** (model inventory/validation/challenger/monitoring per RBI) · **015 Data Lifecycle: Retention, Erasure & Privacy** (DPDP retention/erasure, PII-minimized logs, memory consent).
- Note: ADR-012 (data-class-driven routing) and ADR-009 (injection) + ADR-013 (idempotency) are load-bearing on the P1 pipeline design — they must be decided before P1 code.
- ADRs (Pass-5 — "regulated national infrastructure" reframe; see `GAP_ANALYSIS_PASS5.md`): **016 Agent-Payment-Initiation Boundary** (non-overridable side-effect class — P0, decide before ANY workforce action code) · **017 Regulated-FI Compliance Ops** (CERT-In 6h/DPDP/RBI breach clocks, RBI IT-outsourcing register, DPDP-SDF/DPIA gate, PCI-DSS scoping/CDE, legal-hold override) · **018 Model Governance** (OSS weight licensing + nation-of-origin/sovereignty routing gate) · **019 AI Liability/Indemnity/Insurance chain** · **020 Serving-Ops** · **021 Hardware Root-of-Trust / Confidential-Computing (TEE)** · **022 Agent Identity Lifecycle** · **023 Crypto-Agility/PQC** · **024 microVM Sandbox for LLM-generated code** · **025 Evidentiary Admissibility + Supervisory Audit-Readiness**.
- ADRs (Q1/Q2 founder-question decisions — P0, architecture-defining; see `ADR-026-control-plane-git-native.md`, `LONG_HORIZON_PROGRAMS.md`): **026 Control-Plane Git-Native** (Q2 — definitions [skills/agents/roles/prompts/workflows/policies] are versioned **files in a git-backed control repo, not a DB**; governance is git-native: branch=DRAFT, PR+CI=PENDING_APPROVAL, merge=APPROVED, signed tag on the env/prod ref=PRODUCTION; CODEOWNERS=authoring RBAC + named owner; git history=audit; tag/SHA=versioning/rollback; loaded at startup + hot-reload; RBAC-on-**execute** via manifest front-matter read by the Policy Engine at run time; the data plane [erasable user-memory/PII → NEVER git, vectors/pgvector, event log, sessions, telemetry, budgets, connector tokens] stays in its stores — decide before ANY Studio/governance/marketplace code) · **027 Long-Horizon Program Execution** (Q1 — a durable, resumable **Program** above the Run that decomposes a goal into a dependency-ordered graph of window-sized modules and executes it as thousands of bounded base-loop Runs with state on the Event Log; **closes gap AG**). 🔴
- New P0/near-term subsystem deep-dives to design to 10 (Pass-5): `SERVING_OPS.md` (gaps 7,26,27,37,38+W) · `STRUCTURED_FEDERATED_RETRIEVAL.md` (gaps 4,15,24,25) · `REGULATED_FI_COMPLIANCE_OPS.md` (gaps 3,10-13,33,34+P,Q) · `AGENT_IDENTITY_AND_PAYMENT_BOUNDARY.md` (gaps 1,16+AI) · `LONG_HORIZON_PROGRAMS.md` (gap AG; ADR-027). Security seams (2,8,17,18,20)→TOOLING hardening; correctness seams (21,22,32,36)→respective docs; adoption band (28-31,43-48)→DEV_EXECUTION/WORKFORCE/INTERACTION + Part C risk register.
- **Reframe:** the runtime is "regulated NATIONAL INFRASTRUCTURE," not "an AI platform." Several Pass-5 items (016 payment boundary, 017 breach clocks, 010/PCI, 011/RBI-outsourcing, 018 origin gate) are **go-live blockers or examination findings**, not enhancements.
- Workspace crate architecture + vocabulary lock (own terminology register).
- **Protocol contract** (commands/events) as a versioned, backward-compatible schema.
- **Config model** spec (layering, schemas, invariants) per A1.
- OSS scaffolding per A2.
- **Scenario-matrix harness** framework (runner, categories, pass criteria, CI wiring) per A3 — runs green empty.
- CI/CD: build, lint (clippy), coverage, `cargo audit`, SAST, reproducible builds.
**Exit:** contracts reviewed & signed off; harness runs in CI; OSS files present; no feature code yet.

#### Phase 0 delivery status (2026-07-18 — design gates 3+4 complete; legal Gate #0 pending)
- **ADRs — DELIVERED as artifacts.** Every P0 ADR now exists: **001–015 + 007** as standalone files in `adr/` (`adr/ADR-0NN-*.md`); **018, 019, 023, 024, 026, 028** standalone; **016 (§1–9) + 022 (§10–21)** embedded in `AGENT_IDENTITY_AND_PAYMENT_BOUNDARY.md`; **017 (§1) + 025 (§7)** in `REGULATED_FI_COMPLIANCE_OPS.md`; **020 (§1–5) + 021 (§6–8)** in `SERVING_OPS.md`; **027** in `LONG_HORIZON_PROGRAMS.md`. Each is **Accepted — Design only (no code)** (canonical index: `adr/README.md`).
- **Protocol contract — DELIVERED (design).** `PROTOCOL.md` fixes the one versioned command/event seam every renderer and SDK speaks (governed by ADR-005). It is the normative message-shape contract, not a frozen IDL and not code.
- **Eval + scenario-harness keystone — DELIVERED (design).** `EVAL_PLATFORM.md` (eval-as-a-gate mechanism behind ADR-010, the keystone) + `SCENARIO_MATRIX.md` (the design of the 1,000+-scenario adversarial acceptance rig). These are the *designs* of the harness; the running, CI-wired harness that "runs green empty" (Phase 0 deliverable/Exit) is **not yet built**.
- **Crate architecture — NOT YET WRITTEN (gap).** `CRATE_ARCHITECTURE.md` is named by ADR-001 as its companion (the concrete Rust workspace decomposition realizing every seam ADR-001 asserts), but the file does **not exist** in the corpus. It must be authored before Phase 1 crate scaffolding — treat it as an open Phase 0 design item, not delivered.
- **GATE #0 (Legal / OSS clearance) — NOT PASSED (first blocker).** ADR-007 (license = Apache-2.0) and ADR-028 (clearance checklist + blocking CI) are *decided on paper*, but the gate itself is undischarged: no **human legal/OSS sign-off**; the OSS file set (LICENSE / NOTICE / THIRD_PARTY_LICENSES / THIRD_PARTY_NOTICES / SECURITY / CONTRIBUTING / CODE_OF_CONDUCT / DCO) is **not yet present** in the repo; and the **blocking clearance-gate CI** (dependency-license, DCO, clean-room-lint, core/enterprise-boundary, secret scans) is **not yet stood up**. Per the standing `feedback_legal_first_oss` rule this is FIRST — no subsystem may be implemented until it passes.
- **Gates 3+4 (design) — COMPLETE and internally consistent.** Cross-ADR consistency verified: ADR-006 consults ADR-012's data-class gate FIRST and non-overridably (exclusion before ranking; failover chain pre-filtered so no path reaches a data-class-excluded model); ADR-013 sits *below* the ADR-016 payment boundary (money-movement removed from the ledger's dispatchable set — no contradiction); ADR-004 and ADR-015 explicitly reconcile with ADR-026's control-plane (git) / data-plane (stores) split. No contradictions with ADR-026, ADR-012, or ADR-016 found.
- **Still open before Phase 0 EXIT, in order:** (1) discharge Gate #0 — human legal sign-off + OSS file set landed + clearance-gate CI standing and green; (2) write `CRATE_ARCHITECTURE.md`; (3) build the scenario-matrix *runner* and wire it into CI (runs green empty); (4) complete human review/sign-off of the Protocol + config + capability contracts. Only then does Phase 1 code begin.

### Phase 1 — Runtime Core Spine
**Objective:** the hardened turn pipeline + core services, callable as the sidecar.
**Scope:** Session Manager (actor-per-session, bounded inbox) · Prompt Engine · Context Engine (memory + one retrieval source) · Model Router + Provider Gateway (event-enum seam, ≥2 providers incl. one local) · Agent Runtime (need-driven loop, shared cancellation token, retry/backoff/error-taxonomy, iteration cap + stuck-detector) · Tool Runtime (registry, schema-from-struct, core tools) · **Compliance gate seam** (trait + default) · **Policy/RBAC seam** (trait + default) · Event Log (durable log + incremental projection) · Telemetry (OTel) · Config loader.
**Config surface:** models/providers/routing, tools enabled, prompts, limits — all declarative.
**Acceptance (matrix):** streaming; cancel mid-turn frees all tool futures; provider failover; malformed/partial tool JSON; compliance redaction on in/tool/out; RBAC deny; backpressure→503; huge+unicode/RTL input; N-session concurrency; crash→resume from Event Log.
**Exit:** Python gateway calls the Rust runtime for a full chat turn; compliance+RBAC enforced; all P1 scenarios green; soak clean.

### Phase 2 — Connector Runtime
**Objective:** server-side connectors + OAuth → unblocks **web** Buddy connectors.
**Scope:** connector registry · OAuth2 auth-code+PKCE (Entra/Graph) via gateway · encrypted token store (versioned FERNET) keyed by `jwt.sub` · refresh under Redis distributed lock (double-checked) · GitLab/Jira/Graph connectors · air-gap proxy support · connector policy (org/dept allow-deny) · deauthorize verb.
**Config:** connector defs, scopes, policies — declarative.
**Acceptance (matrix):** OAuth E2E; concurrent refresh races; token encryption + key rotation; per-user isolation; air-gap soft-degrade; policy deny; incremental consent for missing scope.
**Exit:** web + desktop Buddy use identical server-side connectors; zero client-side tokens.

### Phase 3 — Surface Profiles & Feature Parity
**Objective:** express Chat, Buddy, Code, SDLC as declarative profiles; reach parity with Python for migrated capabilities.
**Scope:** profile schema + loader · Chat profile (RAG + conversation-intelligence: follow-up detect/rewrite, intent/complexity routing, citations, memory) · Buddy profile (curated office capabilities + connectors) · Code profile (ripgrep/glob/read + edit engine + sandboxed bash + SAST gate) · SDLC profile (3-tier judge loop, HITL gates on the Approval seam, edit engine, deterministic verify) · Skill Runtime (behavioral→system-prompt, execution→pre-call `## Context`) · Artifact Runtime (doc-gen via structured IR + skill renderer) · Sandbox (quick container + sandbox-as-server).
**Config:** profiles fully declarative (capabilities/skills/autonomy/model-policy/RBAC per profile).
**Acceptance (matrix, from SUBSYSTEM_DEEP_DIVES):** SDLC judge independence + honest `capped`; edit-engine dry-run safety + import restore; doc-gen fidelity (incl. Presenton `template:layoutId`); skill injection order; context RBAC scope-separation (no cross-repo/tenant leak); grep at millions-of-files scale with caps; shadow-mode parity vs Python.
**Exit:** each migrated feature passes its matrix and matches/beats Python; per-capability strangler cutover with rollback.

### Phase 4 — Client Layer
**Objective:** the protocol clients; kill CLI-as-plumbing.
**Scope:** REST/gRPC/SSE transport of the protocol · **Python SDK** (first) · **TypeScript SDK** · **headless CLI** (thin wrapper over SDK; `run`/`--print`/`--json`/stdin/`--continue`; static binary; air-gap) · **IDE extension** (over TS SDK) · repoint Web Chat + Desktop Code at the runtime **directly** (remove the CLI wrapper).
**Config:** endpoint/auth/profile selection.
**Acceptance (matrix):** SDK contract tests; CLI headless in CI pipelines, air-gap, exit codes, stream-json, resume; desktop-direct integration; backward-compat contract tests across a protocol version bump.
**Exit:** Desktop no longer wraps the CLI; CLI is headless-only in prod; SDKs published internally.

### Phase 5 — Extensibility Platform (declarative-first)
**Objective:** engineer-built harnesses, governed, with plugin isolation.
**Scope:** Harness API (declare/run/publish) · `harness dev`/`test`/`publish` loop · **git-native governance lifecycle** (branch=DRAFT → PR+CI=PENDING_APPROVAL → CODEOWNERS-reviewed merge=APPROVED → signed tag on the env/prod ref=PRODUCTION; git history=audit; tag/SHA=rollback — per ADR-026, so `harness publish` **emits a PR to the control repo, not a DB row**) · **Marketplace = federation of pinned git repos (TOFU hash-pin)** (ADR-026 — not a central registry table) · capability-permission enforcement (least-privilege grants; RBAC-on-execute read from manifest front-matter) · **WASM/WASI plugin runtime** for programmatic capabilities.
**Config:** harness manifests; capability grants.
**Acceptance (matrix):** declarative harness E2E; **safety invariants** — author cannot disable compliance/RBAC, exceed budget, exceed granted permissions, or escape the WASM sandbox; plugin isolation + resource-limit tests; marketplace publish + governance gate.
**Exit:** an engineer builds and publishes a governed harness; every safety invariant proven under adversarial test.

### Workstream CP — Git-Native Control-Plane Migration (ADR-026 strangler-fig for definitions)
**Objective:** move the six definition kinds (prompts, skills, agents, roles, workflows, policies) off the DB governance state machine and onto the git-native control plane (ADR-026), one kind at a time, zero-downtime, with instant rollback — the A4 strangler-fig applied to the *control plane* rather than the runtime. Runs in parallel with Phases 3–5; depends on the ADR-026 decision (P0) and the Policy/RBAC + Compliance seams (P1).
**Scope:**
- **Per-kind `authority: db | git` cutover flag** — the single switch per definition kind; the loader reads git when `git`, the DB when `db`. Exactly one plane is authoritative for a kind at any instant (no dual-write ambiguity).
- **DB→git exporter (emits PRs, never direct commits)** — reads a kind's existing DB rows, renders each as a Markdown-with-front-matter definition file on a branch, and **opens a PR** so the initial import itself must clear CODEOWNERS review, CI, and the pre-receive compliance/PII gate (ADR-026 §10) before it can become the source of truth.
- **git→DB read-through projector (one-way, git→DB)** — projects merged git definitions back into the legacy DB tables as a **read-only, non-authoritative cache**, so un-migrated Python code paths that still `SELECT` definitions keep working during and after cutover without becoming a second writer.
- **Per-kind DB-grant revocation** — once a kind is `authority: git` and the projector serves legacy reads, **revoke write grants on that kind's DB tables** at the database-role level, so no path can mutate the now-non-authoritative store: the DB *physically cannot* be a second source of truth (enforcement, not convention).
- **Cutover order (lowest blast-radius first):** **prompts + behavioral skills first** (pure text, no code execution, trivial to diff/review) → **then agents/roles** (front-matter RBAC, moderate blast-radius) → **then policies/workflows last** (they gate execution and side effects — highest blast-radius, migrated only once the mechanism is proven on the easy kinds).
**Config:** per-kind `authority` flag; exporter/projector enable flags; the CODEOWNERS map per manifest path.
**Acceptance (matrix):** the exporter's PR is **rejected by the pre-receive gate** if any exported row carries PII/secrets, and merges only after CODEOWNERS approval; flipping `authority: db→git` for a kind is observable in telemetry and instantly reversible; the read-through projector serves legacy DB readers definitions **byte-identical** to the pre-cutover DB rows; after DB-grant revocation, every write path to that kind's tables **fails closed** (permission-denied, verified under test); a **shadow-mode compare** shows git-loaded definitions produce runtime behavior identical to DB-loaded ones *before* any cutover flip; rollback (`authority: git→db`) restores prior state with **zero lost definitions**; migrating one kind never disturbs another kind's authority.
**Exit:** all six kinds are `authority: git`; DB write grants on definition tables are revoked; the DB governance state machine is retired **for definitions only** (data-plane tables untouched per ADR-026 §3); git history is the sole authoring audit trail.

---

## Part C — Cross-phase tracking
- **Risk register** (maintained): protocol churn, provider API drift, sandbox-escape, token/secret handling, migration parity gaps, scale regressions; **git control-plane integrity** — the **pre-receive compliance/PII gate** and the **commit/tag-signing infrastructure** (CODEOWNERS enforcement, branch protection, signed-tag verification on the env/prod ref) are go-live-blocking infra (ADR-026): a gap lets an unsigned, unreviewed, or PII-bearing definition reach production, and git's non-erasability makes a leaked-PII commit unrecoverable (mitigation: gate + signing must be proven under Workstream CP's matrix before the first kind cuts over to `authority: git`).
- **Dependencies:** P2 depends on P1 (pipeline + policy seam); P3 depends on P1+P2; P4 depends on the protocol (P0) + P3 profiles; P5 depends on P3 (capabilities) + P4 (SDK).
- **Parallelism:** within P1, provider gateway / tool runtime / event log can proceed in parallel once the protocol (P0) is frozen.
- **Each phase ships behind flags + shadow mode; nothing cuts over without matrix-green + parity.**

---

## Part D — Consolidated gap → phase map

Every gap from `GAP_ANALYSIS_VS_AI_PLATFORMS.md` (passes 1–4, codes A–BT) is assigned to a phase here so nothing is orphaned. Codes: A–M pass 1, N–AH pass 2, AI–BD pass 3, BE–BT pass 4 (intelligence/quality/UX). 🔴 critical.

### P0 — Foundations & Contracts (decide + scaffold)
- ADRs 008–015 (see P0 above) 🔴 covering: A injection, B guardrails, C eval-platform, D responsible-AI, N/O data-residency+classification, P model-risk, Q data-lifecycle, R/S idempotency+sagas; extensions AI→003, AJ→012, AK→011/015.
- **ADRs 026 (Control-Plane Git-Native, Q2) 🔴 + 027 (Long-Horizon Programs, Q1)** — 026 splits control-plane (git) from data-plane (stores) and must be decided before any Studio/governance/marketplace code; it also spawns **Workstream CP** (the DB→git strangler-fig migration, Part B). 027 is the Program Supervisor above the Run — it **closes gap AG** (long-horizon task management), reassigned here from P3. See `LONG_HORIZON_PROGRAMS.md`.
- **Eval + quality framework** foundation: C eval-as-gate, **BF/BT answer-quality + quality-drift** built into the scenario harness (quality is measured from day one, not bolted on). 🔴
- **BJ prompt-engineering discipline + prompt registry** scaffolding (per-model). 🔴
- AK tamper-evident audit design; AL secrets/vault design; BA OSS RFC/SECURITY/release governance; BC output-licensing policy; BD team topology/ownership.

### P1 — Runtime Core Spine (in the pipeline)
- **Safety seams (with compliance):** A injection defense, B guardrails layer (incl. groundedness rail), AM system-prompt-leak, T egress/DLP baseline. 🔴
- **Router as compliance component:** N/O data-class → model-eligibility routing. 🔴
- **Authz:** AI on-behalf-of / fine-grained tool+resource authz. 🔴
- **Action safety:** R idempotency + side-effect ledger, S saga/compensation scaffolding. 🔴
- **Reasoning quality:** BE adaptive reasoning depth/thinking budgets; BH numerical/data reasoning via tools (never model arithmetic); BG instruction-following via prompt discipline. 🔴
- U uncertainty/abstention/escalation; X forensic reproducibility capture; AK tamper-evident audit; AL secrets/vault; AU time/clock injection.
- I prompt caching; J LLM observability + cost attribution; AR plan-thrash detector.
- Output feel basics: BK formatting, BO streaming/perceived-latency, BM verbosity, BL tone (via prompt).
- Y SLO/error-budget + degraded-mode scaffolding; V FinOps cost hooks.

### P2 — Connector Runtime
- Server-side OAuth + encrypted tokens (base); T egress DLP on connector outbound; AI OBO authz at connector level; O data-class enforcement on connector data; AL secret rotation.

### P3 — Surface Profiles, RAG & Quality
- **RAG quality engineering:** G eval/chunking/embedding; AJ pre-rank chunk-level ACL + PII-in-embeddings 🔴; AN embedding-lifecycle/re-embed pipeline 🔴; AO vector recall tuning; AP lost-in-middle positioning; Z freshness+source-conflict+lineage; AA citation faithfulness.
- **Answer intelligence:** BI cross-source synthesis; BN citations UX; BQ calibrated clarification; BP proactivity/suggestions; BS personalization/continuity; BR progressive disclosure/steering; BK rich rendering/artifacts; BM verbosity calibration.
- AB semantic tool selection at scale; AX multimodal I/O (+compliance on modalities). *(AG long-horizon task management moved to ADR-027 / `LONG_HORIZON_PROGRAMS.md` — decided in P0.)*

### P4 — Client Layer, DX & Adoption
- K DX playground + eval-driven dev + prompt/harness IDE; AV branch/edit/stop/steer UX; AW trust/error UX; AF accessibility; AE multilingual quality; BO perceived-latency polish; BP capability discovery.
- AY collaboration/team workspaces/sharing.
- **AZ adoption/change-management** (migration off Kilo Code, user onboarding, golden-path templates) 🔴; BB support model/SLAs.

### P5 — Extensibility & the Improvement Engine
- E data flywheel (feedback → evals/retrieval/fine-tune); F LLMOps prompt+model lifecycle; **BJ automated prompt optimization + prompt A/B** 🔴; **BF/BT quality-eval + drift as continuous gate** 🔴; AS online canary + auto-rollback.
- H fine-tuning/distillation for OSS models; AD model supply-chain/weight-signing + poisoning defense; AC provenance/AI-output labeling; P model-risk operationalization; BA marketplace governance.

### Cross-cutting (all phases, owned continuously)
- C eval-as-gate + BT quality regression + the adversarial test agent ("Breaker") = the DoD engine.
- W **inference-serving ops for self-hosted OSS at ≥2,000 req/s** (vLLM/TGI batching, GPU capacity, autoscale) — infra prerequisite from P1 onward wherever local models serve. 🔴
- Y SLOs/error budgets; AT DR/RPO-RTO for AI state; V FinOps; J LLM observability; BD ownership.

**Rule:** a gap is not "planned" until it appears in a phase's scope *and* has scenario-matrix + (where relevant) quality-eval acceptance criteria. Intelligence/quality gaps (BE–BT) carry **quality-eval** acceptance criteria, just as safety gaps carry scenario-matrix criteria.
