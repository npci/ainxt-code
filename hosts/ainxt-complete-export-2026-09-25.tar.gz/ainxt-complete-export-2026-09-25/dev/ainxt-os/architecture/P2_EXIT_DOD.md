# P2 Exit — Definition-of-Done Status

**Status (2026-07-19):** P2 **Connector Runtime** BUILT + increment-reviewed. The functional
acceptance matrix (OAuth E2E, refresh-race, key rotation, per-user isolation, air-gap degrade,
policy deny, incremental consent, egress DLP, data-class ceiling) is **green locally**. Live OAuth
against a real IdP, the Postgres token store, the Redis distributed lock, and real connector HTTP
remain — see "Not yet proven" (stated honestly per `feedback_enterprise_grade_no_poc`).

## What is built (6 crates over the P1 spine)

`ainxt-connector` (policy spine) · `ainxt-token` (encrypted vault) · `ainxt-oauth` (PKCE engine) ·
`ainxt-refresh` (refresh coordinator) · `ainxt-connector-http` (adapters + transport + lifecycle).
Plus an additive `Principal.department` field (org/dept scoping) in `ainxt-types`.

Every outbound connector call takes ONE path with the safety seams enforced by construction:

```
authorize_use (on-behalf-of authz + org/dept policy)   ← #1 ConnectorRuntime, mandatory ctor args
  → guard_egress (data-class ceiling + DLP redaction)  ← #1, enforced by the runtime itself
  → resolve token (refresh if due, under a lock)        ← #4 coordinator / #2 vault
  → inject bearer (AFTER egress, never DLP-scanned)
  → transport.send (air-gap proxy; Unavailable ⇒ soft-degrade)   ← #5
  → tag response Provenance::Connector (untrusted → injection stage)  ← #1/#5
```

## Evidence (all green: per-crate `cargo test` + `clippy -D warnings`; workspace `cargo deny`)

- **P2 crate tests, 0 failed:** `ainxt-connector` 15 · `ainxt-token` 14 · `ainxt-oauth` 14 ·
  `ainxt-refresh` 11 · `ainxt-connector-http` 18 (+ the DoD matrix). Clippy clean on every crate,
  including the feature-gated reqwest transport (`--features reqwest-transport` compiles).
- **License gate:** the new crypto/HTTP deps — `chacha20poly1305`, `zeroize`, `aead`, `poly1305`,
  `cipher`, `chacha20`, `sha2`, `getrandom`, `percent-encoding`, and (optional) `reqwest`+rustls —
  all clear `cargo deny` (`advisories/bans/licenses/sources ok`). Permissive-only tree holds.
- **P2 acceptance matrix** (`ainxt-connector-http/tests/dod_p2_matrix.rs`): the assembled connector
  stack, driven through the P1 scenario harness with layered oracles + JUnit, passes **9 scenarios**
  across the P2 categories — OAuth authorization-code+PKCE **E2E** (mock IdP), **concurrent-refresh**
  collapse (12 callers → exactly 1 network refresh), **key rotation** (old records still open, new
  use the new key), **per-user isolation**, **air-gap soft-degrade**, **org/dept policy deny**
  (refused before any I/O), **incremental consent** (missing scope detected), **egress DLP**
  (secrets redacted from a write body), and the **data-class ceiling** (regulated data refused
  egress and never sent). Scenarios fail-red if their invariant breaks (leak markers asserted
  absent; denials asserted to send nothing — `sent=0`).

### Enterprise invariants proven end-to-end
- **Mandatory safety seams as required constructor args** — a `ConnectorRuntime` cannot be built
  without an org/dept policy, an on-behalf-of authorizer, an egress DLP guard, and an audit sink.
- **On-behalf-of authz (confused-deputy, gap AI)** — capability ladder `connector.<id>` →
  `.<op>` → `:<resource>` → `.<op>:<resource>`; deny messages never echo the resource value.
- **Egress control (gaps T + O)** — DLP redaction on write bodies **and** a hard data-class ceiling
  (regulated/PII never egresses to a cloud connector) enforced by the runtime, not a plugin.
- **Encrypted-at-rest tokens** — XChaCha20-Poly1305 with **per-(user,connector) AAD binding** (a
  sealed token can't be transplanted to another user — proven in `ainxt-token`) and **versioned key
  rotation** (retire an old key and its records stop opening).
- **Thundering-herd safety at scale** — double-checked distributed lock: N concurrent refreshes for
  one stale token ⇒ exactly one token-endpoint call (proven under 12–16 threads).
- **Untrusted ingress** — connector responses are tagged `Provenance::Connector` for the injection
  stage (indirect-injection surface); connector data is never trusted as instructions.
- **Self-service deauthorize** — a user may revoke only their own grant (admin may revoke any);
  every deauthorize is audited; revoke purges the encrypted token.
- **Air-gap aware** — the transport honors a forward proxy (web02 Squid); connect/timeout maps to a
  **soft-degrade**, so a lost connector degrades the feature without failing the whole turn.

## Not yet proven here (needs the infra box, or is a tracked follow-up)

- **Live OAuth** against a real Entra/Graph tenant (authorize redirect + real code exchange +
  real refresh) — the engine + parsing are unit-tested against a mock IdP; the reqwest transport
  compiles but its live tests are `#[ignore]` (no network/keys here).
- **Durable token store:** the Postgres-backed `TokenStore` (the in-memory impl + the codec/vault
  are tested; the DB impl behind the same trait is pending, with a `prod_catchup` SQL migration).
- **Distributed lock:** the Redis `SET NX PX` + fencing `RefreshLock` (the in-memory impl proves the
  double-check + fencing semantics; the Redis impl behind the same trait is pending).
- **Real egress at 2,000 req/s** through the proxy, and connector-loss chaos/soak — need the infra
  box with live endpoints.
- **Enterprise DLP recall:** egress uses the OSS marker/digit-run redactor; the full PCI/DSS DLP
  detector plugs in behind the same `EgressGuard` seam (the NPCI private plugin).
- **Composition binary** (`ainxt-runtimed`, plan L6): assembling the connector runtime + vault +
  coordinator + transport from `RuntimeConfig`, and wiring the connector call path into a surface
  profile (P3), remain — this phase delivers the subsystems + their acceptance matrix.
- **Human Gate #0 (legal/OSS sign-off + real copyright entity + model-weight license clearance)**
  remains the standing P0 blocker before any public open-source release.
