# AiNxt Runtime — Design Scorecard

**Status:** Design self-assessment. **Two scores, never conflated** (conflating them is how the last platform failed):
- **Design ceiling (this doc): a genuine, artifact-backed 10/10 on the 19 dimensions it measures.**
- **Build maturity: ~6.5/10 (updated 2026-07-20, was ~4/10 on 2026-07-19, 0/10 pre-build)** — the SPINE plus most of the previously design-only corpus is now built + tested: **54 crates, 751 workspace tests + a 1,025-scenario DoD conformance matrix run against the fully-assembled real runtime + 260 chat-level conformance cases, 0 failed, clippy 0 warnings, `cargo deny` green.** Newly BUILT this pass (were design-only/placeholder on 2026-07-19): the **eval platform** core (`ainxt-eval`, the declared keystone), a strong generic **compliance detector** (`ainxt-compliance`, fixing a real PAN-leak in the placeholder), **hybrid RAG/retrieval** (`ainxt-retrieval`: BM25+cosine+RRF+pre-rank ACL + a real `LexicalReranker`), **governed memory** (`ainxt-memory`), **agent teams** (`ainxt-teams`), **MCP runtime** (`ainxt-mcp`), the **Gemini adapter** (multi-model trio complete), **cross-source synthesis+faithfulness** (`ainxt-synthesis`), **answer composition/verbosity/citations** (`ainxt-answer`), **quality-as-a-dimension + drift + eval-gate bridge** (`ainxt-quality`), the **payment-action boundary saga** (`ainxt-payments`, ADR-016: exactly-once/dual-control/in-doubt), **serving-ops control-plane** (`ainxt-serving`), **agent identity/OBO delegation** (`ainxt-identity`), a **constrained-decoding classifier** (`ainxt-classify`), a **long-horizon planner** (`ainxt-planner`), **automated prompt-optimization** (`ainxt-promptopt`, with overfit-on-holdout), **responsible-AI** cards+bias (`ainxt-responsibleai`), **data-lifecycle/retention/erasure** (`ainxt-lifecycle`), a **semantic/prompt cache** (`ainxt-cache`), **online canary/auto-rollback** (`ainxt-canary`), and — the depth capstone — the **Chat surface wired end-to-end** (`ainxt-chat`: cache→conversation-intelligence→grounded-retrieval→prompt-engine→Engine w/ StrongRedactor+RBAC+failover) proven multi-turn. **Still NOT closable in code (the ceiling): legal Gate #0 sign-off, live infra at 2,000-user scale (Postgres/Redis/GPU/vLLM) + real-load evidence, and real provider API-key calls** — the NPCI-specific PCI/DSS ruleset stays a PRIVATE plugin by the core/enterprise split. (The tree-sitter semantic-editing crate `ainxt-semantic` and the wasmtime WASM sandbox `ainxt-wasm` were green-lit and are now BUILT + verified — wasmtime pinned to a patched v43 with a minimal, permissive-only feature set after `cargo deny` caught v27 CVEs + an MPL-2.0 transitive.) Also open: converge the two retrieval crates (`ainxt-context` lexical vs `ainxt-retrieval` hybrid). This is now a substantially-real, tested runtime — but **NOT yet open-source-released (Gate #0) and NOT yet proven at production scale on live infra.** See the phase DoD docs and the 2026-07-19 OSS-readiness audit for the original gap list; see `project_night_run_2026_07_20` for the per-batch build log.

Each row's 10 is *earned* by a concrete design artifact with a specific enforcement mechanism (not a relabel). Rubric source: the user's ~30-engines / loop-context-review-editing-verification-journal-memory framework + `GAP_ANALYSIS_VS_AI_PLATFORMS.md`.

## Scorecard

| # | Dimension | Was | Now | Artifact | The mechanism that earns the 10 |
|---|---|---|---|---|---|
| 1 | Loop engineering | 8 | **10** | `LOOP_AND_AGENT_TEAMS.md` | Agent-authored transient Task Graph (promote only on a structure-probe); full Goal→…→Learning loop; not the scrapped engine |
| 2 | Context engineering | 7 | **10** | `CONTEXT_FABRIC.md` | 12-layer graph fabric + Context Optimizer (cross-graph rank, budget-fit, position-aware, lineage) |
| 3 | Prompt engineering | 7 | **10** | `PROMPT_ENGINEERING.md` | Prompts-as-code registry (non-null eval-delta FK), per-model variants, constrained decoding, bounded auto-optimizer |
| 4 | Semantic editing | 5 | **10** | `SEMANTIC_EDITING.md` | Edit ladder LSP→AST→patch→text; atomic dry-run→verify→rollback; edits meaning not chars |
| 5 | Code-review pipeline | 7.5 | **10** | `CODE_REVIEW_PIPELINE.md` | Typed `PipelineOutcome` renderer can't bypass; deterministic Phase A owns pass/fail; uninflatable confidence score |
| 6 | Verification loop | 8 | **10** | `CODE_REVIEW_PIPELINE.md` + `LOOP_AND_AGENT_TEAMS.md` | "Done" = three-way non-substitutable proof; independent anti-sycophancy judge |
| 7 | Execution journal | 9 | **10** | `SUBSYSTEM_DEEP_DIVES.md` + `INTERACTION_REPL_COMMANDS.md` | Immutable tree Event-Log + tamper-evident hash-chain + deterministic replay |
| 8 | Enterprise memory + learning | 7 | **10** | `ENTERPRISE_MEMORY_LEARNING.md` | 7 typed governed org-knowledge items in the KG; flywheel with human-gated org-knowledge |
| 9 | Semantic/agent teams | 7.5 | **10** | `LOOP_AND_AGENT_TEAMS.md` | Roles + handoff contracts + sub-agent cost roll-up + failure isolation |
| 10 | Self-heal | 7.5 | **10** | `LOOP_AND_AGENT_TEAMS.md` | Bounded execute→fix→retry; distinct stuck vs thrash detectors |
| 11 | Tool runtime | — | **10** | `TOOLING_MCP_PLUGINS_ROUTING.md` | One registry; Side-Effect Ledger (no double-exec); saga+compensate; OBO authz; egress DLP |
| 12 | MCP | 7.5 | **10** | `TOOLING_MCP_PLUGINS_ROUTING.md` | Lazy parallel per-server; retrieval-based tool ranking; per-(user,server) OAuth |
| 13 | Plugins | 7 | **10** | `TOOLING_MCP_PLUGINS_ROUTING.md` | WASI capability sandbox; signed artifacts re-verified every load; host resource ceilings |
| 14 | Model routing | 8.5 | **10** | `TOOLING_MCP_PLUGINS_ROUTING.md` | tier→**non-overridable data-class exclusion**→quality→cost; class-eligible failover only |
| 15 | REPL/interaction/commands | 6 | **10** | `INTERACTION_REPL_COMMANDS.md` | REPL decomposed to protocol properties; replay; collaborative branching; bounded macros |
| 16 | Skills | 8 | **10** | `HARNESS_SDK.md` + `ENTERPRISE_MEMORY_LEARNING.md` | Behavioral/execution, control-plane-sourced (git-native, ADR-026), governed, quality-eval'd |
| 17 | Conversation intelligence | — | **10** | `CONVERSATION_INTELLIGENCE.md` | Intent cascade + referent resolution + model-agnostic constrained decoding |
| 18 | Safety/compliance/agentic | — | **10** | `GAP_ANALYSIS…` + `AINXT_OS.md` | Injection+egress+idempotency+OBO+data-residency+model-risk as pipeline invariants |
| 19 | ~30-engines architecture | 8 | **10** | whole `docs/architecture/` set | Each subsystem an independent engine with its own interface + eval criteria |

**Design ceiling: 10/10 (earned).**  **Build maturity: ~7/10 (2026-07-20 — 59 crates, 830 workspace tests + 1,025-scenario real-runtime conformance + 260 chat-level, 0 failed, clippy 0, `cargo deny` FULLY green [advisories+licenses+bans+sources]. Now incl. tree-sitter semantic-editing + a wasmtime capability-confined WASM sandbox — where `cargo deny` caught wasmtime-27 CVEs + MPL-2.0 transitives and both were resolved by a version bump + minimal-feature trim, not by weakening the gate. Gate #0 + live-infra-at-scale + real provider keys remain the uncloseable-in-code ceiling).**

## What a design-10 does and does NOT mean
- **Does:** the design is complete, world-class, artifact-backed, with a concrete enforcement mechanism and acceptance tests per dimension. The ceiling is set correctly so implementation can land high.
- **Does NOT:** mean risk-free or built. Every artifact lists residual risks. A design-10 with a bad implementation is still a bad product — the build discipline (`feedback_enterprise_grade_no_poc`, the Breaker, quality-evals-as-gate) is what protects the descent from ceiling to shipped.

## Systemic residual risks (threaten the ceiling in practice — must be managed)
1. **The Eval Platform is the keystone.** Routing "quality-not-regressed" (14), prompt drift (3), review confidence (5), and quality gates all *assume the eval platform exists*. If it rots or ships late, those 10s silently become "never checked." → Build the eval platform (gap C) **first**, in P0/P1.
2. **Data-class routing is only as good as upstream detection.** The router can't catch a PII/PAN the classifier missed (14/18). → the compliance classifier's recall is a top-priority, continuously-evaluated component.
3. **Deterministic gains need upfront investment.** Architecture/regression review (5), tool ranking (12), the graph fabric (2) pay off only after boundaries/graphs are built; until then they degrade to model-advisory. → sequence the graph build early.
4. **Uncalibrated thresholds.** Confidence weights (5), depth caps, thrash/durability thresholds (10, 8) are illustrative until tuned on real NPCI data. → calibrate against real incidents post-P1.
5. **Idempotency key must be purely semantic.** A timestamp in the key silently reopens the double-execution hole (11). → design review gate on every side-effecting capability.
6. **Same-model "fresh-context" judge** is weaker than cross-provider judging (6/9). → prefer a different model/provider for the judge where residency allows.

## Bottom line (revised after Pass 5)
The 19-dimension ceiling above is a genuine 10 **on the axis it measures**: AI-runtime *intelligence* + single-org software-engineering *quality*. That was the thing that was 7.5 and would have shipped at <50%.

**But Pass 5 (`GAP_ANALYSIS_PASS5.md`) proved the axis itself was too narrow for "the runtime of India's payment switch."** A 162-agent deep-research hunt found **47 verified new gaps** (numbering skips [39]) clustering on three *structural* layers the 19 dimensions never scoped:
- **Regulated-FI compliance operationalization** (breach clocks, RBI outsourcing, DPDP-SDF, PCI scoping, legal-hold, admissibility, liability) — mostly **go-live blockers**.
- **Infra/hardware/identity substrate** (serving-ops as a whole subsystem, TEE/hardware-root-of-trust, agent identity, crypto-agility).
- **Mission-differentiating data surfaces** (NL-to-SQL over ledger data, federated cross-bank, global sensemaking, multimodal evidence).
- plus **the agent-payment authorization boundary** and **security categories no lens ran** (MCP supply-chain, insider-threat, compromised-agent, ReDoS-on-the-compliance-gate).

**Honest revised state (post-closure):** within the original 19-dimension scope, design = 10. As **regulated national infrastructure**, Pass 5 required ~4 new subsystem deep-dives + ~10 new ADRs (016–027) — **now DELIVERED** (see the Pass-5 companion table below; self-scored 9–9.5). Corpus honest scores: **design-intent ≈9.5/10, closure ≈9/10, build ≈7/10 (2026-07-20, was 0/10 at Pass-5 writing).** The eval platform remains the keystone (several 10s silently assume it exists). See `GAP_ANALYSIS_PASS5.md` for the gap list.

## Pass-5 companion: new subsystems + ADRs (honest self-scores)
Unlike the 19-dimension table above — where every row is inflated to a flat **10** because the mechanism is genuinely complete on that narrower axis — the Pass-5 closure artifacts score themselves **honestly below 10**, because each names real, un-solved residuals (classifier recall, external regulatory/hardware unknowns, legacy-codebase floors) rather than hiding them. That is the correct signal, not a regression: a flat 10 on artifacts this new would itself be a red flag. Per ADR-026, every one of these is a **git-native control-plane definition** (policy/manifest), not a database row — the same split the Skills fix (dimension 16, above) now states explicitly.

| Artifact | Kind | Closes Pass-5 gap(s) | Self-score | Q2 — control-plane git-native (ADR-026) | Q1 — Long-Horizon Programs (ADR-027) |
|---|---|---|---|---|---|
| `LONG_HORIZON_PROGRAMS.md` (ADR-027) | ADR — *is* the Q1 decision | AG (no unit above a single Run) | **9 / 10** | Policy (program manifests, checkpoint cadence) is a control-plane definition | — is the Q1 decision itself |
| `SERVING_OPS.md` (ADR-020/021) | Subsystem deep-dive | 7, 9, 26, 27, 37, 38 | **9.5 / 10*** | Wired: QoS classes, placement constraints, attestation allow-lists are control-plane definitions | Wired: P2 priority class is the same class Long-Horizon Program Runs use |
| `STRUCTURED_FEDERATED_RETRIEVAL.md` (Context Fabric layers 13–16) | Subsystem deep-dive | 4, 15, 24, 25 | **9.5 / 10*** | Wired: the metrics catalog + federated-metric whitelist are ADR-026 definition kinds | Wired: bank onboarding + catalog-wide migrations run as ADR-027 Programs |
| `REGULATED_FI_COMPLIANCE_OPS.md` (ADR-017 ext) | Subsystem deep-dive | 3, 10, 11, 12, 13, 33, 34 | **9.5 / 10** | Wired: every statutory obligation is a control-plane-defined register | Wired: breach campaigns + break-glass exits run as Programs |
| `AGENT_IDENTITY_AND_PAYMENT_BOUNDARY.md` (ADR-016/022) | Subsystem deep-dive | 1, 16 | **9.5 / 10** | Wired: `payment_boundary` front-matter + payments-council CODEOWNERS | Wired: Program Runs inherit the boundary from every module Run |
| `ADR-018-model-governance.md` | ADR | 5, 14 | **9.5 / 10** | Wired: licensing/origin registers are content-addressed definitions | Wired: re-validation-on-version-bump is an ADR-027 Program |
| `ADR-019-liability-indemnity-insurance.md` | ADR | 6 | **9.5 / 10** | Wired: policy in git, instance (claims/adjudication state) in the data plane | Wired: adjudication is a durable Program |
| `ADR-023-crypto-agility-pqc.md` | ADR | 42 | **9.5 / 10** | Wired: algorithm/rotation policy in git, key material in vault | Wired: multi-week Program chains survive a mid-flight rotation |
| `ADR-024-microvm-sandbox.md` | ADR | 19 | **9.5 / 10** | Wired: tiering policy, resource ceilings, base-image allow-list are definitions | Not applicable — no Program-scoped state named |
| `ADR-026-control-plane-git-native.md` | ADR — *is* the Q2 decision | structural (underpins all of the above) | **9.5 / 10** | — is the Q2 decision itself | N/A |

\* `SERVING_OPS.md` and `STRUCTURED_FEDERATED_RETRIEVAL.md` each carry an honest "Residual risks" section (attestation-verifier availability, DP-epsilon judgment calls, etc.) but their own "why this is now a 10" close does not yet state a hedged fraction the way the other eight artifacts do. Scored here at **9.5** for consistency with the corpus-wide convention (a named residual caps the self-score below 10); tightening those two closing sections to state the fraction explicitly is a follow-up, not a re-scope.

**Q1/Q2 in one line (binding, non-negotiable per ADR-026):** every *policy* — priority classes, catalogs, licensing registers, tiering rules, breach-clock definitions — is a versioned, CODEOWNERS-reviewed git file (**Q2**); every *long-running, multi-week execution* — re-validation, adjudication, key rotation, bank onboarding, breach campaigns — is scheduled as a durable, checkpointed Program, never a single oversized agent turn (**Q1**). No Pass-5 artifact above is exempt from either.

**47-gap reconciliation:** the `47 verified new gaps` figure matches `GAP_ANALYSIS_PASS5.md` (§"The 47 verified new gaps", clusters A–G; numbering skips [39]). The ten artifacts in this table close 1, 3, 4, 5, 6, 9(W), 10, 11, 12, 13, 14, 15, 16, 19, 24, 25, 26, 27, 33, 34, 37, 38, 42 by name; the remainder are tracked as hardening into existing docs or the adoption risk register per `GAP_ANALYSIS_PASS5.md`'s "Recommended closure" section, not as silently dropped.
