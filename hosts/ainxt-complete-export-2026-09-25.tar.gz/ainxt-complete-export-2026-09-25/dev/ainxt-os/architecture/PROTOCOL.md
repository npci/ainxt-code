# AiNxt Runtime Protocol — The Contract Every Renderer and SDK Speaks

**Status:** Design doc (no code — the message shapes below are the normative contract; the JSON snippets are illustrative of structure, not a frozen field-by-field IDL). Companion to and governed by **ADR-005** (the decision), which fixes *why* this contract exists as one versioned seam. Cross-refs: `RUNTIME_FEATURE_FLOWS.md` (the turn pipeline these messages narrate), `HARNESS_SDK.md` (the SDK that binds to this contract), `INTERACTION_REPL_COMMANDS.md` (branch/edit/stop/steer, replay, presence, voice, notification, feedback — event families designed there, catalogued here), `VENDOR_SYNTHESIS.md` §1.1/§1.6/§1.8 and `codex.md` §2–§9 (studied patterns, re-implemented originally).

**One-sentence contract:** a client sends **Commands** and receives **Events**; both are typed, versioned, transport-agnostic, and identical whether the runtime is embedded in-process or reached over a network.

---

## 1. Design invariants (the rules the whole contract obeys)

These are not style guidelines — every message, transport, and version rule below is consistent with them, and a proposed change that breaks one is wrong.

| # | Invariant | Consequence in this spec |
|---|---|---|
| **I1** | **One contract, two families.** The only coupling between a client and the runtime is the Command family (client → runtime) and the Event family (runtime → client). | §5 Commands, §6 Events. No third family, no side channel. |
| **I2** | **Typed, never freeform.** Tool calls, approvals, artifacts, usage, errors are structured events — never parsed out of model prose. | §6.2 tool calls are events; §11 clean-room. |
| **I3** | **Server owns state; the client is a view.** A session/turn lives in the Session Actor and Event Log; a client attaches and detaches. | §3 lifecycle, §7 cancellation (disconnect ≠ cancel). |
| **I4** | **Downstream of compliance.** No event reaches any transport before compliance-out has run. The wire stream is the post-redaction stream. | §6.3 `compliance.notice`; §9 payment/compliance invariants. |
| **I5** | **Transport is framing, meaning is the contract.** The same turn over any transport emits the same events. | §8 transport bindings; ADR-005 P-1. |
| **I6** | **Forward-compatible by must-ignore.** A renderer ignores unknown event types and unknown fields; additive change never breaks an old client. | §10 versioning. |
| **I7** | **Every message is attributable and ordered.** Commands carry an idempotency key + participant; events carry a per-session sequence and the control-plane SHA. | §4 envelopes. |
| **I8** | **No client-side agent logic.** A client renders and forwards user intent; it never decides retry/dispatch/routing/compliance. | Whole doc; `feedback_cli_backend_boundary.md`. |

---

## 2. The two layers: contract vs transport

```
        ┌──────────────────────────── the CONTRACT (one definition) ────────────────────────────┐
        │  Command family  (client → runtime)      Event family  (runtime → client)              │
        │  Rust enums in a dependency-light contract crate (OSS core, ADR-007)                    │
        │  →  JSON Schema (generated)   →  TypeScript types (generated)   →  Python types (gen.)   │
        └───────────────────────────────────────────────────────────────────────────────────────┘
                                              │  carried, unchanged, by:
        ┌──────────────┬──────────────────────┼──────────────────────┬──────────────────────────┐
     in-proc         gRPC bidi              REST + SSE             WebSocket
   (embedded)     (SDK/IDE/Desktop)     (CI/curl/air-gap/HTTP)   (browser duplex: collab, voice)
        └──────────────┴──────────────────────┴──────────────────────┴──────────────────────────┘
```

- **The contract is authored once as Rust types.** JSON Schema (validation + non-Rust clients), TypeScript types (TS SDK), and Python types (Python SDK) are **generated** from those Rust types in CI (ADR-005 §2.1; `schemars` + Rust→TS discipline, `codex.md` §10). A hand-edit to a generated artifact fails CI (ADR-005 P-10). Wire schema and parser cannot drift.
- **A `Transport` trait** carries the two families across the four bindings (§8). In-proc removes serialization entirely (channel handoff); the network bindings add framing + (de)serialization. Nothing else differs (I5).

---

## 3. Session and turn lifecycle

### 3.1 Session state machine

A **Session** is the Event-Log tree for one conversation (`VENDOR_SYNTHESIS.md` §1.6): turns have stable ids and parent pointers; there is an active branch head; actions/observations correlate by id, so branches survive.

```
            session.open ─────►┌──────────┐
            session.resume ───►│ ATTACHED │◄───── reconnect (session.resume{from_event})
                               └────┬─────┘
                                    │  (transport drops)
                                    ▼
                               ┌──────────┐   turn.submit    ┌──────────┐
                               │ DETACHED │ ───────────────► │  ACTIVE  │  (a turn is running)
                               └────┬─────┘ ◄─────────────── └────┬─────┘
                                    │        turn ends            │
                                    │                             ▼
                                    │                        ┌──────────┐
                                    └───────────────────────►│   IDLE   │  (no turn running, attached or not)
                                            session.close    └────┬─────┘
                                                                  ▼
                                                             ┌──────────┐
                                                             │  CLOSED  │  (Event Log retained per ADR-015)
                                                             └──────────┘
```

- **ATTACHED vs DETACHED is about the transport, not the session.** A DETACHED session with a running turn keeps running (I3) — the turn does not know or care that no client is listening. Reconnecting re-attaches and replays the tail (§7.2).
- **CLOSED** ends the live actor; the Event Log persists (retention/erasure per ADR-015). A closed session can still be *replayed* (`INTERACTION_REPL_COMMANDS.md` §2) but not appended to; `session.resume` on a closed session opens a read-only replay context, not a new active turn.

### 3.2 Turn state machine

A **Turn** is one user-initiated unit of work — the canonical pipeline of `RUNTIME_FEATURE_FLOWS.md` §1.

```
   turn.submit ─► SUBMITTED ─► RUNNING ─┬─────────────────────────────► COMPLETED   (turn.completed)
                                        │                                
                        approval.request│  approval.respond              
                                        ▼                                
                                  AWAITING_APPROVAL ──────────► RUNNING   
                                        │                                
                                turn.stop (any state) ─────────────────► STOPPED     (turn.stopped)
                                        │                                
                                non-retryable error ──────────────────► FAILED       (turn.failed)
```

- **RUNNING** is the agent loop (need-driven; hard iteration cap + deterministic stuck-detector, `RUNTIME_FEATURE_FLOWS.md` step 7; `VENDOR_SYNTHESIS.md` §1.2). It emits content, tool-call, and gate events.
- **AWAITING_APPROVAL** blocks the turn (not the actor — the actor stays responsive to `turn.stop`/`turn.steer` and to other participants) until `approval.respond` (§5) or `turn.stop`. This is the Approval Gate seam (ADR-003; `RUNTIME_FEATURE_FLOWS.md` step 7b).
- **Steer** (`turn.steer`) does not change state — it queues a user interjection delivered at the next safe boundary (`INTERACTION_REPL_COMMANDS.md` §3.3). **Stop** (`turn.stop`) is the only transition to STOPPED and is always immediate and available (§7.1).
- **Terminal states are typed:** COMPLETED (`outcome: complete`), STOPPED (cancelled), FAILED (typed `error`). The SDLC judge-loop's honest `capped` outcome (`SUBSYSTEM_DEEP_DIVES.md` §1) is a `turn.completed{outcome: capped}`, not a FAILED — "could not confirm done" is a truthful completion, not a crash.

### 3.3 Programs (ADR-027) sit above turns

A **Program** (long-horizon, `LONG_HORIZON_PROGRAMS.md`) orchestrates thousands of bounded turns over days/weeks. It rides the same envelope with an additive `program.*` family (§6.6) and a `program_id` correlator on the envelope — no separate protocol. A client that doesn't understand `program.*` ignores it (I6) and still renders every underlying turn correctly.

---

## 4. Envelopes

Every message on the wire is an envelope wrapping a typed body. The envelope is stable across protocol majors far longer than any single body variant — it is the part the resume/ordering/idempotency machinery depends on.

### 4.1 Command envelope (client → runtime)

```jsonc
{
  "protocol_version": "3.2",     // client's protocol version; negotiated at session.open (§10.2)
  "command_id": "c-9f3a…",       // client-minted UUID; idempotency key (ADR-013) — dedups replays (I7)
  "session_id": "s-42a…",        // omitted only on session.open (which mints one)
  "participant_id": "u-priya",   // resolved from JWT sub; total-orders multi-writer collab (INTERACTION §3.2)
  "type": "turn.submit",         // the command discriminator (§5)
  "body": { /* per-type fields */ }
}
```

- **`command_id`** is the exactly-once key: the runtime keeps a bounded dedup ledger (ADR-013); a re-delivered command with a seen `command_id` is acknowledged as a no-op, never re-applied (ADR-005 P-6). This is what makes at-least-once network transports safe.
- **Auth** (the JWT) travels in the transport's auth channel (gRPC metadata / `Authorization` header / WS subprotocol), not in the body — it is validated by the Identity + Policy gate (🔒, `RUNTIME_FEATURE_FLOWS.md` step 2) before any command body is interpreted. `participant_id` is derived from it, never trusted from the body.

### 4.2 Event envelope (runtime → client)

```jsonc
{
  "v": "3.2",                    // schema version of THIS event's body (§10)
  "type": "tool.call.start",     // the event discriminator (§6)
  "session_id": "s-42a…",
  "turn_id": "t-7c1…",           // present for turn-scoped events; absent for session-scoped (e.g. participant.*)
  "program_id": "p-13…",         // present only when the turn belongs to a Program (§3.3)
  "seq": 10427,                  // per-session strictly-monotonic sequence — gap detection + resume (§7.2)
  "ts": "2026-07-18T09:14:22.481Z",
  "control_plane_sha": "a1b2c3…",// the control-repo commit the turn is pinned to (ADR-026 §6.2) — reproducibility
  "body": { /* per-type fields */ }
}
```

- **`seq`** is the ordering + resume backbone: a client detects a gap (missed `seq`) and calls `session.resume{from_event: <last_seen_seq>}` to replay the tail (§7.2). Ordering is total per session (single-writer actor, `codex.md` §9).
- **`control_plane_sha`** ties every event to the exact definitions (prompts/skills/agents/policies) that produced it (ADR-026) — the same value the Event Log records, so live rendering and audit agree (ADR-025).

---

## 5. The Command set (client → runtime)

Complete for v1. Each row is a `type` with a `body`; every command also carries the §4.1 envelope. "Produces" names the primary events the command triggers (full list §6).

| Command | Body (key fields) | Produces | Notes |
|---|---|---|---|
| `session.open` | `profile_id`, `client_info`, `capabilities_wanted?` | `session.snapshot` | Starts a new session for a Surface Profile (`HARNESS_SDK.md`). Handshake carries `protocol_version` (§10.2). Mints `session_id`. |
| `session.resume` | `session_id`, `from_event?` | `session.snapshot` then the replayed tail | Re-attach after disconnect, or continue tomorrow. `from_event` = last-seen `seq`; omitted = full snapshot only (`INTERACTION_REPL_COMMANDS.md` §1.3, `ainxt run --continue`). |
| `session.subscribe` | `session_id`, `mode: observer` | `session.snapshot` + live tail (read-only) | Read-only tail for a dashboard / `ainxt session watch` (`INTERACTION_REPL_COMMANDS.md` §3.9). Cannot submit turns. |
| `session.fork` | `session_id`, `from_turn_id`, `label?` | `session.snapshot` (of the new branch) | Explicit branch to explore an alternative without touching the official line (`INTERACTION_REPL_COMMANDS.md` §3.3). |
| `session.close` | `session_id` | (session → CLOSED) | Ends the live actor; Event Log retained (ADR-015). |
| `turn.submit` | `input` (text + `attachments[]`), `overrides?` | `turn.started` → content/tool/gate events → terminal | The main verb. `overrides` may request a user-selectable model (honored subject to ADR-012 class-eligibility — never overrides a data-class exclusion). |
| `turn.steer` | `turn_id`, `text` | `turn.steer` (echo) | Queued interjection, delivered at next safe boundary — **not** a cancel (§3.2; `INTERACTION_REPL_COMMANDS.md` §3.3). |
| `turn.stop` | `turn_id` | `turn.stopped` | The **only** cancel. Fires the shared cancellation token (§7.1). Idempotent; always available from any authorized participant. |
| `turn.edit` | `turn_id`, `input` | `turn.edit` (echo) → new branch → `turn.started` | Valid only on a *user* turn; creates a sibling branch, never mutates history (`INTERACTION_REPL_COMMANDS.md` §3.1/§3.3). |
| `turn.branch` | `from_turn_id`, `label?` | `turn.branch` (echo) → `session.snapshot` | Named fork (see `session.fork`; kept as a turn-level verb for renderers that branch from within a turn view). |
| `approval.respond` | `approval_id`, `decision`, `feedback?` | (turn resumes) or `turn.stopped` | Answers an `approval.request`. `decision ∈ {approve, approve_for_session, reject}` (tri-state, `VENDOR_SYNTHESIS.md` §1.4). `reject` requires `feedback` (becomes model-visible tool output). **Never valid as a policy auto-decision for a `payment_boundary != none` action** (§9, ADR-016). |
| `program.*` | (per `LONG_HORIZON_PROGRAMS.md`) | `program.*` events | `program.start` / `program.pause` / `program.resume` / `program.checkpoint.respond` — additive; a client that doesn't speak them never needs to (I6). |

**Notes that are load-bearing:**
- **There is no command that dispatches a payment, moves value, or bypasses a gate.** The command set is exhaustive; ADR-016's boundary is enforced by *absence* as well as by policy (ADR-005 P-8).
- **`session.subscribe` observers can never write.** Collaboration writers submit via `turn.*` into the *one* actor inbox, tagged with `participant_id`, and are total-ordered by arrival (`INTERACTION_REPL_COMMANDS.md` §3.2) — there is no multi-writer race to resolve at the data layer.

---

## 6. The typed Event enum (runtime → client)

Grouped by concern. Every event carries the §4.2 envelope. This is the enum ADR-005 §2.3 fixes. **A renderer MUST ignore any `type` it does not recognize (I6).**

### 6.1 Content events (model output, streamed)

| `type` | Body | Meaning |
|---|---|---|
| `text.delta` | `text` | A fragment of assistant prose. Concatenate in `seq` order. (Matches the `HARNESS_SDK.md` §2.2 SDK example.) |
| `reasoning.delta` | `text` | A fragment of model reasoning/"thinking". **Policy-gated** — only streamed to surfaces/roles the Policy Engine (ADR-003) permits; withheld otherwise (ADR-005 residual 4). Separate channel from `text.delta` so a renderer can show/hide it independently (progressive disclosure, `INTERACTION_REPL_COMMANDS.md` §5.1). |

### 6.2 Tool-call lifecycle (always structured, never model-text — I2)

| `type` | Body | Meaning |
|---|---|---|
| `tool.call.start` | `call_id`, `name`, `source` | A tool call is beginning; name is known, args may still stream. `source ∈ {native, mcp, skill}` is a **display label only** — dispatch treats them identically (ADR-002; ADR-005 P-9). |
| `tool.call.delta` | `call_id`, `args_delta` | A fragment of the tool's argument JSON as it streams from the model. |
| `tool.call.stop` | `call_id`, `args` | Arguments fully parsed and validated against the tool's schema; the call is ready to dispatch. |
| `tool.result` | `call_id`, `blocks[]`, `is_error` | The observation fed back to the model. `blocks[]` is the uniform structured result — model-facing content + human-facing display blocks + typed UI blocks (`VENDOR_SYNTHESIS.md` §1.3). `is_error=true` is a *soft* failure fed back to the model, **not** a turn abort (`RUNTIME_FEATURE_FLOWS.md` step 7e). Large output is already two-stage-truncated with an "N omitted" banner (`codex.md` §4) before it appears here. |

### 6.3 Gate events (approval + compliance)

| `type` | Body | Meaning |
|---|---|---|
| `approval.request` | `approval_id`, `action`, `scope`, `risk_tier`, `preview`, `payment_boundary` | The turn is blocked awaiting a decision (Approval Gate, ADR-003). The renderer presents it (rich dialog on Desktop; single blocking `y/n/feedback` on `ainxt run --interactive-approvals`; a pre-declared policy in CI). Client answers with `approval.respond`. If `payment_boundary != none`, an auto/policy decision is refused — a human `approve` is mandatory (§9). |
| `compliance.notice` | `categories[]`, `action` | Tells the renderer *what class* was redacted or audited (`action ∈ {redacted, audited}`), never the raw content (I4; `feedback_redact_dont_block.md`). This is how a user learns "an account number was redacted and the turn proceeded" (`INTERACTION_REPL_COMMANDS.md` §5.2 `compliance_redacted`) without the wire ever carrying the PII (ADR-005 P-7). |

### 6.4 Artifact + accounting

| `type` | Body | Meaning |
|---|---|---|
| `artifact` | `artifact_id`, `kind`, `uri`, `preview?`, `verification?` | A produced artifact reference (docx/pptx/pdf/xlsx/image/source), from the Artifact Runtime. `verification` carries the post-generation artifact-vs-intent check result (`RUNTIME_FEATURE_FLOWS.md` §4.2) — a renderer can show "verified matches your request" vs "returned with caveats". (Matches the `HARNESS_SDK.md` §2.2 `artifact` case.) |
| `usage` | `model`, `input_tokens`, `output_tokens`, `cost`, `cached?` | Token/cost accounting. `model` is the **actually-routed** model (ADR-006/012) — never a placeholder — so a class-ineligible model can never appear here for a regulated turn. (Matches the `HARNESS_SDK.md` §2.2 `usage` case.) |

### 6.5 Lifecycle, error, presence

| `type` | Body | Meaning |
|---|---|---|
| `session.snapshot` | `tree`, `active_head`, `participants[]`, `negotiated_version` | Full current state to a (re)joining client, so a late joiner need not replay from turn zero (`INTERACTION_REPL_COMMANDS.md` §3.4). Sent in response to `session.open`/`resume`/`subscribe`/`fork`. |
| `turn.started` | `turn_id`, `parent_turn_id`, `participant_id`, `model_hint?` | A turn entered RUNNING. The envelope's `control_plane_sha` pins this turn's definitions (ADR-026 §6.2). |
| `turn.rationale` | `turn_id`, `model_tier`, `model`, `capabilities[]`, `sources[]` | The "why this" panel, generated **from the Event Log's own trace** (not a separate explanation system) — audit-grade for free (`INTERACTION_REPL_COMMANDS.md` §5.1). |
| `turn.completed` | `turn_id`, `outcome` | Turn ended. `outcome ∈ {complete, capped}` — `capped` is the honest "judge could not confirm done" (`SUBSYSTEM_DEEP_DIVES.md` §1), not a failure. |
| `turn.stopped` | `turn_id` | Turn cancelled by `turn.stop`; audit-visible, never deleted (`INTERACTION_REPL_COMMANDS.md` §3.3). |
| `turn.failed` | `turn_id`, `error` | Turn ended with a typed, turn-scoped error (§6.5.1). |
| `turn.steer` / `turn.edit` / `turn.branch` | (echo of the command) | Echoed onto the stream so *every* subscriber (collaborators, observers) sees the interjection/branch, not just the sender (`INTERACTION_REPL_COMMANDS.md` §3.8). |
| `error` | `category`, `message`, `retryable`, `recovery` | A **session/stream-level** error (not turn-scoped) — e.g. `protocol_incompatible` at handshake, `capacity` backpressure before a turn starts, `invalid_command`. Distinct from `turn.failed` (which is a turn outcome). |
| `participant.joined` / `.left` / `.typing` / `.viewing` | `participant_id`, `turn_id?` | Presence, broadcast over the same stream (`INTERACTION_REPL_COMMANDS.md` §3.4). Advisory only — never a lock (§3.7 there). |

#### 6.5.1 Typed error taxonomy (the only categories a client renders)

Both `error` and `turn.failed.error` draw from one closed set (`INTERACTION_REPL_COMMANDS.md` §5.2) — never a raw stack trace:

| `category` | Meaning | `retryable` | `recovery` a renderer shows |
|---|---|---|---|
| `capacity` | 503 / backpressure (`RUNTIME_FEATURE_FLOWS.md` step 2) | true | "At capacity — retrying automatically" (auto-backoff) |
| `capability_denied` | RBAC/policy blocked an action (ADR-003) | false | Explain what/why; offer to request access |
| `provider_unavailable` | a model provider failed **and** failover also failed (ADR-006) | true | Shown only after failover attempted; offer retry / switch model |
| `capped` | judge-loop could not confirm completion | false | Show the judge's specific gap report; never claim "done" |
| `ambiguous` | genuinely underspecified request | false | A clarifying question — a conversation turn, not a dead end |
| `protocol_incompatible` | version outside the negotiated N-2 window (§10) | false | "Update your client" with the supported range |
| `invalid_command` | malformed/unknown command or bad envelope | false | Developer-facing; indicates a client bug |

### 6.6 Additive families (designed elsewhere, catalogued here for completeness)

These ride the same envelope; a client ignores any it doesn't implement (I6). Each is fully specified in its home doc.

| Family | Members (examples) | Home |
|---|---|---|
| Notification | `notification.emitted{class, recipient, payload}` | `INTERACTION_REPL_COMMANDS.md` §8 |
| Feedback | `feedback.closed{item_id, change_ref, summary}` | `INTERACTION_REPL_COMMANDS.md` §9 |
| Voice (duplex) | `voice.partial_transcript`, `voice.final_transcript`, `voice.agent_speaking`, `voice.interrupted`, `voice.turn_boundary_candidate` | `INTERACTION_REPL_COMMANDS.md` §10 |
| Program (long-horizon) | `program.started`, `program.module.completed`, `program.checkpoint.request`, `program.paused`, `program.completed` | `LONG_HORIZON_PROGRAMS.md` / ADR-027 |

---

## 7. Cancellation, disconnect, and resume

### 7.1 Cancellation — one token, explicit only

- `turn.stop` fires the turn's **single shared cancellation token** — the one held by the model stream and every in-flight tool future (`RUNTIME_FEATURE_FLOWS.md` step 6; `VENDOR_SYNTHESIS.md` §1.2). Stream + all tool futures abort together; a single `turn.stopped` is emitted; the session returns to IDLE (ADR-005 P-5).
- `turn.stop` is **idempotent** (a second stop on an already-stopping turn is a no-op) and **always available** — a second participant's urgent Stop is never blocked by a first participant's in-progress Steer (`INTERACTION_REPL_COMMANDS.md` §3.3).
- **Steer is not cancel** (§3.2). Barge-in in duplex voice *is* a Stop, but scoped to audio output only (`INTERACTION_REPL_COMMANDS.md` §10.3) — in-flight tool calls still finish at their next safe boundary, never half-executed.

### 7.2 Disconnect ≠ cancel; resume replays the tail (I3)

The single most important operational property of this protocol:

- A transport drop moves the session ATTACHED → DETACHED (§3.1). **The running turn keeps running** in the Session Actor — it has no dependency on a client being connected. Nothing is cancelled (ADR-005 P-4).
- The client reconnects and sends `session.resume{session_id, from_event: <last_seen_seq>}`. The runtime replies with a `session.snapshot` (current tree + `active_head`) and then **replays every event with `seq > from_event`** in order, from the Event Log (`INTERACTION_REPL_COMMANDS.md` §2 mechanics). The client is now caught up with zero lost work.
- If the client was gone long enough that the actor idled out, `session.resume` reconstructs the actor from the Event Log's cached incremental projection (`RUNTIME_FEATURE_FLOWS.md` step 1) — resume is a cold-start-safe operation, not a "hope the actor is still warm" one.
- **This is why the CLI needs no in-process loop.** `ainxt run --continue` (`INTERACTION_REPL_COMMANDS.md` §1.3) is exactly `session.resume` — the conversational loop is a server-side session, not terminal-side state.

### 7.3 Backpressure and flow control

- **Inbound (commands):** the Session Actor's command inbox is **bounded** (`VENDOR_SYNTHESIS.md` §1.2 / §4 anti-pattern: no unbounded channels). When saturated, a further command is rejected with `error{category: capacity, retryable: true}` — the typed form of the platform's 503 back-pressure (`RUNTIME_FEATURE_FLOWS.md` step 2; `core/job_queue.py` discipline; `feedback_scale_2k_users.md`). Never silently dropped, never unbounded-queued (ADR-005 P-12).
- **Outbound (events):** event production is **decoupled** from consumption (`codex.md` §9). A slow subscriber is flow-controlled per-subscriber and, if it falls too far behind its buffer, re-synced with a fresh `session.snapshot` rather than being allowed to stall the engine or the other subscribers (ADR-005 P-13). A slow renderer degrades its own view; it never degrades the turn.

---

## 8. Transport bindings — one contract, four framings

Each binding carries the *same* Command/Event envelopes (§4). Equivalence is a required test, not an aspiration (ADR-005 P-1).

| Binding | Command path | Event path | Cancellation | Primary consumers |
|---|---|---|---|---|
| **in-proc** | push `Command` onto the bounded inbox channel | drain the unbounded event channel | drop/stop via the shared token directly | Embedded runtime (CLI linking the engine; test harness). Zero serialization. |
| **gRPC bidi stream** | client→server stream of `Command` | server→client stream of `Event` | explicit `turn.stop` command (preferred); a client-cancelled gRPC stream **detaches**, it does not cancel the turn (§7.2) | Python/TS SDKs, IDE extension, Desktop |
| **REST + SSE** | `POST /v1/command` (one command per request; returns `{session_id, accepted, command_id}`) | `GET /v1/events?session_id=…&from_event=…` → SSE stream of `Event` (one event per SSE `data:` frame) | `POST /v1/command` with `turn.stop`; SSE reconnect uses `from_event` (native SSE `Last-Event-ID` maps to `seq`) | CI, curl, air-gapped ops, any HTTP-only client, `ainxt --json` |
| **WebSocket** | `Command` frames | `Event` frames | `turn.stop` frame; WS close **detaches** (§7.2) | Browser duplex — collaboration presence, real-time voice (`INTERACTION_REPL_COMMANDS.md` §3/§10) |

**Binding rules:**
- **`seq` is the universal resume cursor.** SSE's `Last-Event-ID`, a gRPC reconnect's `from_event`, and a WS reconnect all resolve to "replay events with `seq >` the cursor" (§7.2). One mechanism, four framings.
- **Disconnect semantics are identical across network bindings:** a dropped connection detaches; only an explicit `turn.stop` cancels (§7.1). This is deliberately *not* "gRPC stream cancel = turn cancel", because a flaky network would otherwise kill long turns.
- **In-proc is not privileged.** It removes serialization; it adds no capability, no extra event, no different ordering. If a behavior appears only in-proc, it is a bug (I5).

---

## 9. Compliance and payment-boundary invariants on the wire

Two invariants are enforced *at the protocol boundary itself*, not merely upstream — because the wire is the point a client (possibly a third-party one) could otherwise observe or influence:

1. **The event stream is strictly post-compliance (I4).** Compliance-out (🔒, `RUNTIME_FEATURE_FLOWS.md` step 8) runs before *any* event is placed on *any* transport. No `text.delta`, `tool.result`, `artifact`, or `reasoning.delta` ever carries un-redacted regulated data; a `compliance.notice` reports the category instead (§6.3). Because the wire stream equals the persisted Event-Log stream, replay and audit see exactly what the user saw (ADR-025; `INTERACTION_REPL_COMMANDS.md` §2.3). Verified by ADR-005 P-7.
2. **No wire path to payment initiation (ADR-016).** There is no command that dispatches a payment (§5 is exhaustive). An `approval.request` whose `payment_boundary != none` **cannot** be satisfied by a policy auto-decision or an SDK convenience default — only an explicit human `approval.respond{decision: approve}` clears it, and that decision is itself audited. A client cannot construct a message that moves value; the boundary is enforced by the *shape of the contract*, not only by policy. Verified by ADR-005 P-8.

Both are consistent with `HARNESS_SDK.md` §4's guarantee that a harness author "cannot disable compliance/RBAC" — here that guarantee is extended to *the protocol a client speaks*: a client cannot disable them either, because it only ever sees the post-gate stream and has no un-gated verb to send.

---

## 10. Versioning and backward-compatibility

### 10.1 What is versioned, and how

- The protocol is semver'd **independently of the runtime binary**: `protocol/MAJOR.MINOR.PATCH`.
  - **PATCH** — clarification/doc only; no wire change.
  - **MINOR** — **additive only**: a new event `type`, a new command `type`, a new *optional* field. Safe for every existing client because of the must-ignore rule (§10.3).
  - **MAJOR** — a breaking change: removing/renaming an event or field, changing a field's type, or changing the *meaning* of an existing field. Gated by the deprecation window (§10.4).
- Each event body carries its own `v` (§4.2) so a mixed-version stream (rare, during a rolling upgrade) is unambiguous.

### 10.2 Handshake and negotiation

- The client sends `protocol_version` in `session.open` (§4.1). The runtime advertises a **supported range** and negotiates the **highest common version**, returned in `session.snapshot.negotiated_version` (§6.5). Both sides then speak that version for the session's life.
- **N-2 major support window:** the runtime supports its current major **plus the two prior majors**. A client older than that gets a clean `error{category: protocol_incompatible, recovery: "<supported range>"}` at handshake — never a partial or corrupt session (ADR-005 P-3). A client *newer* than the runtime is likewise refused cleanly. This window is a config-layered value (ADR-004), sized as a policy knob (ADR-005 residual 2).

### 10.3 The must-ignore rule (the load-bearing forward-compat guarantee — I6)

> **A conforming client MUST ignore an event `type` it does not recognize, and MUST ignore fields it does not recognize within a body it does recognize. It MUST NOT crash, drop the turn, or error the session on either.**

This is what makes the corpus's recurring promise structurally true: *"add a modality → every renderer gets it the moment it's in the enum; no surface-specific plumbing"* (`INTERACTION_REPL_COMMANDS.md` §6/§3.8). A `2.3` client keeps working against a `2.7` runtime that streams new events it has never heard of (ADR-005 P-2). The reference SDKs implement must-ignore centrally so every SDK-based client inherits it; a hand-rolled client that violates it breaks only *its own* forward-compat (ADR-005 residual 1).

### 10.4 Deprecation window

- A field or event marked `deprecated` in major `N` remains present and honored throughout **all of major `N`** and is removed no earlier than major `N+1`. During the window both the old and the replacement coexist, and a contract test asserts both (ADR-005 P-11).
- Deprecations are announced in the protocol changelog shipped with the contract crate; the SDKs surface a build-time deprecation warning, never a silent behavior change.

### 10.5 Enum extensibility

- On the wire, `type` is an **open** discriminator (a string), so an unknown value is representable and ignorable (§10.3). Internally the Rust enums are `#[non_exhaustive]` so adding a variant is a non-breaking library change and every `match` must have a catch-all.

---

## 11. The SDK convenience layer (a view over the contract, never a second contract)

The `HARNESS_SDK.md` §2.2 example shows an SDK loop matching `text.delta`, `tool.call`, `approval.request`, `artifact`, `usage`. That is the **ergonomic layer**, reconciled here (ADR-005 §Alternatives G):

- The **wire** is granular: `tool.call.start` → `tool.call.delta*` → `tool.call.stop` → `tool.result` (§6.2).
- The **SDK optionally coalesces** these into a single `tool.call` event (name + fully-assembled args) for consumers that don't need streaming argument fragments — and passes `text.delta`, `approval.request`, `artifact`, `usage` through unchanged. A consumer that *does* want streaming args subscribes to the raw events instead.
- Coalescing is a **pure client-side transform** over the same ordered stream; it adds no information the wire lacks and removes none the wire guarantees. The wire remains the single contract; the SDK is a thin, generated-type binding with an optional convenience view (`HARNESS_SDK.md` §2.2: "the headless CLI is itself a thin wrapper over this SDK — build once").

---

## 12. Worked examples (illustrative)

### 12.1 A grounded chat turn (Chat profile, `RUNTIME_FEATURE_FLOWS.md` §2.1)

```
→ session.open   {profile_id: "chat", protocol_version: "3.2"}
← session.snapshot {tree: {…}, active_head: null, negotiated_version: "3.2"}
→ turn.submit    {command_id: "c-1", session_id: "s-9", input: {text: "Why did NEFT batch 2026-07-18 lag?"}}
← turn.started   {seq: 1, turn_id: "t-1", control_plane_sha: "a1b2c3"}
← tool.call.start{seq: 2, call_id: "k-1", name: "kb.search", source: "native"}
← tool.call.stop {seq: 3, call_id: "k-1", args: {query: "NEFT settlement lag 2026-07-18"}}
← tool.result    {seq: 4, call_id: "k-1", is_error: false, blocks: [...]}
← text.delta     {seq: 5, text: "The batch lagged because "} …
← turn.rationale {seq: 12, model_tier: "medium", model: "…", sources: ["docs_kb:settlement/…#L120"]}
← usage          {seq: 13, model: "…", input_tokens: 812, output_tokens: 240, cost: 0.0…}
← turn.completed {seq: 14, turn_id: "t-1", outcome: "complete"}
```

### 12.2 A tool call needing approval, then a redaction notice

```
→ turn.submit      {command_id: "c-2", input: {text: "Email the settlement summary to ops@npci.org.in"}}
← turn.started     {seq: 20, turn_id: "t-2"}
← tool.call.start  {seq: 21, call_id: "k-2", name: "connector.email.send", source: "native"}
← tool.call.stop   {seq: 22, call_id: "k-2", args: {to: "ops@npci.org.in", body: "…"}}
← approval.request {seq: 23, approval_id: "a-1", action: "connector.email.send",
                    scope: "domain=*.npci.org.in", risk_tier: "Elevated", payment_boundary: "none"}
→ approval.respond {command_id: "c-3", approval_id: "a-1", decision: "approve_for_session"}
← compliance.notice{seq: 24, categories: ["ACCOUNT_NUMBER"], action: "redacted"}   // a masked number in the body
← tool.result      {seq: 25, call_id: "k-2", is_error: false, blocks: [{text: "sent"}]}
← turn.completed   {seq: 26, outcome: "complete"}
```
(If `payment_boundary` were `initiates-settlement`, `approval.respond` could only be a human `approve` — a policy auto-decision is refused, §9.)

### 12.3 Disconnect mid-turn, then resume (I3, §7.2)

```
← turn.started {seq: 40, turn_id: "t-3"}
← text.delta   {seq: 41, …}          ── transport drops here; the turn keeps running server-side ──
                                        (runtime emits seq 42, 43, 44… into the Event Log)
→ session.resume {command_id: "c-4", session_id: "s-9", from_event: 41}
← session.snapshot {…, active_head: "t-3"}
← text.delta   {seq: 42, …}          // replayed tail — nothing lost
← tool.call.start {seq: 43, …}
← turn.completed  {seq: 45, outcome: "complete"}
```

### 12.4 Version skew (§10)

```
→ session.open {protocol_version: "1.4"}          // runtime current major = 4, N-2 window = [2,3,4]
← error        {category: "protocol_incompatible", retryable: false,
                recovery: "supported protocol range 2.x–4.x; update your client"}
```

---

## 13. Acceptance tests

The protocol's conformance is proven by ADR-005 §5 tests **P-1 … P-14** (transport equivalence, forward-compat must-ignore, version negotiation + N-2, disconnect≠cancel + resume, one-token cancellation, idempotent replay, compliance-upstream, no-payment-path, tool source-agnosticism, schema/type sync, deprecation window, typed backpressure, slow-consumer resync, replay-uses-the-same-enum). This spec adds no separate acceptance table — its correctness *is* those tests, run in the `IMPLEMENTATION_PLAN.md` A3 scenario-matrix harness and the Phase 4 backward-compat contract-test suite.

---

## 14. Clean-room note

All command/event names, the envelope field names, the decision vocabulary (`approve` / `approve_for_session` / `reject`), and the tool-namespacing here are AiNxt's own, and deliberately avoid every vendor identifier flagged in `codex.md` §"CLEAN-ROOM CAUTIONS" / `VENDOR_SYNTHESIS.md` §2 — not `Op`/`EventMsg`, not `Submission`/`submission_loop`, not the `thread/start`·`thread/resume`·`thread/fork`·`turn/start`·`turn/interrupt`·`item/agentMessage/delta` method names, not the `mcp__<server>__<tool>` scheme, not the `allow`/`prompt`/`forbidden` approval spelling. The adopted *patterns* — protocol-first client, dual in-proc/network transport of one contract, typed streaming event enum, `seq`-cursor resume, generated schemas from one source type — are convergent architecture (`VENDOR_SYNTHESIS.md` §0/§1.8), re-implemented originally.
