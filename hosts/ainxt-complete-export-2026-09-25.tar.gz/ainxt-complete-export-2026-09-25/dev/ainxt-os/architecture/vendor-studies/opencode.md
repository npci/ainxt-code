# Vendor Architecture Study — "OpenCode" (Go terminal AI coding assistant)

Clean-room architecture study performed for AiNxt's independent Rust-based AI runtime + CLI.
Scope: architecture and behavioral patterns only. No source code, identifiers, prompt text,
file names, or project-specific terminology from the target were copied. All names below are
paraphrased/generic; where the original project uses a specific term it is called out explicitly
in "Clean-Room Cautions" as something to avoid reusing verbatim.

Target location studied: `other_vendors/opencode-main` (~140 Go files).

## 1. License

MIT License, single copyright holder, 2025. Permissive — no copyleft, no attribution-in-binary
requirement beyond retaining the notice in redistributed copies of the source itself. This means
there is no legal barrier to *reading* the code for architecture learning, but the instruction
here is clean-room regardless: architecture/behavior study only, no code reuse.

## 2. Overall Architecture — Monolithic Single Binary, Not Client-Server

This project is **not** a daemon+client split. It is one process:

- A single Go binary launched by the CLI entry point.
- On startup it: parses flags → loads layered config → opens a local embedded SQL database
  (file-based, auto-migrated) → constructs an in-process "app" object that owns all long-lived
  services → either (a) runs one non-interactive turn and exits, or (b) hands control to an
  interactive terminal UI event loop that lives in the same process and same address space.
- There is no RPC boundary, no separate server process, no localhost port. The "core logic"
  (agent loop, providers, tools, persistence) and the "CLI/UI" are different *packages* in the
  same binary, not different *processes*.
- Separation is achieved purely by package boundaries and a narrow set of interfaces
  (a session service, a message service, a permission service, an agent/runner service). The
  terminal UI layer only ever talks to those service interfaces and to an event-subscription
  mechanism — it never reaches into provider or tool internals directly.
- Non-interactive mode ("run one prompt and print the result, then exit") and interactive mode
  share the exact same core object graph; the only difference is whether a terminal UI event loop
  is attached on top or a single call-and-wait is performed.

**Implication for a from-scratch Rust design:** a monolithic single-binary architecture is a
legitimate, proven choice for a local dev-tool CLI — it avoids IPC complexity entirely. The
separation of concerns that matters is *modular boundaries inside one process* (trait/interface
boundaries between UI, orchestration, providers, tools, storage), not physical process
separation. If AiNxt's own CLI needs a client-server split (e.g., to share a long-lived agent
session across multiple terminal attach points, or to keep secrets out of a UI process), that is
an intentional deviation from this reference, not something inherited from it.

## 3. Provider Abstraction

Multiple LLM vendors are modeled behind one small interface with exactly three methods:
"send a full request and get one response back", "send a request and get a stream of typed
events back", and "report which model is currently bound." Every concrete vendor client
(a large-vendor chat API, a second large-vendor chat API, an OpenAI-compatible-schema family that
several other vendors and self-hosted/local endpoints all reuse, and a cloud-hosted enterprise
variant of the first vendor) implements only two private methods — synchronous send and
streaming send — and a small generic wrapper struct adapts each concrete client to the public
three-method interface. This generic-wrapper-over-a-narrow-private-interface pattern means adding
a new vendor requires writing exactly one new client type; nothing else in the system changes.

Key design points:
- **Config-driven selection, not hardcoded.** A model registry is a static table of model
  records: id, display name, owning vendor, the vendor's own wire-format model string, four
  separate price-per-million-token figures (input, output, cached-input, cached-output), context
  window size, a default max-output-tokens, and two capability booleans (supports extended
  "thinking"/reasoning, supports image/file attachments). Distinct named "agent roles" (a primary
  coding agent, a lightweight session-title generator, a conversation summarizer, and a
  spawned-subtask agent) are each independently bound to a model id in config; a factory function
  looks up the role's configured model id in the registry, resolves the owning vendor, resolves
  that vendor's API key/settings, and constructs the right concrete client with the right options
  — all driven by data, never by an if/else on vendor name at the call site.
- **Vendor-family reuse via base-URL swapping.** Several "vendors" are really just the OpenAI
  wire format pointed at a different base URL and extra headers (a fast-inference vendor, an
  aggregator/router vendor, an xAI-compatible vendor, and a local/self-hosted OpenAI-compatible
  endpoint all reuse the same OpenAI-shaped client with different `base_url` + header options).
  This avoids writing four near-duplicate HTTP clients.
- **Streaming as a typed event enum**, not raw text chunks: distinct event variants exist for
  "content-start", "content-delta" (a text fragment), "thinking-delta" (reasoning-stream
  fragment, for models that expose intermediate reasoning), "tool-call-start" /
  "tool-call-input-delta" / "tool-call-stop" (a tool invocation being streamed in piecemeal,
  since some vendors stream function-call arguments token-by-token as JSON fragments),
  "complete" (carries the final aggregated response plus normalized token-usage numbers and a
  normalized finish-reason), "error", and "warning". The orchestration layer consumes this single
  channel of typed events regardless of which vendor produced them — each vendor client is
  responsible for translating its own wire protocol into this shared event vocabulary.
- **Cost accounting is normalized centrally**, not per-vendor: usage numbers (input tokens,
  output tokens, cache-write tokens, cache-read tokens) come back on the shared response type,
  and a single formula in the orchestration layer multiplies them against the model registry's
  four price fields to get a running dollar cost per conversation, regardless of vendor.
- **Retry/backoff and rate-limit handling live inside each vendor client**, not in the shared
  interface — a fixed max-retries constant is defined once and referenced by convention, but each
  client is free to interpret vendor-specific error codes (e.g., overloaded/rate-limited) itself.
- One "provider" in the registry is a stub explicitly marked not-yet-implemented (a
  mock/test provider that panics if selected) — evidence the interface is designed to be
  satisfied gradually, vendor by vendor.

## 4. Agent / Session Model

- **Session** is a persisted row: id, optional parent-session id (used for two special session
  kinds described below), title, running message count, running prompt/completion token totals,
  a running dollar cost, and — notably — a nullable "summary message id" that marks where a
  rolling summarization checkpoint lives in the message history.
- Three session id conventions layered on the same table:
  1. Ordinary user-visible conversation sessions.
  2. **Ephemeral title-generation sessions** — spawned with a deterministic id derived from the
     parent session id, used purely to ask a cheap model "write a short title for this," then
     discarded from the user's view.
  3. **Sub-agent/task sessions** — when the agent spawns a delegated sub-task (see §5, the
     "delegate to a fresh agent" tool), a new session is created whose id *is* the originating
     tool-call id and whose parent-session id points back at the caller. This means the whole
     session tree is queryable/auditable via the parent-pointer chain, and the cost of the child
     session is rolled up into the parent's running cost after the child finishes.
- **Message** persistence stores role (user/assistant/tool) and a JSON-serialized array of
  typed "content parts" — text, reasoning/thinking text, image-by-URL, inline binary attachment,
  a tool-call (with id/name/raw-JSON-input, filled in incrementally as streaming deltas arrive),
  a tool-result (linked back to the call id, with an is-error flag), and a terminal "finish"
  marker carrying a normalized finish-reason and a timestamp. Each part type is tagged with a
  discriminator string so the same array can be deserialized back into the right Go type — a
  manual tagged-union encoding, since the host language has no native sum-type-with-serde.
- **The agent loop itself** is a synchronous request/response loop per turn, run in a background
  goroutine per session, guarded by a "one in-flight run per session id" map (a session busy with
  a request rejects a second concurrent request rather than queuing it). Loop shape: list prior
  messages for the session → if history is empty, fire off async title generation → check for an
  existing summary checkpoint and, if present, splice history to start from it → append the new
  user message → **iterate**: stream a response from the provider, materialize it into a
  persisted assistant message part-by-part as events arrive, then if the turn ended because the
  model requested tool calls, execute each tool call in order (respecting a permission gate — see
  §5), persist the tool results as a new message, and loop again feeding the tool results back in
  as context; the loop only terminates when a turn ends *without* a pending tool-use finish
  reason. There is no fixed iteration cap in this implementation — it runs until the model stops
  asking for tools (contrast with AiNxt's own orchestrator, which caps at a small fixed number of
  iterations; that cap is a deliberate AiNxt safety choice, not something present here).
- **Cancellation** is per-session context cancellation stored in a concurrent map; cancelling
  mid-stream marks the in-progress assistant message with a "canceled" finish reason and, for any
  tool calls that hadn't started yet, synthesizes error tool-results marking them canceled too, so
  history stays consistent even on abort.
- **Summarization** is a first-class, separately-modeled operation, not a side effect of hitting a
  context limit automatically inside the main loop: it's invoked as an explicit action, uses a
  third, differently-configured model (deliberately allowed to be cheaper/different from the main
  coding model), fetches full history, appends a fixed "summarize our conversation so far,
  focusing on what would help continue it" instruction, sends that off, and on success writes the
  summary as a new assistant message and records its id as the session's summary checkpoint —
  every subsequent turn then starts history-loading from that checkpoint forward, effectively
  compacting context without deleting the original messages from storage. Progress of this
  operation is streamed to any UI listener as a sequence of named-stage events (analyzing →
  generating → creating checkpoint → done), which is a nice UX pattern for a long-running
  background op with no natural token-by-token stream of its own.
- **Persistence** is a local embedded SQL database file inside a per-project dot-directory, opened
  with WAL journaling and a generated type-safe query layer (queries defined once, code-generated
  into typed accessor functions); schema migrations are plain versioned SQL files applied
  automatically and idempotently on every startup via an embedded migration runner. There is no
  external database dependency at all — the whole persistence layer is one file on disk per
  project/working directory.

## 5. Tool System

- A tool is anything satisfying a two-method interface: "describe yourself" (name, free-text
  description — often a fairly long multi-paragraph usage guide embedded as a string constant,
  parameter JSON-schema, required-field list) and "execute yourself" (given a tool-call id/name/
  raw-JSON-input string and a context, return a text-or-image response plus an optional
  JSON-serialized metadata blob, or an error).
- The default tool roster covers: run-a-shell-command (with an explicit denylist of networking/
  browser-launching binaries, a separate allowlist of commands considered safe-enough to
  auto-approve without a permission prompt such as read-only git/go/filesystem inspection
  commands, output truncation with a "first half / last half + elided-line-count" strategy for
  huge output, and a **persistent shell session per working directory** so environment variables
  and `cd` state survive across calls within one run); structural file edit (targeted
  find-and-replace within a file); a JSON-patch-style structured file editor; whole-file write;
  file view/read; glob file matching; regex content grep; directory listing; an HTTP fetch tool
  (also gated by the permission service); a code-search-engine integration tool; an
  LSP-diagnostics tool (only registered at all if at least one language server is actually
  configured/running); and a "delegate" tool (see below).
- **Permission/approval model**: a separate service, not baked into each tool, holds (a) a list
  of already-granted (tool-name, action, path, session-id) tuples for the current process
  lifetime, (b) a set of session ids marked fully auto-approved (used for non-interactive/
  scripted runs so there's no one to prompt), and (c) a map of currently-pending request ids to a
  one-shot response channel. A tool that wants to do something sensitive builds a permission
  request (session id, tool name, a human-readable description of the specific action, the
  directory it touches, and the raw params) and calls a blocking "ask" function: if the session is
  auto-approved or an identical (tool, action, path, session) grant already exists, it returns
  true immediately with no prompt; otherwise it registers a response channel, **publishes an
  event onto the same pub/sub bus the UI is subscribed to** (so the terminal UI renders an
  interactive Y/N/"always allow this" dialog), and blocks on the channel until the UI layer calls
  either "grant once", "grant and remember for this session", or "deny". This is a clean
  decoupling: tools don't know a UI exists; they just make a blocking call into a service, and
  whatever is subscribed to that service's event stream (a terminal dialog today, conceivably a
  different UI tomorrow) is responsible for eventually answering it.
- **Sub-agent delegation** is itself modeled as a tool: given a free-text task description, it
  spins up a brand-new agent instance restricted to a read-only subset of tools (search/list/read,
  explicitly excluding shell/edit/write), gives it its own child session parented to the caller's
  session, runs it to completion synchronously from the calling tool's point of view, rolls the
  child's accumulated cost into the parent session, and returns the child's final text as the
  tool's result. The delegated agent is explicitly stateless/one-shot — the calling model is told
  up front (in the tool's description text) that it cannot have a back-and-forth with the
  sub-agent, only issue one fully-specified task and receive one final report.
- **External tool extensibility** is via a standardized model-context protocol: configured
  external tool servers (either spawned as a local subprocess communicating over stdio, or
  reached over a network streaming-events endpoint) are queried once at startup for their tool
  list, and each remote tool is wrapped in an adapter that satisfies the same local tool interface
  — namespaced by prefixing the server's configured name onto the remote tool's name to avoid
  collisions. Each invocation of a remote tool still goes through the same central permission gate
  as a local tool before the remote call is made.

## 6. Terminal UI Approach and How It Talks to Core

- Built on an Elm-architecture-style terminal UI framework (single immutable-ish model struct,
  a pure `update(model, msg) -> (model, cmd)` function, a pure `view(model) -> string` render
  function, driven by an underlying terminal-cell-diffing renderer). The whole interactive
  experience — chat pane, sidebar, message list, editor/input box, and a stack of modal dialogs
  (session switcher, command palette, model picker, theme picker, help, quit-confirm,
  file-picker, permission-approval dialog) — is composed of nested sub-models following the same
  pattern, laid out via a small flex/split/overlay layout helper library.
- **Core-to-UI communication is pub/sub, not polling.** A small generic broker type (subscribe
  gets you a buffered channel; publish fans out non-blockingly to all current subscribers, and a
  full subscriber channel simply drops the event rather than blocking the publisher) is embedded
  into every long-lived service — sessions, messages, permissions, the agent runner, and the
  logging subsystem all embed one. At startup, one goroutine per service subscribes to that
  service's event channel and forwards everything into a single shared channel that gets pumped
  into the UI framework's event loop as an opaque incoming message; the UI's `update` function
  pattern-matches on the concrete event payload type to decide how to react (append a message
  bubble, update a streaming assistant message in place, pop up a permission dialog, etc). Slow
  UI consumption is handled by a timeout-based drop-with-a-warning-log rather than ever blocking
  a background worker.
- **UI-to-core communication** is direct method calls into the same service interfaces (e.g., the
  editor component calls the agent-runner's "run" method directly when the user hits enter; a
  dialog calls the permission service's "grant" method directly when the user answers a prompt).
  There is no message-queue indirection in this direction — only core-to-UI is event-driven,
  UI-to-core is a normal function call, because they're in the same process and address space.
- **Non-interactive mode bypasses the whole UI framework**: it's a completely separate code path
  in the entry point that creates a session, auto-approves all permissions for it, calls the same
  agent-run method, blocks on a result channel, and prints formatted output. This is a clean
  illustration of the UI being a strictly optional attachment on top of core services rather than
  something core logic is built inside of.
- Panics inside the UI message-handling goroutine or inside the agent-run goroutine are
  recovered centrally by a shared panic-recovery helper that logs and, for the UI case, attempts
  to quit the terminal program cleanly rather than corrupting the terminal state.

## 7. Config, Auth, Extensibility

- **Layered config**: defaults set in code → a config-management library reads a global
  per-user config file (searched across a few conventional locations, plus environment-variable
  overrides using an app-specific env-var prefix) → a project-local config file in the current
  working directory is separately loaded and *merged* on top. There's also a fixed, hardcoded list
  of "context file" filenames the tool will look for in a project root — deliberately including
  the conventional filenames used by several *other* well-known AI coding tools, so a project that
  already documents itself for one tool gets picked up automatically by this one too. Config is a
  single global struct behind a package-level getter, initialized once (calling load twice is a
  no-op returning the same instance), not something threaded explicitly through every call site —
  a pragmatic but somewhat anti-modular choice worth noting for a Rust rewrite (see §8/cautions).
- **Auth is entirely bring-your-own-API-key**, read from environment variables per vendor, or from
  vendor-specific credential-cache files on disk for one special case (a vendor that piggybacks on
  a separate developer-tool's OAuth token cache rather than issuing its own key) with a documented
  fallback across a couple of possible file locations/formats depending on host OS. There is no
  centralized login flow, token refresh, or SSO — each vendor's own key material is looked up
  independently at config-validation time, and a provider with no resolvable key is marked
  disabled.
- **Startup config validation actively repairs itself**: if a configured model id doesn't exist
  in the static model registry, or its vendor has no key/is disabled, or `max_tokens` is zero/
  negative/exceeds half the model's context window, or a "reasoning effort" setting is invalid or
  set on a model that doesn't support reasoning — validation logs a warning and **silently
  rewrites the in-memory config to a computed default** (walking down an ordered preference list
  of vendors by whichever has usable credentials) rather than failing startup. Only "no provider
  at all is usable" is a hard error.
- **Extensibility surface**: (a) language servers — a map of language-id to spawn command/args,
  each started in the background at app startup, wrapped in a JSON-RPC-over-stdio client that
  tracks open files, forwards diagnostics into an in-memory cache exposed to a diagnostics tool,
  and is cleanly shut down on exit; (b) the external tool-server protocol described in §5, over
  either local subprocess or remote streaming transport; there is no separate "plugin" system
  beyond these two — no dynamic code loading, no WASM sandboxing, no scripting hooks.

## 8. Notable Architectural Decisions — Concurrency & Messaging

- **Generic pub/sub broker as the one messaging primitive.** Rather than bespoke observer patterns
  per service, one small generic type is reused for sessions, messages, permissions, agent events,
  and logs. Its two safety properties worth keeping in a Rust design: (1) publish is
  non-blocking-per-subscriber (a full subscriber buffer drops the event instead of stalling the
  publisher — protects background workers from a slow UI), and (2) subscriber lifetime is tied to
  a passed-in cancellation context, with cleanup fully mutex-guarded against a concurrent broker
  shutdown, avoiding both leaks and double-close panics.
- **Goroutine-per-background-operation with structured cancellation**, not a global worker pool:
  every agent run, every title generation, every summarization, every LSP client, every event
  forwarder is its own goroutine tied to a context that a parent explicitly cancels on shutdown,
  with explicit WaitGroups so shutdown can block until everything has actually stopped (with a
  timeout fallback that gives up and force-closes channels rather than hanging forever on exit).
- **A concurrent map keyed by session id holding cancellation functions** is the mechanism for
  both (a) preventing two concurrent runs on one session and (b) allowing an external "cancel"
  call to reach into a specific in-flight background goroutine — a simple, low-ceremony way to get
  per-conversation cancellation without a supervisor actor or task registry abstraction.
- **Streaming events are a closed Go channel of a tagged union struct**, consumed with a `for
  range` loop in the orchestration layer; incremental UI updates happen by re-publishing the
  in-progress message on every delta (the "assistant message" object is mutated part-by-part in
  memory and re-persisted/re-published on every single token/delta), which is simple to reason
  about but does mean a write-and-publish round trip to storage on every streamed token — a
  reasonable dev-tool tradeoff, but a place a high-throughput Rust rewrite might choose to batch/
  coalesce instead.
- **No actor framework, no async runtime abstraction beyond the language's built-in goroutines/
  channels/context** — concurrency primitives are used directly and consistently rather than
  wrapped in a heavier framework. This "boring, direct concurrency" style is itself a transferable
  lesson: the system doesn't need an elaborate actor/message-bus library to get correctness; a
  disciplined convention (context-scoped goroutines + channels + a couple of generic helper types)
  is sufficient at this scale.

---

## CLEAN-ROOM CAUTIONS — do not reuse verbatim

- **Project/product name, package import path, and binary name** used throughout (appears as an
  org/repo name, a CLI binary name, and as a default `User-Agent`/`X-Title` HTTP header value
  sent to at least one aggregator vendor, and in commit-message trailer text embedded in one
  tool's prompt). None of this should appear anywhere in AiNxt's own code, config file names, or
  generated commit messages.
- **The dotfile/config file naming convention** (`.<toolname>.json` in home directory and in
  `$XDG_CONFIG_HOME/<toolname>`, plus a per-project dot-directory of the same name for the local
  SQLite file) and the **specific list of "context file" filenames** it auto-discovers (which
  includes several *other* AI tools' conventional instruction-file names verbatim, plus its own
  three casing variants of its own name) — do not copy this literal filename list; AiNxt should
  decide its own convention deliberately rather than inheriting this exact set.
  Separately note: `CLAUDE.md` is in that discovered list — AiNxt already treats that file as
  load-bearing convention for Claude Code itself, so there is a real naming collision risk to be
  aware of, not a reason to copy the vendor's list.
- **The bash-tool "description" string is, almost verbatim, a well-known coding assistant's own
  system-prompt instructions for its shell tool** — including multi-paragraph git-commit and
  pull-request workflow instructions, a `<commit_analysis>`/`<pr_analysis>` tag convention, and a
  literal commit trailer with that *other* assistant's own name and a "🤖 Generated with
  <toolname>" signature. This is a clear example of prompt content lifted from elsewhere and is
  exactly the category of material (identifiers, phrasing, tag names, signature strings) this
  study must not carry into AiNxt. If AiNxt wants an equivalent shell-tool prompt, it must be
  written fresh, in AiNxt's own words, with AiNxt's own commit-signature convention (which is
  already defined separately for AiNxt's own tooling) — never this vendor's phrasing.
- **Specific model-id constants and default-model-per-vendor tables** (exact model name strings,
  per-vendor default fallback order, hardcoded price-per-million-token figures) are this vendor's
  point-in-time product decisions tied to its own commercial relationships (e.g., a special
  integration with one vendor's IDE-subscription OAuth cache as a first-class credential source,
  ranked first in its default provider preference order) — AiNxt's own model tiering and
  provider-preference order is already defined independently in AiNxt's own policy and must not
  be replaced or influenced by this vendor's ordering/defaults.
- **Exact permission-dialog action vocabulary and exact tool/session/event struct field names**
  (e.g., specific event-type name strings, specific dialog key-bindings) — fine as *inspiration*
  for a UX flow, not to be copied as literal identifiers/strings in AiNxt's Rust code.
- **The MCP client-identity string it sends on every remote-tool-server handshake** (its own
  product name + version) — AiNxt's own MCP client identity is a separate, deliberate choice and
  must announce AiNxt's own identity only.

---

## DESIGN LESSONS FOR AiNxt

**Transferable ideas:**

1. **Monolithic-by-default is fine for a local dev CLI.** Don't reach for a client-server split
   just because "real" platforms have one — AiNxt's own gateway/worker split exists for very
   different reasons (multi-tenant SaaS, RQ back-pressure, PCI compliance gating across many
   concurrent users). A local single-user Rust CLI runtime has none of those pressures by default;
   a single-process design with clean internal module boundaries (traits for provider, tool,
   session-store, permission-gate) gets most of the benefit with none of the IPC complexity. If
   AiNxt's CLI *does* need a persistent background agent process (e.g., to survive terminal
   detach, or to share one session across multiple attached terminals), that should be a
   deliberate, separately-justified design decision — not cargo-culted from a project that doesn't
   need it either.
2. **One narrow provider trait, a data-driven model registry, and family-level reuse for
   OpenAI-schema-compatible vendors.** Concretely: define a `Provider` trait with just
   "send", "stream", "model" — nothing vendor-specific leaks through it. Put per-model metadata
   (pricing, context window, capability flags) in one static table keyed by model id, and drive
   *all* model selection through that table plus a config lookup — never an `if vendor ==
   "anthropic"` scattered through business logic. For any vendor whose wire API is
   OpenAI-schema-compatible (many are), implement one HTTP client parameterized by base-URL/
   headers instead of N duplicate clients — this alone probably halves the provider code.
3. **A typed streaming-event enum decouples the agent loop from every vendor's wire format**, and
   is the single most valuable abstraction to get right early: content delta, reasoning/thinking
   delta, tool-call start/delta/stop, complete-with-usage, error. If AiNxt's Rust runtime defines
   this enum once, both the orchestrator/agent loop and every future vendor integration and every
   consumer (TUI, headless mode, IDE bridge) stay decoupled from vendor-specific streaming
   protocols.
4. **Decouple "a tool wants to do something risky" from "who answers that question."** A tool
   should never know whether a human is watching a terminal, a CLI is running headless with
   auto-approve, or a future GUI/IDE surface is attached — it should just make a blocking call
   into a permission-gate abstraction and let whatever's subscribed to that gate's event stream
   answer. This is directly reusable and maps cleanly onto AiNxt's own compliance-gate philosophy
   of intercepting at one seam rather than scattering checks through every tool implementation.
5. **A pub/sub event bus embedded in each service (not ad hoc callbacks) is what lets a UI be a
   strictly optional attachment.** Every core service publishing to a shared, non-blocking,
   drop-on-full-buffer broker — and the UI being nothing more than "one more subscriber" — is why
   this project's non-interactive/headless mode is trivially a few dozen lines: it's core logic
   with zero UI subscribers attached. AiNxt's Rust CLI should adopt the same posture: core
   agent/session/tool logic must be fully operable and testable with no UI subscribed at all, and
   "attach a TUI" should mean "start subscribing to the existing event stream," never "restructure
   core logic to know about the UI."
6. **Model config validation should repair, not just reject, in a local dev tool** — falling back
   through an ordered preference list of "whichever vendor has a usable credential" when a
   configured model/vendor turns out to be unusable is good defensive UX for a tool that runs on
   many different developers' machines with different credentials configured. This is a pattern
   AiNxt's own CLI (which per project convention must point only at the AiNxt gateway, not at raw
   vendor keys) would adapt differently — the *validate-and-self-heal* posture is the transferable
   part, not the specific vendor-preference mechanism.
7. **Sub-agent delegation as "just another tool" that spins up a fresh, tool-restricted,
   single-shot agent instance with its own child session** is a clean, small pattern for
   controlled multi-agent fan-out without a general workflow/orchestration engine. Note this
   directly parallels — and validates — AiNxt's own already-decided direction of doing multi-agent
   work as in-feature orchestrator calls into a runnable-agent abstraction, rather than building a
   generic workflow/DAG engine for it.

**Anti-patterns / things to deliberately avoid:**

- **A single mutable global config struct behind a process-wide getter**, initialized once with
  a "second call is a no-op" guard, and mutated in place by validation logic. This makes the
  config implicitly global mutable state threaded through the whole codebase via a bare function
  call rather than explicit dependency injection, which will hurt testability far more in a
  strictly-typed Rust codebase (where you'd rather pass an `Arc<Config>` explicitly) than it does
  here. Prefer explicit config ownership/threading in the Rust runtime.
- **Persisting and re-publishing the full message object on every single streamed token/delta**
  is simple but means a storage write on every delta of every response — fine at hobby-CLI single
  session scale, likely wasteful if AiNxt's Rust runtime ever wants tighter latency or to batch
  writes; consider coalescing writes (e.g., time- or size-windowed) while still publishing every
  delta to in-memory subscribers immediately.
- **No hard cap on agent-loop tool-use iterations** in the main run loop (it loops until the model
  stops requesting tools, with no explicit max-iteration guard visible at that layer) — this is a
  real runaway-loop/runaway-cost risk pattern to explicitly avoid; AiNxt's own orchestrator's fixed
  iteration cap is the safer default and should be kept, not relaxed, in the Rust rewrite.
- **A large free-text instructional prompt embedded as a Go string constant, mixing tool
  usage rules with unrelated, extensive git/PR-workflow procedure text** inside one tool's
  description — this bloats every request's context with a huge fixed prompt for one tool
  regardless of whether the current task ever touches git, and (per the caution above) the actual
  content here was lifted from another product. Keep tool descriptions minimal and scoped to what
  the tool itself does; put broader workflow guidance in a system prompt layer that can be
  conditionally included, not permanently baked into a single tool's schema description.
- **Silent auto-repair of misconfiguration by rewriting config to a guessed default** is good for
  a zero-friction hobby CLI but is exactly the kind of implicit, unaudited self-modifying behavior
  AiNxt's own engineering-platform conventions push against (config/behavior should be explicit
  and observable, especially anything security/compliance-adjacent) — if adapted at all, any
  self-healing config behavior in AiNxt's CLI should log loudly and surface to the user/operator,
  never silently persist a guessed change to a config file on disk.
