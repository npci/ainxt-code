# Vendor Architecture Study — "Grok Build" (Rust terminal AI coding agent)

Clean-room study only. No source code, identifiers, comments, prompts, file
names, or folder layouts were copied. Everything below is a description of
*behavior and structure*, written independently, for use in designing
AiNxt's own Rust-based agent runtime + CLI. Where a design choice is
transferable, it is described abstractly (pattern, not implementation).

Studied tree: `other_vendors/grok-build-main 2` (path contains a space —
must be quoted in shell commands). Source revision pinned via a
`SOURCE_REV` file recording a monorepo commit SHA; the tree is a periodic
export from a larger internal monorepo, not the whole product.

## 1. Licensing

- Root license: **Apache License 2.0**, copyright held by the vendor
  (2023–2026). Applies to all first-party crates under `crates/`.
- Third-party exceptions, all clearly isolated:
  - Four small vendored crates under a `third_party/` directory (a graph
    layout library, a graph data-structure library, a Mermaid-diagram
    render pipeline, and an ordered-hashmap utility) are **MIT-licensed**
    by a different named copyright holder, not the main vendor. They are
    vendored (copied into the tree, given their own `Cargo.toml`) rather
    than pulled from crates.io, presumably because they needed patches.
  - One tool-implementation crate (the tool-runtime/toolset crate) contains
    a subdirectory of files explicitly documented as **ported/translated**
    from two other open-source coding-agent projects — one Apache-2.0
    licensed, one MIT-licensed. The crate carries its own
    `THIRD_PARTY_NOTICES.md` with full license text reproduction and an
    explicit "Apache §4(b) change notice" stating the files were modified
    (translated to Rust, adapted to the local tool trait, extended).
    A root-level `THIRD-PARTY-NOTICES` file also indexes this.
  - A `bin/` directory ships a hermetic tool-fetch shim (a small
    single-purpose downloader executable format) used only to fetch a
    protobuf compiler at build time; not part of the shipped product.
- No sub-directory carries a more restrictive (e.g. GPL/AGPL/BSL) license.
  The MIT-licensed vendored crates are permissive and compatible with
  Apache-2.0 aggregation.
- Practical takeaway for a clean-room study: this project is itself
  downstream of two *other* open-source agent CLIs (one from a large lab,
  one from a smaller startup). If AiNxt ever wants prior art on tool
  implementations (file edit, grep, bash, read), those two upstream
  projects are the primal sources — worth studying directly and citing
  their own licenses rather than treating this vendor's translated copies
  as the origin.

## 2. Workspace / crate decomposition

Single Cargo workspace, ~90 members, organized into four top-level buckets
by role rather than by feature:

- **`crates/codegen/*`** — the bulk of the product. Roughly three
  weight classes:
  1. **The composition-root binary crate** — thin `main()` that wires
     everything else together and produces the shipped executable.
  2. **The TUI crate** — the full-screen terminal renderer: scrollback,
     input widgets, modals, views, rendering. No agent logic; only
     presentation and input routing.
  3. **The agent-runtime crate** — the largest crate by file count. Owns
     the per-conversation actor, tool dispatch, MCP client integration,
     compaction triggers, memory, plan-approval state machine, goal/
     subagent orchestration, session persistence, feedback collection.
     This crate is UI-agnostic: it exposes an RPC-like protocol so it can
     run standalone (headless, embedded in an editor, or driving the TUI).
  4. A long tail of **single-purpose leaf crates**: auth, config
     (multi-layer: user file, managed/enterprise policy, remote flags,
     signed policy overrides), secrets/redaction, sandbox policy,
     terminal utilities (raw-mode helpers, TTY capability probing), Git
     status/diff, file-system utilities, path resolution, markdown
     rendering + syntax highlighting, Mermaid-diagram rendering, a
     lightweight embedded pager (used for `$PAGER`/transcript viewing,
     distinct from the main TUI), plugin marketplace client, update
     checker, version metadata, voice (STT/TTS), telemetry/analytics
     client, hooks/plugin type definitions, subagent name resolution,
     token estimation, tracing macros, SQLite-backed append log,
     fast worktree helpers (git worktree pooling), a small actor-style
     model-request sampler (see §5), and default-model-ID metadata loaded
     from an embedded JSON file (so model IDs are data, not code — this is
     the "model registry" pattern).
  Each is its own crate specifically so `cargo check -p <crate>` stays
  fast; the README explicitly tells contributors never to build the whole
  workspace during iteration.
- **`crates/common/*`** — cross-cutting infrastructure shared by the agent
  runtime and (potentially) other hosts: a generic circuit breaker with a
  per-key registry, a JSON-RPC-shaped "tool protocol" (wire envelopes,
  capability negotiation, handshake, error codes — independent of any
  specific tool), a "tool runtime" crate (the `Tool` trait + streaming
  primitives, described in §6), a compaction library (three*distinct*
  compaction strategies, see below), a mid-turn "interjection" buffer
  (letting the user inject a message while the agent is mid-turn without
  corrupting turn state), and a small "computer-use" abstraction (local vs.
  remote execution backend + an SDK for a hosted "computer hub" service —
  i.e. an optional cloud sandbox backend, pluggable behind a trait).
- **`crates/build/*`** — a single proto-codegen crate (build-script only).
- **`prod/mc/*`** — one tiny crate of shared wire types for an internal
  feedback/telemetry proxy; clearly a thin seam into the vendor's larger
  monorepo rather than a general-purpose component.
- **`third_party/*`** — vendored MIT dependencies (see §1).

**Decomposition philosophy observed:** protocol/types crates are split
from their implementations (a "tool-protocol" wire-format crate is
separate from "tool-runtime" trait/execution, separate again from the
concrete tool implementations crate). Similarly sampling has a
"sampling-types" crate (pure data) separate from the "sampler" crate
(actor + HTTP). This buys two things: (1) the type crates can be depended
on by both the TUI and headless/ACP-embedded hosts without pulling in
tokio/reqwest/etc., and (2) compile-time isolation — a change to HTTP
plumbing never triggers a rebuild of pure data types consumed everywhere.
A recurring comment pattern in the larger crates explicitly "quarantines"
a dependency-version-incompatible library (e.g. an MCP client library
needing a newer HTTP client major version than the rest of the workspace)
inside its own crate so the version conflict doesn't propagate outward.

## 3. Terminal UX / TUI (priority focus)

- **Library stack:** `ratatui` (with an "unstable-widget-ref" feature) on
  top of `crossterm` (with event-stream + bracketed-paste features). This
  is the standard modern Rust TUI combination, not a custom renderer.
  Two small wrapper crates exist in the codegen bucket for a ratatui
  inline-viewport helper and a ratatui-based textarea widget — thin
  conveniences, not replacements.
- **Two screen modes:** a full "fullscreen" alternate-screen mode and a
  "minimal"/inline mode that renders into the normal scrollback (like a
  REPL) rather than taking the alternate screen. Users can switch between
  them at runtime with a one-shot re-exec of the process (state is
  preserved across the relaunch via a startup-materialization struct).
  There is also a distinct embedded pager crate for viewing long
  transcripts/output (its own minimal ratatui app, separate from the main
  TUI's own transcript view), invoked by shelling out conceptually like
  `$PAGER` but built in.
- **Rendering architecture:** a `AppView`-centric design — one large
  struct owns *all* UI state (auth state, active view, per-agent tabs,
  modals, scrollback, appearance/theme, permission-queue, voice state,
  etc.) and a pure-ish `draw()` renders it each frame. Input handling and
  IO are explicitly kept out of the render/state layer: the event loop
  documentation states its own job is *only* "IO plumbing" — terminal
  events, an internal async channel from the agent runtime, spawned task
  results, animation ticks, hot-reloadable config — while "all input
  routing, rendering, and state management" is delegated to the view
  layer via an action/effect dispatch. This is a clean Elm/Redux-style
  split: `Action -> dispatch -> Vec<Effect>`, where effects are then
  executed against IO (spawned tasks, further dispatch) by the loop.
- **Terminal input is read on a dedicated OS thread**, not polled inside
  the async `select!`. The rationale documented in-tree: `crossterm`'s
  event stream, if you `.await` and then drop that future because a
  different `select!` arm won, can lose the pending wakeup permanently
  (a known crossterm limitation), silently freezing input until some
  *other* unrelated timer happens to re-poll. The fix is a classic
  thread-plus-mpsc-channel bridge: a blocking loop calls
  `poll(timeout)`/`read()` on its own thread and forwards raw events over
  an unbounded channel that the async loop can safely `.recv()` inside
  `select!` (channel `recv()` futures ARE cancel-safe). The same thread
  supports being "paused" (an atomic flag) so a child process temporarily
  taking over the TTY (an external `$EDITOR`, or a `$PAGER` for viewing a
  transcript) doesn't race the reader for stdin bytes; a second atomic
  flag lets the pause-requester wait until the thread has provably backed
  off before handing the TTY to the child.
- **Streaming token rendering:** tokens arrive as discrete update events on
  an async channel (from the agent-runtime side, itself downstream of an
  actor-per-provider-request model described in §5) and are folded into
  the in-memory scrollback/transcript data structure incrementally — the
  transcript is a tree/list of typed "blocks" (assistant text block,
  thinking/reasoning block, tool-call block with its own status enum,
  user block, system/event block, sub-agent block, etc.), each with an
  independent renderer. A redraw is scheduled (not immediate) — the loop
  tracks a minimum draw interval and a "next scheduled draw" instant, so
  bursts of token events coalesce into a capped frame rate rather than
  redrawing on every token (a deliberate backpressure/perf choice: typed
  "min draw interval" and "scroll cadence" values are derived from a
  terminal capability probe at startup, i.e. the redraw budget adapts to
  how fast the actual terminal/tmux/SSH pipe can keep up).
- **Diffs:** a text-diff crate is used to compute file-edit diffs for
  display; diff rendering is one of the typed scrollback block kinds
  (an "edit" tool call carries structured before/after content, not a
  pre-rendered string, so the view layer can re-flow/re-color it per
  theme and per terminal width).
- **Spinners / progress:** tool-call blocks carry a status enum
  (in-progress / completed / failed) and the animation-tick timer (only
  armed while at least one entry is actually running, to avoid burning
  CPU animating nothing) drives spinner glyph rotation and elapsed-time
  display. Long-running background tasks get their own dedicated pane
  distinct from the main scrollback.
- **Interactive approval prompts (the permission UI):** this is one of the
  most developed subsystems and worth calling out in detail as prior art:
  - Approval requests queue as a `VecDeque`; only the front request is
    interactive, later ones wait — so a burst of tool calls needing
    approval doesn't overwhite each other or auto-cancel older prompts.
  - The prompt overlay takes over the input-prompt area of the screen
    (not a floating modal box) and shows: optional "this came from a
    sub-agent" provenance line, a title, then a *command-aware* rendering
    of what's being requested.
  - For shell/bash approval specifically, the raw command string is
    parsed (via a `tree-sitter` shell grammar, referenced elsewhere in the
    tree) into structural highlight tokens so the UI can (a) syntax
    highlight it, (b) soft-wrap it at real shell operators (`&&`, `||`,
    `|`, `;`) rather than blindly at whitespace, (c) never wrap inside a
    quoted string or a heredoc body, and (d) let the user narrow or widen
    an "always allow" scope by expanding/contracting a *dimmed selection*
    over a prefix of the command's meaningful tokens (left/right arrow),
    visually dimming the tokens outside the current allow-scope. This
    turns a coarse yes/no gate into a graduated trust boundary the user
    can tune per-request without typing.
  - For MCP tool-call approval, a parallel "scope" toggle exists
    (allow-this-tool vs allow-this-whole-server), gated on whether the
    tool's name is namespaced by a server prefix.
  - A "reject with feedback" option flips the overlay into a small inline
    text-input mode so the user can type *why* they're rejecting, which
    becomes the tool's result content the model sees on its next turn —
    turning a hard rejection into steerable feedback instead of a dead
    end.
  - Height/layout math is entirely defensive: every measurement function
    is written to degrade gracefully (clip, cap, saturate) rather than
    panic when the terminal is very short, and there's a separate
    "public" height-measuring function used purely for mouse hit-testing
    so click targets stay pixel-accurate with whatever was actually drawn
    (including when content was clipped).
  - A distinct global mode ("auto-approve"/"yolo" toggle, and a
    middle-ground "auto" mode that runs an LLM-based side-classifier to
    approve only clearly-safe actions) exists per-agent/session, is
    persisted, and is *policy-clamped*: an enterprise/managed config layer
    can pin the maximum permission laxity, and the runtime always reports
    the *actual* post-clamp state back to the UI rather than the raw
    request, specifically to avoid the UI claiming "auto-approve is on"
    when a policy silently downgraded it.
- **Suspend-for-child pattern:** launching `$EDITOR` or `$PAGER` is treated
  as a first-class, carefully sequenced operation: pause+confirm-parked
  the input reader thread, drain any in-flight frame-writer buffer so
  nothing races the child's own writes to the tty, leave the alternate
  screen (fullscreen mode only), disable raw mode, run the child
  synchronously, restore raw mode / re-enter alternate screen, then
  disambiguate two restore cases by probing cursor position before/after:
  a screen-restoring child (like `less`) leaves the cursor where it found
  it (repaint in place), while an inline-printing child (like `cat`) has
  scrolled the physical screen (the live viewport must be re-anchored
  below the new output, growing the scroll region if needed first). Any
  terminal query-reply bytes ("device attributes"/cursor-position
  responses) buffered during the handoff are explicitly drained/discarded
  afterward so they don't get misinterpreted as real keystrokes.
- **Resilience to hostile terminals:** the input-reader thread tolerates
  crossterm parse errors (malformed escape sequences from flaky SSH/VTE
  pipes) up to a consecutive-error budget before giving up, rather than
  crashing the whole TUI on the first bad byte.
- **Theming:** OS-appearance-aware (light/dark) theme resolution with a
  cache and a watcher for live OS theme changes; syntax highlighting via
  `syntect`.

## 4. Agent execution (turn loop, planning, stop conditions, retries)

- **Actor-per-session model.** Each conversation is a long-lived async
  actor (`SessionActor`) driven by an `mpsc` command channel plus an
  internal event channel; a single big `select!` loop dispatches on:
  idle-flush timers (periodic memory summarization), a "dream check" timer
  (background reflective memory consolidation while idle), model-switch
  notifications, chat-state events (context/token-budget bookkeeping),
  a replay/notification buffer flush timer, prompt-completion results, and
  the inbound command enum itself (dozens of variants: submit prompt,
  cancel, change model, toggle yolo/auto mode, rewind, compact, plugin/
  hook reload, MCP server add/remove/toggle, background task control,
  feedback capture, etc.). This is the same actor pattern as the sampler
  (§5), applied one level up: one actor per provider request, one actor
  per conversation, and (implicitly) one process managing many
  conversation actors concurrently (each `spawn_local`'d onto a
  single-threaded-per-session local task set, since much of the session's
  interior state is `Rc`/thread-local rather than `Arc`-shared — sessions
  are independent and never need to cross OS threads with each other).
- **Turn loop shape:** a prompt enters a small input queue (supporting
  reordering, mid-queue edit, and removal — i.e. the user can queue up
  several follow-up messages while the agent is still working and
  reorder/edit them before they're sent). When idle, the actor pulls the
  next queued input and starts a turn. Inside a turn: build the tool
  manifest for this turn (context-dependent — some tools are listed
  conditionally), call the sampler, receive either plain assistant text
  (end of turn) or one or more tool calls, dispatch tool calls (with
  per-file locking so two edits to the *same* file inside one batch run
  sequentially while everything else runs fully concurrently — locking
  key is extracted generically from whichever of several possible
  argument names a given tool uses for its path), feed tool results back,
  and loop until the model stops requesting tools or a stop condition
  fires.
- **Stop conditions observed:** natural stop (model returns text, no tool
  calls), explicit cancel (user-initiated, or "cancel and rewind if the
  turn hasn't produced any persisted side effect yet"), plan-mode gate
  (an "edit gate" that blocks file-mutating tools while in a
  plan/inspect-only mode until the user approves the plan), a
  max-truncation stop (the provider truncated on the token/length limit —
  treated as a *failure* to retry, not a valid completion), and an
  "empty response" stop (model returned no text and no tool calls —
  treated as transient and retried, since it usually means a truncated
  or reasoning-only turn). There's also an explicit **subagent** path:
  a coordinator can spawn nested agent sessions (for delegated
  sub-tasks/parallel exploration) with their own lifecycle, usage
  accounting that folds back into the parent's token/cost ledger, and
  provenance tags surfaced in the UI (so the permission overlay can show
  "this bash command was requested by sub-agent X").
- **"Doom-loop" detection is a first-class stop/retry condition**, not an
  afterthought: the provider stream can carry non-standard signal events
  (or terminal-response fields) that the server itself uses to flag when
  the model is stuck repeating an unproductive pattern. These signals are
  accumulated per-attempt; once "confident" triggers are seen the client
  can abort the stream mid-flight and resample from scratch, on its own
  separate retry budget (distinct from ordinary transport retries), with
  its own backoff. Once that budget is exhausted, the abort is disarmed so
  the final attempt is allowed to complete and gets accepted as-is rather
  than looping forever. This is a genuinely interesting production
  pattern: cheap, provider-assisted stuck-loop detection layered under the
  normal retry/backoff machinery rather than only relying on client-side
  heuristics over tool-call history.
- **Goal orchestration:** beyond the raw turn loop there's a higher-level
  "goal" layer — a classifier decides whether a user request should be
  tracked as a multi-turn goal, a planner/strategist proposes and revises
  a plan, a "next step"/stop detector decides when the goal is satisfied
  or should pause, and a summarizer produces a final recap. This sits
  above the tool-calling turn loop as an optional supervisory layer, with
  its own test suite exercising planner/classifier/strategist/summarizer
  behavior end-to-end against mocked model responses.
- **Compaction (context management) is split into three distinct
  strategies**, each with its own config/trigger/observer:
  1. *History compaction* — summarizing/pruning older conversation turns
     when the context window fills, with validation logic to make sure a
     compacted transcript is still structurally consistent (tool call/
     result pairing intact, etc.).
  2. *Code-artifact compaction* — a dedicated path recognizing that
     tool-emitted file reads/greps/directory-listings are compactable
     "artifacts" distinct from prose, classified by path/tool-args
     heuristics, with its own sampler call and prompt template to produce
     a compacted stand-in.
  3. *Intra-turn vs. inter-turn compaction* — separate modules/configs for
     compacting *within* a single very large turn (e.g. a huge tool
     result) versus *between* turns.
     All three share common primitives (token counting, a generic
     "select what to compact" strategy, reminder-injection after
     compaction so the model knows history was summarized).
- **Mid-turn interjection:** a small, deliberately host-agnostic buffer
  (generic over an "attachment" type so the TUI's own image/asset types
  don't leak into the core library) lets a user message that arrives
  *while a turn is in flight* get queued and safely drained into a
  synthetic follow-up user message at the next safe point, framed with an
  explicit "the user sent a message while you were working" wrapper and a
  tagged `<user_query>` block — never merged with other queued
  interjections, always one synthetic message per original message, FIFO.
  This is a clean, minimal, reusable primitive for "the user is allowed to
  talk to the agent while it's already thinking" without needing to
  cancel the in-flight turn.
- **Retries** live mostly in the sampler layer (§5) but the turn loop also
  retries tool-argument parse failures *without regenerating the whole
  message*: instead of silently coercing malformed tool-call JSON down to
  `{}` (which would force the model to redo all its reasoning), the error
  message returned to the model as a tool result includes the model's own
  original (truncated) argument string plus, if it's actually invalid
  JSON, the exact byte/column parse error — letting a one-character typo
  be self-corrected on the very next turn instead of forcing a full retry.

## 5. Streaming (provider → core → terminal)

Three clean layers, explicitly named as such in the code's own doc
comments:

- **Layer 1 — raw transport.** A `SamplingClient` per API backend/style
  (there are three: an OpenAI-style chat-completions backend, an
  OpenAI-style "responses" backend, and an Anthropic-style messages
  backend) opens an HTTP request with a streaming body and decodes
  provider-native Server-Sent-Events chunks into a typed
  `Result<Chunk, Error>` stream (`eventsource-stream` + `reqwest`
  streaming feature).
- **Layer 2 — per-backend transform.** Three separate transform functions
  (one per backend) turn the raw chunk stream into a single, backend-
  agnostic `SamplingEvent` stream (a shared enum with content-delta,
  reasoning-delta, tool-call-delta, usage, and terminal `Completed`/
  `Failed` variants). Each backend's peculiarities (different delta
  shapes, different "doom-loop" signal placement, different stop-reason
  vocab) are absorbed here so nothing above this layer needs to know
  which backend produced the tokens.
- **Layer 3 — the actor.** A single always-running actor task owns global
  sampler state and a cancellation-token map keyed by request id; it
  receives `Submit`/`Cancel`/`UpdateConfig`/introspection commands over an
  unbounded `mpsc` channel and, per `Submit`, spawns an **independent
  per-request Tokio task** into a `JoinSet`. The actor's own `select!`
  loop is `biased`, always draining finished tasks (`join_next`) before
  picking up new commands, so completed requests are reaped promptly.
  Multiple requests are naturally concurrent because each gets its own
  spawned task; the actor itself never blocks on any one request.
- **Per-request task = the retry/backoff loop.** This is the most reusable
  idea in the whole codebase: the actual attempt (build client → get
  Layer‑1 stream → run it through the Layer‑2 transform → forward every
  non-terminal event live to the caller → wait for the terminal
  `Completed`/`Failed`) is wrapped in an outer loop that classifies the
  terminal outcome into an `AttemptOutcome` (`Completed`, `Empty`,
  `Failed`, `Cancelled`, `InitFailed`) and an inner `apply_retry_decision`
  step that maps the classified error to one of several concrete
  behaviors: plain backoff-and-retry, retry-with-image-stripping (a body
  that was likely rejected for size — proactively strip embedded images
  before resending rather than blindly resending the same oversized
  payload), retry-with-client-rebuild-on-HTTP/1.1 (escaping a poisoned
  HTTP/2 connection-pool state), emit-directly-to-caller (non-retryable
  but not fatal — e.g. auth), or fatal (retry budget exhausted). All
  *intermediate* progress events (content/reasoning/tool-call deltas) are
  forwarded to the caller live and only suppressed for the *final* event
  of an attempt that's about to be retried — so the terminal UI never
  renders a "flicker" of an attempt that's about to be thrown away and
  reattempted, but still sees every real streamed token from the attempt
  that ultimately succeeds.
- **Idle-timeout watchdog:** each attempt races the underlying event
  stream against a configurable idle timeout (default around five
  minutes) so a connection that stops emitting bytes (dead TCP, silently
  hung upstream) is detected and converted into a normal retryable error
  rather than hanging forever — same category of protection as the TUI's
  hostile-terminal input-error budget, applied to the network side.
  A first captured raw error is retained (a small `tee` over the stream
  that copies just the *first* error it sees into a shared cell) so the
  richer, strongly-typed error survives even though the Layer-2 transform
  only emits a flattened "error info" summary type across the event
  channel; on the terminal `Failed` event, the retry classifier prefers
  the original rich error over a reconstruction from the summary.
- **Cancellation (ESC / Ctrl-C):** every actor holds a
  `tokio_util::sync::CancellationToken` per active request; cancelling is
  just calling `.cancel()` on that token from anywhere (a UI keypress
  handler, session shutdown, actor drop). The per-request retry loop
  checks `is_cancelled()` at the top of every retry iteration *and* races
  the cancellation future against the event stream inside the attempt
  itself via a `biased select!` that always prefers the cancellation arm
  — so cancellation is observed near-instantly whether it lands between
  attempts or mid-stream, without needing to poll a flag. On actor
  shutdown, every still-tracked request's token is cancelled and the
  actor awaits every spawned task's graceful teardown before exiting, so
  nothing leaks.
- **Backpressure:** the event channel from the sampler up to the session/
  UI is unbounded (deliberately — sampler events are cheap enough that a
  bounded channel's backpressure isn't needed there and would risk
  stalling the retry loop on a slow consumer); the actual throttling
  happens one hop further out, at the TUI's own draw scheduler (batched,
  minimum-interval redraws — see §3), which is the correct place to
  absorb bursty token arrival without adding artificial latency to the
  model call itself.

## 6. Tool runtime

- **A single generic `Tool` trait**, implemented per concrete tool, with
  an associated typed `Args` (must derive a JSON-schema type) and typed
  `Output` (must implement a small `ToolOutput` trait providing
  model-facing content blocks). A tool overrides either a simple blocking
  `run()` or a full streaming `execute()`; the default `execute()` just
  wraps `run()` into a single-terminal-item stream, so most tools never
  need to think about streaming at all. The stream contract is exactly:
  zero or more `Progress` items, then exactly one `Terminal` item, always.
  A generic blanket impl (`ToolDyn`) erases every concrete `Tool` into an
  object-safe, JSON-in/JSON-out trait object (since generics with
  associated types aren't dyn-safe) — this is the standard Rust pattern
  for "heterogeneous trait objects with typed ergonomics at the edges."
- **Schema generation** comes from deriving a JSON-Schema trait
  (`schemars`) on the typed `Args` struct — the model-facing tool
  manifest is generated from the same struct the tool's `run`/`execute`
  deserializes into, so the schema sent to the model and the type actually
  parsed can never drift apart. `jsonschema` (a validator, separate crate)
  is also a workspace dependency, presumably for validating a manifest or
  incoming arguments defensively.
- **Tool families / variants:** a `ToolFamily` trait lets several
  concrete implementations share one externally-visible tool identity but
  route to a different variant implementation (used, per the ported-code
  notice in §1, to let the same wire tool name be backed by, e.g., a
  locally-authored implementation OR one of the two ported
  implementations, selectable presumably per toolset/mode).
- **Progress payloads** are a small closed enum (plain text chunk, rich
  content blocks — including an image variant carrying enough metadata
  for a downstream "media" concept to reconstruct a referenceable asset
  — or an open "custom" escape hatch tagged with a tool-owned sub-kind
  string) rather than raw bytes, so a terminal renderer never has to
  sniff tool output to know how to display it.
- **Dispatch layer:** an object-safe `ToolDispatch` trait sits above
  `ToolDyn` (decode raw JSON args → route to the right tool by a stable
  `ToolId` → return the stream), with a default `call_terminal()`
  convenience that drains progress and returns just the final result for
  callers that don't care about intermediate frames. Concrete routing
  ("which registry, which permission gate, which sandbox") lives further
  downstream in the shell/agent-runtime crate, deliberately kept out of
  this low-level trait crate.
- **Execution / sandboxing:** a separate crate defines sandbox *policy*
  data (deny-lists with glob support, network policy, path policy,
  "profiles" bundling a policy preset) and OS-level child-process network
  restriction helpers, kept apart from the tool trait/dispatch machinery.
  There's also a distinct optional remote/hosted "computer-use" execution
  backend (an SDK talking to a pooled, authenticated, multiplexed remote
  session service) selectable behind a small resolver/registry, alongside
  a "local" backend for on-box execution — i.e. sandboxing/execution
  backend is itself a pluggable trait, not hardwired to local subprocess
  execution.
- **MCP tools are just more tools:** once discovered from a configured MCP
  server, they're registered into the same tool registry with a namespaced
  wire name (`server__toolname` pattern) and the same manifest/dispatch
  path as built-in tools — no special-cased execution path for MCP versus
  native tools once registration is done.

## 7. Model / provider abstraction & tool-call parsing

- **Backend enum, not per-provider trait hierarchy.** There is exactly one
  `SamplingClient` concept with an internal `ApiBackend` enum
  (`ChatCompletions` / `Responses` / `Messages`) rather than one trait
  implemented three times — the three Layer‑2 transform functions (§5) are
  the actual seam where behavior diverges. This keeps the retry/actor/
  cancellation machinery (the hard, easy-to-get-wrong part) written
  exactly once, shared unconditionally by all three backends.
- **Tool-call parsing happens inside the Layer-2 transform**, per backend,
  because each backend streams tool-call arguments differently (some
  stream incremental JSON-argument-string deltas that must be
  concatenated and parsed only once complete; some send the full
  arguments in one chunk). The unified `SamplingEvent`/`ConversationResponse`
  types downstream never see backend-specific shapes — by the time the
  actor/session sees a tool call, it's already a stable, backend-neutral
  struct (name + accumulated argument string + call id).
- **Model identity is data, not code:** default model IDs per tier live in
  an embedded JSON file loaded by a tiny dedicated crate — changing which
  concrete model string backs "the coding model" or "the fast model" is a
  data change, not a recompile, and the crate is small enough to be
  trivially unit-testable against the embedded JSON's own shape.
- **Auth is dependency-inverted**, not baked into the HTTP client: a
  small trait (`AuthCredentialProvider`, yielding a `CredentialSnapshot`)
  is defined in a leaf crate specifically so a *lower-level* utility crate
  (file/data utilities) can make authenticated HTTP calls with automatic
  token refresh without depending on the much larger shell/session crate
  that actually knows how to refresh tokens. This inversion-of-control
  seam is a good general pattern for avoiding circular crate dependencies
  in a layered system: define the capability as a trait where it's
  *consumed*, implement it where the real logic lives, wire the concrete
  implementation in at the top.
- **Doom-loop / empty-response / truncation handling** (§4/§5) is the
  closest thing to "provider-quality-of-service" abstraction: it's
  provider-agnostic policy layered generically over any backend's
  terminal response, not per-provider special-casing.

## 8. Session / state / config / auth

- **Config is explicitly multi-layered** with a defined precedence
  (observed precedence in the pager startup path: CLI flag > project/
  user TOML file > enterprise "managed" config > remote-served feature
  flags > compiled-in default), and *policy-clamped*: certain settings
  (permission laxity, feature gates) can be **pinned** by a managed/
  enterprise config layer such that a user-requested looser setting is
  silently downgraded — but the UI is required to always display the
  *actual effective* value, never the raw request, specifically to avoid
  lying to the user about what mode they're really in. There's a signed-
  policy module (implying managed config can be cryptographically signed
  to prevent tampering) and a macOS-specific "managed" config reader
  (likely reading a system MDM/profile-delivered plist).
- **Config loading is careful about partial failure:** loading is
  structured so that if one layer fails to parse, the others still apply
  ("full merge when every layer parses; partial merge below if any layer
  fails" is an explicit code comment) rather than the whole config
  resolution aborting on one bad file.
- **Auth flow:** OAuth/browser-based login is the primary path (first
  launch opens a browser to authenticate, per the README) with an
  API-key path as an alternative, explicit support for multiple
  advertised login methods (so a headless/managed environment can pin a
  *preferred* method rather than always defaulting to the interactive
  browser flow), and separate credential resolution for MCP servers
  (their own OAuth flow orchestrator + credential store, kept in the MCP
  crate specifically because of its heavier dependency footprint — see
  §9).
- **Session persistence:** conversation state persists as an append-style
  log (a dedicated SQLite-backed append/journal crate exists), with
  support for forking a session, rewinding to an earlier point (including
  "rewind across a compaction boundary" as an explicitly tested case —
  i.e. rewinding has to reconstruct pre-compaction history, not just seek
  in the compacted log), repairing a corrupted history, and reconnecting/
  resuming a session that was torn down mid-turn (a reconnect path
  replays only the tail after a client-supplied cursor id when possible,
  falling back to a full replay).
- **Secrets are actively scrubbed**, not just kept out of logs by
  discipline: a dedicated sanitizer crate regex-matches (with word
  boundaries to avoid false positives like matching inside unrelated
  words) a broad set of known secret shapes — vendor API key prefixes,
  AWS access-key IDs, GitHub/GitLab/Slack tokens, Google API keys, PEM
  private-key blocks, bearer tokens, bare JWTs, and generic
  `key/token/secret/password = <8+ char value>` assignments — plus a
  list of sensitive URL query-parameter names to redact, before values
  can reach logs/telemetry/crash reports. This is the closest analogue in
  this codebase to AiNxt's own compliance/PII engine, and is architected
  as a pure, dependency-light, synchronous text transform (no network, no
  async) precisely so it can be called from anywhere without ceremony.
- **Folder trust:** a first-run-per-workspace trust prompt (has this
  directory been explicitly trusted for code execution?) gates whether
  local automation/tooling that reads repo-local config (MCP server
  definitions, hooks, LSP configs) is allowed to activate — a
  supply-chain mitigation against a malicious repo silently wiring up
  its own dangerous tool config the moment it's opened.
- **Managed/enterprise policy, feature flags, remote settings, and
  telemetry** are all resolved through small `resolve_*` pure functions
  that take the various config layers as explicit parameters and return
  a value *plus its source* (so the UI/telemetry can show or log which
  layer actually won) — a nice, testable alternative to scattering
  ad-hoc "check env, then config, then default" branches throughout the
  codebase.

## 9. MCP support

- Full MCP client support, deliberately isolated into its own crate
  specifically because the MCP client library it depends on requires a
  newer major version of the HTTP client crate than the rest of the
  workspace uses — the crate-level doc comment calls this out explicitly
  as a "quarantine." Everything else in the workspace that needs to touch
  MCP-provided types imports them *through* this crate's re-exports rather
  than depending on the MCP client library directly, keeping the
  version-incompatible HTTP stack from ever appearing in the dependency
  graph of, e.g., the TUI.
- Supports the standard MCP transports (stdio/async-rw and streamable
  HTTP), OAuth-based MCP server authentication (its own flow orchestrator
  and credential store, separate from the main product's own user-facing
  auth), a liveness/health-watcher for configured MCP servers (auto-
  restart on failure, gated behind a resolved config flag so it can be
  disabled), and dynamic reconfiguration (add/remove/toggle a server or an
  individual tool within a server at runtime, diffed against the previous
  config so only the actual delta triggers re-registration).
- MCP-provided tools are registered into the same generic tool registry
  used for native tools (see §6) with a namespacing convention so a tool
  name collision across servers can't occur, and a permission-scope
  concept (allow just this tool vs. the whole server) that plugs into the
  same interactive approval overlay used for native dangerous actions
  (§3) rather than a separate MCP-specific consent UI.
- A parallel "reverse" channel exists so the *agent* can also invoke a
  tool hosted in an in-process/SDK-embedded MCP server on the *client*
  side (documented as a distinct wire method from the normal forward
  direction) — i.e. MCP tool-calling is bidirectional in this design, not
  purely "agent calls out to external MCP servers."
- An in-app "MCP doctor"/status view exists for diagnosing connection and
  auth-required states per server, and MCP server/tool configuration is
  exposed through the same settings surface as everything else (a modal
  in the TUI), not a separate config file the user has to hand-edit,
  although a config-file path also exists for scripted/headless setups.

## 10. Key dependencies worth evaluating

- `ratatui` + `crossterm` (with `event-stream`, `bracketed-paste`) — the
  TUI foundation; validated at real scale here (a ~2,200-file agent CLI),
  a strong signal these are production-ready for a Rust coding-agent TUI.
- `tokio` (actor pattern via `mpsc` + `JoinSet` + `CancellationToken`),
  `tokio-util`, `futures`/`futures-util`, `async-stream` — the entire
  concurrency/streaming backbone; no custom executor or hand-rolled
  reactor anywhere observed.
- `reqwest` (streaming feature) + `eventsource-stream` for SSE decoding
  of provider responses; two incompatible major versions are deliberately
  kept apart via crate quarantining (main workspace vs. the MCP crate).
  `async-openai` also appears as a workspace dependency (likely for
  request/response type definitions against an OpenAI-compatible schema,
  reused since one backend is chat-completions-shaped).
  `alacritty_terminal` also appears in workspace deps — likely repurposed
  for terminal-emulation logic needed by the embedded PTY/terminal-runner
  tool (running a real shell session with proper ANSI/VT handling) rather
  than the main TUI's own rendering.
- `schemars` (derive JSON Schema from Rust structs) + `jsonschema`
  (validate against a schema) — the tool-schema-generation backbone (§6).
- `serde`/`serde_json`/`serde_yaml` — universal; config files are TOML
  (via a config-loading layer) with some YAML also present (agent/skill
  definition files, per file extensions seen).
- `git2` (`vendored-libgit2` feature) — in-process Git status/diff/branch
  info without shelling out to the `git` binary.
- `syntect` + `ansi-to-tui` + `strip-ansi-escapes` — syntax highlighting
  and ANSI-to-ratatui-styled-text conversion; `textwrap`,
  `unicode-width`/`unicode-segmentation` for correct wide-character-aware
  text layout (essential for CJK/emoji-heavy terminal content).
  `anstyle`/`anstyle-lossy`/`anstyle-syntect` bridge ANSI styling
  concepts across crate boundaries.
- `rmcp` (official-shape MCP client library) + `oauth2` + `axum` (as an
  OAuth local-callback listener) — the MCP integration stack; `axum` here
  is *not* used as the product's main server, just a tiny loopback HTTP
  listener for OAuth redirect callbacks.
  `agent-client-protocol` (with an "unstable" feature) is the
  editor-embedding protocol (ACP) — the shell/session layer's public API
  is expressed almost entirely in ACP request/response/notification types
  (session/new, session/prompt, session update notifications, permission
  requests, tool-call updates), meaning the TUI itself is just one more
  ACP client, on equal footing with any external IDE embedding this
  agent — a strong "protocol-first" architecture choice.
- `minijinja` — templating (very likely for prompt assembly / system
  prompt composition from partials).
- `blake3` / `crc32fast` / `sha2` — hashing (content-addressed caching,
  integrity checks, telemetry IDs).
- `bm25` — a lexical/keyword search-ranking crate, presumably backing a
  local memory or codebase search index.
- `image` + `infer` + `pdf_oxide` + `zip` (deflate-only, default features
  off to avoid pulling in AES/bzip2/lzma/zstd) — multi-modal input
  handling (screenshots, PDFs, PPTX text extraction) with a deliberately
  trimmed `zip` feature set to keep the shipped binary lean.
- `arc-swap` / `parking_lot` — lock-free/low-overhead shared mutable state
  where `std::sync` primitives would be heavier.
- `indexmap` — insertion-ordered maps, used where JSON object key order
  matters for round-tripping or deterministic output.
- `dotslash` (build-time only, via the `bin/` shim) — hermetic, pinned
  fetch of the `protoc` compiler so contributors don't need it
  preinstalled; a nice pattern for reproducible builds of tools with
  native-binary build dependencies.

## Clean-room cautions — do not reuse

Names, terms, and structural choices that are this vendor's own
identifying vocabulary or brand, and must not appear in AiNxt's own
runtime/CLI:

- The product name, its short CLI invocation name, and the parent
  company/brand names (appearing throughout crate names, doc comments,
  and the README) — never use these strings anywhere in AiNxt code,
  identifiers, comments, or docs, including as an "inspired by" credit.
- **Every crate name is prefixed with the vendor's own two-letter/product
  brand token** (e.g. `<brand>-grok-*`). Do not adopt this prefixing
  scheme (a vendor-token prefix on every workspace crate) verbatim even
  with a different token substituted — it's a distinctive, recognizable
  structural fingerprint, not a generic Rust convention. Pick an
  AiNxt-native crate-naming scheme, but do not mirror the *pattern* of
  "single global brand-prefix + short business-purpose suffix" if the
  goal is to avoid the tree visually resembling this vendor's workspace
  listing.
- Product-specific feature/brand names observed as distinctive
  identifiers, none of which should be reused even as internal code names:
  the "yolo mode" permission-laxity name (use a neutral term like
  "always-approve" internally — note it does appear as a neutral display
  string alongside the informal one, so a neutral synonym clearly
  existed and should be preferred), the specific "doom loop"
  terminology for stuck-model detection (use a neutral term like
  "repetition/stagnation detection"), the specific "dream"/"dream check"
  naming for idle memory consolidation (use "idle memory consolidation"
  or similar), any "x.ai/..." — or generally `<vendor-domain>/...` —
  namespaced wire-protocol strings, the specific "grok build"/"grok.com"
  branding inside the auth-method identifiers, and any references to a
  "computer hub"/hosted computer-use product name.
- The three ported-tool-implementation subdirectories (from two other,
  *separate* open-source agent projects) are not this vendor's own
  invention and are explicitly marked as translated/ported in-tree. Do
  not treat this vendor's adaptations of them as the canonical reference;
  if AiNxt wants to study those tool designs, go to the two upstream
  projects directly and respect their own (different) licenses and
  attribution requirements independently — don't launder attribution
  through this vendor's copy.
- Internal jargon that is safe to learn from conceptually but should be
  renamed if adopted: "pager" (as the name for the main TUI binary/crate
  — a deliberately misleading-sounding internal name; if AiNxt borrows
  the "TUI is layered over a protocol; multiple frontends could exist"
  idea, name the crate for what it *is* — a terminal renderer — not for
  this vendor's internal nickname), "leader" (their term for a
  supervising process that can host/roster multiple agent sessions —
  rename to something like "session supervisor" or "fleet controller"),
  "roster"/"fleet view" (their dashboard-of-sessions concept name),
  "hub"/"computer hub" (their hosted sandbox concept name), and the
  specific ACP method-name strings under any vendor-namespaced prefix.
- Do not copy the specific redaction regex library/pattern set verbatim
  from the secrets-sanitizer crate as a drop-in for AiNxt's own PII/PCI
  compliance engine — the *category list* (vendor API key shapes, cloud
  provider access keys, PEM blocks, bearer/JWT, generic secret-looking
  assignments, sensitive query params) is generically useful domain
  knowledge and fine to independently re-derive, but the exact regex
  literals, constant names, and redaction placeholder strings are this
  vendor's specific implementation and not something to transcribe.
- Do not reuse the specific enterprise/managed-config precedence *names*
  or file-format details (e.g. their specific TOML table names, their
  specific macOS-managed-profile reader) — the *pattern* (layered config
  with policy-clamping and "always display effective value" as a rule)
  is the transferable idea; the concrete keys are vendor-specific.

## Design lessons for AiNxt

Transferable ideas (patterns and behaviors, not code) to consider adopting
in AiNxt's own Rust runtime + CLI, plus anti-patterns to avoid:

**Adopt:**

1. **Actor-per-request + actor-per-session, both via the identical shape**
   (mpsc command channel in, spawned-task-per-unit-of-work, a
   `CancellationToken` per unit, `JoinSet` to reap completions). Reusing
   one well-tested concurrency shape at two different granularities (one
   provider call; one whole conversation) reduces the amount of "new"
   concurrency logic AiNxt has to get right to exactly one pattern,
   proven twice.
2. **Three-layer streaming split** (raw transport → per-provider
   normalization → actor/retry orchestration) with a shared,
   provider-neutral event enum from Layer 2 upward. This is the single
   highest-leverage idea in the whole codebase for AiNxt's own
   model-agnostic requirement (already a hard rule in AiNxt's own
   CLAUDE.md) — it is a proven way to keep "which provider" fully
   contained beneath a stable internal event contract, exactly matching
   AiNxt's "route via model_router, never hardcode a vendor" mandate.
3. **Suppress-then-replace terminal events on retry**, not visible
   flicker: forward every live token of an attempt, but only surface the
   attempt's *own* terminal success/failure once the outer retry loop has
   decided the attempt is final. Prevents the terminal UI from ever
   showing a half-finished response that then vanishes and restarts.
4. **Doom-loop / stagnation detection as a named, budgeted, disarmable
   retry class**, separate from ordinary transport retries, with its own
   backoff and its own "give up and accept what we have" fallback once
   the budget is spent. A concrete, working design for a problem ("model
   stuck looping on tool calls") that's real and currently only handled
   ad hoc (if at all) elsewhere.
5. **Dedicated OS thread + channel bridge for terminal input**, never
   polling the terminal event stream inside the same async `select!` that
   also does everything else — with an explicit "pause and wait for
   provable park" handshake before handing the TTY to a child process
   (`$EDITOR`/pager). This is directly relevant if AiNxt's CLI ever moves
   toward a Rust TUI (noted as a real target in AiNxt's own program
   backlog): this exact failure mode (a dropped poll future silently
   freezing input until an unrelated timer happens to re-poll) is a
   documented, non-obvious crossterm pitfall worth designing around from
   day one rather than discovering it in production.
6. **Graduated, command-aware approval UI** instead of binary yes/no:
   parsing a shell command into real tokens so "always allow" can scope
   to exactly a safe prefix, syntax-highlighting and soft-wrapping at real
   operators (never mid-quote/mid-heredoc), and letting a rejection carry
   free-text feedback back to the model instead of just closing the door.
   Directly reusable conceptually for AiNxt's own tool-approval/HITL
   surfaces (referenced in AiNxt's SDLC HITL approval gates).
7. **Policy-clamped settings that always display the *effective*, not
   requested, value** — a small, disciplined rule (compute the actual
   post-policy state, report only that) that avoids an entire class of
   "the UI lied to me about what mode I was in" bug and support ticket.
8. **Config resolution as pure `resolve_*(layer1, layer2, ...) -> (value,
   source)` functions** rather than scattered ad hoc precedence checks —
   easy to unit test every precedence combination in isolation, and the
   returned "source" is a cheap, valuable debugging/telemetry signal.
9. **Split protocol/type crates from implementation crates**, and
   explicitly "quarantine" any dependency with a version conflict into
   its own small crate that re-exports only what's needed — keeps a
   heavyweight/awkward dependency (an MCP library needing a newer HTTP
   stack) from ever touching the rest of the dependency graph.
10. **Model IDs and tier→model mappings as embedded data, not code** —
    directly reinforces AiNxt's own existing `core/model_registry.py`
    approach; worth mirroring exactly this shape in a future Rust runtime
    (a small crate whose only job is exposing a versioned, embedded
    model-ID table).
11. **Mid-turn interjection as a small, host-agnostic, generically-typed
    buffer** (generic over attachment type) rather than baking "can the
    user talk to the agent while it's thinking" into either the TUI or
    the session actor directly — a clean primitive worth lifting whole
    as a design shape for any AiNxt agent-loop work that wants the same
    capability.
12. **Regex-based secret redaction as a synchronous, dependency-light,
    stateless text transform**, callable from absolutely anywhere with no
    ceremony — worth comparing directly against AiNxt's own
    `compliance_engine.py` design goals (multi-layered regex + validation,
    redact-and-proceed per `feedback_redact_dont_block.md`) as a
    cross-check that the *shape* of AiNxt's compliance pass (cheap,
    synchronous, callable pre/post every model call) is sound.

**Anti-patterns / things to avoid:**

1. **One giant `AppView` struct owning all UI state** works here because
   the codebase is large enough to have invested heavily in disciplined
   `Action -> dispatch -> Effect` separation around it, but it is a
   sprawling, thousands-of-fields risk if that discipline slips even
   slightly — a smaller, more modular state design (even at some
   ergonomic cost) is safer for a team not at this vendor's scale.
2. **Very large single files for "the session actor's command handling"**
   (a single match-heavy function spanning dozens of command variants and
   hundreds of lines) is a maintainability smell even in a codebase this
   mature — worth deliberately avoiding by splitting command handling
   into per-command-family functions from the start rather than one
   monolithic dispatcher.
3. **Deep layering of optional subsystems** (goal orchestration, memory
   "dream" consolidation, laziness detection, feedback collection, voice,
   plugin marketplace, subagent coordination, worktree pooling, all
   simultaneously live in one session actor) creates a lot of surface
   area and cross-cutting state to reason about per turn; AiNxt should be
   deliberate about which of these are genuinely load-bearing for its own
   near-term goals versus speculative scope that just adds actor-loop
   complexity for marginal benefit.
4. **Ported-and-modified third-party tool code living inside a
   first-party crate** (rather than as a clearly separate vendored
   dependency) makes license provenance harder to audit at a glance, even
   with a good `THIRD_PARTY_NOTICES.md` — if AiNxt ever needs to adapt
   ideas from another OSS agent's tool implementation, keeping such code
   in an isolated, clearly-marked module (or a separate crate) from day
   one is easier to audit than folding it into the same directory tree as
   fully original code.
5. **Relying on a single unbounded `mpsc` channel for high-volume UI
   events** is fine at this vendor's scale but is a latent memory-growth
   risk if any consumer (the TUI draw loop) ever stalls for long — AiNxt
   should decide deliberately (not by default) whether any analogous
   internal event bus should be bounded with an explicit
   drop/backpressure policy, especially given AiNxt's own "2,000 parallel
   users, no polling storms, no unbounded state" scaling mandate
   (`feedback_scale_2k_users.md`) — an unbounded channel *inside a single
   session* is fine (bounded blast radius), but the same pattern must not
   leak into anything shared across sessions/users on a multi-tenant
   server.
