# Vendor Architecture Study — OpenAI Codex CLI (Rust)

**Target:** `other_vendors/codex-main` (workspace crate root: `codex-main/codex-rs`)
**Purpose:** Clean-room architecture study only. No source code, identifiers, comments, prompts, file names, or folder layouts from this project may be copied into AiNxt. This document describes *behavior and structure in our own words*, and separately calls out the vendor's exact names so engineers can positively avoid them.
**Why this vendor matters most:** AiNxt's own CLI + runtime are Rust. This is the closest real-world reference for "how do you split a multi-hundred-thousand-line agentic CLI into Cargo crates" that we have.

---

## 1. License

- **Root license: Apache License 2.0** (confirmed at `codex-main/LICENSE`, `NOTICE` file, and `[workspace.package] license = "Apache-2.0"` in `codex-rs/Cargo.toml`). Apache-2.0 permits studying and reimplementing ideas; it does not permit lifting substantial source verbatim without attribution — for our purposes we are treating it as read-only reference material and writing everything ourselves regardless.
- **Sub-directories with different licenses (do not treat as Apache-2.0):**
  - `third_party/wezterm/` — MIT License (vendored terminal-emulation reference code).
  - `codex-rs/vendor/bubblewrap/` — **GNU LGPL v2**, not Apache. This is the vendored copy of the `bwrap` sandboxing helper binary/sources. Copyleft license — a reason on its own to reimplement Linux sandboxing against the bubblewrap *binary* (as a subprocess) rather than vendoring or linking its library code.
  - `codex-rs/skills/src/assets/samples/*` (skill-installer, openai-docs, imagegen, skill-creator) — each ships its own `LICENSE.txt`/`license.txt`; these are sample content bundles, not core runtime code, and are license-isolated from the rest of the tree.
  - The project's `NOTICE` file also discloses that its TUI terminal-diffing code is **derived from Ratatui** (MIT, Ratatui Developers) — i.e. even within the Apache-2.0 tree, one file explicitly carries an inbound MIT attribution because they forked and modified a dependency's source rather than only depending on the crate.

**Takeaway for AiNxt:** if we vendor or shell out to bubblewrap-equivalent sandboxing on Linux, do it as an external subprocess dependency (like they do via a thin wrapper crate), never by copying LGPL source into our tree.

---

## 2. Crate / Workspace Structure

This is not a small CLI — the workspace declares **~140 member crates**. That scale is itself a data point: a mature Rust agentic CLI outgrows a "one core crate + one CLI crate" model quickly, and the vendor has clearly been through several splitting passes (crate names like `agent-identity`, `code-mode`, `guardian`, `connectors`, `cloud-tasks*` suggest features bolted on over time, not an initial design).

### 2.1 Layering (confirmed by inspecting actual `Cargo.toml` dependency lists, not just naming conventions)

**Leaf utility layer** — `utils/*` (path-handling, caching, PTY wrapper, fuzzy-match, string helpers, template rendering, output truncation, sandbox-summary formatting, etc.). No internal dependencies beyond other utils. Pure, small, independently testable.

**Foundation layer** — crates almost everything else depends on:
- A **wire/contract crate** (their `protocol`) defining the full set of client→engine command types and engine→client event types, plus shared value types (response items, approvals, error taxonomy, tool/thread/session identifiers). This is the single most load-bearing crate in the whole tree — every process (interactive UI, headless runner, IPC server, MCP server) that wants to drive or observe an agent run depends on it.
- A **config crate** defining the on-disk configuration schema and merge/layering rules.
- A **provider-metadata crate** — small, dependency-light — defining what a "model provider" configuration record looks like (base URL, auth style, wire dialect, retry/timeout knobs), separate from the crate that actually *implements* HTTP calls to a provider.
- An **HTTP transport crate** wrapping the actual HTTP client library, providing shared proxy/TLS/cert configuration once for the whole workspace.
- A **low-level API/transport crate** implementing the actual request/response and streaming wire format against a specific backend API shape, independent from the higher-level "which provider" selection logic.

**Engine (core) layer** — one large aggregator crate that depends on ~40 other internal crates (protocol, config, provider abstraction, MCP client, sandboxing, tool implementations, session persistence, execution-policy, thread storage, etc.). This is where the actual agent loop, tool dispatch, turn/session state machine, and retry logic live. Notably, this crate is *not* directly exposed to every consumer — see below.

**IPC / protocol-server layer** — a crate pair that (a) defines an RPC-style protocol (thread/turn/item lifecycle messages) independent of the low-level engine's internal event enum, and (b) implements a server that embeds the engine crate and exposes it over that RPC protocol — reachable either **in-process** (an async bridge with no OS process boundary, used by default) or **out-of-process** (a detached daemon reachable over Unix domain socket, WebSocket, or stdio JSON-RPC, used for external integrations like editor plugins or desktop apps).

**Client-facing binaries / entry-point crates:**
- An interactive terminal UI crate.
- A headless/scriptable "exec" crate for CI and automation (plain text or JSON-Lines output).
- An MCP-server crate (exposes the whole engine as a single tool to *other* agent hosts).
- A top-level CLI crate that is purely a `clap` argument-parsing dispatcher, routing subcommands to the above (interactive mode is simply "no subcommand given").

**A key structural surprise worth internalizing:** the terminal UI crate does **not** link the engine crate directly. It depends only on the IPC-protocol and IPC-client crates. Every other first-party consumer (the CLI dispatcher, the headless exec mode, the MCP server, the RPC daemon binary) links the engine crate directly and in-process. The terminal UI is deliberately kept on the far side of the same abstraction boundary that external, out-of-process integrations use — it just happens to usually take the "in-process, no OS process boundary" branch of that abstraction rather than the "separate daemon" branch. This buys them one clean answer to "how does an external tool (editor extension, desktop shell) talk to the agent" and reuses it for their own terminal UI instead of writing a second, TUI-specific integration path.

**Peripheral/vertical crates** (feature-specific, each isolated so they can be added/removed without touching the engine's core): per-OS sandboxing (three separate crates: macOS, Linux, Windows, plus a thin cross-platform facade crate), a declarative command-approval policy engine, a custom file-patch format parser/applier, an MCP client crate (wrapping an upstream Rust MCP SDK) and an MCP-server crate, a login/auth crate, a secrets-storage crate, an OS-keyring abstraction crate, session-transcript persistence, a richer "conversation index" crate layered on top of raw transcripts, a SQLite-backed mirror for queryable runtime state, a feature-flag registry crate, a model-catalog-refresh crate, an OpenTelemetry/tracing crate, and integration-specific crates for cloud task execution, browser/desktop connectors, and multiple local-inference backends (each as its own thin crate providing only lifecycle/health-check glue, not a second implementation of the provider abstraction).

### 2.2 Dependency graph shape

`utils/* → {protocol, config, provider-metadata, http-transport} → engine (core) → {IPC-server, IPC-client}`, with client binaries branching off after the IPC layer for the terminal UI, and branching directly off the engine layer for the CLI dispatcher, headless-exec, and MCP-server binaries. It is a layered DAG, not a strict pipeline — many peripheral crates (sandboxing, MCP client, patch-apply, approval-policy) sit alongside the engine as dependencies *of* it rather than being layered strictly above/below foundation crates.

### 2.3 Build tooling signal

The repo root also carries a **full Bazel build graph** (`MODULE.bazel`, `BUILD.bazel` files, remote-execution config) *in addition to* Cargo. This is a sign of monorepo-scale engineering investment (hermetic builds, cross-platform toolchains, hooked into CI/remote build execution) — evidence that this project graduated from "cargo workspace" scale to "big-company monorepo" scale. For AiNxt, this is a signal of *eventual* scale, not a starting point — we should design our crate boundaries to survive that kind of growth (small, single-purpose crates with narrow public APIs) without adopting Bazel prematurely.

### 2.4 Companion SDKs

Outside the Rust workspace, the repo root also ships a TypeScript SDK package and two Python packages (a client SDK and a separate "runtime" package for sandboxed execution) — these are thin language bindings over the IPC protocol described above, not reimplementations of the engine. This validates the "one core protocol, N language SDKs" pattern for anyone who wants official multi-language embedding later, without needing to port the engine itself.

---

## 3. Agent Execution Loop

**Conceptual model:** a long-lived, actor-style "session" object owns all mutable state for one conversation and is driven by a single command-consuming task. External callers never touch that state directly — they submit commands into a queue and receive events from a separate outbound queue.

**Per-turn control flow (three logical layers):**
1. **Outer turn loop.** For a single user-initiated turn, the engine repeatedly (a) assembles the current conversation history + tool definitions into a request, (b) sends it to the model, (c) processes the streamed response, and (d) decides whether another round is needed. It keeps looping as long as the last round produced tool calls that need their results fed back to the model, or a new user message arrived mid-turn. There is **no hard cap on the number of tool-call rounds** — the loop is purely need-driven ("does the model still have unanswered tool calls / unconsumed input"), not iteration-count-driven. This is a deliberate difference from a fixed "max N iterations" ceiling.
2. **Single sampling attempt with transport retry.** Each round's model call is itself wrapped in a bounded retry loop for transport-level failures (timeouts, connection resets, 5xx, malformed stream termination) using exponential backoff with jitter, and can fail over between transport mechanisms (e.g. a persistent streaming channel falling back to plain request/response) if the primary transport is unhealthy. A distinct, non-retryable error class exists for things retries can't fix (context-window exceeded, quota/usage-limit reached, sandbox denial) — these abort the turn immediately with a typed error rather than retrying.
3. **Inner streaming-event loop.** While a single model response streams in, the engine consumes structured events (message text deltas, reasoning deltas, "a discrete output item is complete," "the whole response is complete") one at a time. Whenever a complete tool-call item arrives, its execution is kicked off immediately — it does not wait for the full response to finish streaming before starting tool execution, and multiple tool calls that appear in the same response are executed **concurrently**, with completion order tracked so results can be matched back to the right call ID. All tool executions in flight are raced against a single cancellation signal shared for the whole turn, so a user interrupt cancels the model stream and every outstanding tool call together.

**Stopping conditions, concretely:**
- Model response completes with no pending tool calls and no queued follow-up input → turn ends normally.
- User sends an explicit interrupt/cancel → a cancellation token tied to the active turn fires; the model stream and all in-flight tool executions are aborted together; the turn ends in an "aborted" state, not an error state.
- A non-retryable error class is hit (context window exceeded, quota exhausted, fatal tool error, sandbox denial) → the turn ends in a failure state immediately, no further retries.
- A tool implementation reports a "soft" failure (bad arguments, file not found, etc.) → this is **not** treated as a loop-ending error. It is packaged as a normal tool result (with an error flag) and fed back to the model on the next round, so the model can self-correct. Only a small, explicit set of "fatal" tool failures actually aborts the turn outright.

**Error/retry taxonomy is exhaustive and centralized**, not scattered: one error enum decides retryability, one backoff function computes delay, and one function is the single call site that decides "retry, fail over transport, or give up" for every model call in the system. This centralization is worth adopting — it prevents each new tool/provider from re-inventing its own retry heuristics.

**Async architecture:** classic single-writer actor pattern. One task owns a bounded inbound command queue and processes commands strictly one at a time (serializing all mutation of session state). Turn execution itself is handed off to a second, per-turn task so the command-consuming task stays responsive to new commands (in particular: interrupts) while a turn is running. Outbound events flow through a separate, unbounded queue so a slow consumer never blocks the engine from making progress. A lightweight "current status" broadcast (via a watch-style single-latest-value channel) lets any number of observers cheaply check "is the agent idle/thinking/waiting for approval" without subscribing to the full event stream. Cross-task shared state (conversation history, rate-limit counters, cached provider capabilities) lives behind async-aware mutexes on the session object rather than being message-passed on every access.

---

## 4. Tool Runtime

**Registration:** tools are registered into a lookup table keyed by tool name, where each entry is a boxed trait object implementing a common "tool runtime" interface (something like: given structured arguments + execution context, return a result or a typed error). Built-in tools (shell/process execution, the custom file-patch tool, requesting user input, requesting elevated permissions, reporting remaining context budget, viewing an image, a sandboxed "run code" tool) all implement the same trait as tools that are dynamically discovered from external MCP servers — from the dispatcher's point of view, a locally-implemented tool and a remotely-proxied MCP tool are indistinguishable.

**Description to the model:** each tool has a name, a JSON-Schema-shaped argument definition, and a description string; these get serialized into the vendor-specific "tool" section of the model request. There is a clean separation between the *tool-definition data structures* (name, schema, description — provider-agnostic) and the *code that turns those into a specific provider's wire format* (e.g. converting a generic tool spec into a particular API's expected JSON shape lives in a narrow adapter, not scattered across the codebase).

**Invocation:** when the model's streamed response completes a tool-call output item, the dispatcher looks up the tool by name in the registry, builds a future for its execution, and pushes that future into an ordered-but-concurrent collection (so N tool calls in one turn run in parallel, but results can still be correlated back to the originating call ID once each future resolves). Each execution future also races against the shared per-turn cancellation signal.

**Sandboxing (tool-runtime-level, per OS):**
- One dedicated crate per OS handles the actual isolation mechanism, behind a shared cross-platform facade so calling code doesn't need OS-specific branches.
- **macOS:** uses the OS's declarative sandbox-profile mechanism (a policy language compiled into a profile, then the process is launched under it) — a fixed, well-known system binary applies the profile.
- **Linux:** primarily uses **user/PID/mount/network namespace isolation via an external unprivileged-sandboxing helper** (the bubblewrap-style approach: unshare namespaces, then bind-mount a restricted filesystem view), *plus* an in-process syscall filter (seccomp) to additionally block dangerous syscalls (e.g. raw sockets) even inside the namespace. An older kernel-LSM-based mechanism exists as a legacy fallback, not the default path anymore.
- **Windows:** does **not** use the two most obvious mechanisms (AppContainer, Job Objects). Instead it constructs a **restricted access token** with capability-scoped security identifiers, applies filesystem access-control entries keyed to that token, runs the process under a dedicated low-privilege desktop/session, and enforces network policy through the OS's low-level filtering platform, scoped to that token's identity. This is a materially more involved (and more Windows-idiomatic) approach than the "just spawn in a container" instinct — worth studying in depth if AiNxt needs Windows sandboxing.
- A separate, higher-level **declarative command-approval policy** (implemented as a tiny embedded scripting-language ruleset, not a bespoke parser) classifies *specific command invocations* into "run silently," "ask the user first," or "always block," independent of the filesystem/process sandbox itself. This is a distinct concern from sandboxing: sandboxing limits *blast radius if a command runs*; the policy layer decides *whether to even ask the user before running it*. Approval requests pause the turn and surface as an event the calling UI must respond to (or, in the MCP-server-embedded scenario, as a protocol-native "ask the human" request forwarded to whatever hosts the MCP client).

**Custom file-edit format:** rather than requiring the model to emit a valid unified diff (whitespace/line-number-sensitive, easy for a model to get subtly wrong), there's a bespoke, more forgiving patch envelope: explicit begin/end markers, one block per file with an explicit add/update/delete/rename operation type, and hunks matched against the current file contents using a *fuzzy* context-search (so minor drift in context lines from what the model "remembers" the file to contain doesn't cause the whole patch to fail to apply). This is a strong, transferable idea: diff-format leniency measurably reduces model-edit failure rates compared to requiring byte-perfect unified-diff hunks.

**Result flow back to the model:** tool output (stdout/stderr/exit code, or file-edit results) is captured with a hard byte cap at the point of capture (to avoid unbounded memory use from a runaway command), then — separately — truncated again with a *token*-aware policy before being placed into the conversation sent to the model, using head+tail preservation (drop only the middle) plus an explicit "this was truncated, N tokens omitted" banner so the model knows information is missing rather than silently seeing a shortened result. Two-stage truncation (byte-safety cap at capture time, token-budget-aware truncation at prompt-construction time) is a good pattern to copy.

---

## 5. Model / Provider Abstraction

**Core abstraction:** a single trait represents "a place that can run model inference," exposing roughly: static metadata (base config), a capabilities descriptor (max context, whether it supports parallel tool calls / images / web-search, etc.), an auth resolver, a "build me a low-level API client for this provider" method, and account/usage-state accessors. The vast majority of providers (the primary cloud API, and every self-hosted/local backend) share **one generic implementation** driven entirely by a data record (name, base URL, which env var holds the API key, which wire dialect it speaks, retry/timeout knobs, custom headers). Only one provider family (a specific cloud vendor's managed inference service, needing a fundamentally different signing/auth scheme) gets its own bespoke trait implementation. A factory function picks the right implementation by inspecting the provider's configuration record.

This is an important design lesson: **don't build a new trait implementation per provider.** Build one config-driven generic implementation that covers "anything speaking a compatible JSON wire dialect over HTTP with header/bearer-token auth," and reserve bespoke implementations only for providers whose *auth or transport* is fundamentally incompatible (e.g. request-signing schemes), not just providers with a different vendor name.

**Provider registry:** a small hardcoded set of "known" providers ships built-in (the primary cloud API, the one bespoke-auth cloud provider, and two local-inference backends), and users can add arbitrary custom providers via config records with the same schema. Local-inference-backend crates (for two different local model servers) are intentionally thin — they only add lifecycle helpers (health probing, listing locally available models, pulling/downloading a model) and do **not** implement a second inference-abstraction trait; they still flow through the one generic provider implementation because they speak the same wire dialect as the primary cloud API. This strongly suggests standardizing on **one wire dialect internally** and only writing thin adapter shims for backends that already speak something compatible, rather than writing bespoke request/response mapping per backend.

**Streaming:** implemented as Server-Sent Events, parsed using an existing SSE-parsing library (not hand-rolled byte scanning) layered under a manual mapping step that turns named SSE event types into a project-specific typed event enum (a delta of output text, a delta of tool-call arguments, a delta of "reasoning" content, "this streamed item is now complete," "the whole response is complete," rate-limit metadata, failure). An idle-timeout wraps the read loop so a stalled stream is detected and can trigger the retry path rather than hanging forever. A WebSocket-based transport variant exists as an alternative to HTTP+SSE for the same logical request/response shape — evidence that the SSE-vs-WebSocket choice is treated as a transport detail below the provider abstraction, not something tool-dispatch or turn logic needs to know about.

**Tool-call parsing:** tool calls are always **native structured JSON** from the provider's own function/tool-calling feature — there is no freeform "the model writes JSON inside a text block and we regex it out" fallback for tool invocation itself. A separate, unrelated text-stream-parsing utility exists purely for the *presentation* layer (extracting inline markup like citation markers or hidden tags from plain assistant prose as it streams) — it is not used for tool-call extraction. Keeping these two concerns (structured tool-calling vs. in-band text markup parsing) in separate utilities, rather than one "parse everything out of model text" grab-bag, is a clean, worth-copying separation.

**Auth:** per-provider API keys are the base case (read from a configured environment variable name), layered with: a config-driven "run this external command and use its stdout as a bearer token" escape hatch, a browser-based OAuth/PKCE flow (with a short-lived local HTTP listener for the redirect), a device-code flow for headless/remote logins, and a signing-based scheme for the one bespoke cloud provider. Credential storage is pluggable across three backends (plaintext file, OS keyring, or in-memory/ephemeral for tests) with a preference order that tries the most secure option first and falls back gracefully — this "storage backend is a strategy, not a hardcoded file path" pattern is worth adopting directly.

**Retries/backoff:** centralized in one place (not duplicated per provider), parameterized by which error classes are retryable (429s off by default, 5xx and transport errors on by default), exponential backoff with jitter, and a hard cap on attempts read from config.

---

## 6. Session / State / Config

**Config:** TOML files, merged from multiple layered sources in ascending precedence — a system-wide file, the user's home-directory file, an optional named "profile" overlay, a current-directory file, and files discovered by walking up from the current directory toward a repo root — plus enterprise/admin-managed constraint files that can *restrict* rather than just default settings, and CLI-flag overrides on top of everything. Config controls model selection, provider selection, context-window/auto-compaction thresholds, reasoning verbosity, the command-approval policy, the sandbox mode, and the map of configured MCP servers.

**Home directory concept:** a single root directory (overridable via an environment variable, defaulting to a dotfile-style directory under the user's home) holds: the main config file, an auth/credentials file, a directory of session transcripts (organized by date, one file per session), an archived-sessions directory, and a session-index file for fast lookup without re-scanning every transcript.

**Auth storage:** a dedicated JSON credentials file under the home directory (restrictive file permissions on Unix), holding whichever auth mode is active (API key, OAuth tokens + refresh metadata, other scheme-specific fields) — but the *storage backend* for this file is itself pluggable (plain file vs. OS keyring vs. an encrypted local secrets store vs. ephemeral/in-memory), selected by config, with automatic fallback if the preferred backend is unavailable.

**Session persistence — two distinct layers, not one:**
1. A **raw, append-only transcript log**, one file per session, written incrementally as the conversation proceeds (optionally compressed), used to resume or replay a session by literally reconstructing state from the log. This is the durable source of truth.
2. A **higher-level index/query layer** on top of those raw logs — modeling "conversations" with metadata, search, listing, archiving, without needing to re-parse every raw log file for every operation. This layer is itself backed by a local SQL database that mirrors metadata extracted from the raw logs (rebuildable from the logs if the database were lost, but queried directly in the hot path for speed).

Separating "durable, replayable, append-only transcript" from "fast, queryable index/metadata" is the key transferable idea here — it avoids both the failure mode of a slow linear-scan session list *and* the failure mode of an index that's the only copy of the data (if the SQL layer is corrupted/lost, the transcripts alone are enough to rebuild it).

**Feature flags:** a small, centralized enum-based registry with an explicit lifecycle stage per flag (experimental / stable / deprecated / removed) and config-driven overrides, rather than scattered boolean config fields with no lifecycle tracking. Worth adopting directly as a pattern: every feature flag should carry its own maturity stage so stale/forgotten flags are visible in code review rather than invisible.

**Model catalog:** capability metadata (context window size, whether a model supports a given reasoning-effort/verbosity parameter, etc.) is sourced from three tiers — hardcoded bundled defaults (works offline / on first run), a time-to-live'd on-disk cache, and a live network refresh — with a strategy selector (always hit network / cached-only / automatic) rather than one hardcoded fetch policy. This means the tool keeps working (with slightly stale capability data) even if the catalog endpoint is unreachable.

---

## 7. TUI / Streaming Rendering

**Library choice:** an immediate-mode terminal UI library (the kind that redraws a virtual character-grid buffer each frame and diffs it against the previous frame to compute a minimal set of terminal escape-sequence writes) paired with a lower-level terminal I/O library for raw input events and cursor/style control — both taken as external dependencies, **not** built from scratch, though the top-level "terminal driver" object is a heavily modified fork of the library's own default implementation rather than used off-the-shelf.

**Widget composition:** the screen is composed as a tree of widgets rooted at one top-level "chat" widget, with sub-widgets for the bottom input/status area and for individual rendered history entries (a tool-call result, an exec-output block, etc.) — standard immediate-mode composition, redrawn every frame from current state rather than mutated in place.

**The one genuinely distinctive rendering technique, worth adopting:** finished/settled conversation history is **not** kept in the redrawn buffer at all. Once a message or tool-result is complete, it is written *once* directly into the real terminal's native scrollback using raw cursor-movement and scroll escape sequences, and then permanently dropped from the state that gets redrawn every frame. Only the "live" region — the currently-streaming assistant response, a spinner, a status line — is redrawn via the immediate-mode diff loop each frame. This avoids the classic flicker/CPU-cost problem of re-diffing and repainting an ever-growing scrollback of already-finished content on every single streamed token, at the cost of some extra care around terminal resize handling (since content pushed into native scrollback can't be reflowed by the app afterward the way buffer-diffed content can). **This is one of the highest-value, directly transferable ideas in the entire codebase for anyone building a Rust streaming-chat TUI.**

**CLI-to-engine relationship (thin client vs. embedded logic):** as covered in section 2, the terminal UI is a genuinely thin client — it holds no agent-loop logic itself. It sends commands and receives events across the same client abstraction used for out-of-process integrations, just usually taking the in-process/no-syscall-boundary branch of that abstraction rather than a real IPC hop. The headless/scripted execution mode and the interactive TUI share this exact same client layer, differing only in how they render the event stream (human-readable text or one-JSON-object-per-line, versus a rendered widget tree) — meaning "how do I add a third UI" is answered by "write a new renderer against the existing event stream," not "reimplement agent-loop plumbing."

---

## 8. MCP Support

The project is **both an MCP client and an MCP server** — a dual role, not just one direction:

- **As a client:** external MCP servers are declared in config (by launch command for local stdio servers, or by URL for HTTP-streamed servers), with optional OAuth for the HTTP case. A connection manager establishes and maintains a connection per configured server (built on top of an upstream, third-party Rust MCP SDK crate rather than a hand-rolled MCP client protocol implementation). Tools discovered from each connected server are namespaced (server name + tool name, joined by a fixed delimiter) so tool names never collide across servers, then merged into the same lookup table used for built-in tools — from the tool-dispatch code's point of view there is no difference between a built-in tool and a remote MCP tool. Tools can also be filtered out of the model-visible set via metadata (e.g. a tool marked as UI-only, not model-invocable).
- **As a server:** the whole engine can itself be exposed as a single MCP server (so other agent hosts — e.g. a different vendor's desktop app — can treat "run this agentic engine on a task" as one callable tool). In that mode, things that would otherwise be interactive approval prompts (approve this shell command, approve this file patch) are translated into the MCP protocol's own "ask the connecting client to elicit input from its user" mechanism, rather than requiring a bespoke side-channel.

**Design lesson:** building the MCP client on top of an existing, spec-compliant SDK crate (rather than hand-rolling JSON-RPC framing, capability negotiation, and elicitation) is clearly the right call, and building MCP-server-mode as a thin adapter over the *same* internal event/approval model used for local, interactive use (rather than a parallel implementation) kept it from becoming a second agent loop to maintain.

---

## 9. Async Model

Confirmed pattern: **tokio + async channels, single-writer actor per conversation, no cross-task shared mutable state without a lock.**

- One bounded multi-producer/single-consumer channel carries inbound commands into a single task that processes them strictly serially (this is what makes "session state" safe to mutate without fine-grained locking — only one task ever mutates it directly).
- One unbounded channel carries outbound events out to whatever is consuming them, decoupling event production speed from consumption speed.
- A single-latest-value ("watch"-style) channel exposes a cheap, poll-without-subscribing "what's the current high-level status" signal, separate from the full event stream — useful for UI elements that only need "idle/running/waiting-for-approval," not the full transcript.
- Each active turn gets its own spawned task, holding its own cancellation token; interrupting a turn cancels that token, which every tool-call future and the model-stream read loop are both racing against, so a single cancellation propagates to everything the turn was doing.
- Concurrent tool-call execution within a turn uses an ordered-completion collection of futures (so results can be matched to call IDs regardless of which one finishes first), each also racing the same cancellation token.

There is no evidence of a heavier "actor framework" crate (like `actix` or `xtra`) — the actor pattern is hand-rolled directly on top of `tokio::spawn` + channels + `Arc<Mutex<...>>`, which is simpler to reason about and debug than a framework, at the cost of being slightly more boilerplate per new "actor."

---

## 10. Key External Crates to Evaluate

| Concern | Crate(s) used | Note |
|---|---|---|
| Async runtime | `tokio` (feature-gated per-crate, not blanket-enabled) | Confirms: don't blanket-enable all tokio features workspace-wide; let each crate declare only what it needs. |
| HTTP client | `reqwest` (shared, wrapped in one internal transport crate) | One shared HTTP client construction path (proxy/TLS/cert config) reused everywhere, not reqwest::Client::new() scattered around. |
| Local HTTP/WS server | `axum` | Used narrowly, only where a process needs to expose a local control surface. |
| Serialization | `serde` + `serde_json` + `toml`/`toml_edit` + `schemars` (JSON Schema generation) + a Rust→TypeScript type-generation crate | Schema/type generation from Rust structs is used to keep the wire protocol and companion SDKs in sync with the Rust types automatically — strong pattern for a protocol that has multiple language bindings. |
| CLI parsing | `clap` (derive) + shell-completion generation crate | Standard, no surprises. |
| TUI | An immediate-mode terminal UI crate + a lower-level terminal I/O crate, both used via **forked/patched versions**, plus a syntax-highlighting crate and an image-rendering crate for inline images | Forking the TUI library itself (not just consuming it) was necessary to get the scrollback-based history trick in section 7 — a sign that stock immediate-mode TUI libraries don't natively support "commit finished content to real scrollback," so we should expect to need similar low-level control if we want that behavior. |
| Error handling | `anyhow` (application-level) + a structured-error-derive crate (library-level typed errors) + a pretty-panic/error-report crate at binary entry points | Textbook split: typed errors in libraries, ergonomic dynamic errors in application glue, nice terminal error rendering only at the outermost binary. |
| Logging/tracing | `tracing` ecosystem + a full OpenTelemetry exporter pipeline, centralized in one crate | Observability is a first-class, separately-owned concern, not ad hoc `println!`/`log`. |
| Streaming | `futures` + an async-generator-style streaming macro crate + an SSE-parsing crate | SSE parsing uses an existing crate rather than hand-rolled byte scanning — validated choice. |
| MCP | An upstream, spec-compliant Rust MCP SDK crate, wrapped rather than reimplemented | Do not write a bespoke MCP client/server protocol implementation; adopt (or build once against) a compliant SDK. |
| Sandboxing | Kernel namespace/seccomp-oriented crates on Linux (plus an external unprivileged-sandbox helper binary invoked as a subprocess), OS-native primitives directly on Windows and macOS (no cross-platform sandboxing crate exists that they could just depend on) | Confirms: there is no shortcut here — expect to write and maintain three real OS-specific sandboxing implementations behind one facade trait. |
| Persistence | An embedded SQL database crate (bundled, no external DB server) for the queryable session-index layer | Good default for a local-first CLI: no external DB dependency, but still real SQL for the query layer. |
| Fuzzy matching / search | A fuzzy-matching crate and a BM25-style ranking crate | Used for local file-search / conversation-search features, not for retrieval-augmented generation against a vector store — this project has no vector DB / embeddings dependency anywhere, worth noting as a scope difference from AiNxt's own RAG-heavy platform. |
| Experimental / notable | A pinned, exact-version JS engine embedding crate isolated in its own proof-of-concept crate, and an embeddable configuration-scripting-language interpreter used for the declarative command-approval policy | Both are examples of "reach for a real embeddable interpreter/engine crate instead of writing a bespoke mini-DSL parser" — validates using an existing embeddable scripting language for any future AiNxt policy/rule DSL rather than hand-rolling one. |

---

## CLEAN-ROOM CAUTIONS — Do Not Reuse

The following are this project's own coined terms, exact identifiers, file/directory names, protocol tokens, and distinctive structures. Treat this list as a *do-not-reuse* checklist when naming AiNxt's own crates, types, config keys, and protocol messages. (Grouped by area; this is not exhaustive of every symbol in a ~2,600-file codebase, but covers every genuinely distinctive/coined name surfaced during this study.)

**Crate/package names:** anything following the `codex-*` naming convention generally (e.g. `codex-api`, `codex-client`, `codex-login`, `codex-secrets`, `codex-http-client`, `codex-app-server*`, `codex-exec-server*`, `codex-mcp*`, `codex-execpolicy`, `codex-rollout*`, `codex-models-manager`, `codex-agent-identity`, `codex-agent-graph-store`, `codex-core-plugins`, `codex-core-skills`, `codex-connectors`, `codex-terminal-detection`, `codex-uds`, `codex-stdio-to-uds`). AiNxt should use its own product-name prefix and its own set of crate boundary names even where the *concept* is copied.

**Core engine / turn-loop types:** `CodexThread`, `SessionIo`, `Submission`, `submission_loop`, `Op` / `EventMsg` as the command/event enum pair names, `ActiveTurn`, `SessionTask` / `AnySessionTask`, `StepContext`, `TurnContext`, `TurnInput`, `TurnItem`, `SamplingRequestResult`, `run_turn` / `run_sampling_request` / `try_run_sampling_request`, `ToolRouter`, `ToolRegistry`, `CoreToolRuntime`, `ToolCallRuntime`, `ToolInvocation`, `ToolPayload`, `ToolName`, `FunctionCallError` (and its `RespondToModel`/`Fatal` variant names), `WorldState`, `TurnDiffTracker`, `ModelClientSession`, `CodeModeSessionProvider` / the phrase "code mode" as a feature name, `AgentControl` / `AgentStatus`, the "mailbox" inter-agent-communication naming, `Guardian` / `GuardianAssessmentEvent` as a safety-reviewer feature name, `ThreadStore` / `ThreadManager` / `ThreadRollback` / `ThreadMemoryMode`, `RolloutItem` / `RolloutRecorder`, `CompactionPhase` / "auto-compact" as the exact term.

**Provider/streaming types:** `ModelProvider` / `SharedModelProvider` / `ConfiguredModelProvider` / `AmazonBedrockModelProvider`, `ModelProviderInfo`, `ProviderCapabilities`, `ResponsesClient`, `ResponseEvent` and its exact variant names (`ToolCallInputDelta`, `ReasoningSummaryDelta`, `ReasoningContentDelta`, `ServerReasoningIncluded`), `SafetyBuffering` / `SafetyBufferingTreatment`, `KeyringStore` / `DefaultKeyringStore`, `LocalSecretsBackend` / `LocalSecretsNamespace` / `ManagedSecrets`, `RetryPolicy` / `RetryOn` / `run_with_retry`, `ProposedPlanParser`, `TaggedLineParser`, `Utf8StreamParser`, provider-ID string constants (`"ollama-chat"` as a legacy/rejected ID, the specific env var names `CODEX_OSS_PORT`, `CODEX_OSS_BASE_URL`), the exact wire-dialect field name `wire_api` with value `"responses"`.

**TUI/CLI/IPC names:** `codex`/`codex-exec`/`codex-tui`/`codex-mcp-server` as binary names, `InProcessAppServerClient` / `RemoteAppServerClient` / `AppServerClient`, `InProcessClientHandle`, `MessageProcessor`, JSON-RPC method names such as `thread/start`, `thread/resume`, `thread/fork`, `turn/start`, `turn/interrupt`, `item/agentMessage/delta`, the `CODEX_HOME` environment variable name, `CODEX_ACCESS_TOKEN` / `CODEX_API_KEY`, the file names `config.toml`, `auth.json`, `session_index.jsonl`, the directory names `sessions/`, `archived_sessions/`, `app-server-daemon/`, `app-server-control/`, the TUI internal names `custom_terminal.rs`, `insert_history.rs`, `ChatWidget`, `history_cell`, `exec_cell`, `bottom_pane`, and the "pet picker" easter-egg feature.

**MCP naming:** the tool-name namespacing scheme `mcp__<server>__<tool>` (prefix `mcp`, delimiter `__`) and the `_meta.ui.visibility` metadata field name.

**Sandboxing/policy/patch naming:** file extension `.codexpolicy`, the Starlark builtin names `prefix_rule(...)` / `host_executable(...)`, the decision vocabulary `allow`/`prompt`/`forbidden` as an enum's exact spelling, the WFP-object name `"Codex Windows Sandbox WFP"`, the `--use-legacy-landlock` flag name, and — most importantly — the **exact custom patch envelope tokens**: `*** Begin Patch`, `*** End Patch`, `*** Add File:`, `*** Update File:`, `*** Delete File:`, `*** Move to:`, `*** End of File`. If AiNxt builds a similarly lenient custom patch format (a good idea — see Design Lessons), it must use its own distinct marker syntax, not these strings.

**Auth/config naming:** the OAuth client-id constant value, the keyring service-name string `"Codex Auth"`, the secret name `CODEX_AUTH`, the OAuth callback ports `1455`/`1457`, and the feature-flag enum's exact variant names (`ShellTool`, `CodexHooks`, `UnifiedExec`, `Chronicle`, etc.).

**General rule:** where AiNxt adopts an *architectural pattern* documented above (actor-per-session, dual in-process/daemon IPC client, scrollback-commit rendering, fuzzy patch matching, tiered model-catalog refresh, layered config merge, three-tier credential storage fallback), always invent fresh AiNxt-native names for the types, files, config keys, and protocol messages that implement it.

---

## DESIGN LESSONS FOR AiNxt

### Transferable ideas worth adopting (patterns, not code)

1. **Single actor per conversation, driven by bounded-command-in / unbounded-event-out channels, with per-turn cancellation tokens shared by the model stream and every concurrently-running tool call.** This gives clean interrupt semantics almost for free and avoids fine-grained locking of conversation state. Strongly recommended as the baseline concurrency model for AiNxt's Rust runtime.

2. **Decouple the wire protocol between "driving client" and "engine" from the engine's own internal event representation**, and make that protocol rich enough (thread/turn/item lifecycle, not just raw text deltas) that *every* consumer — your own terminal UI, a headless/CI mode, a future desktop app, third-party editor integrations — can be implemented purely as a renderer over that protocol, with **zero duplicated agent-loop logic** in the client. Offer both an in-process (same-binary, channel-based) and an out-of-process (socket/websocket) implementation of the *same* client abstraction, so "run embedded" and "connect to a running daemon" are just two implementations of one trait, not two different integration stories.

3. **One generic, config-driven model-provider implementation covering every backend that speaks a compatible wire dialect; bespoke implementations reserved only for backends with fundamentally incompatible auth/signing (not just a different vendor name).** Local-inference backends should be thin lifecycle/health-check shims over the same generic implementation, not parallel abstractions. This keeps "add a new OpenAI-compatible provider" a config change, not a code change.

4. **Terminal history should be committed once to the real terminal scrollback via raw escape sequences and dropped from the redrawn buffer; only the "live," still-changing region should be repainted every frame.** This is the single highest-value TUI-specific lesson found — directly solves flicker/CPU cost for long streaming sessions, at the cost of needing to write (or fork) lower-level terminal-control code than a stock immediate-mode TUI library exposes by default.

5. **Give the model a forgiving, fuzzy-context-matching custom patch format instead of demanding byte-perfect unified diffs**, and truncate large tool output in two stages: a hard byte cap at capture time (memory safety) and a separate token-aware, head+tail-preserving truncation with an explicit "N tokens omitted" banner at prompt-construction time (so the model isn't silently misled by missing content).

6. **Sandboxing has no true cross-platform shortcut** — expect (and budget for) three genuinely different, OS-idiomatic implementations (declarative sandbox profile on macOS, namespaces+seccomp on Linux via an external unprivileged-sandbox helper process, restricted-token+ACL+packet-filter on Windows) behind one shared trait, plus a *separate*, simpler declarative approval-policy layer (built on an embedded scripting language, not a hand-rolled parser) that decides whether to prompt a human before running a command — keep these two concerns (blast-radius limiting vs. human-approval gating) architecturally distinct.

7. **Split session persistence into two tiers**: a durable, replayable, append-only raw transcript log (source of truth, one file per session) plus a separate, rebuildable local-SQL index/metadata layer for fast search/listing — never make the fast index the only copy of the data.

8. **Credential storage should be a pluggable strategy (OS keyring → encrypted local store → plaintext file → ephemeral) selected by config with automatic fallback**, not a single hardcoded storage location, and model/provider capability metadata should be sourced from a three-tier fallback (bundled defaults → time-boxed local cache → live network refresh) so the tool degrades gracefully rather than failing outright when a catalog endpoint is unreachable.

9. **Adopt an existing, spec-compliant MCP SDK crate rather than hand-rolling MCP client/server protocol handling**, and implement "expose yourself as an MCP server" as a thin adapter over the *same* internal approval/event model used for normal interactive operation — never a second, parallel agent loop.

10. **Reach for an embeddable interpreter (a real scripting-language crate) for any policy/rule DSL** (command approval, execution policy) rather than writing a bespoke mini-language parser; it buys you a real grammar, error messages, and testability for free.

### Anti-patterns / things to avoid

- **Crate sprawl without a corresponding dependency-graph discipline.** ~140 workspace crates is defensible only because the layering (utils → foundation → engine → IPC → binaries) is still basically sound; a smaller team should resist splitting this aggressively until crate boundaries are earning their keep (i.e., a crate should exist because something genuinely needs to depend on it *without* pulling in everything else, not merely because a feature is conceptually separable).
- **Vendoring a copyleft-licensed dependency's source into the tree** (as happened with the Linux sandboxing helper) rather than shelling out to it as an external binary — a licensing risk worth designing around from day one rather than discovering later.
- **No fixed iteration cap on the tool-call loop is fine only because retryable vs. fatal error classification and per-turn cancellation are both airtight** — if AiNxt copies the "loop until no more tool calls" pattern without equally rigorous error taxonomy and cancellation, an unbounded loop becomes a real runaway-cost risk. Treat the "need-driven, not count-driven" loop and "exhaustive, centralized retry/error taxonomy" as a package deal, not two independent choices.
- **A proof-of-concept, pinned-exact-version, heavyweight dependency (the embedded JS engine) isolated in its own crate** is a reasonable way to experiment, but is a reminder to keep speculative/experimental integrations behind a feature flag and a dedicated crate boundary so they never become an accidental hard dependency of the main engine crate.
