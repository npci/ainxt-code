# Vendor Study: Aider (clean-room architecture notes)

**Target:** Aider — path `other_vendors/aider-main` (Python, ~147 `.py` files)
**Purpose:** Clean-room architecture study to inform AiNxt's own Rust-based AI runtime + CLI.
**Scope note:** This document describes *behavior and architecture only*, in original wording.
No source code, identifiers, prompts, comments, filenames, or project-specific terminology from
the target project are reproduced. Any short technical terms below (e.g. "search/replace block",
"unified diff") are generic industry vocabulary, not vendor-coined names.

---

## 1. License

Apache License 2.0. Permissive; allows study, reuse of ideas, and reimplementation. Attribution
requirements apply only if actual source/object code or NOTICE content were redistributed — this
study reproduces neither.

---

## 2. Overall Module Structure and Architecture

The tool is a single-process, terminal-first pair-programming assistant built around one
central object that represents "the current editing strategy in a conversation." Around that
core there are cleanly separated concerns:

- **Conversation/session core** — owns the message history, the set of files currently "open" in
  the session (read-write vs read-only), token accounting, cost tracking, and the top-level
  request loop (get user input → build prompt → call model → parse model output → apply edits →
  lint/test → commit → possibly auto-continue).
- **A family of interchangeable "editing strategy" subclasses** of that core object, one per
  supported edit representation (search/replace blocks, unified-diff-like hunks, whole-file
  rewrites, a structured patch envelope format, function-calling/JSON variants, and a two-phase
  "planner + editor" composite). Each subclass supplies its own system-prompt templates and its
  own parse/apply logic, but shares all session/state/git/lint machinery from the core.
- **A model/provider abstraction** that normalizes many LLM backends behind one calling
  convention, tracks per-model capability metadata (context size, whether it supports vision,
  prompt caching, "thinking"/reasoning tokens, etc.), and — critically — decides which editing
  strategy is appropriate for a given model by name/family pattern matching.
- **A repository intelligence layer** that builds a ranked, token-budgeted summary of the whole
  codebase (signatures/definitions, not full bodies) to give the model situational awareness of
  files it hasn't been shown in full.
- **A VCS integration layer** wrapping a local git binding: dirty-tree detection, automatic
  commit-per-turn with LLM-generated commit messages, selective undo, diff display, and
  ignore-file handling.
- **A lint/test feedback subsystem** that can invoke language-specific static checks and project
  test commands after an edit, and feed failures back into the conversation as a natural-language
  correction request (a "reflection" — bounded to a handful of automatic retries per turn).
- **Peripheral subsystems**: a terminal I/O/prompt-toolkit layer, a command dispatcher for
  slash-style meta-commands, voice input, browser/GUI front-end, "watch mode" (reading inline
  comment markers from files being edited in an external IDE), URL/content scraping for
  context injection, and a benchmarking harness (used for internal capability evaluation, not
  part of the runtime).

Control flow is a straightforward synchronous loop, not an actor/agent framework: one request →
one model call (streamed) → one parse-and-apply pass → optional bounded self-correction loop. There
is no persistent task graph, no tool-calling loop in the modern "agentic" sense for the core edit
path (a couple of edit *formats* are implemented as function/JSON-calling, but that's a wire format
choice, not a multi-step planning framework).

---

## 3. Edit/Diff Formats — Expression, Parsing, Application, Recovery (Priority Section)

This is the project's most differentiated engineering. Several distinct *edit formats* are
supported simultaneously, selected per model family, each trading off model reliability against
token cost and patch precision.

### 3.1 Search/replace block format

The model is asked to emit, per file, one or more blocks structured as: a filename line, then a
"search" section containing an exact excerpt of the current file content, a divider, and a
"replace" section containing the new content, closed by a terminal marker. Multiple blocks per
file and per response are allowed; a bare block with no leading filename inherits the
most-recently-named file (so the model doesn't have to repeat the filename for consecutive edits
to the same file).

**Parsing** is done with a hand-rolled line-scanner (not a general grammar): it looks for the three
marker lines (head/divider/tail) using regexes tolerant of marker-length variation (some models emit
markers with different numbers of repeated marker characters), extracts the filename by scanning a
small window of preceding lines and testing candidates against fence syntax, a set of files already
known to be in the session (exact match, basename match, then fuzzy string-distance match, then
"has a file extension" as a last resort), and otherwise re-using the last seen filename. Shell-style
fenced code blocks that are *not* immediately followed by a block-start marker are captured
separately and treated as suggested shell commands rather than edits — this lets the model mix
"run this command" advice with file edits in one response. Malformed structure (missing divider,
missing terminal marker, an unpaired ellipsis-elision marker described below) raises a structured
parse error that includes the partial content consumed so far, which is later surfaced back to the
model verbatim as a correction request.

**Application** is a layered "best effort" matcher, attempted in order, first hit wins:
1. Exact substring/line-sequence match of the "search" text against the current file content.
2. A pass that drops a single spurious leading blank line some models add to the search section.
3. Support for an explicit "elision" convention: the model may put a line containing only an
   ellipsis marker inside the search *and* replace sections to mean "unchanged content omitted
   here"; the applier splits both sections on that marker, requires the surrounding literal
   pieces to appear exactly once each in the file, and stitches the edit around them. Mismatched
   ellipsis counts between search and replace, or non-unique/absent literal anchors, are treated as
   failures, not partial successes.
4. A whitespace-tolerant match: compute the minimum common leading indentation removed from both
   search and replace blocks, then look for a line-sequence match against the file ignoring
   per-line leading-whitespace differences, and re-apply a *uniform* discovered offset when
   substituting — this recovers from models that get indentation right relatively but wrong
   absolutely (or drop/duplicate a consistent indent level).
5. (An edit-distance/fuzzy whole-chunk replace strategy exists in the code but is intentionally
   disabled/short-circuited — the project settled on *not* doing fuzzy content matching for this
   format, preferring to fail loudly and ask the model to retry rather than silently guess.)

If the search text is empty, the block is interpreted as "append to file" (or "create file" if the
target doesn't exist yet) — this is the mechanism for new-file creation and pure appends without a
special-cased directive.

**Failure recovery / self-healing:** all edits in a response are attempted in a single dry-run
pass before anything is written to disk. Edits that matched are distinguished from edits that
failed. For every failed block, the tool computes and returns the most similar contiguous run of
lines actually present in the file (via a generic longest-common-subsequence similarity ratio) as
a "did you mean this?" hint, and separately warns if the *replacement* text is already present in
the file (a strong signal the edit is redundant/already applied — for example after a retry).
Failed and succeeded blocks are reported back together, explicitly telling the model not to resend
the ones that already succeeded, and to retry only the failed ones — this exists specifically to
avoid burning tokens/turns re-issuing already-correct edits after a partial failure. This entire
error report is raised as a single structured error that the outer session loop catches and
resubmits to the model as a same-turn follow-up ("reflection"), bounded to a small fixed number of
automatic retries.

An important secondary matching path: if a block's target file (as named by the model) doesn't
match on disk, the applier falls back to trying that same search/replace pair against *every other
file currently open in the session* before giving up — hedging against the model naming the wrong
file when the intent is otherwise unambiguous.

### 3.2 Unified-diff-style format

The model emits fenced hunks resembling the standard unified-diff hunk syntax (context lines,
`-`/`+` prefixed lines), optionally preceded by from/to file header lines (with standard
`a/`/`b/`-prefix stripping and `/dev/null` handling for new-file creation). Multiple hunks may
appear back-to-back in one fenced block; a hunk with no header line reuses the previous hunk's
target file, mirroring the same "don't repeat yourself" affordance as the search/replace format.

**Parsing** scans for the fence-open marker, then walks lines classifying by leading character
(context/add/delete), splitting into discrete hunks whenever a new file-header pair is seen. This
is a purpose-built line scanner, not a call into a standard patch/diff parsing library — a deliberate
choice, because model-emitted "diffs" are frequently *not* valid unified diff syntax (wrong line
counts in hunk headers, inconsistent context) and a strict parser would reject too much
correctable output.

**Application** is structurally different from a real patch tool: hunk headers' line numbers are
*ignored entirely*. Instead each hunk is normalized by first converting its lines into "before"/
"after" logical text via a helper, then round-tripped back through a diff computation to produce a
canonical minimal hunk (this absorbs models that emit correct before/after content but garbled or
redundant diff markup). The normalized hunk is then applied with a cascading strategy:
1. Try a direct, whole-hunk content-based search-and-replace of the hunk's "before" text against
   the file's "after" text is skipped — instead it tries the "before" block as a literal anchor
   directly, refusing to do a repeat-based replace if the anchor text is short and non-unique in the
   file (protects against ambiguous tiny hunks).
2. If that fails, the hunk is split into runs of edit vs. context by run-length-encoding the
   operation type per position, and a partial-hunk applier is tried, which iteratively shrinks how
   much of the leading/trailing context it insists on matching (trying every combination of
   dropping some preceding and/or following context lines, largest-context-first) until some
   variant anchors uniquely in the file. This directly targets the common failure mode where a
   model includes context lines that don't quite match the real file (extra/missing blank lines,
   slightly different surrounding code than what's actually on disk).
3. A separate "make new lines explicit" pass exists for the case where the hunk's *before* text
   itself doesn't match the file, but a real line-level diff between the hunk's declared "before"
   and the actual file content is small — in that case the hunk is rewritten against the *actual*
   file content before retrying, converting a mismatched hunk into a matching one when the
   divergence is only cosmetic.

Ambiguous hunks (the anchor text occurs more than once in the file) and non-matching hunks are
reported as two distinct, differently-worded errors — "found nowhere" vs. "found multiple times,
add more context" — because the correct model action differs (retry with a real anchor vs. retry
with more disambiguating context). As with the block format, hunks that already applied
successfully are excluded from the retry-error content, with a one-line note that some hunks
already succeeded.

### 3.3 Whole-file format

The simplest and most reliable format: the model re-emits the entire file content inside a
fenced block per file. No diffing at all is involved in application — the file is simply
overwritten. This format is reserved for weaker/older models that are unreliable at emitting
precise partial diffs; it costs far more output tokens per edit (proportional to file size, not
edit size) but has effectively zero "did it apply" failure mode, at the cost of being impractical
for large files and burning output-token budget quickly. A function/JSON-calling variant of the same
idea exists for backends that support structured tool-call responses instead of freeform fenced
text.

### 3.4 Structured patch-envelope format

A fourth, more rigorously specified format: an explicit multi-line envelope with a begin/end
sentinel and per-file action headers (add/delete/update, with optional move/rename), where update
actions contain one or more change sections addressed by an optional coarse "scope" locator line
plus a context/add/delete hunk (conceptually similar to the unified-diff format but with a stricter,
custom grammar and explicit action verbs rather than generic diff syntax).

This format's parser is the most "formal" of the four: it builds an explicit action/patch object
model (typed action records with a change-list) rather than working line-by-line at apply time.
Context-matching for locating where a change applies is tiered (exact match → whitespace-normalized
match → aggressively-stripped match, each successively "fuzzier" and recorded as increasing fuzz
cost), and an End-of-File anchor is specially handled by first trying to match at the literal end of
the file before falling back to a normal scan (with an explicit fuzz penalty if the "end of file"
claim turns out to be wrong). A coarse optional "scope" locator (a human-readable landmark, e.g. a
containing function/class signature) can be given to narrow the search window before the detailed
context match runs, which is a cheap way to disambiguate a repeated code pattern without forcing the
model to include a lot of literal context lines. At apply time, the engine re-verifies that the
lines it's about to delete still literally match the current file (defense against the file having
drifted since parse time or the "found" location being subtly wrong due to fuzz), and raises a
detailed expected-vs-actual mismatch error if not. Multiple update sections for the same file across
one envelope are merged into one action rather than applied as independent overwrites, so ordering
and overlap between chunks is explicitly validated (out-of-order or overlapping chunk start
positions raise an error rather than silently mis-merging).

### 3.5 Cross-format observations worth carrying forward

- **Every format treats "apply" as a two-phase operation**: parse fully into an in-memory edit
  list first (raising on structural malformance before touching disk), then a **dry-run** apply
  pass to partition edits into would-succeed/would-fail *before* any file is actually written, and
  only write files once the dry run is known-good for that file. This means a response containing
  five edits to one file where only the fourth is unmatchable never leaves the file in a
  partially-edited, inconsistent state relative to what was reported back to the model.
- **Errors are always turned into a same-turn corrective prompt, not a hard failure surfaced only
  to the human.** The loop that drives this ("reflection") is capped at a small constant number of
  automatic retries per user turn specifically to avoid infinite correction loops burning tokens
  when a model is systematically incapable of the requested format.
- **Fuzziness is applied at the whitespace/formatting level, never at the semantic level.** None of
  the appliers use embedding similarity or "looks kind of like this" heuristics to decide *where* an
  edit goes semantically — only exact-content matching with tolerance for whitespace/indentation
  and context-window slack. Ambiguity (found in 0 or >1 places) is always surfaced as an error
  asking for more precise input, never resolved by picking "the most likely" location silently.
  This is a deliberate reliability-over-convenience trade-off.
- **Partial success is always communicated distinctly from total failure**, both to avoid resending
  already-good edits and to let the human see incremental progress via the "N files edited" status
  even when a later block in the same response failed.
- Choice of fence delimiter (triple-backtick vs. alternatives) is dynamically negotiated per
  request by scanning the current file contents for pre-existing occurrences of every candidate
  delimiter and picking the first one that doesn't collide — because file content containing its
  own triple-backtick (e.g. embedded Markdown) would otherwise break block boundary detection.

---

## 4. Repo Map / Context Assembly

The context-assembly problem being solved: given a hard per-request token budget, and a repo far
larger than that budget, decide *which* symbol definitions from *which* files (outside the files
already fully included in the conversation) are worth showing the model, and render them compactly.

**Extraction:** each source file is parsed with a general incremental parsing library
(grammar-per-language), driven by small per-language declarative query files that identify
"definition" and "reference" occurrences (functions, classes, methods, etc., depending on what the
grammar for that language exposes). Every definition/reference occurrence becomes a lightweight
record: which file, symbol name, line, and def-vs-ref kind. For languages/parsers that only expose
definitions and not references (some grammars are definition-only), a generic tokenizer-based
fallback (a general-purpose lexer, not a language-aware parser) backfills a reference list from raw
token text, so the ranking step below always has *some* reference signal even for weakly-supported
languages. Parsed-tag output per file is cached keyed by file path + modification time, so unchanged
files never get re-parsed.

**Ranking:** every distinct symbol name becomes a node-linking problem, modeled as a directed graph
where files are nodes and a reference of symbol X in file A pointing to a definition of X in file B
creates a weighted edge A→B. Edge weight is boosted heavily (roughly an order of magnitude each) for:
symbols explicitly mentioned in the user's current message, symbols with "substantial" identifier
shapes (long, snake/kebab/camel-case names — a heuristic proxy for "this is a meaningful,
non-generic identifier" as opposed to short generic names like `x` or `i`), and — most heavily —
symbols referenced *from* a file that's already fully included in the chat context (favoring
"neighbors of what's already being discussed"). Weight is reduced for private/underscore-prefixed
symbols and for symbols with many separate definitions (ambiguous/overloaded names contribute less
confidently). A personalized PageRank (biased toward files already in the chat and files/identifiers
explicitly mentioned by name in the current message) is then run over that graph; each file's rank
score is distributed proportionally across its outbound edges to produce a per-(file, symbol)
importance score, which is what actually gets sorted and truncated to the token budget — i.e. the
unit of ranking is not "importance of a file" but "importance of a specific definition inside a
file," so a token-budget cutoff can include the three most relevant functions from a large file
without including the whole file's symbol table.

**Budget-fitting:** because token cost of the rendered map is a nonlinear function of *how many*
top-ranked definitions are included (rendering interleaves surrounding source lines, not just bare
signatures), the system does not compute a fixed cutoff analytically — it does a bounded binary
search over "how many ranked entries to include," rendering a candidate map at each probe count,
measuring its actual token count, and converging on the largest entry-count whose rendered token
count is within a small tolerance of (or just under) the budget. Token counting itself is
approximated for speed on large candidate texts by sampling every Nth line and extrapolating rather
than tokenizing the full candidate each probe.

**Rendering:** for each selected file, the relevant "lines of interest" (the specific definition
lines that were ranked in) are expanded into a small amount of surrounding syntactic context (e.g.
enclosing signature/braces) using the same incremental-parse infrastructure, so the map reads as
recognizable, syntactically-anchored snippets rather than bare line numbers — while still typically
being a small fraction of the file's full size. Files that have no extracted tags at all (e.g.
unsupported languages, or plain config/doc files) still get a bare filename-only line included so
the model at least knows they exist, and a short curated "specially important" filename list
(README-like/build-manifest-like names) is force-included ahead of the ranked results regardless of
score.

**Caching and refresh policy:** the final rendered map for a given (open-files, other-files,
budget, [mentioned files/symbols]) combination is cached; refresh strategy is configurable —
recompute on every message, recompute only when file mtimes change, recompute once and reuse for
the rest of the session, or an adaptive "auto" mode that starts fresh every time but *switches* to
mtime-triggered caching once it observes the computation is itself slow (protecting interactive
latency on large repos without requiring the user to tune anything by hand). A hard fallback
sequence exists if the primary ranked-map computation yields nothing useful for the currently-open
files (e.g. because they're graph-disconnected from the rest of the repo): retry with an unranked/
neutral view of the whole repo, and if that's still empty, retry once more with an even more
minimal, completely unhinted listing — so a context-assembly failure degrades gracefully instead of
silently omitting repo context altogether.

**Assembly into the final prompt:** the repo map is one layer in a fixed stack — system
instructions, few-shot examples, prior summarized history, the repo map, read-only reference files
(full content, not excerpted), the fully-editable open files (full content), then the live
conversation tail. Each layer is assembled independently and only combined + token-counted at send
time, and a trailing "reminder" of key formatting instructions is appended last (as its own message
turn or folded into the final user turn, depending on model preference) only if there's still budget
headroom, since instructions right before generation are more reliably followed than instructions
buried earlier in a long prompt.

---

## 5. Git Workflow

- **Repo discovery** happens at session start by resolving the git root from the working directory
  or from the set of files named on startup; if files span more than one distinct repo root, that's
  treated as a hard configuration error rather than silently picking one.
- **Dirty-tree handling:** before any file that already has uncommitted changes is edited, those
  pre-existing changes are committed first (as a distinct, separately-labeled commit), specifically
  so that the *next* commit (the one containing the AI's edit) has a clean diff that represents only
  the AI's change — and so `undo` always has a well-defined single commit to revert. This dirty-tree
  commit only fires for files about to be touched, not the whole tree.
  - Auto-commit of the AI's own edit happens once per turn after all edits in that turn are applied
    successfully, scoped only to the specific files that were actually touched (not a blanket `git add
    -A`), and only if the resulting diff for those files against the pre-edit tree is non-empty. If
    a file was previously untracked, it is staged individually as part of the same operation.
  - Commit message generation is delegated to an LLM call: the actual diff plus recent conversation
    context is sent to a small/cheap model first, falling back to a stronger model if the cheap one's
    context window can't fit the diff; the response is stripped of wrapping quotes and used verbatim
    as the commit message (with a fixed placeholder if generation fails outright, rather than
    blocking the commit).
  - **Attribution is layered and configurable independently for author vs. committer identity**,
    and separately for whether AI-attribution happens by modifying the git author/committer *name*
    field (with a suffix marker) vs. adding a `Co-authored-by:` trailer to the commit message body —
    with an explicit precedence rule set for what happens when both are requested, both left at
    default, or explicitly disabled. User-initiated commits (not AI-driven) modify only the committer
    identity by default, never the author identity, since the human is legitimately the author.
    Environment-variable-based git identity overrides are scoped with context managers so they're
    guaranteed to be restored to prior values after the commit call, even on failure — never
    permanently mutating process/environment git identity.
- **Undo** is deliberately conservative, not a generic `git reset`: it only proceeds if the most
  recent commit is (a) not the repo's very first commit, (b) recorded internally as one the AI made
  during *this* session (a session-local set of commit hashes — an externally-made commit with the
  same position in history cannot be "undone" this way), (c) has exactly one parent (refuses to
  touch merge commits), and (d) not already pushed to the tracked remote branch. It further checks,
  per file changed by that commit, that the file has no uncommitted local changes and that the file
  actually existed in the parent commit (protects against silently resurrecting/deleting content in
  an unsafe way). Only the specific files touched by that one commit are restored to their prior
  blob content (via a targeted checkout of just those paths), and history is then rewound with a
  soft reset — index and working tree content for unrelated files is never touched.
- **Diff display** on demand always renders both the index and working-tree diff when there's no
  prior commit to diff against yet, or a normal `HEAD` diff otherwise, and separately supports
  diffing two arbitrary named commits (used for showing "what changed since the AI's last commit").
- **Ignore handling** layers two independent mechanisms: standard git-ignore semantics (delegated to
  the git binding directly) and a second, tool-specific ignore file with its own gitignore-syntax
  pattern list, checked and cached separately, plus an optional "subtree-only" mode that additionally
  excludes anything outside the current working subdirectory regardless of ignore files — useful for
  scoping a huge monorepo to just the relevant subtree without editing shared ignore files.

---

## 6. The "Coder" Abstraction — Multiple Edit Strategies, Selection

The core session object is designed as a small abstract base with almost all cross-cutting
behavior (message history, file set management, token/cost accounting, the request/response loop,
lint/test/commit orchestration) implemented once, and only a handful of methods treated as
strategy-specific: how to render the edit-format-specific portion of the system prompt, how to parse
model output into an internal edit-list representation, and how to apply that edit list to disk. A
factory method picks the concrete subclass by a string tag ("edit format") stored as a class
attribute on each subclass, looked up against a registry populated by simply importing every
subclass at startup — adding a new format is adding a new subclass plus registering it, not
modifying a central dispatch table.

**Switching strategy mid-conversation** is a first-class operation: cloning the current session
into a new one with a different concrete subclass, carrying forward the open-file set, git repo
handle, cost/token counters, and prior conversation — but if the edit format is changing, the prior
assistant turns are first *summarized* (compressed to a shorter recap) rather than carried forward
verbatim, specifically because leaving old-format-flavored assistant messages in history risks the
new model imitating a format its own system prompt says not to use.

**Two-model composite strategy:** one edit format is implemented not as its own parser/applier at
all, but as a *conversation pattern*: the primary model is asked only to produce a plan/description
of the change in prose (no file edits expected), the user is optionally asked to confirm intent to
proceed, and then a **second**, potentially different model/edit-format pair is invoked with that
prose as its instruction and a stripped-down session context (repo map disabled, no shell-command
suggestions) to actually produce and apply the file edits — letting a strong-but-expensive reasoning
model do planning while a cheaper-but-precise editing model does mechanical patch production, each
using whichever edit format suits its own strengths.

**Per-model format selection:** rather than the user manually choosing a format, model metadata
(populated from a large external per-model capability database, augmented by pattern-matching
overrides keyed on model name substrings/family) supplies a default edit format for that model.
The pattern-matching layer is explicitly acknowledged internally as a pile of empirically-tuned,
model-family-specific special cases (particular reasoning models get search/replace with repo-map
enabled and no sampling temperature; certain older completion-style models get whole-file; one
older code-focused chat model generation gets the unified-diff format; etc.) rather than a
principled general rule — reflecting that the "best" format for a given model is an empirical,
frequently-revisited fact about that model's real-world reliability, not something derivable from
the model's advertised capabilities alone.

---

## 7. Model/Provider Handling and Token Accounting

- **Uniform provider abstraction:** all model calls funnel through a single third-party
  completion-calling abstraction library that normalizes dozens of providers (hosted APIs, local
  inference servers, etc.) behind one request/response shape, so the rest of the codebase never
  branches on provider identity for the actual call — only for capability metadata.
- **Capability metadata** per model (context window size, whether it supports vision/PDF input,
  prompt caching, reasoning/"thinking" token budgets, whether it wants a system-role message at all,
  streaming support, cost-per-token) is loaded from a bundled/external database keyed by model name,
  then overridden by the family pattern-matching layer described above, then overridden again by
  any explicit user/config settings — a three-tier precedence (database defaults → family heuristics
  → explicit override).
- **Token counting** prefers the provider's own tokenizer when reachable, with a local
  general-purpose tokenizer fallback so token estimates remain available offline/without a live
  endpoint. For large texts (like the rendered repo map) exact tokenization of every candidate is
  avoided for latency reasons — a sampled-line-subset estimate is scaled up instead, trading a small
  amount of accuracy for large speedups during the map-fitting search loop.
- **Streaming and partial-response handling:** model responses are consumed as an incremental
  stream, with special handling for a "finish reason: length" signal — treated as a distinct
  recoverable condition (the response was cut off by an output-token cap, not by the model choosing
  to stop) that, for models supporting response continuation/prefill, triggers automatically
  resending the truncated partial content back as an assistant-prefix to request continuation,
  rather than treating a truncated edit block as a parse failure.
  Retry-with-backoff is applied uniformly to transient provider errors, with a hard distinction for
  "context window exceeded" (not retried — surfaced immediately, since retrying can't fix it) versus
  other transient failures.
- **Cost tracking** accumulates per-message and per-session token counts (separately for
  cache-write, cache-hit, and normal input/output tokens) and computes cost either via the provider
  library's built-in cost table when available or a manual fallback formula that specifically
  accounts for cache-write/cache-read pricing multipliers being different from base input pricing
  (particularly relevant for providers whose prompt-caching discount/premium structure differs from
  a flat per-token rate).
- **Prompt caching** is opportunistic: cache-control boundary markers are only added when the
  provider/model advertises cache support, and an optional low-frequency background "keep warm"
  ping loop can be enabled to periodically resend a minimal cacheable prefix so a cache entry
  doesn't expire between user turns in a slow-typing session — explicitly gated so it only runs while
  the session object is still alive and cache-warming is still desired (cleanly stoppable, not a
  detached leak-prone timer).

---

## 8. Linting / Testing Feedback Loops

- **Auto-lint** runs immediately after a successful edit-apply, scoped only to the files actually
  edited in that turn (not the whole repo). Linting is pluggable per language: a user-configured
  external command takes priority; failing that, a small set of built-in language-specific checks;
  failing that, a generic fallback that leans on the same incremental-parser infrastructure used for
  the repo map to detect raw syntax errors (parse-tree error/missing nodes) for any language that has
  a grammar available, even with zero dedicated tooling. For one language with first-class built-in
  support, multiple lightweight checks are layered together (a raw compile/parse check for hard
  syntax errors, plus a fast style-checker restricted to a curated *fatal-only* rule subset — nothing
  stylistic, only correctness-class issues — since the goal is "catch bugs the AI just introduced,"
  not enforce house style).
- **Error presentation to the model** always couples raw tool output with a rendered source-context
  excerpt (the same context-expansion machinery used for the repo map) centered on the reported
  error lines, and explicitly asks for a fix — this becomes the next "reflection" message rather than
  a new independent user turn, and the affected files are automatically re-committed once the
  original edit already produced a commit, so the lint-fix ends up recorded as a small, separate,
  clearly-attributable follow-up commit rather than being squashed into the original edit's commit or
  left uncommitted.
- **Auto-test** works the same way structurally but is opt-in and runs a user-specified project test
  command (not language-inferred) only after edits, feeding failing output back as a correction
  request under the same reflection mechanism.
- **Reflection bounding:** both lint-triggered and parse-failure-triggered self-correction share one
  counter and one small fixed cap per user turn (not per lint/test event) — this is a deliberate
  circuit breaker: a model that is systematically incapable of satisfying the lint/format requirement
  will stop retrying and surface the unresolved state to the human rather than loop indefinitely
  re-spending tokens.
- Both auto-lint and auto-test are explicitly skippable/confirmable interactively (the human can
  decline to let the tool auto-attempt a fix), and either can be disabled entirely; when disabled,
  the same lint/test command strings are still surfaced to the model as descriptive platform
  context ("here is the project's test command, don't suggest running it yourself") so the model
  doesn't redundantly suggest running something that's already handled automatically, or, if
  automatic running is off, so it knows what command the human prefers if it wants to suggest running
  tests itself.

---

## Clean-Room Cautions

Do **not** reuse, even informally, any of the following — they are this project's specific
branding/vocabulary/layout, not generic concepts:

- The product/project name itself, or its CLI binary/command name, in any AiNxt-facing docs,
  code, config keys, or error strings.
- Its specific configuration file names/extensions and its specific "ignore file" name/extension.
- Its specific marker/sentinel strings used inside its structured patch-envelope format (the
  literal begin/end-of-patch phrases, the "Update/Delete/Add File:" action-header phrasing, the
  "Move to:" directive phrasing) — these are verbatim protocol strings a model must be trained/
  prompted to emit; AiNxt should design its own distinct sentinel vocabulary if it adopts a similar
  envelope-style format.
- The specific marker character sequences and exact repeat-count tolerances used to delimit its
  search/replace convention, and its exact terminal-marker label text.
- Any of its internal error-class names, its cache-directory naming/versioning scheme, its
  environment-variable name prefixes, or its author/committer git-identity suffix convention.
- Its exact per-file-directory module layout and naming (the "coder"/"prompts" file-pairing
  convention per edit format, the queries-directory-per-parser-pack layout) — the *pattern*
  (strategy object + matching prompt object + matching format-specific query assets) is a fine
  concept to borrow abstractly, but should get AiNxt-native naming and directory structure.
- Its specific commit-message trailer text and any of its literal user-facing prompt copy
  (warnings, hints, confirmation question text) — these are copyrightable expression, not just
  architecture, and are easy to accidentally paraphrase too closely; write AiNxt's own copy from the
  behavioral requirement, not by lightly editing observed strings.
- Its specific per-model-family pattern-matching special-case list (which literal model name
  substrings map to which settings) — that list is a maintenance artifact tied to a specific
  external model catalog and naming scheme; AiNxt's own model registry (already defined in
  `core/model_registry.py`) is the correct source of truth and should not be structured to mirror
  this vendor's per-model-string-matching approach.

---

## Design Lessons for AiNxt (Rust reimplementation)

### Edit-application engine

1. **Treat "parse fully, dry-run fully, then write" as a hard invariant**, not an optimization.
   AiNxt's Rust edit engine should build a complete, typed edit-list from model output before
   touching any file, then run every edit against an in-memory snapshot of current file content to
   classify each individual edit as would-apply/would-fail, and only perform real writes once that
   full classification is known. This guarantees a response containing five edits where one is bad
   never leaves a file in a state inconsistent with what gets reported back to the model or the user.
2. **Support at least two edit representations tuned to different reliability/cost trade-offs**, and
   make the choice a property of the *model*, not a global config: a precise localized-edit format
   (search/replace-style or hunk-style) for capable models, and a whole-file-rewrite fallback for
   weaker/local models where partial-diff precision isn't reliable. Do not force one universal format
   across a genuinely multi-model, on-prem-capable platform (this directly matches AiNxt's existing
   model-agnostic mandate) — build the format-selection table into `model_router.py`/
   `core/model_registry.py` rather than hardcoding a single expected format in the edit engine.
3. **Whitespace/formatting fuzziness is worth building; semantic/location fuzziness is not.**
   Implement tolerance for indentation drift, stray blank lines, and shrinking context windows when
   an anchor doesn't match exactly — but when an anchor is genuinely ambiguous (matches zero or
   multiple locations), fail loudly and ask for a more specific edit rather than guessing. This is
   the single highest-leverage reliability lesson from this study: never let an edit "probably" land
   in the right place. Given the NPCI accuracy mandate (wrong answers are unacceptable), this
   principle should be treated as non-negotiable in AiNxt's engine, not just a nice-to-have.
4. **Make partial success visible and non-repeatable.** When applying multiple edits from one model
   response, always report back which specific edits succeeded vs. failed, and explicitly instruct
   the model not to resend successful ones. Skipping this (i.e., just failing the whole batch or
   re-sending everything) either wastes tokens or risks double-applying an edit that already landed.
5. **Cap auto-correction loops with a single per-turn counter shared across all failure types**
   (parse failure, lint failure, test failure) — not one counter per failure category. An unbounded
   or per-category-bounded retry loop against a model that is systematically wrong about one
   dimension (e.g. always garbles indentation) can silently multiply cost several-fold in a single
   user turn; a single shared small cap forces escalation to the human quickly. This is a direct
   compliment to AiNxt's `feedback_scale_2k_users.md` cost-discipline concern.
6. **Anti-pattern to avoid:** resist the temptation to reach for "closest match by edit distance"
   as a silent fallback strategy for locating an edit target. It exists in this codebase as dead/
   disabled code — evidently tried and deliberately not shipped active — which is itself a useful
   signal: the maintainers apparently found exact-plus-whitespace-tolerant matching more reliable in
   practice than fuzzy content matching for *this class* of problem (as opposed to, say, fuzzy
   filename resolution, which is used and works fine because filenames are short, low-stakes
   strings).

### Repo-map / context engine

7. **Rank at the granularity of individual definitions, not whole files**, and let a global
   reference graph (not per-file heuristics) drive relevance — a directed graph of
   "file-that-references-X → file-that-defines-X," weighted up for symbols mentioned in the current
   turn and for symbols referenced from files already in full context, run through personalized
   PageRank. This produces much denser, more relevant context per token than naive strategies like
   "most recently touched files" or "files with matching filenames," and degrades gracefully for
   languages with weak tooling (definition-only extraction, generic-lexer reference backfill) rather
   than excluding those languages entirely — directly serving AiNxt's "all languages via tree-sitter"
   mandate.
8. **Fit to a token budget by measuring, not estimating analytically.** Because rendering cost per
   included symbol is non-uniform (context expansion varies), do a bounded search over
   "how many ranked items to include," measuring actual rendered token count at each probe, rather
   than trying to precompute a cutoff. Combine with a cheap sampled-token-count estimator (don't
   re-tokenize a multi-thousand-line candidate exactly on every probe) to keep this fast enough for
   interactive use, but always verify the *final* choice against the exact budget before committing
   to it in the request.
9. **Cache aggressively at multiple layers, but key correctly.** Per-file symbol extraction should be
   cached by (path, mtime) so unchanged files are free on every subsequent turn; the final assembled
   map should be cached by the tuple of (open files, other files, budget, mentioned files/symbols) so
   repeated similar turns are cheap, with an adaptive policy that only starts paying for
   expensive-to-invalidate caching once the map computation is empirically observed to be slow on
   that repo — avoiding a one-size-fits-all cache TTL that's wrong for both small and huge repos.
10. **Always have a degradation ladder, never a hard "no context" failure.** If the primary ranked
    view yields nothing usable (e.g. the open files are graph-disconnected from the rest of the
    repo), fall back to an unranked global view, and if that's still empty, fall back to a minimal
    unhinted listing — three-tier graceful degradation rather than an all-or-nothing context step
    that can silently leave the model with zero repo awareness.

### Git integration

11. **Scope every auto-commit to exactly the files that were actually touched**, never a blanket
    "commit everything dirty" — and commit any *pre-existing* dirty state on a file separately and
    *before* applying the AI's edit to it, so the AI's own commit is always a clean, attributable diff
    and `undo` always has an unambiguous single commit to revert.
12. **Make `undo` conservative by construction, not just by convention:** only allow reverting a
    commit the tool itself made in the *current* session (track session-local commit hashes, don't
    trust `git log` authorship alone), refuse merge commits, refuse commits already pushed to a
    tracked remote, and verify per-file that there's no uncommitted local drift and that the file
    genuinely existed pre-commit before reverting it. Restore only the specific files that commit
    touched, via a soft history rewind plus targeted per-path restoration — never a blanket hard
    reset that could discard unrelated work.
13. **Delegate commit-message generation to the cheapest model that fits the diff**, falling back to
    a stronger model only if the cheap one's context can't hold the diff — commit messages are a
    low-stakes, high-frequency LLM call and don't warrant the primary/expensive model tier. This maps
    directly onto AiNxt's existing haiku/mini-tier-for-lightweight-tasks policy.
14. **Scope environment-based git identity overrides (for AI-attribution) with strict save/restore
    semantics** (e.g., an RAII guard in Rust) around the single commit call — never mutate global
    process environment or git config persistently for attribution purposes, and support attribution
    as an explicit, independently toggleable policy (author name suffix vs. committer name suffix vs.
    commit-message trailer) rather than a single boolean, since different organizations will have
    different compliance/audit preferences about how AI-authorship is recorded in git history — a
    natural fit for a PCI/DSS-conscious platform that needs an audit trail of what changes were
    AI-generated.

### Anti-patterns to avoid overall

- Don't hardcode one edit format as "the" format across all models — it directly contradicts
  AiNxt's model-agnostic mandate and this vendor's own experience shows format reliability is
  strongly model-family-dependent.
- Don't let lint/test auto-fix loops run unbounded or with independent per-category budgets; a
  shared, small, per-turn cap is what prevents runaway cost.
- Don't treat commit auto-generation or lint feedback as separate, disconnected features — wiring
  lint failure back into the same correction channel as edit-parse failure (one reflection
  mechanism, one budget) keeps the design simpler and the cost ceiling predictable.
- Don't build a single monolithic "apply patch" function per format; separate concerns into parse
  (produce a typed edit-list, fail loudly on structural malformance) → dry-run classify (would this
  specific edit apply, against which exact location) → commit-to-disk (only for edits classified as
  safe) as three distinct, independently testable stages, mirroring the structure observed across
  all four formats studied here.
