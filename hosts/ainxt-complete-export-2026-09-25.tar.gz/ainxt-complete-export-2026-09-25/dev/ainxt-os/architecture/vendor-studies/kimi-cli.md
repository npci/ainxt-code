# Vendor Study: Kimi CLI (clean-room architecture notes)

Scope: architecture, agent loop, tool runtime, and MCP client integration. Written from
independent reading of the public source tree for internal design reference only. No
source text, identifiers, prompts, comments, or file/folder names are reproduced verbatim
below; everything is restated in our own words. Do not paste any of the vendor's actual
code, strings, or naming into our Rust implementation — see "Clean-Room Cautions."

## 1. License

- Root project: Apache License 2.0.
- Three internal sub-packages (a model/provider abstraction library, an OS/filesystem
  abstraction library, and a client SDK) each ship their own `LICENSE` file, but on
  inspection all three are byte-for-byte the same Apache 2.0 text as the root license.
  There is no dual-licensing or copyleft component anywhere in the tree.
- Net effect: the entire codebase is single-licensed Apache 2.0. Permissive, but Apache 2.0
  carries a patent grant and a NOTICE-preservation obligation — irrelevant for a clean-room
  *study*, but worth flagging if anyone later considers vendoring any file verbatim (which
  we are not doing).

## 2. Overall Module Structure

The project is a monorepo with a clear separation between "the reusable agent engine" and
"the CLI product built on it":

- A **generic agent-loop/provider library** (pure Python, no CLI concerns): defines the
  message/content-part data model, a provider-agnostic streaming chat interface, a
  tool/toolset abstraction, and a single `generate one assistant turn` primitive. It has
  adapters for several LLM vendors (an OpenAI-style Chat Completions adapter, an OpenAI
  Responses-API adapter, an Anthropic Messages adapter, a Google GenAI adapter, plus a
  "native" adapter for the vendor's own hosted model) behind one interface, and a
  deterministic mock/scripted provider used for testing.
- An **OS-abstraction library**: a small filesystem/path/process-execution layer that can
  target either the local machine or a remote host over SSH through the same API surface,
  so the rest of the agent code never branches on "local vs remote."
- The **CLI application package** itself, layered as:
  - a thin command-line front door (built on a standard Python CLI framework) that parses
    subcommands (run/chat, MCP server management, plugin management, web-UI launcher, a
    trace-visualizer launcher, auth/login, export) and lazily imports each subcommand's
    implementation so startup stays fast;
  - an **agent runtime/session layer** — configuration loading, OAuth/token storage,
    per-session state and on-disk history, a "runtime" object that bundles all
    cross-cutting services (approval, notifications, background tasks, subagent registry,
    skills, environment info);
  - the **agent core** ("the loop that talks to the model and dispatches tools"), which is
    the most interesting layer for this study (see §3–§5);
  - a **tool library** organized one-directory-per-capability (shell execution, file
    read/write/edit/search, web fetch/search, planning/todo tracking, sub-agent
    delegation, background task management, a "compose a message to a past checkpoint"
    utility, user-interaction prompts) — most non-trivial tools ship their long-form
    description as a companion Markdown file next to the Python implementation, which is
    loaded at import time rather than inlined as a Python string;
  - a **hooks engine** (pre/post tool-use, notification, stop/failure lifecycle events)
    that can run user-registered shell commands or plugins at defined extension points;
  - a **plugin system** and a **subagent system** (typed, named agent personas with their
    own tool allow-lists, spawnable from a "delegate to a specialized helper" tool);
  - an **agent-editor-protocol server** implementation (see §9) for IDE integration;
  - two independent front-ends written in TypeScript/React (see §8) — a local web UI and a
    detached trace/timeline viewer — both served by a small FastAPI/uvicorn process baked
    into the Python package, not by a separate Node server.

The CLI entry point is a very thin `main()` that installs crash/telemetry hooks, handles a
couple of bare flags, then delegates entirely to the CLI-framework command tree. All actual
behavior — model calls, tool execution, MCP, session state — lives in the runtime/session
and agent-core layers described above; the CLI layer is just argument parsing plus command
wiring.

Agents themselves are **data, not code**: a declarative spec (YAML) names a system-prompt
template file, a list of importable tool references (`"<python module path>:<class name>"`
strings, resolved via dynamic import + reflection-based dependency injection at load time),
optional MCP server references, and optional named sub-agent personas. One spec can
`extend` another and override/exclude individual fields, giving a simple inheritance model
for building custom agents without touching the interpreter. A default agent ships in the
package; one additional built-in persona exists mainly as an example/alternate voice.

## 3. Agent Loop

The loop is turn-based and explicitly documented in-code as a numbered lifecycle, which
made it easy to extract faithfully:

1. **Turn init** — drain any stale "steer" (mid-flight user interjection) messages from the
   previous turn; if any tool sources were configured to load their capability list
   asynchronously (MCP servers), kick that off now and block until it settles (with a
   "loading" status event emitted to the UI in the meantime).
2. **Step loop** (bounded by a configurable max-steps-per-turn, default four figures, which
   raises a hard "too many steps" error rather than looping forever):
   a. guard against exceeding the step budget;
   b. emit a "step begin" event to whatever UI/wire is attached;
   c. if the running token count crosses a configurable trigger ratio of the model's
      context window (leaving a reserved safety margin for the next response), run an
      automatic context-compaction pass before calling the model again;
   d. write a checkpoint of the conversation state (used for the rewind mechanism below);
   e. run one step: build the effective message history (normalizing adjacent same-role
      messages), call the model with retry/backoff around transient provider errors and a
      connection-recovery wrapper, stream partial output to the UI as it arrives, then
      **execute every tool call the model requested concurrently** and await all results
      before continuing;
   f. two special exception paths: a caught internal "revert to a previous checkpoint and
      inject a message as if from the agent's own past self" signal, and any unrecoverable
      step exception, which is logged, fires a failure-lifecycle hook, and re-raised to
      abort the turn;
   g. **stop-condition resolution** happens after each step:
      - if the model's response contained *no* tool calls at all → stop, this is the normal
        "done" condition, and the assistant's text is the turn's final answer;
      - if one or more tool calls were rejected by the user/approval layer and none of the
        rejections carried explanatory feedback text → stop immediately (a bare rejection
        with no feedback is treated as "abandon this turn", whereas a rejection *with*
        feedback is fed back to the model so it can adapt, except when the caller is itself
        a sub-agent, where rejections are always fed back rather than aborting, since a
        helper agent should try an alternative rather than terminating the parent's turn);
      - if a per-step repeated-identical-tool-call detector escalates to its top severity
        (see §4) → force-stop the turn with the last assistant message as the visible
        result;
      - otherwise, if there were tool calls, loop back to step (a) for another step; if a
        mid-turn user "steer" message arrived while tools were running, it is injected and
        forces one more step even if the model would otherwise have stopped.
3. **Turn resolution** — package the stop reason, the final assistant message (only
   populated for the "no tool calls" case), and the step count for the caller.

Two notable design choices baked into this loop:
- **Checkpoint + rewind**: before every step the full context is snapshotted; a tool can
  later signal "I need to roll the conversation back to an earlier checkpoint and inject a
  note," which the loop honors by truncating context and appending a synthetic user-role
  message describing what happened. This is used to let an agent "message its own past" —
  e.g., a sub-process or background task can leave a note that gets replayed into the
  conversation at the point where it becomes relevant, even though wall-clock time has
  moved forward. It is a deliberately whimsical name internally, but the underlying
  mechanism (state checkpointing + selective revert + synthetic replay message) is a
  genuinely reusable idea independent of the naming.
- **Concurrent tool execution with per-step and cross-step dedup**: all tool calls emitted
  by one model response run in parallel (as async tasks), not sequentially. See §4.

## 4. Tool Runtime

Tool definition, in the core library, has two flavors:
- an untyped form: a class carries `name`, `description`, and a raw JSON-schema
  `parameters` dict, plus an async `__call__` that receives already-validated/unpacked
  positional-or-keyword arguments (arguments are JSON-schema-validated before dispatch);
- a typed form: a class declares a Pydantic model as its parameter schema; the JSON schema
  exposed to the model is derived automatically from that Pydantic model (with schema
  `$ref`s dereferenced and field titles stripped so the model doesn't see Python-internal
  noise), and the call site receives one validated, strongly-typed parameter object instead
  of loose kwargs.

Every tool call returns a uniform result envelope with four channels: model-facing content
(text or structured content parts — text/image/audio/video), a short human-readable
message, a list of "display blocks" meant for the terminal/UI (a small pluggable registry
of typed blocks — plain text brief, diff, shell-output, todo-list, etc. — dispatched by a
`type` discriminator, with an explicit fallback block for unrecognized types so forward
compatibility is graceful), and an `is_error` flag. This envelope is the same shape whether
the tool is a built-in Python tool, a plugin tool, an externally-registered tool bridged
from another process, or a wrapped MCP tool — everything downstream (context growth,
transcript rendering, telemetry) only has to understand this one shape.

The concrete CLI-level toolset wraps the generic library toolset with several
production-grade behaviors worth calling out:
- **Registration**: tools are named strings resolved by dotted-path + class-name import,
  with constructor arguments supplied by a small reflection-based dependency-injection
  step (it inspects the constructor's positional parameters, matches each parameter's type
  annotation against a small registry of available runtime services, and injects them;
  keyword-only constructor parameters are left for the tool author to supply directly).
  This lets tool authors write plain classes without a framework-specific base beyond the
  abstract tool class, while still getting access to shared services like the approval
  gate, the session, or the runtime.
- **Description-to-model**: description text shown to the model is often authored as a
  separate Markdown file next to the tool's Python module and loaded at import time —
  keeping long usage guidance out of the Python source and easy for non-engineers to edit.
- **Hidden tools**: a tool can be registered but excluded from what's advertised to the
  model (used to keep a tool callable programmatically while not letting the model choose
  it directly).
- **PreToolUse / PostToolUse / PostToolUseFailure hooks**: every dispatched call runs
  through a hook engine before and after execution; a `PreToolUse` hook can veto the call
  outright (returned to the model as a rejection error, not a crash); `PostToolUse*` hooks
  run fire-and-forget (their own failures are swallowed, never propagated back into the
  turn).
- **Approval gate**: any tool that needs a side-effecting action (shell command, MCP tool
  call, etc.) calls into a shared approval service before doing the work. The service
  supports: fully-automatic modes (an explicit "auto-approve everything" mode and an
  "unattended/away" mode that also implies auto-approve but is tracked as a distinct
  reason), a persisted set of pre-approved "actions" (a caller-chosen identifier string,
  not the raw tool name, so multiple call shapes can share one approval decision),
  synchronous request/response against a pending-approvals queue for the interactive case,
  and a three-way outcome (approve once / approve for the rest of the session / reject,
  optionally with free-text feedback that gets surfaced back to the model so it can try a
  different approach rather than just seeing an opaque "no").
- **Concurrency + dedup**: every tool call for the current step is launched as its own
  async task immediately; if the *same* tool+canonicalized-arguments pair is called twice
  within one step, the second call is not re-executed — it awaits and copies the result of
  the first (arguments are canonicalized by recursively sorting JSON keys before hashing,
  so key-order differences don't defeat the dedup). Across *consecutive* steps, repeats of
  the same call are tracked as a streak; at increasing streak thresholds the tool result
  gets an appended system-reminder telling the model it's repeating itself, escalating in
  urgency, and past a hard ceiling the loop force-stops the turn outright rather than
  trusting the model to notice on its own. This is a pragmatic, self-contained guard
  against infinite tool-call loops that doesn't rely on the model to police itself.
- **Output budgeting**: tool output is capped in size before being added to context (a
  smaller cap for built-in tools, a larger shared character budget for MCP tool output
  specifically, because MCP responses are more likely to be multi-part text+media and to
  come from tools the CLI author doesn't control, like a browser-automation MCP server that
  might return a full page DOM). Oversized text is truncated with a visible marker; oversized
  media parts are dropped entirely with a placeholder rather than truncated mid-binary.
- **Telemetry**: every dispatch (success, error, cancellation, dedup hit) emits a structured
  event with duration, outcome, and (when available) a request trace ID, uniformly across
  built-in, plugin, and MCP tools.

## 5. MCP Integration (client side)

This is the most transferable part of the study for our purposes.

- **Library used**: the official Python MCP SDK for the wire protocol/content types, plus a
  higher-level third-party MCP *client* toolkit that provides connection-pooling,
  transport selection, OAuth device/browser flow, and a config-file format. The CLI does
  not hand-roll stdio/HTTP JSON-RPC framing itself — it delegates that to the client
  toolkit and only implements the "how do I turn one of its tools into *our* tool object"
  and "how do I turn its config format into *our* config format" glue.
- **Configuration model**: a single declarative structure maps server-name → server
  definition. A server definition is one of: a stdio launch spec (command + args + env), a
  streamable-HTTP endpoint (URL + headers + optional auth mode), or an SSE endpoint (same
  shape, different transport tag). This config can come from: a global on-disk config file
  managed by CLI subcommands (add/remove/list/test/auth/reset-auth), an agent-spec's own
  MCP section, or — when the CLI is driven as an IDE agent over the agent-editor protocol —
  MCP server definitions handed over dynamically by the IDE client at session-start time and
  translated into the same internal config shape.
- **OAuth for remote MCP servers**: when a server config's auth mode is `oauth`, the client
  performs the OAuth flow via the client toolkit's built-in OAuth helper, using a
  file-tree-backed token store scoped to the *user's* app-data directory (permissions
  locked down) and keyed by server URL, so tokens persist across CLI invocations without a
  central daemon. Before attempting a connection, the loader checks whether a token
  already exists for that server URL; if not, the server is marked "unauthorized" and
  simply skipped (its tools never show up) rather than blocking the whole toolset load or
  prompting mid-turn — the user has to proactively run an "authorize this server" command,
  which opens a browser for the interactive OAuth grant. A companion command clears cached
  tokens to force re-auth.
- **Connection lifecycle**: MCP servers are connected **lazily and in parallel**, in the
  background, right at the start of a turn (not at process startup) — the loop shows a
  "loading" status while this happens and blocks the *first* turn on it, so the model
  always has an accurate, final tool list before it ever gets to choose a tool. Each server
  gets its own client handle and its own status (pending/connecting/connected/failed/
  unauthorized), tracked independently, and one server's failure doesn't stop the others
  from being tried — the loader gathers all connection attempts and only raises if at
  least one hard-failed (as opposed to soft-skipped for missing auth).
- **Tool discovery and wrapping**: on successful connection, the client's tool-list call
  returns each remote tool's name/description/input-schema; each one becomes a thin wrapper
  object satisfying the *same* internal tool interface as any local tool — its JSON schema
  passes straight through from the remote tool's declared input schema, and its
  description is auto-prefixed with a note identifying which MCP server it came from (so
  the model — and a human skimming the tool list — can tell built-in vs. remote-provided
  capabilities apart, and so a human can attribute misbehavior to the right server).
  Because the wrapper satisfies the normal tool interface, everything else (approval gate,
  dedup, hooks, telemetry, output budgeting) applies uniformly with no MCP-specific
  special-casing anywhere except at the boundary of "convert remote content parts to our
  content parts."
- **Per-call behavior**: each MCP tool call still goes through the approval gate exactly
  like a local tool (with a synthesized action name distinguishing it as MCP-sourced), has
  its own configurable timeout (default one minute, applied via the client library's own
  timeout parameter, distinguished from other runtime errors only by string-matching the
  raised exception — a known rough edge, noted as such directly in that layer), and its
  result content list is converted from the standard MCP content-block types
  (text/image/audio/embedded-resource/resource-link) into the CLI's own content-part types,
  with unsupported/unknown content types swapped for a placeholder text part instead of
  raising and killing the turn.
- **Shutdown**: closing the toolset cancels any still-pending background connection task
  and explicitly closes every connected client, swallowing (but logging) any errors during
  close so teardown never crashes the process.
- **ACP bridge**: when running as an agent-editor-protocol server for an IDE, the IDE's own
  MCP server declarations (which arrive in the IDE's own schema, supporting HTTP, SSE, and
  stdio server types with header/env lists) are translated field-for-field into the CLI's
  internal MCP config shape before being handed to the same loader described above — one
  MCP runtime serves both the standalone CLI and the IDE-embedded mode.

## 6. Model/Provider Abstraction and Streaming

The provider abstraction lives in the shared library and is intentionally narrow: a
provider implements one method that, given a system prompt, a tool list, and history,
returns an async stream of typed message parts (text chunks, "thinking"/reasoning chunks,
tool-call chunks) plus metadata (a request ID, token usage once known, and an optional
provider request-trace-id surfaced as soon as the HTTP response headers arrive — useful for
support/debugging without waiting for the full stream). A single `generate` function in
the shared library consumes that stream generically: it merges adjacent streamed parts of
the same kind in place where possible (e.g. incremental text deltas), pushes each completed
part to optional callbacks (raw part / completed tool call / trace-id) as they resolve,
and fires a small number of correctness invariants — most notably rejecting a response
that contains *only* reasoning/thinking content with no visible text and no tool calls, on
the theory that such a response can only mean the stream was cut short or the output-token
budget ran out mid-thought, never a deliberate model choice.

Concrete provider adapters exist for the major Chat-Completions-style, Responses-API-style,
and native Anthropic- and Gemini-style wire formats, plus the vendor's own hosted model
protocol, all normalized to the same streamed-parts interface — so the rest of the codebase
(agent loop, context management, tool dispatch) never branches on which vendor is active.
A deterministic "echo" provider and a "scripted echo" provider (which can be driven by a
small DSL to script exact responses/tool calls) exist purely for testing the agent loop
without a live model. Model *selection* is a separate configuration concern: named model
aliases map to a provider + underlying model ID + declared capability flags (image input,
video input, "has thinking," "always thinks") and a context-window size, letting the loop
apply capability-aware behavior (e.g. dropping unsupported content types, or estimating
extra token cost for image/media parts) without hardcoding per-vendor conditionals.

## 7. Session / State / Config / Auth

- **Config**: a single validated settings object loaded from a config file (with an
  "is this the default location" flag so the CLI can warn appropriately), covering default
  model/thinking-mode/approval-mode, named models/providers, agent-loop tuning knobs (step
  limit, retry count, context-compaction trigger ratio and reserved headroom), background-
  task limits, notification settings, MCP client timeout, and a hooks list. Nothing here is
  MCP-server-specific beyond the shared tool-call timeout — actual server definitions live
  in a separate file (see §5).
- **Session/state**: each session persists its own state file (working directory, list of
  additional directories the agent has been granted access to, approval-mode flags —
  yolo/away-mode/pre-approved actions — so those choices survive a resume) separate from
  the conversation transcript itself. A "fork" concept exists to branch a new session from
  an existing one's history.
- **Auth**: a dedicated OAuth manager handles login for the vendor's own hosted model
  (device-code-style flow judging by the "run `login`, then follow instructions" messaging
  surfaced through the IDE-protocol auth-required error path), storing tokens under a
  per-user app-data directory. MCP server auth is handled by a *separate* OAuth code path
  (§5), reusing the same on-disk-token-store pattern but keyed per remote MCP server URL
  rather than per model provider — i.e., there are two independent OAuth subsystems (model
  auth vs. tool/MCP auth) sharing a storage pattern but not a token namespace.
- **Filesystem/process abstraction**: a small internal library gives the agent one API for
  "read/write a file," "list a directory," "run a command" that transparently targets
  either the local machine or a remote machine over SSH, so most of the agent code is
  written without caring which backend is active. This is distinct from and unrelated to
  MCP; it's used for the CLI's own built-in file/shell tools.

## 8. Role of the TypeScript/TSX Portion

There is **no terminal-UI framework written in TypeScript** — the interactive terminal
experience is implemented entirely in Python using a mature terminal-toolkit library (the
same family of libraries used for REPLs), living under the CLI's own "shell UI" module.

The TypeScript/TSX code (roughly 175 files) implements **two separate, optional, browser-
based front-ends**, both React + Vite, both served locally by a small FastAPI/uvicorn
process embedded in the Python package (invoked via their own CLI subcommands) rather than
requiring a separately-run Node server in production:
1. A **local web UI** — a fuller chat interface (session list, streaming message view,
   theming, git-diff-stats display, media thumbnails) that talks to the same agent runtime
   as the terminal, over what looks like a typed "wire message" protocol shared between the
   Python backend and this frontend (the frontend has its own hand-maintained TypeScript
   types mirroring the backend's wire event types).
2. A **trace/timeline visualizer** ("Technical Preview" per the docs) — a much smaller
   React app focused on inspecting agent run traces/timelines after the fact, with its own
   lightweight caching and markdown-rendering utilities.

Both are genuinely optional: the CLI is fully usable without ever building or launching
either. They exist to give users a browser-based alternative UI and a debugging/inspection
tool, not to replace or wrap the terminal experience.

## 9. ACP / IDE Integration

The project implements a full **agent-client-protocol (ACP) server** — this is the
"editor talks to agent over a JSON-RPC-like protocol" pattern used by ACP-aware editors.
Notable pieces:
- **Version negotiation** on `initialize`, with the negotiated protocol version threaded
  through the rest of the session so behavior can adapt to older/newer editor clients.
- **Capability advertisement and auth-required signaling**: if the editor's user isn't
  authenticated with the vendor's hosted model, the server returns a structured
  "auth required" response that includes a ready-to-run terminal command (binary path +
  `login` subcommand) the editor can surface to the user, rather than just failing the
  request.
- **Per-session state**: each ACP session gets its own wrapped agent session and a small
  model-ID conversion helper (mapping between the editor's model-selection vocabulary and
  the CLI's internal model aliases).
- **Tool substitution for IDE context**: a dedicated module swaps in editor-aware versions
  of certain built-in tools when running under ACP (e.g. so "open a diff" or "read a file"
  can go through the editor's own APIs instead of raw filesystem calls), rather than the
  IDE integration being bolted on as a totally separate agent implementation.
- **MCP passthrough**: as covered in §5, MCP servers declared by the IDE client itself are
  converted into the CLI's own MCP config shape and loaded through the exact same runtime
  as CLI-native MCP config — one MCP implementation, two entry points.

There's also a companion small client SDK package (separate from the ACP server) that looks
aimed at embedding/driving the CLI programmatically from other tooling, and an example pair
showing how to swap in a fully custom "voice"/system-prompt-and-tools bundle without forking
the agent loop itself — i.e. the loop is designed to be reusable as a library, not just as
an end-user binary.

## Clean-Room Cautions

Do not reuse any of the following in our Rust implementation — these are the vendor's own
naming/branding/layout choices, not generic industry terms:

- Any of the product/brand name forms (the CLI's own name and its two-word product name),
  the persona/agent names used for its built-in alternate agent and for internal mechanism
  nicknames, or any other whimsical internal codename for a mechanism (e.g. the
  "message-to-a-past-checkpoint" rewind feature and the internal library names for the
  provider-abstraction package, the OS-abstraction package, and the client SDK package —
  all are cute, unrelated-to-function names; we should name our equivalents plainly,
  e.g. "checkpoint-revert" and "remote-exec-abstraction").
- The specific config file names/locations, directory layout (`.kimi/`, per-brand skill
  directories, share-directory layout under the user's app-data path), and the exact CLI
  subcommand names/flags (`mcp add/remove/list/test/auth/reset-auth`, `--yolo`, `--afk`,
  etc.) — the *capabilities* are worth having, the exact spellings are the vendor's product
  surface.
- The agent-spec YAML shape and field names (`extend`, `allowed_tools`, `exclude_tools`,
  `when_to_use`, etc.), and the `"<module>:<ClassName>"` tool-reference string convention —
  fine as a *pattern* to learn from, not to copy field-for-field.
- Wire/event type names and the specific "display block" type tags used between backend and
  the two web frontends.
- Telemetry event names and property names (`tool_call_dedup_detected`, `permission_
  approval_result`, etc.) and the specific reminder/system-message copy shown to the model
  on repeated tool calls or plan-mode transitions — these are prompt-engineering text, not
  architecture, and copying LLM-facing instructional strings verbatim is both a licensing
  risk (derivative prompt text) and pointless since our own model/prompt tuning will differ.
- Any doc/example directory names, package names (`kosong`, `kaos`, plus the SDK/plugin
  example names), or the specific third-party MCP-client-library brand — we should describe
  our dependency as "an MCP client/transport library," not name-drop or mimic its API shape
  1:1 in our own crate naming.

## Design Lessons for AiNxt (Rust MCP + tool runtime)

**Adopt:**

1. **Lazy, parallel, background MCP connection at turn-start, not process-start.** Treat
   each configured MCP server as an independent state machine
   (pending → connecting → connected/failed/unauthorized) resolved concurrently; block only
   the very first turn on this, and surface a "still connecting" status rather than
   stalling silently. One server's failure must never take down the others — aggregate
   failures and only hard-fail the turn if a server marked non-optional actually failed
   (missing-auth should be a soft skip, not an error).
2. **One uniform tool interface for local, plugin, and MCP-sourced tools alike.** MCP tools
   should be thin adapters that convert remote schema/description/content into exactly the
   same tool-call/tool-result types used everywhere else, so approval, dedup, hooks,
   telemetry, and output-size budgeting apply automatically with zero MCP-specific
   branching in the dispatch path. Only the schema/content *conversion* boundary should
   know MCP exists.
3. **Structural safeguards against runaway tool-call loops, independent of model quality.**
   Canonicalize call arguments (stable key ordering) for dedup keying; short-circuit
   identical concurrent calls within a step by sharing one in-flight result; track
   cross-step repeat streaks and escalate from a gentle reminder to a hard forced stop past
   a fixed threshold. This must live in the runtime, not be "hoped for" via prompting.
4. **A tri-state, session-cacheable approval gate keyed by a caller-chosen action id (not
   raw tool name), with feedback threaded back to the model on rejection.** Distinguish
   "reject silently → abort the turn" from "reject with feedback → let the model adapt" —
   and for delegated/sub-agent contexts, always prefer feeding rejection back over aborting,
   since a helper should retry differently rather than kill the parent's turn.
5. **Separate OAuth/token storage per MCP server URL from model-provider auth**, using a
   permission-locked per-user token store and a simple "has a token, yes/no" pre-flight
   check so the loader can skip unauthenticated servers instead of blocking startup; provide
   explicit authorize/deauthorize/test CLI verbs so recovering from a bad or revoked token
   doesn't require touching the config file by hand.
6. **Provider abstraction should normalize streaming to a small set of part types (text,
   reasoning, tool-call) with in-place merge semantics**, and enforce a couple of "this
   response is structurally impossible" invariants (e.g., reasoning-only output with no
   tool calls and no visible text is always a truncation bug, never intentional) directly in
   the shared generation path rather than leaving each provider adapter to reinvent it.
7. **Author long tool-usage guidance as data (a companion file) loaded at registration time,
   not as inline string literals**, and keep tool registration declarative (name → concrete
   implementation reference + constructor dependencies resolved by type) so adding a tool
   doesn't require touching the agent-loop code.
8. **Bound and label truncation at the tool-output boundary**, with separate budgets for
   trusted built-in tools vs. third-party/MCP tools (which are more likely to return
   oversized or binary-heavy payloads you don't control), and drop oversized media parts
   with a placeholder rather than corrupting them via mid-binary truncation.

**Avoid / anti-patterns to route around:**

1. Don't let "timeout" detection depend on string-matching an exception message from an
   underlying async transport (the study project's own MCP tool-call timeout handling does
   exactly this and calls it out as a rough edge). In Rust, use a typed timeout error/variant
   from the transport layer so this is a match arm, not a substring check.
2. Don't couple context-window compaction triggers purely to a single ratio-of-max-context
   heuristic without also reserving headroom for the *next* response — both conditions
   (ratio threshold OR remaining headroom too small) should be able to trigger compaction
   independently, since a single ratio check can still let a huge next completion overflow.
3. Don't bake a step/turn hard cap so high (four-figure default) that it functions as "off"
   in practice while still being a magic number developers have to know about — pick a
   default that's a genuine safety net, and make the failure mode (raise vs. silent stop)
   an explicit, documented product decision rather than an incidental exception type.
4. Don't give a core recovery/rewind mechanism (checkpoint + selective revert + synthetic
   replay message) a cute unexplained internal name divorced from its function — it made
   this exact feature slower to understand from the outside and is worth avoiding purely
   for our own maintainability, independent of the clean-room concern.
5. Don't let two independent OAuth subsystems (model-provider auth and per-tool/MCP-server
   auth) share a storage *pattern* without sharing a namespace, then leave discovering that
   distinction to whoever reads the source — document explicitly which auth system owns
   which credential class up front.
