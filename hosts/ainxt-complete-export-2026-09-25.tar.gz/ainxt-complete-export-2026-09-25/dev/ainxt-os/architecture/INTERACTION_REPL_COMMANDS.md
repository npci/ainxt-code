# Interaction, REPL & Commands — design to 10/10

**Status:** Design (no code). Closes the scorecard's interaction/UX gaps (`GAP_ANALYSIS_VS_AI_PLATFORMS.md` codes **AV** conversation control, **AW** trust/error UX, **AX** multimodal I/O, **AY** collaboration, **BK** rich rendering, **BO** perceived latency, **BQ** clarification) to a genuine 10/10 — including the hardest one: proving that our *strategic divergence from every studied vendor* (no interactive terminal UI) is not a gap but a better answer. Also closes three Pass-5 gaps (`GAP_ANALYSIS_PASS5.md`): **[45]** async notification/attention budget (§8), **[46]** feedback loop-closure (§9), **[48]** real-time duplex voice (§10).
**Companion docs:** `AINXT_OS.md` (creation philosophy, Studio/vendor boundary), `RUNTIME_FEATURE_FLOWS.md` (turn pipeline, per-feature traces), `CONVERSATION_INTELLIGENCE.md` (intent/referent resolution — the layer commands and REPL sit on top of), `SUBSYSTEM_DEEP_DIVES.md` §6 (Event Log), `VENDOR_SYNTHESIS.md` §1.6, §1.9 (event-log-as-truth, terminal UX patterns studied), `HARNESS_SDK.md` (Harness composition — commands are a specialization of it), `AGENT_TESTER.md` (replay reused by the Breaker), **ADR-026** (Control Plane is Git-Native — §4.4's authoring/storage/governance for Command Pipelines is an ADR-026 definition kind, not a DB row).

---

## 0. The principle

Every vendor we studied (`VENDOR_SYNTHESIS.md` §1.9) ties "interaction quality" to a bespoke terminal renderer: an Elm-style state machine, a dedicated input thread, scrollback-commit rendering, batched redraws. That is real, hard-won engineering — and it buys exactly one thing: a **good terminal**. It buys nothing for Web, nothing for Desktop, nothing for a shared team session, and it is the same class of investment (a second UI reconciler to independently harden for cancellation, resize, unicode/RTL, and memory) that already produced a real production incident for us — the 26 GB yoga-WASM leak in the scrapped CLI v1 TUI (`feedback_cli_v2_yoga_wasm_leak_fix.md`) and the custom-react-reconciler-for-a-terminal effort it took to get v2's TUI merely *correct* (`feedback_cli_v2_custom_renderer.md`).

**Our answer:** interaction quality is a property of the **protocol and the Event Log**, not of any one renderer. Branch/edit/stop/steer, replay, presence, commands, streaming feel — every one of these is designed *once*, in the spine, as typed events and Event-Log operations. Desktop (rich, GUI-native) and Web get full fidelity for free because they are full-fidelity renderers of that protocol. The CLI stays **headless-only** — a thin, correct, pipe-friendly renderer of the *same* events — and loses nothing that matters for its actual job (automation, CI, air-gapped ops, scripting), because the things a REPL is *for* are covered elsewhere, more fully, at zero duplicated hardening cost. §1 makes this case rigorously, use case by use case. §2–§7 design the actual capabilities — replay, collaboration, commands, trust UX, multimodal, latency — that make the claim true rather than aspirational.

---

## 1. Why no interactive TUI — and where every REPL use case actually lives

### 1.1 What a REPL/TUI is actually buying (deconstructed)

Studying six vendor CLIs (`VENDOR_SYNTHESIS.md`) and our own scrapped v1/v2 TUI effort, "interactive terminal UI" collapses into six underlying jobs — none of which requires a terminal, all of which require a good **protocol**:

| Underlying job | Terminal's mechanism | What actually provides it |
|---|---|---|
| Continuous conversational loop | REPL prompt loop, in-process state | a **session** (Event Log) that survives across invocations |
| Inline approval on risky actions | modal dialog drawn in terminal cells | the **Approval Gate** protocol event (§5, `RUNTIME_FEATURE_FLOWS.md` step 7b) |
| Live visibility into tool calls / "thinking" | streaming redraw of a status line | the typed **event enum** streamed to any renderer (§7) |
| Power-user shortcuts | slash commands, keybindings | **Command Pipelines** (§4) — a protocol/data concept, not a keystroke |
| Resume after crash / long session | in-memory scrollback + save file | the **Event Log** (durable, replayable — §2) |
| Fast, low-ceremony feel | no browser/app to open, instant keystroke echo | a **thin, stateless-startup CLI** (still true without a TUI) |

Every job on the right already has a designed home in the runtime *before* any terminal-specific code is written. A TUI would be a second, terminal-shaped implementation of jobs the protocol already solves once — the exact "each subsystem re-implements its own shallow loop" failure mode `AINXT_OS.md` §1 diagnoses for the *previous* platform, recreated at the client layer.

### 1.2 The four justifications, stated plainly

1. **Fidelity asymmetry is structural, not a polish gap.** A terminal cannot render an inline image, a side-by-side diff with syntax highlighting and click-to-jump, a drag-and-drop attachment, a branch-tree minimap with avatars, or a properly localized RTL paragraph without heroics that still fall short of a native GUI. Desktop (Tauri, per `ainxt_runtime_solution.md` §7) and Web give us all of this natively. Every hour spent approximating it in terminal cells is an hour spent losing to the fidelity ceiling on purpose.
2. **We already paid the cost of the alternative and it broke.** The v1/v2 CLI TUI required its own react-reconciler-style renderer (`feedback_cli_v2_custom_renderer.md`) and produced a 26 GB memory leak from the terminal-layout engine itself (`feedback_cli_v2_yoga_wasm_leak_fix.md`) — bugs with *zero* relationship to agent quality, purely the tax of maintaining a second rendering engine. That tax recurs every time the protocol changes shape (new event type ⇒ new terminal widget to build and re-harden), permanently, for a fidelity-capped surface.
3. **It is the same anti-pattern `AINXT_OS.md` names for the platform layer, recurring at the client layer.** "Fragmentation… each was shallow, and only ever one was hardened at a time" (`AINXT_OS.md` §1) describes a TUI perfectly if we also maintain a Desktop renderer: two UI stacks competing for the same hardening budget, and it is *always* the terminal one that loses when a real deadline hits — which is precisely how v1's TUI ended up behind the Desktop app in practice.
4. **Nothing valuable is actually terminal-specific.** §1.1's table shows every job REPL users care about is a protocol/Event-Log property. A CLI that renders that protocol honestly (streaming text, structured JSON, exit codes) is a **complete, correct renderer** for its actual job — automation — without needing to also be a mediocre chat UI.

### 1.3 Coverage proof — every REPL use case, named, and where it lives now

| REPL use case | Surface that covers it | Mechanism |
|---|---|---|
| "I want to just keep talking, not run a command per message" | Desktop, Web | persistent session over the Event Log; open once, stays open |
| "I want to keep a session alive from a terminal across multiple invocations" | Headless CLI | `ainxt run --session <id>` / `--continue` resumes the same Event Log session; no in-process loop needed — state is server-side, not terminal-side |
| Approve/deny a risky tool call, mid-flow | Desktop (rich dialog: diff preview, scope, "always allow this") / Web | Approval Gate event (§5); CLI in non-interactive contexts uses a pre-declared policy (auto-approve/deny lists) because CI/cron has no human to prompt anyway |
| A human at a bare terminal (SSH, no GUI reachable) needs to approve something *live* | Headless CLI, degraded interactive mode | `ainxt run --interactive-approvals`: a single blocking `y/n/feedback` readline per Approval Gate event — **not a TUI**, one synchronous prompt over the same protocol event a Desktop dialog answers. Zero new rendering engine. This is the one honestly-residual case and it is covered, deliberately minimally. |
| Watch the model "think" / see tool calls live | All | the typed event stream (§7); CLI renders `stream-json` or plain incremental text |
| Slash commands / reusable macros | All | Command Pipelines (§4) — data, interpreted by the same turn pipeline everywhere |
| Resume after a crash, or come back tomorrow | All | Event Log replay + cached incremental projection (`RUNTIME_FEATURE_FLOWS.md` step 1) |
| Review a code diff before it lands | Desktop (rich diff viewer), IDE extension | native diff rendering; CLI emits a plain unified diff to stdout — sufficient for scripted review (`git diff`-style piping), not intended as the human review surface |
| Keyboard-first speed (no mouse) | Desktop | command palette + keybindings + slash commands give keyboard-first *without* the terminal's fidelity ceiling |
| Scripting, cron, CI pipelines, air-gapped ops | Headless CLI | exactly the job it is built for — `--print`, `--json`, exit codes, static binary (`IMPLEMENTATION_PLAN.md` Phase 4) |
| Pairing / demoing a past session to a colleague | Desktop/Web + **Execution Replay** (§2) | replay the recorded session deterministically instead of re-driving it live |
| Multiple people on one thread | Desktop/Web + **Collaborative sessions** (§3) | shared Event-Log session with presence/branching; CLI's role here is observer/bot-participant, not a live multi-writer terminal editor (§3.9) |

**Net claim:** nothing a REPL was ever good for is missing — it has moved to where it is done better (Desktop/Web) or was never actually terminal-specific (protocol/Event-Log properties), with exactly one narrow, explicitly-designed exception (interactive approval with zero GUI reachable), covered by a one-line blocking prompt rather than a second rendering engine.

---

## 2. Execution Replay — deterministic replay from the Event Log

**Principle:** because the Event Log is immutable, tree-shaped, and correlates actions/observations by id (`VENDOR_SYNTHESIS.md` §1.6), any recorded session is a **complete, faithful recording** of a turn pipeline run. Replay is not a bolted-on recorder — it is the Event Log being read instead of appended to, played back through the exact same protocol every live renderer already consumes.

### 2.1 Two replay modes — kept strictly distinct

| Mode | What it does | Cost | Use |
|---|---|---|---|
| **Pure event replay** (default) | Re-streams the *recorded* protocol events exactly as they happened — text deltas, tool calls, approvals, results, timings. No model call, no tool execution, no side effects. | Free (no tokens, no external calls) | Debug ("what exactly happened in run X"), audit/compliance review, demo, training, onboarding |
| **Re-execution replay** (opt-in, explicitly labeled) | Re-runs the turn against the *same frozen inputs* — exact prompt + context + model version + params + seed, captured per turn (`GAP_ANALYSIS_VS_AI_PLATFORMS.md` gaps X/AS) — to check whether behavior has drifted after a prompt/model change | Real tokens, real model call; may legitimately diverge on non-deterministic providers | Regression/behavioral diffing after a prompt or model change; the Breaker's differential oracle (`AGENT_TESTER.md` §2) |

Re-execution never silently substitutes itself for a live turn and never overwrites history: it always forks a **new branch** off the original turn (§3.1), so the recorded past and the "what happened when we ran it again" are both preserved and visibly distinguishable.

### 2.2 Mechanics

```
Replay Engine
  input:  session_id, branch (default = active), turn range (default = all), mode
  reads:  the Event Log slice for that range (read-only; never appends to source)
  emits:  the SAME typed protocol event enum the turn pipeline emits live
  to:     any renderer — Desktop / Web / CLI — identically to a live turn
```

- **Pacing:** real-time (matches original inter-event timing — best for demo/training, so a viewer experiences the actual cadence of tool calls and thinking pauses), fast-forward (2x/5x/instant — best for debug), or **step mode** (advance one event at a time, pause at every tool call / approval / model-call boundary — the primary debugging affordance).
- **Scrub/seek:** jump to any turn or tool-call boundary directly (indexed by event id, not wall-clock offset, since the Event Log is id-correlated not position-correlated).
- **Export:** a replay slice can be packaged as a **replay bundle** — a signed manifest + the event slice, no live account/session access required — so a demo or a training example can be shared without granting the recipient access to the live thread or its credentials.
- **Breaker reuse:** the same Replay Engine backs the adversarial test agent's record/replay and delta-debugging minimizer (`AGENT_TESTER.md` §3, §7) — one mechanism, two consumers (human debugging, autonomous test-shrinking).

### 2.3 Access control and redaction (non-negotiable for a payment org)

- Replay is **RBAC-scoped identically to live viewing** — a session's normal participants can replay it; a compliance/audit role can replay any in-scope session; nobody else can, regardless of "just for demo."
- **What gets replayed is what was persisted after compliance redaction** — the Event Log's primary record is the already-redacted (safe) stream (compliance-in/tool/out already ran before persistence, per the turn pipeline's 🔒 gates). Replay never re-exposes pre-redaction content to a normal viewer.
- If a legal/regulatory requirement needs the pre-redaction original retained (rare, and separately justified), it lives in a **distinct, more tightly gated compliance-evidence record**, accessible only to a dedicated compliance-officer role, itself audited (break-glass access is logged as its own event) — never merged into the normal replay path.

---

## 3. Persistent + collaborative session state

**Foundation already in place:** the Event Log is a **tree**, not a line (`VENDOR_SYNTHESIS.md` §1.6) — turns have stable ids, a movable "active branch head," and actions/observations correlate by id so branched/parallel history survives. What this section designs is the **multi-user protocol and UX** built on top of that tree — shared threads, team workspaces, and branch/edit/stop/steer as first-class, precisely-specified operations.

### 3.1 Session = a tree of turns

Every turn has a stable id and a parent pointer. "Editing" a prior message never mutates it — it creates a **new sibling branch** from that turn's parent. The original branch is never deleted; it stays fully replayable (§2) and audit-visible. A session viewer always has an **active branch head** (which path is "current") plus the ability to switch heads — this is the same primitive whether the switch is "regenerate this answer" (one user) or "compare Priya's version to mine" (a team).

### 3.2 Multi-writer collaboration without relaxing single-writer safety

The turn pipeline's actor-per-session model is single-writer for a reason — a bounded inbox serialized by one task is what makes cancellation and concurrent-tool-call safety tractable (`RUNTIME_FEATURE_FLOWS.md` step 1, `VENDOR_SYNTHESIS.md` §1.2). Collaboration does **not** relax this. Instead: **multiple authenticated participants submit commands into the same one inbox**, each command tagged with `participant_id`. The actor still processes one command at a time, in arrival order — collaboration is *shared access to one inbox*, not *multiple writers racing*. This is why there is no data-layer edit-conflict to resolve (§3.6) — arrival order already total-orders every command.

### 3.3 Stop vs. steer — precisely distinguished

These are the two most-confused REPL affordances and the design must not blur them:

- **Stop** fires the turn's shared cancellation token (`RUNTIME_FEATURE_FLOWS.md` step 6/7 — "one cancellation token shared by stream and all tool futures"). In-flight model stream and tool futures are cancelled cleanly; the turn is marked `turn.stopped` in the Event Log (never deleted — audit-visible); session returns to idle. **Always available, always immediate, from any authorized participant** — safety over politeness: a second participant's urgent Stop is never blocked by a first participant's in-progress steer.
- **Steer** does **not** cancel. It appends a `turn.steer{text}` event while a turn is in flight. The agent loop treats it as a queued user interjection, delivered at the next **safe boundary**: immediately if the model is generating text, or after the current tool call completes if one is in flight (steer never interrupts a tool call mid-execution, which could leave a side effect half-done). The model incorporates it as new input without restarting the turn from scratch.
- **Edit** is only valid on a *user* turn (the assistant's own turns are not user-editable) and is exactly the branch operation in §3.1 — old descendants are preserved on the old branch, never discarded.
- **Branch** is an explicit, user-invoked fork (`turn.branch{from_turn_id}`) used to deliberately explore an alternative without touching the "official" line — named/labeled for team clarity ("what-if: without the discount clause").

### 3.4 Presence and awareness

Presence is broadcast over the **same** event stream every participant already subscribes to (SSE/WebSocket fan-out, no new transport): `participant.joined`, `participant.left`, `participant.typing`, `participant.viewing{turn_id}`. On join, a participant receives a `session.snapshot` event carrying the current tree state, so a late joiner doesn't need to replay from turn zero.

### 3.5 Team workspaces and sharing

A **workspace** is an RBAC container over a set of sessions, using the *same* visibility model already designed for Agents/Skills/Workflows (`AINXT_OS.md` §3, `CLAUDE.md` Auth section): public / department / private, department-scoped via the AD org tree. Sharing a session sets its visibility and, optionally, an explicit collaborator allow-list beyond the department default. **Sharing is never a privilege-escalation path**: a shared session can only include participants who are *independently* authorized for that session's data scope (repo/department/data-class) — sharing widens *visibility of a conversation*, never *grants* access to underlying data a participant wasn't already permitted to see (ties to the on-behalf-of / confused-deputy authz gate, `GAP_ANALYSIS_VS_AI_PLATFORMS.md` code AI).

### 3.6 "Conflicts" are a UX problem, not a data-layer one

Because commands are strictly serialized (§3.2), there is no race at the data layer. What can happen is a **UX** collision: two people edit the same turn moments apart. The second edit is simply a **second sibling branch** off the same parent — never a silent overwrite. The UI shows both branches labeled with author + timestamp and lets the team pick one to continue from, or manually copy content forward from one branch onto another's head ("take this version"). **Automatic merging of divergent AI-generated branches is explicitly not attempted** — text-merging generative content is a known, unreliable, uncanny-valley problem; the design punts to human choice on purpose rather than fabricating a merge.

### 3.7 Soft focus indicators

An advisory-only "Priya is steering this turn" indicator reduces confusing double-steers, but it is **never a hard lock** — it cannot block a legitimate Stop or Steer from another authorized participant.

### 3.8 Protocol surface

Collaboration adds a small set of new variants to the **same** typed event enum every renderer already consumes — `session.snapshot`, `turn.branch`, `turn.edit`, `turn.stop`, `turn.steer`, `participant.*` — no new transport, no renderer-specific side channel. This is deliberate: a Desktop client, a Web client, and a bot participant posting from a CI job all speak the identical protocol.

### 3.9 What the CLI does in a collaborative session — honestly scoped

Consistent with §1: the CLI's role in collaboration is **observability and automation**, not full interactive multi-writer editing.
- `ainxt session watch <id>` — read-only tail of a shared session's live event stream (useful for a status dashboard, a log, or a human occasionally checking in from a terminal).
- `ainxt session log <id> --tree` — an ASCII rendering of the branch tree for a quick terminal-side orientation.
- `ainxt session share <id> --workspace <ws>` — a scriptable equivalent of the Desktop "share" action.
- A CLI invocation *can* be a full participant (e.g., a CI job posting a build-status turn into a shared thread) — it just isn't the surface for a human to interactively co-edit branches, because without a rich UI that experience degrades badly; that job belongs to Desktop/Web, per §1's coverage table.

---

## 4. Programmable command pipelines — the AiNxt way (not a visual DAG)

**Boundary statement (load-bearing, restated from `AINXT_OS.md` §0):** the visual node-and-wire DAG is the **external vendor's** product, for the deterministic/auditable/scheduled niche where explicit graphs are *wanted*. Command Pipelines are **not** a smaller version of that tool. They are declarative, reusable, **intelligence-driven** macros — the same moat (`AINXT_OS.md` §0: "intelligence, not configuration") applied to repeat-invocation instead of one-off chat.

### 4.1 Slash commands — the entry point, already designed

`CONVERSATION_INTELLIGENCE.md` §2 Stage 1 already treats a slash command as a **deterministic intent signal** that skips classification entirely (`/pdf`, `/doc`, `/ppt`). Command Pipelines are the generalization: a slash command can name either a built-in capability shortcut (existing behavior, unchanged) **or** a user-authored Command spec (new). No new intent-detection seam is needed — Commands slot into Stage 1 exactly where slash commands already live.

### 4.2 A Command is a named, parameterized step sequence — not a graph

A Command is a `kind: command` **control-plane definition** (ADR-026 §4/§5) — a `definition.md` under `commands/weekly-settlement-brief/` in the control repo. The front-matter above the fold is the *same* ADR-026 §5 manifest every definition kind carries (`kind`/`id`/`version`/`owner`/`execute_rbac`/`data_class_ceiling`); `trigger`/`params`/`steps`/`autonomy` are the fields this kind adds:

```yaml
---
kind: command                        # skill | agent | role | team | workflow | policy | prompt | command
id: command.weekly-settlement-brief
version: 1.0.0
owner: settlement-ops                 # accountable CODEOWNERS group (ADR-026 §5/§8)
summary: Summarize this week's settlement exceptions and post to the team channel.

execute_rbac:                         # read by the Policy Engine (ADR-003) at INVOKE time, §4.4
  visibility: public                  # public | private
  departments: [settlement-ops]       # empty ⇒ all; dept-scoping enforced per JWT dept
  min_role: user

data_class_ceiling: internal          # ADR-012 — max data class this Command may operate on

trigger: {type: manual}               # manual | cron | event — §4.4

params:
  - week: {type: date_range, default: last_7_days}
steps:
  - id: exceptions
    run: connector.postgres.query        # a Capability — governed/permissioned, same registry as everywhere
    args: {query: "settlement_exceptions", range: "{params.week}"}
  - id: brief
    run: agent.invoke                    # an INTELLIGENCE step, not a fixed template
    args:
      instruction: >
        Summarize {exceptions} for a non-technical audience: top 3 causes,
        trend vs last week, and one recommended action.
  - id: post
    run: connector.teams.post_message
    args: {channel: "#settlement-ops", text: "{brief}"}
autonomy: assisted        # HITL approval before "post" — the same Approval Gate seam as everywhere
---
```

Steps chain via `{step_id}` output references — the **same** convention `CLAUDE.md` already mandates for workflow-step chaining and SDLC; reused, not reinvented.

### 4.3 The one design choice that keeps this from becoming the scrapped DAG

Step `brief` is a genuine sub-turn through the canonical **Agent Loop** (`RUNTIME_FEATURE_FLOWS.md` §1) — it can reason over malformed `exceptions` data, call further tools, or ask a clarifying question if `{exceptions}` is empty. A visual-DAG competitor's node is a fixed transform with fixed edges; our step is a bounded conversation, not a wire. This is *why* a Command inherits compliance/RBAC/approval/cancellation for free — it is not a parallel execution engine that needs its own hardening pass, it is N ordinary turns with output-passing between them.

**Explicit anti-scope-creep rule:** Commands stay a **linear step list + params + `{ref}` interpolation** — no branching/looping/control-flow language is added to the spec. The moment a use case needs real conditional branching, fan-in/fan-out graphs, or industrial-scale scheduled ETL with an auditable node-by-node structure, **that is the explicit signal to use the vendor's visual Studio instead** (`AINXT_OS.md` §0's own boundary). Commands are kept deliberately simple *so that we never accidentally rebuild the tool we decided not to own*.

### 4.4 Authoring, storage, triggers — git-native (ADR-026)

Command Pipelines are a **control-plane definition kind**, exactly like Skills/Agents/Roles/Workflows (ADR-026 §2/§3) — not a DB row. A Command's spec lives as a `definition.md` under `commands/<name>/` (manual/ad-hoc Commands) or `workflows/<name>/` (scheduled/event-triggered Commands — same manifest shape, front-matter `trigger` differs) in the git control repo.

- **Conversational-first authoring** (mirrors Role/Skill/Agent creation, `AINXT_OS.md` §4): describe it once — *"every Monday I want a settlement exceptions brief posted to the team channel"* — and the Factory proposes the steps spec back for review. Per ADR-026 §16's Studio-as-git-client obligation, the Factory **emits a PR** — it drafts the front-matter + step body on a feature branch and opens the merge request on the author's behalf; the human reviews a diff, not a form submit. The YAML is the **stored artifact**, never the required *authoring* interface — a non-engineer never hand-writes git commands to get a Command reviewed.
- **Power-user path**: hand-edit the `definition.md` directly on a feature branch and push — this is the "slash-commands for power users" requirement, satisfied without contradicting the intelligence-first thesis: conversational creation is the default, direct spec/PR editing is the shortcut, exactly mirroring the existing Skill/Agent authoring duality (`HARNESS_SDK.md` §2).
- **Storage/governance (ADR-026):** lifecycle is git-native, per ADR-026 §7.1's mapping — a feature branch is `DRAFT`; an open PR (schema validation + the compliance-gate + a Breaker dry-run in CI, ADR-026 §10) is `PENDING_APPROVAL`; merge to `main` (CODEOWNERS-approved, signed commit, ADR-026 §8) is `APPROVED`; a signed semver tag promoted onto `env/prod` is `PRODUCTION`. There is **no `status:` field** in the manifest — status is the file's position in git, never a declared value a single actor could flip (ADR-026 §5). **Visibility/department scoping** is the `execute_rbac` front-matter block (§4.2) — read by the Policy Engine (ADR-003) at **invocation** time, not at authoring time: a Command merged and tagged to `env/prod` may *exist* in production; whether a given caller may *run* it is the orthogonal, per-turn RBAC-on-execute question (ADR-026 §8), unchanged by how git-approved the definition is. A Command is committed **via a reviewed PR, never a DB row** — the same CODEOWNERS authoring RBAC, signed-commit integrity, and content-addressed lockfile verification apply as to every other control-plane definition kind. A Command is, structurally, a lightweight parameterized **Harness composition** (`HARNESS_SDK.md`) specialized for repeat invocation by a short name.
- **Triggers**: manual (typed as a slash command), scheduled (cron via the existing scheduler), or event-triggered (an inbound connector event — the same seam SDLC uses for GitLab/Jira webhooks, `RUNTIME_FEATURE_FLOWS.md` §2.4). The trigger type is itself reviewed front-matter (`trigger: {type: manual|cron|event, ...}`, §4.2) — never a scheduler-UI setting configured out-of-band from the reviewed definition. One mechanism, three trigger sources.
- **Composability, bounded**: a step can invoke another Command (`run: command.invoke`), resolved through the same semver-ranged `depends_on` composition graph every control-plane definition uses (ADR-026 §5), with a bounded depth and cycle-detection enforced at load — the same discipline already applied to single-level agent/sub-agent inheritance (`HARNESS_SDK.md` §1) — reuse without an uncontrolled graph.

---

## 5. Trust/transparency UX and graceful error UX

### 5.1 Sources, confidence, "why this"

- **Sources:** every grounded claim carries an inline, clickable citation referencing the Context Fabric's **lineage record** (`CONTEXT_FABRIC.md` §3 — "context window + a lineage record"). Desktop/Web render source snippet + link on hover/click; CLI/`--json` renders a numbered footnote list (`[1] docs_kb:platform/settlement-ops.md#L120`) — same information, degraded gracefully, never dropped.
- **Confidence:** a calibrated three-tier indicator (high/medium/low), never fake decimal precision — derived from retrieval score + the model's own uncertainty/abstention signal (`GAP_ANALYSIS_VS_AI_PLATFORMS.md` gap U). **Low confidence triggers a clarifying question (gap BQ) instead of a confidently wrong answer** — the calibrated-clarification discipline `CONVERSATION_INTELLIGENCE.md` §2 Stage 3 already specifies, extended from "ambiguous intent" to "low-confidence retrieval" as a second trigger for the same mechanism.
- **"Why this":** a collapsible `turn.rationale` panel (progressive disclosure — never forced on the user) showing which model tier was chosen and why, which capabilities/tools ran, and which sources were pulled in. It is generated **from the Event Log itself** — the turn's own trace, not a separately maintained explanation system that can drift out of sync with what actually happened. This makes "why this" audit-grade for free: it is the same record compliance already relies on.

### 5.2 A typed error taxonomy — never a stack trace

Every user-facing failure is one of a small, honest, named set — each with a designed recovery affordance, never a dead end:

| Category | Meaning | Recovery shown to the user |
|---|---|---|
| `capacity` | 503 / backpressure | "We're at capacity — retrying automatically" (auto-retry with backoff) |
| `capability_denied` | RBAC/policy blocked an action | explain what was denied and why; offer to request access |
| `provider_unavailable` | a model provider failed *and* failover also failed | only ever shown after failover is attempted first; offer retry / switch model |
| `capped` | the SDLC judge-loop honestly could not confirm completion (`SUBSYSTEM_DEEP_DIVES.md` §1 point 8) | show the judge's specific gap report; never claim "done" |
| `compliance_redacted` | content was redacted, audit-and-proceed | tell the user *what category* was redacted and that the action proceeded — never a silent content change |
| `ambiguous` | genuinely underspecified request | a clarifying question — this is a *conversation turn*, not an error state |

### 5.3 Partial-result handling

A turn that fails partway (e.g., 2 of 3 fan-out compare branches errored, `RUNTIME_FEATURE_FLOWS.md` §2.3) still renders the branches that **succeeded**, clearly labeled as partial, rather than discarding the whole turn. This extends the existing "soft tool failures fed back as ordinary results" pattern (`VENDOR_SYNTHESIS.md` §1.2) from the model-facing loop to the user-facing UX layer — failure is informative, not erasing.

---

## 6. Multimodal I/O

- **Input:** text; file attachments (any type, size-capped, passed through the modality-aware Compliance Gate below); images (routed to the vision model tier per `model_router`); voice — today, batch STT → the identical text-turn pipeline → optional TTS out, generalizing the existing `VoiceMode.jsx` pattern to the new protocol; **§10 designs the real-time duplex upgrade** (persistent bidirectional session, server-VAD, barge-in, sub-300ms turn-taking) additive to this batch path, which remains the fallback for transports that can't hold a persistent stream; and, for Buddy, gated screen-context capture.
- **Output:** text; artifacts (docx/pptx/xlsx/pdf via the Artifact Runtime); images (Gemini Imagen / DALL·E only, per the enterprise no-stock-API rule); audio (TTS); and rich structured blocks (tables/charts/diagrams) rendered natively by Desktop/Web, degrading to fenced code/ASCII in CLI or `--json` mode.
- **One typed `Attachment`/`Modality` family in the protocol event enum** — not per-surface bespoke handling. Every renderer gets every modality the moment it's added to the enum; no surface-specific plumbing.
- **Compliance is modality-aware, not text-only:** the Compliance Gate (🔒, `RUNTIME_FEATURE_FLOWS.md` step 3/8) runs a per-modality pre-processor — OCR for images, ASR for audio, vision-caption for screenshots — **before** the redaction ruleset applies, so a PAN visible in a screenshot or an account number spoken aloud is caught exactly like typed text. This directly closes the gap `GAP_ANALYSIS_VS_AI_PLATFORMS.md` calls out by name (AX: "PII in images, audio transcripts").

---

## 7. Perceived latency and streaming feel

- **Time-to-first-signal, not just time-to-first-token:** the moment the turn pipeline *accepts* a request (before the model has produced anything), a "thinking" indicator fires — the user sees acknowledgment within tens of milliseconds, never a blank wait, even before prompt assembly/retrieval finishes.
- **Token-level streaming end to end:** Desktop/Web render incremental markdown (tables and code blocks re-parsed progressively, never flashing); CLI's `stream-json` mode emits one JSON object per protocol event for pipe-friendly incremental consumption; plain-text mode flushes per token.
- **Long agent turns show progress, not silence:** every tool-call start/stop is already its own protocol event (emitted for the 🔒 approval/compliance gates regardless of UX) — the renderer's job is only to *render* them ("Searching knowledge base…", "Running tests…", "Waiting for approval…"), not to invent new signal. Perceived responsiveness during a multi-tool-call turn is a rendering choice on top of data that already exists.
- **Batched, rate-limited redraws** (generalizing `VENDOR_SYNTHESIS.md` §1.9's terminal-specific finding to every renderer) — never redraw faster than perceptible; avoids visual jank without adding actual latency.
- **Measured, not vibes-based:** p50/p95 **time-to-first-token** and **time-to-first-tool-call-visible** are tracked per surface as real SLOs (ties to gap BO and the Y SLO/error-budget gap) — "it feels slow" becomes a monitored metric with an owner, not a subjective complaint.

---

## 8. Async notification & attention budget (`GAP_ANALYSIS_PASS5.md` gap 45)

**Principle:** every notification the platform emits competes for a scarce, non-renewable resource — human attention. A platform that pages carelessly gets its channel muted, which is *worse* than not notifying at all (a muted channel then also misses the one notification that actually mattered). Attention budget is designed once, as a property of the notification path, not reinvented per feature/connector.

### 8.1 Batch vs. immediate — a per-event classification, decided by the emitter
Every event that could notify a human carries a **notification class**, set at emission time by the subsystem that raised it (Approval Gate, SDLC run, compliance alert, …) — never by the delivery channel, so the same event class behaves identically regardless of which channel a recipient happens to be on:

| Class | Examples | Delivery |
|---|---|---|
| `immediate` | Approval Gate awaiting a live human (§5), a `capacity`/`provider_unavailable` failure blocking a run the user is watching, a security-incident breach clock (`REGULATED_FI_COMPLIANCE_OPS.md` §2) | pushed now, on every subscribed channel, bypassing digest and quiet hours |
| `batched` | SDLC run completed, a scheduled Command (§4) posted its result, a non-blocking eval regression | queued into the recipient's next digest (§8.2) |
| `informational` | routine run-log entries, presence events (§3.4) | never paged; visible only if the recipient looks (session tail, Event Log) |

### 8.2 Quiet hours and digest — attention budget, per recipient
- **Quiet hours** are a per-user, server-side preference (Postgres, data plane — `CLAUDE.md` no-localStorage rule) — a window during which `batched`/`informational` notifications are held; `immediate` notifications still deliver, because attention budget never overrides a live approval need.
- **Digest** is a scheduled rollup (the same cron seam as Command triggers, §4.4) that delivers all held `batched` events since the last digest as one summarized message — generated by the same summarization capability used elsewhere, not a bespoke template ("3 SDLC runs completed, 1 needs your review" instead of three separate pings).
- **One typed event, fanned out per recipient preference:** the notification path emits a single `notification.emitted{class, recipient, payload}` protocol event; a Notification Router resolves channel (Slack/Teams/email/in-app) + quiet-hours + digest per recipient. Individual connectors never decide batching themselves — there is exactly one place attention-budget policy is applied.

### 8.3 Escalation ladder — unacknowledged is never silently dropped
An `immediate` notification unacknowledged within a bounded window escalates — generalizing the breach-clock paging ladder `REGULATED_FI_COMPLIANCE_OPS.md` §2 already uses (50/75/90% of budget): unacknowledged after N minutes → re-delivered on a secondary channel → after M minutes → escalated to the recipient's manager/on-call (department org-tree lookup, `CLAUDE.md` Auth). Every step — original delivery, re-delivery, and escalation — is its own `notification.*` Event-Log entry, so "did anyone see this" is always answerable, never a guess. Reclassifying an event from `batched` to `immediate` (e.g., 3 consecutive SDLC failures) is an emitter-side escalation rule, not a manual per-user channel toggle.

---

## 9. Feedback loop-closure — "you told us X, we changed Y" (`GAP_ANALYSIS_PASS5.md` gap 46)

**Principle:** feedback that disappears into a silent backlog trains users to stop giving it — the fastest way to kill a feedback channel is for the first few submissions to visibly go nowhere. Closure is a mechanism, not a policy reminder to product owners.

- **Every feedback item is a typed, tracked artifact.** A thumbs-down on a turn, a `/feedback` command, or a routed support ticket becomes an `InboxItem`-shaped record (`CLAUDE.md` storage layer — Postgres, **data plane**: feedback tied to a person/session is operational state, not a control-plane definition, ADR-026 §3) with a stable id, linked to the originating turn/session (Event Log id), the owning team, and a status: `received → triaged → actioned → shipped`, or `declined {reason}`.
- **"Actioned" requires a linked artifact, not a status flip.** A feedback item reaches `shipped` only when linked to the change that closed it — a merged control-plane PR (a prompt/skill/policy diff, ADR-026 — the commit SHA is the proof), a shipped code change (linked MR), or an explicit decline reason. There is no path to `shipped` that is just someone editing a status field — this is what makes "we changed Y" independently checkable, not a claim to trust.
- **Closing the loop back to the reporter is itself a notification (§8).** `feedback.closed{item_id, change_ref, summary}` fires a notification (`batched` by default — a "your feedback shipped" is never urgent, per §8.1) back to the original reporter, generated from the actual linked change, not a generic thank-you template. This is the specific mechanism that makes closure *visible to the person who gave the feedback*, not merely closed in a tracker they never see again.
- **Aggregate transparency, reusing §4, not a bespoke report.** A rolling feedback digest ("this month: 40 received, 22 shipped, 12 declined with reasons, 6 in triage") is itself a scheduled Command (§4) posted to a public dashboard/channel — the same mechanism, not a second reporting job — making loop-closure rate a visible, owned metric rather than an internal number nobody outside the team ever sees.

---

## 10. Real-time duplex voice architecture (`GAP_ANALYSIS_PASS5.md` gap 48)

**Where this sits:** §6 describes today's voice pattern — batch STT → the identical text-turn pipeline → optional TTS out. That pattern is correct and simple but structurally cannot support a natural spoken conversation: no interruption, no mid-sentence backchannel, and turn latency dominated by "wait for silence, then wait for the whole reply." This section designs the **duplex upgrade**, additive to §6, never a replacement — batch voice remains the fallback for transports that can't hold a persistent stream (e.g., a Teams voice-message attachment).

### 10.1 Persistent bidirectional session — the structural change
A duplex voice turn is not "many quick batch turns" — it is **one long-lived, bidirectional session** over a single transport (WebSocket/WebRTC), carrying the *same* typed protocol event enum every other renderer consumes (extending §7's discipline to audio): audio frames in; `voice.partial_transcript` / `voice.final_transcript` / `voice.agent_speaking` / `voice.interrupted` out. This reuses the Event Log exactly as text turns do — a duplex call is a session like any other: replayable (§2), observable via `ainxt session watch` (§3.9), and Approval-Gate-compatible (a risky tool call mid-call fires the same gate, rendered as a spoken prompt, §5).

### 10.2 Server-side VAD — who decides the user is "done" speaking
Voice Activity Detection runs **server-side** on the streaming audio — not client-side, and not a fixed silence timeout (either too eager, cutting off a thought, or too laggy, feeling unresponsive). The VAD model continuously scores speech-vs-silence and emits `voice.turn_boundary_candidate` the moment confidence crosses threshold; the agent loop treats this exactly like a text turn's submit, with the **same steer semantics as §3.3** — if the user resumes speaking within a short grace window, the candidate boundary is retracted and folded into the same turn rather than firing two turns for one thought.

### 10.3 Barge-in — the agent must be interruptible mid-sentence
While the agent's TTS is streaming, user speech crossing the VAD threshold fires `voice.interrupted`, which: (1) cancels the in-flight TTS stream immediately — barge-in *is* a Stop (§3.3), scoped to audio output only, so in-flight tool calls still finish at their next safe boundary, never half-executed; (2) truncates the persisted transcript at the interruption point, so replay (§2) shows exactly what was actually heard, not the full unplayed reply; (3) immediately starts listening for the next turn or steer (same §3.3 distinction, applied to speech). Barge-in is the single hardest real-time property in this design (residual risk, §12) — implemented sluggishly, it degrades into "the bot ignores you until it finishes talking," which is worse than no duplex support at all.

### 10.4 The <300ms budget — where it is spent, honestly
"<300ms" is a **conversational-turn-taking** latency budget (end-of-user-speech to first-audio-frame-of-reply), not a full-response budget:

| Stage | Budget | Mechanism |
|---|---|---|
| VAD boundary detection | ~50–100ms | server-side streaming VAD (§10.2) |
| STT partial→final transcript | ~50–100ms | streaming ASR refining in place, not batch |
| First model token | the existing time-to-first-signal/first-token budget (§7, L1/L3) | same acknowledgment-before-output discipline, reused |
| TTS first-audio-frame | ~50–100ms | streaming TTS synthesizing from the first tokens, not the full response |

Each stage is its **own measured SLO** (extending §7's "measured, not vibes-based" discipline to voice) — a regression is attributable to a specific stage, never lost in an aggregate "voice feels slow" complaint. Where the full agent turn genuinely needs longer (a multi-tool-call reasoning turn), the *turn-taking* budget is still met by a natural verbal acknowledgment ("let me check that…") synthesized immediately — the same perceived-latency pattern §7 already designs for text ("Searching knowledge base…"), generalized from a status line to speech.

### 10.5 Compliance stays on the hot path
Duplex voice does not weaken §6's modality-aware Compliance Gate: ASR output is scanned exactly as batch voice is (M2, §6) — on the **streaming partial transcript** as it finalizes, not deferred to end-of-call, so a spoken account number is caught within the turn it was spoken, not after the whole call ends.

---

## 11. Acceptance tests

**§1 — no-TUI coverage claim**
- **N1:** for every row in §1.3's coverage table, a scenario exists proving the named surface actually delivers the use case (e.g., Desktop's rich approval dialog shows diff+scope+"always allow"; headless CLI `--continue` resumes a session created from Desktop).
- **N2:** a human with only SSH access (no GUI reachable) can approve/deny a live tool call via `ainxt run --interactive-approvals` without any TUI rendering engine — a single blocking prompt answers the same Approval Gate protocol event Desktop answers with a dialog.
- **N3:** CLI `stream-json` output is byte-for-byte reconstructable into the same protocol event sequence Desktop rendered live for the identical turn (proves "same protocol, different renderer," not "different behavior for CLI").

**§2 — Execution Replay**
- **R1:** pure event replay of a recorded session reproduces the exact original text/tool-call/approval sequence with zero model calls and zero side effects.
- **R2:** re-execution replay is visually/structurally distinguished from pure replay in every renderer, and always lands on a new branch — the original branch is untouched and independently replayable afterward.
- **R3:** replay honors RBAC — a user outside the session's scope cannot replay it; a compliance-audit role can replay any in-scope session.
- **R4:** a replay bundle exported for a demo contains no live credentials and does not grant the recipient access to the source session.
- **R5:** step-mode replay pauses at every tool-call and approval boundary and can be resumed or aborted at each pause.

**§3 — Collaborative sessions**
- **S1:** two participants submitting commands to the same session at overlapping times never produce a data-layer race — the actor processes them in a total, deterministic order.
- **S2:** editing a turn that already has descendant turns preserves the old branch fully (still replayable) and creates a new sibling branch for the edit.
- **S3:** Stop cancels an in-flight turn's model stream *and* every in-flight tool future within one cancellation-token fire, and is never blocked by another participant's concurrent steer.
- **S4:** Steer injected while a tool call is executing is queued and delivered only after that tool call completes — never mid-tool-call.
- **S5:** two participants editing the same turn within seconds of each other produce two labeled sibling branches (author + timestamp), never a silent overwrite and never an attempted automatic text-merge.
- **S6:** a session shared to a department-visibility workspace is only visible to participants independently authorized for its underlying data scope — sharing alone never grants access to data a participant wasn't already permitted to see.
- **S7:** a late-joining participant receives a `session.snapshot` reflecting current tree state without replaying from turn zero.

**§4 — Command Pipelines**
- **C1:** a Command with a data-fetch step, an intelligence step, and a connector-post step executes end to end, with the intelligence step correctly handling an empty/malformed upstream payload by asking a clarifying question rather than crashing or hallucinating data.
- **C2:** the `autonomy: assisted` HITL gate on a Command's side-effecting step blocks on the same Approval Gate seam a normal chat turn's tool call uses — no separate approval mechanism was built.
- **C3:** a Command authored conversationally ("every Monday...") produces a spec a power user can subsequently hand-edit directly, and re-running the edited spec reflects the edit.
- **C4:** attempting to express a conditional-branch/loop control-flow requirement in a Command spec is explicitly rejected/unsupported (by design) — proving the spec has not silently grown into a DAG language.
- **C5:** a Command triggered by a scheduled cron and one triggered manually by slash command produce identical, indistinguishable event sequences downstream of the trigger.

**§5 — Trust/error UX**
- **T1:** every citation shown in a rendered answer resolves to a lineage record entry that can be independently verified against the source document.
- **T2:** a retrieval with low confidence triggers a clarifying question instead of a confidently-stated low-grounding answer.
- **T3:** the "why this" rationale panel for a given turn matches the Event Log's own recorded trace for that turn exactly (no divergent, separately-generated explanation).
- **T4:** each error-taxonomy category (§5.2) renders its designed recovery affordance; no failure path renders a raw stack trace or an unrecoverable dead end to the user.
- **T5:** a 2-of-3 fan-out compare where one branch errors still renders the two successful results, clearly labeled partial.

**§6 — Multimodal**
- **M1:** a PAN visible only inside an uploaded screenshot is redacted by the compliance gate before the turn proceeds (OCR pre-processing verified).
- **M2:** a spoken account number in a voice turn is caught by compliance identically to the same number typed as text.
- **M3:** an image-generation request is fulfilled only via Gemini Imagen/DALL·E — never a stock-photo API — across every surface.

**§7 — Latency/streaming feel**
- **L1:** a "thinking" indicator appears within a fixed small bound (tens of ms) of request acceptance, before the model has produced any token.
- **L2:** during a multi-tool-call turn, at least one progress signal (tool-call start/stop) is visible to the user at least every N seconds — never a silent gap longer than the bound.
- **L3:** p95 time-to-first-token and time-to-first-tool-call-visible are captured as monitored SLOs per surface and alert on regression.

**§8 — Async notification & attention budget**
- **AN1:** an `immediate`-class notification is delivered on every subscribed channel within a bounded latency regardless of the recipient's quiet-hours setting.
- **AN2:** a `batched`-class notification issued during a recipient's quiet hours is held and delivered only in the next digest, never as an interrupt.
- **AN3:** an `immediate` notification unacknowledged past its escalation window is re-delivered on a secondary channel and, if still unacknowledged, escalates to the recipient's org-tree manager — with both the original delivery and the escalation recorded as Event-Log entries.
- **AN4:** reclassifying an event from `batched` to `immediate` (e.g., 3 consecutive SDLC failures) is driven by the emitting subsystem's own escalation rule, not a manual per-user channel toggle.

**§9 — Feedback loop-closure**
- **FB1:** a submitted feedback item is retrievable by the reporter at any later time and shows one of the defined statuses — it never silently disappears from view.
- **FB2:** a feedback item cannot be marked `shipped` without a linked change artifact (a PR/MR or control-plane commit SHA) that a reviewer can independently open and inspect.
- **FB3:** when a feedback item reaches `shipped`, the original reporter receives a notification naming the specific change, generated from the linked artifact, within one digest cycle.
- **FB4:** the aggregate feedback digest total (received/shipped/declined/in-triage) reconciles exactly against the underlying `InboxItem` records for the period — the dashboard number is never higher than what is independently auditable.

**§10 — Real-time duplex voice**
- **V1:** a user speaking naturally, without a fixed pause, has their turn boundary detected by server VAD without cutting off mid-thought (measured against a corpus of natural speech containing mid-sentence pauses).
- **V2:** speaking over the agent's TTS output truncates playback within a bounded, sub-200ms window, and the truncation point is reflected exactly in the persisted, replayable transcript.
- **V3:** p95 time from end-of-user-speech to first-audio-frame-of-reply is measured and alerted per stage (VAD/STT/first-token/TTS) as independent SLOs, and the aggregate meets the <300ms conversational-turn-taking budget for simple turns.
- **V4:** a spoken PAN/account number is redacted by the compliance gate before the turn proceeds, verified against the streaming partial transcript, not only the final one.
- **V5:** a duplex voice session is fully replayable (§2) and RBAC-scoped identically to a text session (§2.3) — the audio transport creates no parallel, less-audited path.

---

## 12. Why this is now a 10

It takes the one place we deliberately diverge from every studied vendor and proves the divergence rather than asserting it: §1 names the six real jobs a REPL does, shows each already has a designed, better home (protocol + Event Log + Desktop/Web), and honestly ships the one residual gap (SSH-only interactive approval) as a one-line blocking prompt rather than hand-waving it away. §2–§7 then design, in full, exactly the things that make "we don't need a TUI" true instead of convenient: deterministic Execution Replay (two clearly-separated modes, RBAC-scoped, redaction-preserving) for debug/audit/demo; a fully specified branch/edit/stop/steer protocol and collaborative-session UX built on the Event-Log tree, with conflicts resolved by branching (never silent overwrite or fake merge); Command Pipelines that are genuinely intelligence-driven (agent sub-turns, not fixed templates), git-native like every other control-plane definition (ADR-026 — branch→PR+CI→merge→signed tag, `execute_rbac` front-matter for visibility/dept scoping, never a DB row), and explicitly, permanently bounded so they can never regrow into the vendor's DAG; trust UX where sources/confidence/rationale are derived from the same audit record compliance uses (nothing to keep in sync); a typed, recoverable error taxonomy; modality-aware compliance closing a named gap (AX) rather than leaving it implicit; and a latency design that treats "feels slow" as a monitored SLO. §8–§10 then close three Pass-5 gaps with the same discipline: attention budget as a per-event notification class with quiet-hours/digest and an auditable escalation ladder (gap 45); feedback loop-closure where "shipped" requires a linked, independently-verifiable change artifact rather than a status flip (gap 46); and a real-time duplex voice architecture — persistent bidirectional session, server-VAD, barge-in as a scoped Stop, a per-stage <300ms turn-taking budget — additive to, not a replacement for, the existing batch STT→TTS path (gap 48). Every section closes with acceptance tests, so "10/10" is a testable claim, not a rating.

**Residual risks:**
1. **Steer-boundary timing is a genuinely hard real-time property** — "next safe boundary" must be implemented precisely (never mid-tool-call) or steer silently degrades into a second stop-and-restart, which would quietly break the UX promise in §3.3.
2. **Branch-tree UX can become overwhelming** at high collaboration volume (many siblings on one thread) — the minimap/labeling design in §3 needs real usability validation with actual multi-person threads, not just the protocol correctness proven by S1–S7.
3. **Re-execution replay's non-determinism on some providers** means "behavioral diff" reports will sometimes show noise unrelated to a prompt/model change; the reporting UX must distinguish "meaningful drift" from "provider sampling variance" or teams will stop trusting it.
4. **The interactive-approval fallback (§1.3) is a narrow escape hatch** — if product pressure pushes it to grow richer over time (multi-step wizards, inline diffs in a terminal), it is the exact seam where TUI scope-creep would re-enter; it must stay a single blocking prompt by policy, not just by current design.
5. **Command Pipelines' "no control-flow" line (§4.3, C4) requires ongoing discipline** — the first genuinely compelling request for a conditional step is exactly the pressure that regrows a DAG language; this needs to be an enforced authoring-time rejection, not a norm people can quietly work around.
6. **Studio-as-git-client latency applies to Commands too (ADR-026 §17.4)** — if the branch→PR→CI→merge round trip for a Command feels slow to a non-engineer author, the pressure will be for a "quick publish" side door; that door must be refused, the same discipline ADR-026 already demands for every other definition kind.
7. **Barge-in is the hardest real-time property in this entire document (§10.3)** — sub-200ms audio-truncation-on-interrupt is a genuinely difficult latency target; implemented sluggishly, duplex voice degrades into a worse experience than batch voice (an agent that ignores you until it finishes talking), which is exactly the failure mode the mechanism exists to prevent.
8. **Attention-budget classification quality is only as good as the emitter's judgment (§8.1)** — a subsystem that over-classifies routine events as `immediate` recreates the muted-channel failure mode this section exists to prevent; the per-event class needs the same ongoing calibration discipline as any other threshold in this corpus.
