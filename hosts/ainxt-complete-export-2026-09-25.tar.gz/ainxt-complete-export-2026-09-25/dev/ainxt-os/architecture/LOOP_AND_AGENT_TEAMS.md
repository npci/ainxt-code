# Loop Engineering & Hierarchical Agent Teams — design to 10/10

**Status:** Design (no code). Closes gap **M** (multi-agent orchestration robustness) and **AR** (plan stability / anti-thrashing) from `GAP_ANALYSIS_VS_AI_PLATFORMS.md`. Companion to `SUBSYSTEM_DEEP_DIVES.md` §1 (the SDLC judge-loop — the concrete instance this doc generalizes), `AGENT_TESTER.md` (the Tester/Breaker role), `CONTEXT_FABRIC.md` (the Context step), `SEMANTIC_EDITING.md` (the Execution step's edit substrate), `RUNTIME_FEATURE_FLOWS.md` §7b (the Agent Loop kernel primitive), and `AINXT_OS.md` §0 (intelligence-first vs. the external vendor's visual DAG).
**One line:** the runtime runs one kind of loop — a goal-seeking, self-correcting, team-shaped loop — and a plan is something the agent *thinks its way into*, not something a human wires. Structure, when it helps, is a side effect of reasoning, never a precondition for it.

---

## 0. The tension, resolved

The external vendor's Studio sells **configuration**: a human drags nodes onto a canvas and wires edges — the graph is the product, authored before the work starts, static once deployed. AiNxt's moat is **intelligence**: a vague goal gets planned, executed, checked, and repaired without anyone pre-wiring a graph (`AINXT_OS.md` §0).

The naive read of that principle is "therefore AiNxt never has a task graph." That's wrong, and it would forfeit real parallelism on the ~20% of goals that *are* graph-shaped (independent modules, fan-out investigations, multi-service migrations). The correct read:

> **The Task Graph is a runtime data structure the agent authors and mutates as part of reasoning — the same way it decides to call a tool. It is never a human artifact, never pre-provisioned, and never required.** Most turns never materialize one; a flat, ordered task list is the default and is sufficient for most goals. The Planner promotes to an explicit graph only when it detects real independence worth exploiting, and it can just as easily flatten a graph back down when reality turns out simpler than expected.

This is the same distinction the runtime already draws for Studio workflows: `AINXT_OS.md` §3 is explicit that Studio-authored workflows run on "the runtime scheduler/event-bus (**NOT** the scrapped [Python] engine)." That scheduler is a generic execution primitive. What this doc adds is *who is allowed to author the graph that the scheduler executes*: for the external vendor's product, a human; for AiNxt's own loop, the agent itself, as an emergent artifact of planning — transient, versioned, revisable, and scoped to a single Run. It is deleted (or folded into the Learning record) when the Run ends; it never becomes a permanent, human-maintained pipeline. That is the entire resolution: **dynamic planning that can *look like* a DAG operationally, while remaining intelligence-first genetically** — the graph is a symptom of a plan, not the plan's origin.

---

## 1. The full loop, end to end

```
   Goal (user turn / connector event / scheduled trigger)
        │
        ▼
   PLANNER  ── adaptive depth, decomposition, (maybe) materializes a Task Graph ──┐
        │                                                                         │
        ▼                                                                         │
   TASK ORCHESTRATION  ── schedules ready nodes; sequential by default ───────────┘
        │                    fans out only where the graph says independent
        ▼
   CONTEXT (Context Fabric)  ── per-task context compiled fresh: symbol/call/
        │                        import/architecture/git/runtime/test/docs/memory
        ▼
   EXECUTION  ── the role assigned to this task (usually Coder) runs its
        │          tier-1 reactive loop: act → observe → act
        ▼
   REFLECTION  ── the acting role reflects on its own step: did this move the
        │           task forward? is more work needed on this task?
        ▼
   CRITIC (tier 2, per-step)  ── cheap, fast, narrow: does this step still
        │                         serve the task's acceptance criteria?
        ├─ fail → REPAIR (SELF-HEAL: execute → detect → fix → retry, bounded)
        │            │
        │            └─ repaired → back to EXECUTION; exhausted → escalate
        ▼
   VERIFICATION  ── deterministic gate: build/test/lint/type — code, not a
        │             model's opinion (§7)
        ▼
   GIT / REVIEW  ── Reviewer role's Code-Review Pipeline (static gate) +
        │             Tester/Breaker role's adversarial dynamic proof (§7)
        ▼
   (independent JUDGE, tier 3, outer goal loop) ── fresh-context Architect-role
        │    audit against the ORIGINAL goal + acceptance criteria, not the
        │    coder's rationalizations. Confirms → done. Gap → becomes the
        │    Planner's next task (loop back to PLANNER). Round-cap → `capped`.
        ▼
   LEARNING  ── every terminal Run (complete or capped) emits a Learning
                Record: feeds evals, plan-template priors, Role Spec tuning
                (§10 — the flywheel)
```

Every box above is a **stage of one loop**, not a pipeline of separate products — the same nesting that makes the SDLC judge-loop (`SUBSYSTEM_DEEP_DIVES.md` §1) production-grade is the general shape for *any* goal a Role runs, not a bespoke SDLC-only mechanism.

---

## 2. The Planner — adaptive reasoning depth & decomposition

**Input:** a goal (user turn, connector event, or a gap report handed back by the tier-3 judge). **Output:** either (a) a flat, ordered task list, or (b) a materialized Task Graph.

**Adaptive depth.** The Planner's own reasoning effort scales with a cheap up-front classification (the same simple/medium/complex tiering used for model routing, reused here for *planning* depth):
- **Simple** goal (single file, single intent, no ambiguity) → the Planner emits **one task**, no decomposition step at all. Zero planning overhead — this is the majority case and it must stay cheap.
- **Medium** goal (a feature touching a handful of files, a bug with an unclear root cause) → the Planner decomposes into an **ordered task list** with explicit acceptance criteria per task, but no graph — tasks run sequentially because sequencing is genuinely required (each depends on the last) or because the independence isn't worth the coordination cost.
- **Complex** goal (multi-service change, independent investigation branches, "do X and Y and compare") → the Planner runs a **structure probe**: a cheap heuristic pass (do candidate tasks share files/symbols/state? per the Context Fabric's dependency graph) followed by a short LLM judgment — *"would materializing independent tracks reduce latency or improve quality without adding coordination risk?"* Only on "yes" does it call `plan.materialize_graph`, converting the task list into typed nodes/edges (`sequence`, `parallel`, `join`, `conditional`).

**Decomposition contract.** Every task, whether in a flat list or a graph node, carries the same fields — this uniformity is what lets tasks move between the two representations without translation loss:

| Field | Purpose |
|---|---|
| `task_id` | stable identity across replans |
| `description` | what must be true when done |
| `role` | which team role owns it (§3) |
| `inputs` | context refs / upstream task outputs it needs |
| `acceptance_criteria` | machine-checkable where possible, semantic otherwise |
| `dependencies` | task_ids that must complete first (empty for a flat list's implicit sequence) |
| `budget` | token/tool-call/wall-time ceiling for this task |

**Re-planning.** The Planner is re-invoked — never silently overridden by a downstream role — whenever: the tier-2 critic reports a task can't be completed as scoped, the tier-3 judge returns a gap, or execution surfaces new information that invalidates an assumption (e.g., a dependency the Planner didn't know existed). Re-planning is itself bounded by the anti-thrash mechanism (§9) so this doesn't degenerate into constant reshuffling.

---

## 3. Task orchestration — scheduling the materialized plan

Once the Planner has *either* a flat list *or* a graph, orchestration is deliberately dumb — all the intelligence already happened upstream, in the Planner. This is the load-bearing design choice that keeps the loop intelligence-first: the scheduler never decides *what* to do, only *when* a task that's already been decided is ready to run.

- **Flat list:** execute in order, one task at a time. No scheduler state beyond "current task."
- **Materialized graph:** a dependency-respecting scheduler (Kahn-style: track in-degree per node, run any node whose dependencies are all satisfied) admits every *ready* node up to the Run's fan-out ceiling (§8), executes them concurrently, and joins at `join` nodes before continuing. `conditional` nodes are resolved by the owning role's own reasoning (e.g., "if the investigation found no repro, skip the fix task") — the scheduler evaluates the *result*, it never encodes the *condition's logic* itself.

**This is explicitly not a reincarnation of the scrapped Python `workflows/engine.py`.** Three properties keep it from becoming that: (1) the graph is authored by the agent, never by a human on a canvas; (2) it is scoped to a single Run and discarded (or folded into the Learning record) at Run end — never a standing, separately-maintained pipeline; (3) the Planner can flatten it back to a list mid-run if a node fails in a way that reveals the independence assumption was wrong. A DAG that a human drew is a commitment; this graph is a hypothesis the Planner is allowed to revise.

---

## 4. Hierarchical agent teams — composed roles

Complex goals are executed by a small **team of composed Roles** (each a Role Spec per `AINXT_OS.md` §4), not one monolithic agent doing everything:

| Role | Job | Tier | Reads from Context Fabric |
|---|---|---|---|
| **Architect** | Owns *intent*: shapes the design/approach for anything non-trivial; in a **separate, fresh-context invocation**, also serves as the tier-3 judge that audits the finished work against that same intent (§5) | 3 (bookends the loop) | architecture graph, git-history graph |
| **Planner** | Decomposes the goal/design into tasks; materializes/maintains the Task Graph; re-plans on signal (§2, §9) | 3 (mid-loop) | symbol graph, dependency graph, memory (plan-template priors) |
| **Coder** | Executes a task via the reactive inner loop and the Semantic Editing engine | 1 | symbol/call/import graphs, runtime/observability |
| **Reviewer** | Per-step critic (tier 2) + the deterministic Code-Review Pipeline (compile/lint/type/SAST) before anything is proposed as done | 2 | AST graph, test graph |
| **Tester (the Breaker)** | Adversarial dynamic verification — the second non-model proof (`AGENT_TESTER.md`) | 3 (audit-adjacent) | test graph, runtime/observability |

**Why Architect plays both ends:** anti-sycophancy (`SUBSYSTEM_DEEP_DIVES.md` §1) requires the judge not share context with the executor. Reusing the *Architect persona* but invoking it **fresh** — no shared conversation, ideally a different underlying model — gets independence without inventing a sixth role whose only job is "be skeptical." The Architect that wrote the design brief is architecturally the right auditor for whether the delivered work satisfies it; the freshness constraint is what keeps it honest.

**Handoff contract.** Roles never hand off free text. Every handoff is a structured artifact:

```
HandoffContract {
  from_role, to_role, task_id,
  inputs: [context refs / upstream outputs],
  outputs: [artifact refs: diff, report, plan-delta, finding],
  acceptance_criteria: [ ... ],       // copied from the task, never re-derived
  confidence: 0.0–1.0,                 // the producing role's own self-estimate
  cost_used: { tokens, tool_calls, wall_time, dollars },
  open_questions: [ ... ]              // things the next role must NOT silently assume
}
```
`open_questions` exists specifically to stop the class of bug the SDLC judge-loop already guards against: a role that "resolves" an ambiguity by silently guessing must instead surface it, so the receiving role (or a human, via the Approval Gate seam) resolves it explicitly.

**Sub-agent cost roll-up.** Every role invocation is a call through the kernel's `agent.invoke` primitive (`RUNTIME_FEATURE_FLOWS.md` §7b's "call another agent as a sub-agent"). Each invocation returns its `cost_used` block, and the parent **rolls it up** into the Run's aggregate — the budget middleware checks the *Run's total*, never a per-role slice in isolation. This closes the exact loophole a hierarchical team would otherwise open: spawning five roles to do the work of one shouldn't let anyone bypass the per-user token ceiling five-fold.

**Failure isolation.** Each sub-agent invocation runs under a **child cancellation token** (derived from the Run's shared token, §8) and its **own** iteration cap and budget slice. If Coder throws, times out, or exhausts its cap, `agent.invoke` returns a **typed failure** to the caller (Planner/Reviewer) — it does not propagate as a panic and does not kill sibling invocations already in flight (e.g., a parallel Coder task on an unrelated module keeps running). The calling role then decides: retry the same role, reroute to a different role/model tier, or escalate to the human via the Approval Gate seam. This is the bulkhead pattern applied to agent hierarchies — one branch's failure is data the parent reasons about, never an outage for the team.

**Depth cap.** `AINXT_OS.md`'s "single-level inheritance" discipline for *authoring* agent specs is mirrored at *runtime*: the kernel enforces a hard maximum hierarchy depth (default 3: e.g. Architect → Planner → Coder, with Reviewer/Tester as depth-2 siblings of Coder, not depth-4 descendants). An invocation attempting to exceed the cap is blocked with a structured error at the kernel boundary, not a convention roles are trusted to self-police — this is the guard against an agent-spawns-agent recursion runaway.

---

## 5. The 3-tier loop — reactive inner loop, per-step critic, judge-audited outer loop

This generalizes the SDLC judge-loop (`SUBSYSTEM_DEEP_DIVES.md` §1) to any team, any goal:

- **Tier 1 — reactive inner loop (per task, single role).** Act → observe → act. Need-driven (keeps going only while the task's acceptance criteria are unmet), hard iteration cap, deterministic stuck-detector (`RUNTIME_FEATURE_FLOWS.md` §7b's kernel primitive — inherited, not reimplemented per role).
- **Tier 2 — per-step critic (cheap, narrow, fast).** After each tool-call/diff, a lightweight judgment: *does this step still serve the task's acceptance criteria, and did it introduce an obvious regression?* This is intentionally cheap (small model, narrow question) because it runs on **every** step — it exists to catch the 80% of problems before they reach the expensive tier-3 audit. On fail: hands to Repair/SELF-HEAL (§6); on repeated fail: escalates the *task* back to the Planner (this is one of the re-planning triggers in §2), not a fresh guess by the same role.
- **Tier 3 — outer goal loop (independent, judge-audited).** Once every task the Planner scoped is nominally complete, the fresh-context Architect-as-judge audits the *whole deliverable* against the *original* goal + acceptance criteria — never against the team's self-reported narrative. Three outcomes:
  - **Confirmed** → Run terminates `complete`.
  - **Gap found** → the judge emits a *specific, actionable* "what's missing," which becomes the Planner's next task (loop back to §2) — never a vague "try harder."
  - **Round-cap hit** → Run terminates `capped`, and the gap report is surfaced to the human as an honest, first-class outcome (§7) — never silently claimed as done.

The nesting matters: tier 1 is cheap and constant (every action), tier 2 is cheap and frequent (every step), tier 3 is expensive and rare (once per goal, or once per re-plan cycle) — cost is spent where judgment quality actually changes the outcome, not spread evenly.

---

## 6. SELF-HEAL — bounded execute → detect → fix → retry

Self-heal is tier-1's Repair path, generalized beyond code execution to any task failure a role hits:

```
execute task step → error/failure detected → classify error
  → gather more context (relevant log/trace from Context Fabric's
     runtime/observability graph; is this a known failure class?)
  → LLM proposes a fix, scoped to the SAME task
  → retry
  → succeed: continue tier-1 loop
  → fail again: escalate context (add more signal, or bump model tier,
     or pull the Reviewer in early) and retry — up to the cap
  → cap exhausted: abort THIS TASK to the Planner (not to the human
     directly — the Planner decides whether to re-scope, skip, or escalate)
```

**Two distinct bounded detectors — never conflated:**

| Detector | Level | Signal | Trigger example | Remedy |
|---|---|---|---|---|
| **Stuck-detector** | Tier 1 (execution) | *repetition* — the same or near-identical action/diff/error recurs (hash/near-hash match) | Coder proposes the same failing patch 3 times in a row | Abort the task to the Planner; never burn more tokens polishing a dead end |
| **Thrash-detector** | Tier 3 / Planner (plan-level) | *structural churn* — the plan itself keeps reversing prior decisions across successive re-plans, independent of whether any single action repeats | Planner adds task X, drops it, re-adds a different version of X, three re-plans running | Freeze the plan (§9); force one deliberate consolidated re-plan instead of continuous micro-edits |

They are unrelated failure modes and must be detected independently: a loop can thrash (change its mind every cycle) while never literally repeating an action, and it can get stuck (repeat one action) while the plan around it stays perfectly stable. Collapsing them into one "is it looping?" check misses whichever one the check wasn't built for.

---

## 7. Verification — "never done until proven"

No single check is allowed to declare a goal done. Three **non-substitutable** proofs, at least all present before `complete`:

1. **Deterministic gate (Reviewer)** — build/test/lint/type/SAST. This is **code, not a model's opinion** — "tests pass" is never model-judged (`SUBSYSTEM_DEEP_DIVES.md` §1's founding rule, applied generally). Proves *it doesn't break what already had a check written for it.*
2. **Adversarial dynamic proof (Tester/Breaker)** — layered oracles (`AGENT_TESTER.md` §2) drive the real artifact and look for silent correctness/security/compliance failures no assertion was written for. Proves *it doesn't break under load nobody scripted.*
3. **Semantic completeness (Architect-as-judge, tier 3)** — audits against the *original goal's intent*, independent context, anti-sycophancy by construction (§4, §5). Proves *it actually does what was asked, not merely "something that compiles and passes."*

`complete` requires all three green. `capped` is the honest alternative when the round-cap is hit with any of the three still red or amber — it is always reported with the specific gap, never silently upgraded to `complete`. This is the same discipline `SUBSYSTEM_DEEP_DIVES.md` §1 established for SDLC, generalized: *"done" is a claim that must be proven three independent ways, not asserted once.*

---

## 8. Actor-per-session, cancellation, backpressure, need-driven termination

**Actor model.** The kernel's actor-per-session primitive (`AINXT_OS.md` §2, `IMPLEMENTATION_PLAN.md`) is the *session's* actor, not one actor per role. A hierarchical team's sub-agent invocations (`agent.invoke` calls) are **bounded async tasks inside the parent Run's actor**, not separate actors — spawning an actor per Coder/Reviewer/Tester invocation at 2,000 concurrent users would blow the actor budget for no benefit, since roles don't need independent mailboxes, only independent cancellation/budget scopes (§4). The one exception: a long-running autonomous Run (an SDLC feature build, a multi-hour investigation) gets its **own persistent Run actor**, distinct from the interactive chat actor that spawned it — so a user closing their browser tab doesn't kill background team work; the Run actor outlives the request that started it and is reattachable.

**Cancellation.** One cancellation token per Run, shared by the streaming response, every tool future, every fan-out branch (`RUNTIME_FEATURE_FLOWS.md` §7b), and — new here — every child role invocation's derived token. Cancelling the parent cancels the entire team, at whatever depth it has reached, immediately. A user-initiated stop is always a first-class, instant action (`GAP_ANALYSIS_VS_AI_PLATFORMS.md` AV), never something that waits for the current tier-1 step to finish.

**Backpressure.** A hierarchical team multiplies concurrency — N roles, each potentially fanning out M parallel tasks. The kernel's admission control counts **the whole team as one Run** against a total fan-out ceiling, not an unlimited multiply-out; a team that would exceed the ceiling gets its excess branches queued (not silently degraded, not silently dropped) or the Run itself gets a 503 at admission if the *queue* is also over depth (`core/job_queue.py`'s `check_queue_pressure` pattern, generalized to the Rust kernel).

**Need-driven termination.** At every level — tier 1's task loop, the Planner's task list/graph, the tier-3 outer loop — the loop keeps running **only while an unmet need exists**: an open task, an unsatisfied acceptance criterion, a judge-reported gap. The instant no need remains, it stops. This is deliberately symmetric: it is the fix for *both* declaring done too early (a task marked complete while its criteria are unmet is, by definition, still "needed") *and* running needlessly long (a team that keeps "double-checking" after every proof is green has no remaining need and must stop) — a fixed iteration count "to be thorough" is never the mechanism; an explicit, checkable need is.

---

## 9. Plan stability / anti-thrash

Beyond the thrash-*detector* (§6), the plan itself has a stability discipline:

- **Plan persistence.** Every version of the Task Graph/list is an append-only revision in the Event Log — never overwritten in place. A Run's full planning history is replayable.
- **Change-justification.** Every mutation (`plan.add_task`, `plan.drop_task`, `plan.materialize_graph`, `plan.flatten`) must carry a **triggering signal**: which critic finding, which judge gap, which new piece of context caused this change. A mutation with no signal is rejected at the API boundary — the Planner cannot silently reshuffle "because it changed its mind."
- **Freeze on thrash.** When the thrash-detector (§6) fires — plan-diff overlap across N consecutive revisions exceeds a churn threshold (e.g., >40% of tasks touched across 3 re-plans) — plan mutation is **frozen** for a cooldown window. The Planner must execute the current frozen plan to its next natural checkpoint (a task completion or a hard failure) before a *single*, deliberate, consolidated re-plan is allowed — replacing a stream of small course-corrections with one considered one.
- **Escalation path.** If freeze-and-consolidate still doesn't stabilize (the team thrashes again immediately after the cooldown), the Run escalates to the Architect role for a fresh design pass, or to a human via the Approval Gate seam — thrash surviving one consolidation attempt is itself a signal that the *goal* was underspecified, not that the Planner needs another retry.

---

## 10. Learning — feeding the flywheel

Every terminal Run — `complete` or `capped` — emits a **Learning Record**, closing the loop back into the platform (this is the loop-and-teams-specific instance of gap **E**, the improvement flywheel, from `GAP_ANALYSIS_VS_AI_PLATFORMS.md`):

```
LearningRecord {
  goal, final_plan (graph or list, with full revision history),
  role_transcripts: [ per-role HandoffContract chain ],
  verification_results: { deterministic, adversarial, judge },
  human_feedback: [ corrections, approvals/rejections at HITL gates ],
  cost: aggregate roll-up (§4),
  outcome: complete | capped(gap)
}
```

It feeds three concrete things, none of which is "hardcode a better prompt by hand":
1. **Eval-set generation.** A `capped` Run or a Breaker finding becomes a **permanent regression scenario** (`AGENT_TESTER.md` §6: "a bug found once is tested forever") — the exact gap that caused the cap is now something every future Run of a similar shape is checked against.
2. **Plan-template priors.** Successful plan *shapes* for a goal-class (e.g., "cross-service rename tends to materialize a 3-branch parallel graph") become retrieval-time exemplars in the Context Fabric's memory layer that the Planner can draw on — **priors that bias decomposition, never a rule that forces it.** This preserves intelligence-first: the exemplar is advisory context the Planner may weigh, not a template it is required to instantiate.
3. **Role Spec tuning.** Aggregate cost/capability usage across Learning Records tells the Studio which capabilities a Role Spec actually exercises versus was merely granted — feeding the least-privilege tightening loop from `AINXT_OS.md` §4 Step 3, and flagging roles whose real-world task mix has drifted from their spec (a signal for re-approval, not a silent auto-change).

---

## 11. Acceptance & scenario tests

| # | Scenario | What's exercised | Pass condition |
|---|---|---|---|
| 1 | Single-file, unambiguous bug fix | Planner adaptive depth (simple path) | No Task Graph object is created; trace shows one flat task; no structure-probe LLM call fired |
| 2 | Refactor touching 3 genuinely independent modules | Planner structure probe + graph materialization + task orchestration | Task Graph materialized with 3 parallel branches + a join before Reviewer; measured wall-time < a forced-sequential baseline run of the same goal |
| 3 | Coder proposes the same failing patch 3 times | Stuck-detector (tier 1) | Aborts the *task* to the Planner before a tier-3 judge round is spent; no further retries burned |
| 4 | Planner adds, drops, and re-adds variants of the same task across 3 consecutive re-plans | Thrash-detector, plan freeze | Freeze triggers; plan mutation blocked until current plan reaches its next checkpoint; one consolidated re-plan follows, not a fourth micro-edit |
| 5 | Coder sub-agent throws mid-task while a sibling Coder task (different module) is still running | Failure isolation, `agent.invoke` typed failure | Parent (Planner) receives a structured failure and decides retry/reroute/escalate; the sibling task is unaffected and completes normally |
| 6 | A diff is technically complete but omits a stated requirement, delivered with a confident coder rationale | Tier-3 judge, anti-sycophancy | Fresh-context Architect-as-judge, given only the goal + criteria + diff (not the coder's narrative), reports the specific gap; Run does not terminate `complete` |
| 7 | User clicks stop three levels deep into an Architect→Planner→Coder chain | Cancellation propagation | All descendant invocations cancel within the runtime's cancellation SLA; no orphaned sub-agent keeps running or billing |
| 8 | 50 concurrent Runs, each spawning a 4-role team (Architect/Planner/Coder×2/Reviewer/Tester) | Backpressure at Run granularity | Total fan-out respects the kernel's ceiling; excess branches queue or the Run gets an explicit 503 at admission — never silent degradation (e.g., roles quietly skipped) |
| 9 | A Run spawns 4 sub-agent invocations with known individual costs | Sub-agent cost roll-up | Budget middleware sees one aggregate cost equal to the sum of the four children; no per-role budget bypass is possible |
| 10 | A role attempts `agent.invoke` at hierarchy depth 4 (cap = 3) | Depth cap enforcement | Kernel blocks at the boundary with a structured error; the attempt is logged; no recursive spawn occurs |
| 11 | All three verification proofs disagree (deterministic green, Breaker finds a race, judge sees no gap) | "Never done until proven" (§7) | Run does not terminate `complete` — the Breaker's red result alone blocks it; report shows which of the three failed |
| 12 | A goal is genuinely under-specified and thrashes even after one consolidated re-plan | Escalation path (§9) | Run escalates to Architect fresh-design-pass or human Approval Gate — it does not attempt a third consolidation silently |
| 13 | A `capped` Run's judge gap is a class of bug not previously covered | Learning flywheel | A new regression scenario is generated and added to the permanent matrix; a later Run of similar shape is checked against it pre-emptively |

---

## 12. Why this is now a 10

It resolves the platform's defining tension instead of dodging it: dynamic, agent-authored planning is the *only* path, and an explicit task graph is something the Planner *earns the right to materialize*, never something a human wires in — closing the exact gap (`GAP_ANALYSIS_VS_AI_PLATFORMS.md` **M**) that called the old orchestration "in-feature calls to AgentRunner," not a fleet. It generalizes the validated SDLC judge-loop into a reusable 3-tier shape (reactive inner / per-step critic / judge-audited outer) any team can run. It gives hierarchical teams the three things a real fleet needs and the old design didn't have — typed handoff contracts, cost roll-up that closes the per-agent-budget-bypass loophole, and bulkhead-style failure isolation with a hard depth cap. It keeps SELF-HEAL bounded with **two distinct, independently-triggered detectors** (repetition vs. structural thrash — closing gap **AR**) instead of one fuzzy "is it looping" check. "Done" stays a three-way proof, never a single model's self-report. And the loop is symmetric by construction — need-driven termination stops both premature "done" claims and needless over-running — with every terminal Run feeding the Learning flywheel so the *next* Run of a similar shape starts smarter, without ever hand-coding a template that would silently re-import the configuration-first failure mode this whole design exists to avoid.

## 13. Residual risk / open questions
- **Structure-probe cost at scale.** The probe itself (heuristic + a short LLM call) runs on every "maybe-complex" goal; at 2,000 concurrent users this needs its own latency/cost budget so planning overhead doesn't rival execution cost for goals that end up not being graph-shaped after all.
- **Depth-cap default (3) is a guess.** Needs empirical tuning against real Architect→Planner→Coder(+Reviewer/Tester siblings) traces once the runtime exists — too shallow blocks legitimate composition (a Coder that needs to delegate a sub-investigation), too deep re-opens the runaway-recursion risk.
- **Architect-as-judge model diversity.** "Fresh context" is necessary but weaker than "different model" for anti-sycophancy; the design should mandate cross-provider judging wherever budget allows, not just fresh-context same-model.
- **Thrash threshold tuning.** The 40%-over-3-revisions figure is illustrative; real workloads may thrash at different rates depending on goal class, and a static global threshold risks false-freezing genuinely exploratory early-stage planning.
- **Plan-template priors drifting into de-facto templates.** Section 10's "priors, never a rule" boundary is a policy statement, not yet a mechanism — needs a concrete design (e.g., the Planner must always be able to articulate *why* it deviated from a prior) so exemplars don't quietly calcify into the configuration-first pattern this doc argues against.
