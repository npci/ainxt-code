# Semantic Editing Engine — design to 10/10

**Status:** Design (no code). Closes the scorecard's weakest gap (was 5/10: we only had text/patch editing). Target: text edits are the *last* resort; the agent edits *meaning*, not characters.

## 1. The principle
The agent expresses a **semantic operation** (rename this symbol, add this method, change this signature, extract this function, move this class), not a text diff. The engine *plans and applies* the concrete multi-file changes — every call site, import, and reference — **atomically and verifiably**. Text patching is the bottom of a fallback ladder, never the default.

## 2. The edit ladder (highest fidelity first)
1. **Semantic op via LSP** — use the language server's own refactors (rename, organize-imports, code-actions). Highest fidelity; the toolchain guarantees correctness.
2. **AST transform** — tree-sitter parse → structural edit on the syntax tree → print back. Used where LSP is absent/weak or for structural ops LSP doesn't expose.
3. **Structured patch** — anchored search/replace with dry-run classification (the aider-grade engine we already designed).
4. **Text patch** — last resort; only for non-code or when 1–3 can't apply. Always verified.

The engine picks the *highest* rung available for the language + operation (capability matrix per language), and falls *down* the ladder only on failure, logging why.

## 3. The code-intelligence substrate (shared with the Context Fabric)
- **Tree-sitter** parsers (all languages) → concrete syntax trees.
- **LSP clients** — a pool of language servers (rust-analyzer, pyright, tsserver, gopls, jdtls…) the engine drives for rename/refs/diagnostics/code-actions.
- **Symbol graph** — definitions + references across the repo.
- **Call graph** + **import graph** + **cross-reference index** — so a change knows *everything it touches*.
- **Type information** — from the LSP, for type-aware edits and signature changes.

## 4. Core operations (each = a planned, atomic, verified transaction)
- **Rename symbol** → LSP rename (or AST rename + xref) updates *all* references/imports across files atomically.
- **Change signature** → update the declaration + *every call site* + imports; insert defaults/adapters where needed.
- **Add/replace method or function** → insert into the right AST node; the import manager adds missing imports; the method-preservation + import-restore guards run.
- **Extract / inline / move** → structural AST transforms with reference rewrites.
- **Field rename/type change** → blocked-then-guided if usages exist elsewhere (our known-bug guard), now handled properly via xref rewrite instead of blocking.

## 5. Apply protocol (the invariant that makes it safe)
```
plan semantic op → resolve ALL affected sites via graphs
  → build a multi-file edit set
  → DRY-RUN against an in-memory AST/workspace snapshot
  → verify: re-parse OK + LSP diagnostics clean + type-check + (compile where cheap)
  → if clean: write atomically (all files or none)   else: fall down the ladder / structured error → self-correct
  → post-write re-verify; on regression: automatic rollback
```
Conflict-aware (concurrent edits serialize per file/symbol), transactional (all-or-nothing), and every step lands in the Event Log for replay.

## 6. Language-agnostic
Capability matrix per language: `{lsp: yes/no, tree-sitter: yes, refactors: [...]}`. Full-power languages use LSP; others degrade gracefully to AST, then patch — but never silently: the rung used is recorded, and quality evals track per-language edit fidelity.

## 7. Integration
- Feeds and reads the **Context Fabric** graphs (same symbol/call/import graphs).
- Every edit flows into the **Code-Review Pipeline** (compile→test→lint→type→SAST→…) before commit.
- Emits to the **Event Log** (semantic op + resolved sites + verification result) for audit/replay.

## 8. Why this is now a 10
It covers every item the rubric demands — tree-sitter, LSP, AST transforms, symbol graph, rename engine, cross-reference engine, call graph, import graph, "text last resort" — with a *verified, atomic, conflict-aware* apply protocol and graceful multi-language degradation. It edits meaning, proves the edit didn't break the tree/types, and rolls back if it did.
