# AiNxt Runtime — GAP TRACKER (live status)
_Re-audit 2026-07-21. ✅ FIXED = a proving test landed & the crate suite is green. 🔧 = being wired into the live path now. ⏳ = seam+offline-test built, live-verification infra/legal-gated. ➖ = refuted (already implemented). Every row has a `▶ verify yourself` command._

**Status:** ✅ 86 fixed · 🔧 56 wiring · ⏳ 10 infra-deferred · ⬜ 12 open · ➖ 3 refuted · **167 total**
---

## 🔴 CRITICAL

### 🔧 `FI-01` — PCI write-path CHD sink-guard not wired in front of any durable sink (§5.1 no-CDE-persistence)
- **subsystem:** regulated-fi-responsible-lifecycle · **status:** WIRING-IN-PROGRESS
- **design:** A write-path CHD sink-guard sits before EVERY durable sink (Event Log, memory, vector index, traces, DSAR exports); because CHD is redacted before every durable write, the stores are structurally CHD-free by construction, not by audit luck. The guarantee is mechanical only if eve
- **original evidence:** SinkGuard/persist/sweep fully implemented in ainxt-compliance/src/lib.rs:647-738, but the ONLY callers are its own tests (sink_guard_tests, lib.rs:740-830). runtimed and chat wire only the StrongRedactor I/O gate: ainxt-runtimed/src/lib.rs:378 and ainxt-chat/s
- **▶ verify yourself:** `sed -n '645,651p' runtime/crates/ainxt-compliance/src/lib.rs`

### 🔧 `LOOP-01` — Entire loop/teams/long-horizon subsystem is unreachable from any live executing path
- **subsystem:** loop-teams-longhorizon · **status:** WIRING-IN-PROGRESS
- **design:** LOOP one-line: 'the runtime runs one kind of loop — a goal-seeking, self-correcting, team-shaped loop'; ADR-027: Programs execute as thousands of base-loop Runs. This is THE execution spine.
- **original evidence:** No Cargo.toml in crates/* lists ainxt-teams or ainxt-planner as a dependency; grep of all crates/*.rs for ainxt_teams/ainxt_planner outside their own crates returns only two doc-comment cross-references (ainxt-planner/src/lib.rs:18, ainxt-teams/src/lib.rs:51);
- **▶ verify yourself:** `sed -n '16,22p' runtime/crates/ainxt-planner/src/lib.rs`

### ✅ `LOOP-02` — Program Supervisor execution loop (the orchestrator that runs Programs)
- **subsystem:** loop-teams-longhorizon · **status:** FIXED
- **proof:** test `supervisor::tests::gap_loop_02_supervisor_runs_a_program_to_completion (also gap_loop_02_child_program_node_resolves_then_parent_runs_own_work)` in `/Users/admin/Desktop/ai-copilot/runtime/crates/ainxt-planner/src/supervisor.rs`
- **design:** ADR-027 §1/§5: a Program Supervisor schedules READY nodes, spawns one base-loop Run per module, appends events, persists to the Event Log, and drives per-module→per-edge→sweep verification.
- **original evidence:** ainxt-planner/src/program.rs provides only a pure event-fold state machine (project/apply at :884/:577) and pure planners (plan_single_module_rollback:930, plan_quarantine:1014, partial_report:1066). There is no Supervisor struct/loop; schedulable_nodes() (pro
- **▶ verify yourself:** `sed -n '492,498p' runtime/crates/program.rs`


## 🟠 HIGH

### 🔧 `CONN-01` — Persistent token store in Postgres (user_connector_tokens)
- **subsystem:** Connectors · **status:** WIRING-IN-PROGRESS
- **design:** Tokens encrypted and stored in Postgres user_connector_tokens keyed by (jwt.sub, connector, tenant).
- **original evidence:** ainxt-token/src/lib.rs only implements InMemoryTokenStore (l.284) and FileTokenStore (l.337, single-process Mutex + whole-file rewrite); grep for 'user_connector_tokens|PostgresTokenStore|postgres' across the crate returns nothing. The TokenStore trait (l.273)

### ✅ `CONN-02` — Multi-tenant token isolation (tenant dimension in key + AAD)
- **subsystem:** Connectors · **status:** FIXED
- **proof:** test `gap_ainxt_token_conn_02_multi_tenant_isolation` in `runtime/crates/ainxt-token/src/lib.rs`
- **design:** Tokens keyed by (jwt.sub, connector, tenant); multi-tenant token store.
- **original evidence:** ainxt-token/src/lib.rs TokenKey = { user_id, connector } (l.246-250), and TokenVault::aad binds only user_id\0connector (l.480-486). No 'tenant' field anywhere in ainxt-token (grep 'tenant' hits only oauth's Entra endpoint helper). The designed third key axis 
- **▶ verify yourself:** `rg "tenant" runtime/crates`

### 🔧 `CONN-03` — Connector Runtime exposed to web + desktop surfaces (gateway callback, /connectors)
- **subsystem:** Connectors · **status:** WIRING-IN-PROGRESS
- **design:** Tokens and connector execution live in the runtime; web and desktop are identical renderers over the same Connector Runtime; gateway starts OAuth and handles the redirect callback.
- **original evidence:** grep 'connector|oauth|ainxt-token|refresh' in crates/ainxt-runtimed/Cargo.toml and crates/ainxt-server/Cargo.toml returns EMPTY; grep 'callback|authorize_use|begin_and_store|ConnectorInvoker|validate_callback' in ainxt-server/src and ainxt-runtimed/src returns
- **▶ verify yourself:** `rg "connector|oauth|ainxt-token|refresh" runtime/crates`

### ⏳ `CONN-04` — Redis-backed distributed refresh lock
- **subsystem:** Connectors · **status:** DEFERRED-INFRA
- **deferred reason:** Real cross-process refresh-lock correctness requires a live Redis. Implemented the full Redis command contract: RedisLockKv over a RedisCommands seam (INCR fence + SET NX PX acquire + Lua compare-and-delete release), proven offline against a FakeRedis emulator (gap_ainxt_refresh_conn_04_redis_lock_kv_command_semantics) and end-to-end through the coordinator (gap_ainxt_refresh_conn_04_redis_lock_collapses_the_herd: 16 callers -> exactly one refresh). Closing it for real needs a RedisCommands impl wrapping a live redis::Connection (infra), which cannot be exercised without a running Redis.
- **design:** Refresh under a Redis distributed lock (double-checked) so concurrent workers/turns don't race across the 2,000-user fleet.
- **original evidence:** ainxt-refresh/src/lib.rs provides DistributedRefreshLock (l.259) over a LockKv seam, but the only LockKv impl is the in-memory SharedLockKv stand-in (l.202-254) explicitly described as modelling Redis; grep 'redis' in the crate hits only doc comments, and Carg
- **▶ verify yourself:** `rg "redis" runtime/crates`

### ✅ `CONV-01` — Stage-2 model-backed constrained classifier wired into the conversation cascade (§2 Stage-2, §5)
- **subsystem:** Conversation Intelligence · **status:** FIXED
- **proof:** test `gap_ainxt_convo_conv_01_model_backed_classifier_drives_intent, gap_ainxt_convo_conv_01_model_classifier_receives_constraint_prompt, gap_ainxt_convo_conv_01_model_classifier_runs_in_live_pipeline` in `runtime/crates/ainxt-convo/tests/intent_cascade_test.rs`
- **design:** When Stage-1 is inconclusive, one cheap constrained model call classifies intent∈{chitchat,qa,task,doc_generation,code,comparison}+output_format with a confidence, robust on weak models via grammar/JSON-schema-constrained decoding; the runtime owns control-flow, the model classif
- **original evidence:** ainxt-classify implements the full machinery (classify_constrained/LabelModel/build_prompt/parse_label, ainxt-classify/src/lib.rs:661) but NO crate depends on it — grep for ainxt_classify/classify_constrained across crates/*.rs is empty; ainxt-convo/Cargo.toml
- **▶ verify yourself:** `sed -n '659,665p' runtime/crates/ainxt-classify/src/lib.rs`

### ✅ `CONV-02` — Stage-3 clarify-on-low-confidence in the live conversation path (§0.3, §2 Stage-3, §3)
- **subsystem:** Conversation Intelligence · **status:** FIXED
- **proof:** test `gap_ainxt_convo_conv_02_ambiguous_read_clarifies_in_live_path, gap_ainxt_convo_conv_02_low_confidence_streaming_path_clarifies` in `runtime/crates/ainxt-convo/tests/intent_cascade_test.rs`
- **design:** Low confidence → ask a clarifying question; never a silent wrong guess. 'Deterministic first, model second, ask third.'
- **original evidence:** IntentResult.confidence is written by HeuristicClassifier (ainxt-convo/src/lib.rs:207,214,222,227) but NEVER read in handle() or run_turn_streaming() — grep 'confidence' in convo src shows only writes. The sole Clarify path is ContentSource::Ambiguous for doc-
- **▶ verify yourself:** `sed -n '205,211p' runtime/crates/ainxt-convo/src/lib.rs`

### 🔧 `CTX-01` — Context Optimizer not integrated (planning + cross-graph ranking never composed into assembly)
- **subsystem:** context-fabric · **status:** WIRING-IN-PROGRESS
- **design:** CONTEXT_FABRIC §3: an optimizer that plans which graphs to draw from, ranks nodes across the unified graph via personalized PageRank, then position-aware assembles, arbitrates freshness/conflict, and emits the window + lineage
- **original evidence:** ainxt-context/src/optimizer.rs (plan_query, personalized_pagerank, QueryPlan, GraphLayer, rank_by_score) is never referenced outside its own module (grep across all crates empty); assemble() at ainxt-context/src/lib.rs:316 only calls retriever.retrieve()+build
- **▶ verify yourself:** `sed -n '314,320p' runtime/crates/ainxt-context/src/lib.rs`

### 🔧 `CTX-02` — Hybrid RRF+rerank wired into the live path
- **subsystem:** context-fabric · **status:** WIRING-IN-PROGRESS
- **design:** CONTEXT_FABRIC §2/§3 + crate docs: the production hybrid retriever (pgvector HNSW + BM25 -> RRF -> rerank) is the real engine on the live path; swapping the lexical placeholder for it is a one-line change
- **original evidence:** live ChatSurface hardcodes the placeholder: ainxt-chat/src/lib.rs:87 Box::new(LexicalRetriever::new(corpus)); the real engine (ainxt-retrieval Corpus::hybrid) and its adapter HybridRetriever (ainxt-context/src/lib.rs:140) have no live consumer; convo calls ain
- **▶ verify yourself:** `sed -n '85,91p' runtime/crates/ainxt-chat/src/lib.rs`

### 🔧 `CTX-03` — Budget-fit-to-eligible-model (two-phase, Gap-22) wired + CI acceptance test + ADR-026 tier->window profile
- **subsystem:** context-fabric · **status:** WIRING-IN-PROGRESS
- **design:** CONTEXT_FABRIC §3: resolve tier_eligible∩class_eligible before budget fitting, fit to narrowest eligible window, re-fit on model-confirm and on every failover; acceptance = CI regression asserting emitted tokens ≤ real window with zero silently dropped, over the failover chain; w
- **original evidence:** budget_fit_eligible/refit/eligible_floor_window exist and are unit-tested (ainxt-retrieval/src/lib.rs:685,694,728) but are never invoked in a live path; convo/chat use assemble() not assemble_with_budget; no failover-chain CI regression and no ADR-026 profile-
- **▶ verify yourself:** `sed -n '683,689p' runtime/crates/ainxt-retrieval/src/lib.rs`

### ✅ `CTX-04` — 12+ graph layers as an actual queryable fabric
- **subsystem:** context-fabric · **status:** FIXED
- **proof:** test `optimizer::tests::gap_ctx_04_typed_fabric_answers_structured_graph_queries` in `/Users/admin/Desktop/ai-copilot/runtime/crates/ainxt-context/src/optimizer.rs`
- **design:** CONTEXT_FABRIC §2 + STRUCTURED_FEDERATED §1: 16 layers (conversation, repo, symbol, AST, call, import, architecture, git-history, runtime, test, docs, memory, structured, federated, global-summary, multimodal) unified into one KG, each queryable via whoCalls/refsOf/metric/federat
- **original evidence:** ainxt-context/src/optimizer.rs:33 GraphLayer enumerates 16 variants but only as planner labels; no symbol/AST/call/import/architecture/git/runtime/test graph construction, no unified KG, and none of the named query-interface functions exist; only layer 11 (doc
- **▶ verify yourself:** `sed -n '31,37p' runtime/crates/ainxt-context/src/optimizer.rs`

### ⏳ `CTX-05` — Row-level security (RLS) row-filter
- **subsystem:** context-fabric · **status:** DEFERRED-INFRA
- **deferred reason:** Native Postgres ROW LEVEL SECURITY on curated read-replica views (SET LOCAL current_setting + native RLS policy enforcement) requires a live database and cannot be exercised in-process. IMPLEMENTED offline and tested (ainxt-retrieval/src/structured.rs::tests::gap_ctx_05_rls_row_filter_scopes_rows_by_obo_session_context): the RlsPolicy→SET-LOCAL session-var derivation from the OBO AccessContext is fail-closed (a missing department/ad_level claim aborts the query rather than emit an all-rows predicate), the RlsExecutor read-replica seam carries a stale_as_of watermark, and a reference RowFilter oracle proves the derived session context excludes out-of-scope rows. Remaining work needs a real Postgres replica with the named RLS policies installed — infra, not code.
- **design:** STRUCTURED_FEDERATED §3: native Postgres ROW LEVEL SECURITY on curated views, keyed off SET LOCAL session vars sourced from OBO context, on read replicas with stale_as_of flag
- **original evidence:** no RLS / SET LOCAL / current_setting / read-replica logic anywhere in the three crates (grep empty); rederive.rs:256 only mentions a read-replica executor as a future trait seam; an RLS-capable compiler exists in a separate crate (ainxt-nl2sql/src/lib.rs:65) b
- **▶ verify yourself:** `sed -n '254,260p' runtime/crates/rederive.rs`

### 🔧 `CTX-06` — Numeric re-derivation gate on the live answer path
- **subsystem:** context-fabric · **status:** WIRING-IN-PROGRESS
- **design:** STRUCTURED_FEDERATED §5: every model-stated structured number must carry a source and be independently re-executed server-side; mismatch/not-reproducible BLOCKS the answer (payments-critical hard gate)
- **original evidence:** full fail-closed logic exists and is tested in ainxt-synthesis/src/rederive.rs (numeric_gate, rederive_and_verify, lint_numeric_claims) but ainxt-synthesis has ZERO dependents (only crates/ainxt-synthesis/Cargo.toml self-lists it); Rederiver (rederive.rs:263) 
- **▶ verify yourself:** `sed -n '261,267p' runtime/crates/rederive.rs`

### ✅ `CTX-07` — Structured metrics catalog (ADR-026 git-native) + closed-vocabulary NL-to-SQL compiler
- **subsystem:** context-fabric · **status:** FIXED
- **proof:** test `tests::gap_ctx_07_metric_catalog_is_the_closed_vocabulary` in `/Users/admin/Desktop/ai-copilot/runtime/crates/ainxt-retrieval/src/structured.rs`
- **design:** STRUCTURED_FEDERATED §2/§4: a git-reviewed, all-or-nothing-validated metric+dimension catalog is the entire vocabulary; a deterministic compiler (model never emits SQL) targets only catalog source_views
- **original evidence:** no catalog definition kind, loader, or intent->SQL compiler in the three crates; the standalone ainxt-nl2sql crate implements a safe compiler but has no catalog-as-control-plane and zero dependents (unwired)

### 🔧 `EDIT-01` — Pipeline integration — 'one gate every edit passes through; no other path to done' (§1)
- **subsystem:** semantic-editing-codereview · **status:** WIRING-IN-PROGRESS
- **design:** CODE_REVIEW_PIPELINE.md §1/§2: the turn renderer has NO code path that emits a done/success affordance for a code-editing turn without a Complete value; the pipeline fires on EVERY write the edit engine commits.
- **original evidence:** grep for `ainxt_pipeline` across all runtime/**/*.rs returns zero matches; run_pipeline/PipelineOutcome/commit_approval have no callers outside crates/ainxt-pipeline/. The invariant is enforced only within outcome.rs's type system (CommitApproval seal), but no

### ✅ `EDIT-02` — Edit ladder wired to real rung handlers (LSP→AST→patch→text)
- **subsystem:** semantic-editing-codereview · **status:** FIXED
- **proof:** test `gap_ainxt_pipeline_edit_02_rust_replace_uses_the_ast_rung; gap_ainxt_pipeline_edit_02_falls_from_ast_to_structured_then_records_rung; ast_failure_falls_to_structured_patch` in `runtime/crates/ainxt-pipeline/src/ladder_driver.rs`
- **design:** SEMANTIC_EDITING.md §2/§7: the engine picks the highest rung and falls down on failure; every edit flows into the pipeline before commit.
- **original evidence:** ladder.rs EditLadder::run (l.210) takes ast/structured/text as caller closures and has no callers anywhere; nothing composes rung2=ainxt-semantic replace_function, rung3=ainxt-edit apply, rung4=text. LSP rung is a bare trait seam (LspRefactor l.153) with no dr

### ✅ `EDIT-03` — Twelve-stage execution (Compile/Test/Lint/TypeCheck/Perf/Architecture/Regression/LLM-Review)
- **subsystem:** semantic-editing-codereview · **status:** FIXED
- **proof:** test `gap_ainxt_pipeline_edit_03_stages_actually_run_and_pass; gap_ainxt_pipeline_edit_03_sast_is_auto_run_and_flags_a_secret; gap_ainxt_pipeline_edit_03_python_typecheck_is_skipped_honestly; fail_fast_stops_before_tests_but_still_runs_sast` in `runtime/crates/ainxt-pipeline/src/stages.rs`
- **design:** CODE_REVIEW_PIPELINE.md §4: each stage states what it checks, deterministic vs model, inputs/outputs, failure feedback.
- **original evidence:** pipeline.rs run_pipeline (l.55) receives `stage_reports: Vec<StageReport>` already-run from the caller; stage.rs defines Stage as an enum + StageReport struct only. No stage runner or trait seam exists for Compile/Test/Lint/TypeCheck/Perf/Architecture/Regressi

### ✅ `EDIT-04` — Self-heal feedback loop (re-enter earliest invalidated stage, round-cap + stuck detector)
- **subsystem:** semantic-editing-codereview · **status:** FIXED
- **proof:** test `gap_ainxt_pipeline_edit_04_self_heal_re_enters_and_converges_to_complete; gap_ainxt_pipeline_edit_04_round_cap_yields_real_rounds_exhausted_not_zero; gap_ainxt_pipeline_edit_04_stuck_detector_cuts_thrash_before_the_cap` in `runtime/crates/ainxt-pipeline/src/selfheal.rs`
- **design:** CODE_REVIEW_PIPELINE.md §6: stage fails→Observation→Coder→re-apply→re-enter; bounded by round-cap AND stuck-detector; emit SelfHealTriggered/RoundCapped.
- **original evidence:** pipeline.rs run_pipeline is a single pass with rounds_exhausted hard-coded 0 (l.151,161); no Coder seam, no round counter. Pieces exist but are uncomposed: StageCache::stages_to_rerun (pipeline.rs l.240) and ainxt_judge::StuckDetector/JudgeLoop (judge lib.rs l

### 🔧 `EVAL-01` — Statistically-valid gate not the one that actually runs (gap [40] keystone)
- **subsystem:** eval-tester-scenarios · **status:** WIRING-IN-PROGRESS
- **design:** §5: the gate is a pre-registered, powered, FDR-corrected, effect-size-reported statistical decision; 'a gate that blocks on candidate_mean < baseline_mean blocks on coin-flips.'
- **original evidence:** ainxt-eval/src/lib.rs:209 evaluate_gate() blocks via `report.pass_rate + policy.noninferiority_margin < base.pass_rate` (aggregate arithmetic, no significance/power/per-cell); the rigorous stats::statistical_gate (stats.rs:659) has NO caller outside stats.rs u
- **▶ verify yourself:** `sed -n '207,213p' runtime/crates/ainxt-eval/src/lib.rs`

### 🔧 `EVAL-02` — Rigorous instruments not composed into an end-to-end gate / not invoked by any orchestrator, CI, or runtime path
- **subsystem:** eval-tester-scenarios · **status:** WIRING-IN-PROGRESS
- **design:** §2/§9/§10/§11/§12: contamination scan, sealed-holdout load, Judge admission+data-class routing, meta-gate on the set, Vault run, and a reproduce-from-SHA VerdictRecord written to the Event Log BEFORE a change ships — as one merge-blocking pipeline.
- **original evidence:** grep across crates: scan_contamination, admit_judge, route_judge, meta_gate_eval_set, RegressionVault, VerdictRecord are referenced ONLY from their own module #[cfg(test)] blocks; no non-test caller composes them; ainxt-canary and ainxt-quality::monitor have z

### 🔧 `FI-02` — Breach-notification engine not fed by any real detection source (§2.1)
- **subsystem:** regulated-fi-responsible-lifecycle · **status:** WIRING-IN-PROGRESS
- **design:** An IncidentCandidate is raised by typed sources each already present in the runtime — the compliance gate egress, the write-path sink-guard, the quality circuit-breaker, the payment boundary, serving-ops, the store-sweep, the NTP-skew monitor. From the instant the runtime notices
- **original evidence:** ainxt-incident exposes CandidateSource variants (lib.rs:91-114) and a complete engine, but the crate has zero reverse dependencies (absent from every other Cargo.toml; workspace members list runtime/Cargo.toml:6). No runtime code constructs an IncidentCandidat
- **▶ verify yourself:** `sed -n '89,95p' runtime/crates/lib.rs`

### 🔧 `FI-03` — RBI outsourcing register + register-as-router-eligibility (§3)
- **subsystem:** regulated-fi-responsible-lifecycle · **status:** WIRING-IN-PROGRESS
- **design:** One git control-plane file per outsourcing arrangement (permitted_data_class, data_residency, sub_processors pinned by hash, exit_plan_ref); the register IS the model router's non-overridable eligibility input — a route with no register entry, or below the request's data class/re
- **original evidence:** No OutsourcingRegister type or arrangement schema anywhere (grep 'outsourcing' hits only doc comments in ainxt-incident/src/lib.rs and ainxt-responsibleai/src/lib.rs:606). ModelRiskRecord.permitted_data_class + may_carry exist (ainxt-responsibleai/src/lib.rs:6
- **▶ verify yourself:** `sed -n '604,610p' runtime/crates/ainxt-responsibleai/src/lib.rs`

### ✅ `FI-04` — Evidentiary Export + BSA §63 certificate (§7 / ADR-025)
- **subsystem:** regulated-fi-responsible-lifecycle · **status:** FIXED
- **proof:** test `gap_ainxt_incident_fi04_export_produces_bsa63_certificate_with_particulars_filled (plus gap_ainxt_incident_fi04_tampered_export_fails_integrity_attestation, gap_ainxt_incident_fi04_export_refused_over_a_broken_chain)` in `runtime/crates/ainxt-incident/src/evidence.rs`
- **design:** An Evidentiary Export for any record-set produces three parts: the hash-chained slice, a chain-of-custody manifest, and a BSA §63-shaped electronic-record certificate auto-populated with runtime version, live control-plane SHA, chain root + record hashes, and NIC/NPL NTP source +
- **original evidence:** grep 'certificate' = 0 files across crates; 'Evidentiary' appears only in an ainxt-incident doc comment. The incident and DSAR registers are hash-chained/tamper-evident (ainxt-incident/src/lib.rs:985 verify; ainxt-lifecycle/src/dsar.rs:509 verify) but there is
- **▶ verify yourself:** `sed -n '983,989p' runtime/crates/ainxt-incident/src/lib.rs`

### ✅ `FI-05` — Supervisory audit-readiness: auditor read-only mode, India-residency verifier, NIC/NPL NTP + clock-skew incident (§8)
- **subsystem:** regulated-fi-responsible-lifecycle · **status:** FIXED
- **proof:** test `gap_ainxt_incident_fi05_auditor_mode_is_read_only_scoped_and_chain_logs_every_query; gap_ainxt_incident_fi05_ntp_skew_beyond_threshold_raises_a_2_incident; gap_ainxt_incident_fi05_mislocated_store_raises_a_residency_incident` in `runtime/crates/ainxt-incident/src/evidence.rs, runtime/crates/ainxt-incident/src/ops.rs`
- **design:** A read-only-by-construction auditor evidence-access mode (self-service, no engineer, every query chain-logged, existence-hiding scope filter), all ICT logs retained ≥180 days within Indian jurisdiction (residency verifier; a mis-located store is a §2 incident), and all clocks syn
- **original evidence:** No auditor-mode capability type (grep 'auditor' hits are incidental words in memory/scenario/synthesis/replay, not an access mode). NIC/NPL = 0 files; clock_skew = 0 files; the CandidateSource::NtpSkew enum variant exists (ainxt-incident/src/lib.rs:107) but no
- **▶ verify yourself:** `sed -n '105,111p' runtime/crates/ainxt-incident/src/lib.rs`

### 🔧 `HARN-01` — A registered harness is invocable from a surface (Chat, REST, connector trigger)
- **subsystem:** harness-sdk-governance · **status:** WIRING-IN-PROGRESS
- **design:** §2.1: 'Register it → it becomes a first-class agent invocable from Chat, CLI, REST, or a connector trigger. No code written.' §6: harnesses are discoverable/reusable across departments.
- **original evidence:** No crate outside ainxt-harness/ainxt-client/ainxt-cli references HarnessManifest/HarnessRuntime/run_harness (grep across crates returns nothing); ainxt-server/src/lib.rs:155 exposes only `.route("/v1/chat", ...)` with no harness route; there is no registry tha
- **▶ verify yourself:** `sed -n '153,159p' runtime/crates/ainxt-server/src/lib.rs`

### 🔧 `HARN-02` — StepExecutor bridges a step to a REAL engine turn that performs the step's capability
- **subsystem:** harness-sdk-governance · **status:** WIRING-IN-PROGRESS
- **design:** §2.2: each admitted step is executed as a real engine turn; the SDK yields tool.call / artifact events; capabilities include connector.postgres.query, artifact.generate_report, code.edit, etc. that actually do work.
- **original evidence:** Client::run_harness builds `Request::chat(session, &step.id, &input, ctx.data_class)` where input is step.input or the persona (ainxt-client/src/lib.rs:294-301); the step's `capability` is only used for gating (ainxt-harness gate_step lib.rs:820-847) and is ne
- **▶ verify yourself:** `sed -n '292,298p' runtime/crates/ainxt-client/src/lib.rs`

### 🔧 `IDN-01` — Payment boundary crate not wired into the runtime — Layers 5 (egress perimeter) & 6 (tripwire) are dead code on the live path
- **subsystem:** Agent Identity & Payment Boundary · **status:** WIRING-IN-PROGRESS
- **design:** §3/§4: five INDEPENDENT structural denials, each individually sufficient; Layer 5 settlement-perimeter deny-list stops the outbound value-moving call 'regardless of caller', Layer 6 tripwire inspects the actual effect of EVERY dispatch and fail-closed aborts+quarantines+revokes+i
- **original evidence:** grep across runtime/: no Cargo.toml or `use` references ainxt-payments/ainxt_payments outside its own crate; PaymentBoundary::screen / SettlementPerimeter / EgressAllowList (ainxt-payments/src/boundary.rs:439,64,152) have no external callers; ainxt-connector-h
- **▶ verify yourself:** `sed -n '437,443p' runtime/crates/ainxt-payments/src/boundary.rs`

### ✅ `IDN-02` — Producer≠approver Separation-of-Duties + signed handoffs (§18) — the Pass-5 [17] forged-approval fix
- **subsystem:** Agent Identity & Payment Boundary · **status:** FIXED
- **proof:** test `gap_idn_02_self_approval_is_rejected_same_run (+ gap_idn_02_same_model_two_runs_still_cannot_self_approve, _distinct_approver_is_granted_and_recorded, _approver_role_allow_list_is_enforced, _forged_handoff_signature_is_rejected, _valid_judge_handoff_to_distinct_receiver_is_accepted, _validly_signed_but_self_approval_still_rejected, _artifact_swap_is_rejected)` in `runtime/crates/ainxt-identity/src/sod.rs`
- **design:** §18: Policy Engine REFUSES an approval/merge/commit from an actor whose AWC produced the same artifact; handoffs are signed by the producer's AWC and the receiver verifies signature+SoD before acting — 'Pass-5 [17] closed structurally'
- **original evidence:** grep for producer/approver/SoD/handoff/self_approve across ainxt-identity: zero matches (only ainxt-payments dual-control, which is distinct-approver quorum, not producer≠approver-by-identity); no signature-on-handoff type exists

### 🔧 `IDN-03` — AIA identity lifecycle never invoked by the agent loop — no action runs under an AWC
- **subsystem:** Agent Identity & Payment Boundary · **status:** WIRING-IN-PROGRESS
- **design:** §12/§14: EVERY agent action is performed under a per-Run AWC which is the Policy-Engine principal and the Event-Log actor of record, completing ADR-026's two-trail audit
- **original evidence:** IdentityAuthority/AgentWorkloadCredential (ainxt-identity/src/authority.rs:540,59) have no cross-crate consumers; ainxt-runtime/ainxt-runtimed do not depend on or reference ainxt-identity; the AWC uri()/label() actor is never written into ainxt-eventlog
- **▶ verify yourself:** `sed -n '538,544p' runtime/crates/ainxt-identity/src/authority.rs`

### ✅ `LOOP-03` — SELF-HEAL: execute → detect → LLM-propose-fix → retry → escalate (bounded)
- **subsystem:** loop-teams-longhorizon · **status:** FIXED
- **proof:** test `tiers::tests::gap_ainxt_teams_loop_03_self_heal_repairs_then_succeeds (also gap_ainxt_teams_loop_03_stuck_detector_aborts_a_repeating_failure)` in `/Users/admin/Desktop/ai-copilot/runtime/crates/ainxt-teams/src/tiers.rs`
- **design:** LOOP §6: on task failure, classify error, gather context, LLM proposes a fix scoped to the same task, retry, escalate context/model-tier, and abort the task to the Planner at the cap.
- **original evidence:** ainxt-runtime/src/lib.rs has only provider-level transient retry/failover ('attempts loop at :929 with HeuristicErrorClassifier) and implicit tool-error feedback to the model (prompt.push_str at :1109/:1250). No error-classification→LLM-fix→retry→escalate exis
- **▶ verify yourself:** `sed -n '706,712p' runtime/crates/lib.rs`

### ✅ `LOOP-04` — 3-tier loop: tier-2 per-step critic + tier-3 fresh-context judge-audited outer loop
- **subsystem:** loop-teams-longhorizon · **status:** FIXED
- **proof:** test `tiers::tests::gap_ainxt_teams_loop_04_fresh_judge_blocks_a_confidently_incomplete_deliverable (also ..._three_tier_happy_path_completes)` in `/Users/admin/Desktop/ai-copilot/runtime/crates/ainxt-teams/src/tiers.rs`
- **design:** LOOP §5/§7: after each step a cheap critic checks acceptance criteria; once tasks are nominally done, a fresh-context Architect-as-judge audits the whole deliverable against the original goal (anti-sycophancy) and gaps loop back to the Planner.
- **original evidence:** The reachable Engine (ainxt-runtime/src/lib.rs run_turn_cancellable) has no critic or judge invocation (grep for critic/judge in that file: none). verify.rs JudgeVerdict (ainxt-planner/src/verify.rs:108) is an inert data struct combined by three_way_gate, not 
- **▶ verify yourself:** `sed -n '106,112p' runtime/crates/ainxt-planner/src/verify.rs`

### ✅ `LOOP-05` — Planner adaptive depth + LLM decomposition + graph materialization/flatten
- **subsystem:** loop-teams-longhorizon · **status:** FIXED
- **proof:** test `tests::gap_loop_05_materialize_graph_promotes_a_flat_list_to_parallel_tracks (also ..._flatten_linearizes..., ..._adaptive_depth_classifies_goals)` in `/Users/admin/Desktop/ai-copilot/runtime/crates/ainxt-planner/src/lib.rs`
- **design:** LOOP §2/§3: simple/medium/complex tiering of planning effort, a structure probe, plan.materialize_graph and plan.flatten, with an LLM Architect-role decomposer.
- **original evidence:** ainxt-planner/src/lib.rs ships only TemplateDecomposer (a fixed template, :289); the Decomposer trait (:252) has no LLM implementation. There is no simple/medium/complex classification, no structure probe, and no materialize_graph/flatten API on Plan. teams Ta

### 🔧 `LOOP-06` — Durable, hash-chained Event-Log persistence for Program/Plan state
- **subsystem:** loop-teams-longhorizon · **status:** WIRING-IN-PROGRESS
- **design:** ADR-027 §4: program state is an append-only, crypto-hash-chained stream on the runtime Event Log, durable across restarts/model-swaps/multi-week wall-clock; resume = replay to last checkpoint.
- **original evidence:** ainxt-planner/src/program.rs folds an in-memory &[ProgramEvent] slice (project:884, project_incremental:895) and uses a placeholder FNV-1a hash explicitly 'not crypto' (:362). No wiring to ainxt-eventlog for durable storage; nothing persists or reloads a strea

### ✅ `LOOP-07` — Program budget governance + staged human checkpoints (Start/Phase/Budget/Critical-path/Anomaly)
- **subsystem:** loop-teams-longhorizon · **status:** FIXED
- **proof:** test `supervisor::tests::gap_loop_07_crossing_the_hard_budget_ceiling_pauses_the_program (also ..._a_budget_threshold_forces_a_checkpoint_review_gate, ..._critical_path_node_rejected_by_human_is_blocked)` in `/Users/admin/Desktop/ai-copilot/runtime/crates/ainxt-planner/src/supervisor.rs`
- **design:** ADR-027 §7/§8: a program budget with 25/50/75% CHECKPOINT_REVIEW gates and a 100% hard pause; critical-path modules force assisted human commit regardless of score; checkpoints reuse the Approval Gate seam.
- **original evidence:** program.rs has CheckpointClass (:77) and ProgramPhase::CheckpointReview (:119) enums but no budget counters, no threshold-gate logic, and no ApprovalGate invocation. CheckpointReviewOpened is a manually-supplied event (:268) with no automatic trigger; critical

### ✅ `MEM-01` — Compliance-on-write gate is bypassable-by-omission (not mandatory)
- **subsystem:** Enterprise Memory & Continuous Learning · **status:** FIXED
- **proof:** test `gap_ainxt_memory_mem_01_default_store_gate_is_never_off_by_omission` in `runtime/crates/ainxt-memory/src/store.rs`
- **design:** §8.4: 'the same mandatory, non-bypassable gate ... also scans every memory write — session, episodic, semantic, OKI — before persistence'; the runtime-wide A1 invariant is 'configurable provider, never configurable off'.
- **original evidence:** store.rs:125 redactor is Option<Box<dyn Redactor>>, default None; store.rs:198-206 redact_item() is a no-op when None; write() (store.rs:683-812) never requires a redactor. A store built via InMemoryStore::new() silently persists PAN/PII. Gate is configurable 
- **▶ verify yourself:** `sed -n '123,129p' runtime/crates/store.rs`

### ✅ `MEM-02` — Redaction never covers OKI typed-payload fields
- **subsystem:** Enterprise Memory & Continuous Learning · **status:** FIXED
- **proof:** test `gap_ainxt_memory_mem_02_redaction_covers_oki_typed_payload_fields` in `runtime/crates/ainxt-memory/src/store.rs`
- **design:** §8.4 the gate scans every memory write before persistence; §2 the substance lives in the typed payload, not free text.
- **original evidence:** store.rs:198-206 redact_item() only rewrites title, body, tags; store.rs:398-425 re_redact() likewise only title/body/tags. OrgPayload fields (e.g. IncidentPostmortem.timeline, CommonFix.fix_template, SecurityRule.rule) in lib.rs:340 MemoryItem.payload are nev
- **▶ verify yourself:** `sed -n '196,202p' runtime/crates/store.rs`

### ✅ `MEM-03` — Org/team/repo-scoped non-OKI memory is written authoritative with no human gate or capability check
- **subsystem:** Enterprise Memory & Continuous Learning · **status:** FIXED
- **proof:** test `gap_ainxt_memory_mem_03_shared_scope_nonoki_requires_governance_not_a_single_caller` in `runtime/crates/ainxt-memory/src/store.rs`
- **design:** §8.2 'There is no code path from a user said so directly to org-scope memory — org-scope requires the governance queue, full stop'; §8.3 no auto-promotion to authority.
- **original evidence:** store.rs:693-729 write() only human-gates kind==OrgKnowledge; a MemoryKind::Semantic item at Scope::Org is created Approved (lib.rs:399 governance=Approved in MemoryItem::new) and is_authoritative()==true (lib.rs:469-477), served by default queries — with no C
- **▶ verify yourself:** `sed -n '691,697p' runtime/crates/store.rs`

### 🔧 `MEM-04` — Memory not integrated into the Context Fabric read path / turn pipeline
- **subsystem:** Enterprise Memory & Continuous Learning · **status:** WIRING-IN-PROGRESS
- **design:** §7 'Memory does not have its own retrieval code path — it is layer 12 of the Context Fabric, read by the same Context Optimizer', with query-planning by task and a per-turn lineage record enabling forensic replay.
- **original evidence:** grep across runtime/crates finds no reference to MemoryStore/InMemoryStore/query/MemoryItem outside crates/ainxt-memory/. query() (store.rs:907) and resolve() (store.rs:226) are never called; no query-planning picks sub-types by task; nothing captures injected
- **▶ verify yourself:** `sed -n '905,911p' runtime/crates/store.rs`

### ⏳ `MEM-05` — No durable store — in-memory only; no Postgres/KG backend
- **subsystem:** Enterprise Memory & Continuous Learning · **status:** DEFERRED-INFRA
- **deferred reason:** A durable Postgres/KG-backed MemoryStore (with pgvector embeddings + KG edges) requires a live Postgres/pgvector instance to implement and test honestly; it cannot be exercised offline without faking the DB. The seam is in place: the MemoryStore trait + the deterministic InMemoryStore reference impl (edit-free versioning, governance, retention, erasure, re-embed routing) define exactly the surface a durable impl must satisfy, so a Postgres impl slots in behind the trait without touching callers. This also covers the durable Redis backing referenced by MEM-06.
- **design:** §2 OKIs 'stored in Postgres with full lifecycle governance'; §3 Episodic (Postgres), Semantic+OKI (unified Knowledge Graph).
- **original evidence:** store.rs:118-127 InMemoryStore (HashMap) is the only MemoryStore impl; lib.rs:36-37 explicitly defers 'a durable Postgres/KG-backed impl slots in behind the same trait'. All tiers are process-memory; nothing survives restart.
- **▶ verify yourself:** `sed -n '116,122p' runtime/crates/store.rs`

### ⬜ `OS-01` — Role rung — the 'digital worker' (agent(s)+workflows+connectors+knowledge+governance+KPIs+charter+escalation) that maps to a whole job function
- **subsystem:** AiNxt OS / Skill→Agent→Role→Team Workforce Ladder + Role Studio · **status:** OPEN
- **design:** WORKFORCE_AND_OS §1/§2: the central concept — 'replace an entire person' = the Role rung, a composition (charter → structured spec of responsibilities/inputs/outputs/escalation, capabilities grant, skills, autonomy model, knowledge namespace, governance, KPIs, validation).
- **original evidence:** No RoleSpec/RoleManifest/RoleDefinition/charter/KPI type anywhere (grep charter|KPI|digital-worker|'job description' = 0 non-comment hits). The only `Role` types are the RBAC enum ainxt-types/src/lib.rs:48 (User/Admin) and the multi-agent execution role ainxt-
- **▶ verify yourself:** `sed -n '46,52p' runtime/crates/ainxt-types/src/lib.rs`

### ⬜ `OS-02` — Role Studio authoring flow (charter→spec decompose, auto-assembled draft, KPI auto-gen eval set, knowledge retrieval-quality gate, shadow-run, monitor/improve)
- **subsystem:** AiNxt OS / Skill→Agent→Role→Team Workforce Ladder + Role Studio · **status:** OPEN
- **design:** AINXT_OS §4 Steps 1-10 / WORKFORCE §2: conversational factory turns a plain-language job description into a Role Spec, auto-assembles capabilities/skills, auto-generates a per-role quality-eval set, runs a retrieval-quality check, then shadow-runs beside a human before cutover.
- **original evidence:** No factory/decompose code; grep 'shadow'|charter|KPI|'job description' returns only unrelated hits (nl2sql serde 'shadow' rows, responsibleai text). No crate consumes a job-charter or emits a role spec; ainxt-eval has no per-role KPI auto-generation path.
- **▶ verify yourself:** `rg "shadow" runtime/crates`

### 🔧 `PRMT-01` — Layered Registry + per-model variant serving is not wired into the runtime serving path
- **subsystem:** Prompt engineering · **status:** WIRING-IN-PROGRESS
- **design:** Section 3/7: prompt layers loaded into the runtime Definition Registry; the Prompt Engine resolves the (L1,L2,L3,L4,family) deployment tuple per turn and serves the per-model variant to the Provider Gateway
- **original evidence:** registry.rs Registry::serve (line 634) and layered.rs LayeredAssembler (line 144) have NO callers outside ainxt-prompt (grep for .serve(/Deployment::/LayeredAssembler/ResolvedLayer across crates returns nothing); the live path uses the flat single-string engin
- **▶ verify yourself:** `sed -n '489,495p' runtime/crates/ainxt-convo/src/lib.rs`

### ✅ `PRMT-02` — Grammar/GBNF/JSON-schema constrained decoding (the load-bearing section-4 technique)
- **subsystem:** Prompt engineering · **status:** FIXED
- **proof:** test `gap_ainxt_prompt_prmt_02_constrained_decoding_100_of_100_valid (+ _repair_budget_is_bounded_and_fails_closed, _provider_error_propagates_not_swallowed, _cancellation_aborts_the_loop, _native_decoder_that_lies_fails_closed)` in `crates/ainxt-prompt/src/constrained.rs`
- **design:** Section 4: attach a JSON-schema or GBNF grammar so the model literally cannot emit an invalid token; generalize CONVERSATION_INTELLIGENCE section-5 constrained decoding to EVERY structured output (tool args, Role Spec JSON, judge verdicts, doc-gen payloads); 100/100 schema-valid 
- **original evidence:** No gbnf/grammar/schema-enforcement code in ainxt-prompt at all; the only related crate, ainxt-classify/src/lib.rs:13-14, states the runtime must 'behave identically whether or not the transport supports GBNF / JSON-schema' and is a prompted-label + bounded-rep
- **▶ verify yourself:** `sed -n '11,17p' runtime/crates/ainxt-classify/src/lib.rs`

### 🔧 `PRMT-03` — System-prompt-leak output rail not enforced at runtime
- **subsystem:** Prompt engineering · **status:** WIRING-IN-PROGRESS
- **design:** Section 6.A / PE5: an independent output-side rail pattern-matches model output against L1-L4 and blocks near-verbatim leaks (incl. base64/hex/reversed) regardless of the model's decision
- **original evidence:** ainxt-prompt guard.rs:98 LeakRail::inspect and the parallel ainxt-guardrails SystemPromptLeakRail both exist and are tested, but neither is wired: RailChain::from_config (ainxt-guardrails/src/lib.rs:499) only registers jailbreak/groundedness/toxicity/topic; th
- **▶ verify yourself:** `sed -n '96,102p' runtime/crates/guard.rs`

### 🔧 `PRMT-04` — Numeric-via-tools ENFORCEMENT (BH) not wired; only the directive is emitted
- **subsystem:** Prompt engineering · **status:** WIRING-IN-PROGRESS
- **design:** BH: for payments a number must come from a tool, never the model's head; numeric.rs header itself notes the audit finding 'instructs but does not enforce' and adds a post-condition that flags any amount-like output number not attributable to a tool result
- **original evidence:** numeric::enforce (numeric.rs:60) has no callers outside ainxt-prompt; the wired flat engine only emits the [NUMERIC] directive text (lib.rs:228-235), and ainxt-chat/src/lib.rs:13 lists 'numeric discipline' as the directive-level assembly only
- **▶ verify yourself:** `sed -n '58,64p' runtime/crates/numeric.rs`

### 🔧 `SRV-01` — Serving-Ops wired into a request path / ADR-020 model.infer capability
- **subsystem:** Serving-Ops · **status:** WIRING-IN-PROGRESS
- **design:** §7/§ Decision: Serving-Ops sits between the Model Router and the physical fleet and 'exposes exactly one capability upward — model.infer(model_id, priority_class, tenant, data_class, payload) → stream — through the same CapabilityRegistry every other capability uses'; it is the s
- **original evidence:** No crate depends on ainxt-serving: `grep -rln ainxt-serving crates/*/Cargo.toml` returns only crates/ainxt-serving/Cargo.toml. No `model.infer`/`model_infer` capability symbol exists anywhere. AdmissionController/PreemptionScheduler/AttestationGate/etc. have z

### 🔧 `SURF-01` — Surface Profiles consumed by the daemon (one-runtime-N-surfaces)
- **subsystem:** surfaces-profiles-skills-config · **status:** WIRING-IN-PROGRESS
- **design:** A product surface = a Renderer + a declarative Surface Profile that configures the spine; profiles are loaded and CONSUMED by the runtime so RBAC floor, data-class ceiling, autonomy, retrieval scope, dept scoping, and model policy are enforced per turn.
- **original evidence:** ainxt-runtimed/Cargo.toml [dependencies] omits ainxt-surface/ainxt-profile/ainxt-skill; grep across runtime shows SurfaceCatalog/SurfaceBinding/TurnPlan/builtin_profiles referenced ONLY in runtime/Cargo.toml + ainxt-surface's own catalog.rs/tests. main.rs:35,9
- **▶ verify yourself:** `sed -n '33,39p' runtime/crates/main.rs`

### 🔧 `SURF-02` — Served Chat surface serves grounded retrieval + citations
- **subsystem:** surfaces-profiles-skills-config · **status:** WIRING-IN-PROGRESS
- **design:** Chat surface = grounded Q&A over the platform KB with citations; retrieval is clearance-filtered pre-rank (Context Engine + RAG).
- **original evidence:** Daemon's served chat: ainxt-runtimed/src/lib.rs:390 builds ainxt_convo::ConversationManager::new(engine, HeuristicClassifier) — the no-retriever constructor (ainxt-convo/src/lib.rs:423 sets retriever: None), so no grounding/citations. The grounded path (Conver
- **▶ verify yourself:** `sed -n '388,394p' runtime/crates/ainxt-runtimed/src/lib.rs`

### 🔧 `SURF-09` — Safe NL-to-SQL wired as a live runtime query capability
- **subsystem:** data-surfaces-artifacts · **status:** WIRING-IN-PROGRESS
- **design:** A model NEVER emits raw SQL; it proposes a QueryIntent that this crate compiles to bounded, parameterized, RLS-scoped SQL — the boundary that makes agent-over-ledger queries safe on a payments platform.
- **original evidence:** grep for ainxt_nl2sql across runtime/crates/**/*.rs returns NONE outside crates/ainxt-nl2sql/; not a dependency in any Cargo.toml; no tool/capability registration (no nl2sql/query_intent/validate_and_compile in ainxt-tools/ainxt-mcp/ainxt-runtime src). Library

### 🔧 `SURF-10` — Knowledge-graph RBAC traversal wired into the runtime
- **subsystem:** data-surfaces-artifacts · **status:** WIRING-IN-PROGRESS
- **design:** Unified code+docs graph with RBAC enforced at traversal time (no path-count/stepping-stone/reachability leak) exposed as the platform's /graph.
- **original evidence:** grep for ainxt_graph across runtime/crates/**/*.rs returns NONE outside crates/ainxt-graph/; no Cargo.toml dependents; no server/runtimed reference. ainxt-graph/src/lib.rs Graph::{traversal,shortest_path,neighbors} fully implemented+17 tests but consumed by no

### 🔧 `SURF-11` — Execution Replay + turn-tree (branch/edit/stop/steer) wired to the real Event Log
- **subsystem:** data-surfaces-artifacts · **status:** WIRING-IN-PROGRESS
- **design:** INTERACTION_REPL_COMMANDS §2/§3: the Event Log is a tree; deterministic RBAC-scoped pure replay + branch/edit/stop/steer are first-class on the live session; replay backs audit/compliance and the Breaker.
- **original evidence:** grep for ainxt_replay returns NONE outside crates/ainxt-replay/. The WIRED log ainxt-eventlog/src/lib.rs is append-only LINEAR JsonlEventLog (no parent/branch/tree API); the WIRED session ainxt-session/src/lib.rs exposes per-turn CancelToken (Stop) only — no b

### ✅ `TOOL-01` — Per-resource locking absent
- **subsystem:** tooling-mcp-plugins-routing · **status:** FIXED
- **proof:** test `gap_tool_01_concurrent_calls_on_same_resource_serialize (+ gap_tool_01_disjoint_resources_run_in_parallel)` in `runtime/crates/ainxt-tools/tests/resource_lock_test.rs`
- **design:** Concurrent calls sharing a resource_key serialize (scenario 8).
- **original evidence:** ainxt-tools dispatch has no per-resource lock; resource_of feeds only authz.

### ⬜ `TRAN-01` — a
- **subsystem:** transport-daemon · **status:** OPEN
- **design:** b
- **original evidence:** c

### 🔧 `TURN-01` — Budget check in the Identity+Policy gate
- **subsystem:** turn-pipeline · **status:** WIRING-IN-PROGRESS
- **design:** RUNTIME_FEATURE_FLOWS §1 step 2 (🔒): 'validate JWT → RBAC + dept scope; budget check; rate-limit/backpressure (503 if over)' — per-user token/cost limit is a mandatory pre-turn gate
- **original evidence:** ainxt-runtime/src/lib.rs:796-811 the gate runs ONLY authz(CAP_CHAT_SEND); no budget/quota check anywhere in run_turn_cancellable. grep 'budget' across runtime finds only history_budget_tokens (context-window sizing, ainxt-profile/src/lib.rs:146) — no per-user 
- **▶ verify yourself:** `sed -n '794,800p' runtime/crates/ainxt-runtime/src/lib.rs`

### ✅ `TURN-02` — Protocol envelope (command_id/idempotency, session_id, participant_id, seq, ts, control_plane_sha, program_id)
- **subsystem:** turn-pipeline · **status:** FIXED
- **proof:** test `gap_turn_02_envelopes_carry_the_full_machinery` in `runtime/crates/ainxt-protocol/src/lib.rs`
- **design:** PROTOCOL.md §4 — every wire message wraps a typed body in a stable envelope; seq is the ordering/resume backbone (I7), command_id is the exactly-once dedup key (I7/ADR-013), control_plane_sha pins definitions for audit
- **original evidence:** ainxt-protocol/src/lib.rs:25-42 Request has only {session,turn,input,data_class,tier,forced_provider,untrusted_tainted}; Event (:60-82) carries no seq/ts/envelope. No envelope struct exists in the crate; grep for command_id/seq/participant_id/control_plane_sha
- **▶ verify yourself:** `sed -n '23,29p' runtime/crates/ainxt-protocol/src/lib.rs`

### ✅ `TURN-03` — Command family (session.open/resume/subscribe/fork/close, turn.submit/steer/stop/edit/branch, approval.respond, program.*)
- **subsystem:** turn-pipeline · **status:** FIXED
- **proof:** test `gap_turn_03_command_family_round_trips + gap_turn_03_payment_boundary_requires_human_approve` in `runtime/crates/ainxt-protocol/src/lib.rs`
- **design:** PROTOCOL.md §5 — a client sends typed Commands; the set is exhaustive and its absence enforces 'no wire path to payment initiation' (§9/I1)
- **original evidence:** ainxt-protocol/src/lib.rs defines no `enum Command`; the only client→runtime type is `Request` (≈ the turn.submit body). No session lifecycle, steer, edit, branch, subscribe, or approval.respond command types exist; approval is handled in-process only (engine 

### 🔧 `TURN-04` — Disconnect ≠ cancel (detach semantics)
- **subsystem:** turn-pipeline · **status:** WIRING-IN-PROGRESS
- **design:** PROTOCOL.md §7.2 / I3 — 'the single most important operational property': a transport drop DETACHES; the running turn keeps running server-side; only an explicit turn.stop cancels — deliberately NOT 'stream cancel = turn cancel' so a flaky network never kills long turns
- **original evidence:** ainxt-server/src/lib.rs:177-182 CancelOnDisconnect::drop() calls token.cancel(); :223 the guard is tied to the SSE response so a client disconnect fires the shared cancel token and ABORTS the turn — the exact inverse of the design invariant. A dropped SDLC/lon
- **▶ verify yourself:** `sed -n '175,181p' runtime/crates/ainxt-server/src/lib.rs`

### 🔧 `TURN-05` — session.resume{from_event} tail replay via seq cursor
- **subsystem:** turn-pipeline · **status:** WIRING-IN-PROGRESS
- **design:** PROTOCOL.md §7.2 — a reconnecting client sends session.resume{from_event:<last_seq>}; runtime returns session.snapshot then replays every event with seq>from_event from the Event Log; resume is cold-start safe
- **original evidence:** No seq, from_event, session.resume, or snapshot anywhere (grep empty across ainxt-protocol/ainxt-server/ainxt-session/ainxt-runtimed). ainxt-server/src/lib.rs:224-229 simply drains the mpsc rx into SSE; if the stream drops there is no cursor and no replay path
- **▶ verify yourself:** `sed -n '222,228p' runtime/crates/ainxt-server/src/lib.rs`


## 🟡 MEDIUM

### ✅ `CONN-05` — Egress DLP coverage of request URLs / query params
- **subsystem:** Connectors · **status:** FIXED
- **proof:** test `gap_conn_05_url_dlp_blocks_pan_in_read_path` in `runtime/crates/ainxt-connector-http/src/lib.rs`
- **design:** Before any bytes leave, the payload passes the DLP redactor; secrets/PANs redacted before egress (gap T).
- **original evidence:** ainxt-connector-http/src/lib.rs invoke() builds the egress payload only from the request BODY when prepared.egress_body is true (l.388-397); reads set payload = String::new(). Adapter URLs embed user-controlled data (e.g. GitLab::get_file path/ref at l.464-476

### ✅ `CONN-06` — Production HTTP transport / air-gap proxy path verification
- **subsystem:** Connectors · **status:** FIXED
- **proof:** test `gap_conn_06_connect_failure_maps_to_unavailable_soft_degrade` in `runtime/crates/ainxt-connector-http/src/lib.rs`
- **design:** Callback token exchange and Graph calls routed through HTTPS_PROXY/web02 in air-gapped prod; unreachable proxy soft-degrades.
- **original evidence:** ReqwestTransport (ainxt-connector-http/src/lib.rs l.708-768) is behind the default-OFF 'reqwest-transport' feature and has ZERO tests: the module doc claims 'Its live tests are #[ignore]' but the full test run reports '0 ignored' and grep for '#[ignore]' in th

### ✅ `CONV-03` — Model-agnostic / capability-aware extraction (§5): grammar-constrained decoding + registry capability-flag selection
- **subsystem:** Conversation Intelligence · **status:** FIXED
- **proof:** test `gap_ainxt_convo_conv_03_capability_flags_select_extraction_strategy, gap_ainxt_convo_conv_03_weak_model_gets_larger_repair_budget` in `runtime/crates/ainxt-convo/tests/intent_cascade_test.rs`
- **design:** Keyed off model-registry capability flags (native-tool-calling? grammar-constrained? context size?): GBNF/JSON-schema-constrained decoding for OSS models; capability-aware control-flow; same cascade, only extraction technique differs per model.
- **original evidence:** LabelModel is a bare text-in/text-out seam with no transport impl and no capability-flag-driven selection anywhere (ainxt-classify/src/lib.rs:543); crate docs concede grammar enforcement is a 'downstream transport seam'. Because the whole classify crate is unw
- **▶ verify yourself:** `sed -n '541,547p' runtime/crates/ainxt-classify/src/lib.rs`

### ✅ `CONV-04` — Intent taxonomy completeness (§2: chitchat, qa, task, doc_generation, code, comparison)
- **subsystem:** Conversation Intelligence · **status:** FIXED
- **proof:** test `gap_ainxt_convo_conv_04_taxonomy_covers_code_and_task` in `runtime/crates/ainxt-convo/tests/intent_cascade_test.rs`
- **design:** Stage-2 classifies intent into six labels including task and code.
- **original evidence:** ainxt-convo Intent enum has no Code variant (Chitchat/Qa/Task/Comparison/DocGeneration, lib.rs:141-148); HeuristicClassifier only ever emits DocGeneration/Comparison/Chitchat/Qa (lib.rs:203-228) — Task is declared but never produced and Code cannot be represen
- **▶ verify yourself:** `sed -n '139,145p' runtime/crates/lib.rs`

### ✅ `CONV-05` — Follow-up rewrite to a self-contained standalone query (§3)
- **subsystem:** Conversation Intelligence · **status:** FIXED
- **proof:** test `gap_ainxt_convo_conv_05_model_rewrite_is_clean_standalone` in `runtime/crates/ainxt-convo/tests/intent_cascade_test.rs`
- **design:** Rewrite the turn into a self-contained form: 'generate this as pdf' ⇒ 'Generate a PDF of the UPI growth analysis provided in the previous answer.'
- **original evidence:** rewrite_query does not produce a standalone rewrite; it prepends a truncated context prefix and appends the raw message: format!('(context — prior question: {:?}; prior answer: {}) follow-up: {message}', ...) (ainxt-convo/src/lib.rs:327-330). It grounds retrie
- **▶ verify yourself:** `sed -n '325,331p' runtime/crates/ainxt-convo/src/lib.rs`

### ✅ `CONV-06` — Content resolution order 3 — referenced artifact / turn id (§4)
- **subsystem:** Conversation Intelligence · **status:** FIXED
- **proof:** test `gap_ainxt_convo_conv_06_resolve_specific_answer_by_ordinal_and_id` in `runtime/crates/ainxt-convo/tests/intent_cascade_test.rs`
- **design:** Resolution order includes (3) a user pointing at a specific earlier message or artifact by id → use that.
- **original evidence:** resolve_content only implements order-1 (' about '/':' heuristic) and order-2 (anaphora→last substantive answer) then Ambiguous (ainxt-convo/src/lib.rs:257-280); there is no addressing of a specific prior turn/artifact id — history Messages carry no id at all 
- **▶ verify yourself:** `sed -n '255,261p' runtime/crates/ainxt-convo/src/lib.rs`

### ✅ `CONV-07` — 'Substantive assistant answer' skips acknowledgements & clarifying questions (§4)
- **subsystem:** Conversation Intelligence · **status:** FIXED
- **proof:** test `gap_ainxt_convo_conv_07_substantive_skips_ack_and_clarifying_question` in `runtime/crates/ainxt-convo/tests/intent_cascade_test.rs`
- **design:** The referent = last assistant turn that produced real content, skipping acknowledgements, clarifying questions, and the current instruction.
- **original evidence:** last_substantive_assistant only skips whitespace-empty text (ainxt-convo/src/lib.rs:125-131: find(|m| m.role==Assistant && !m.text.trim().is_empty())). A prior assistant clarifying question ('Which content should I put in the PDF?') or a bare acknowledgement w
- **▶ verify yourself:** `sed -n '123,129p' runtime/crates/ainxt-convo/src/lib.rs`

### ✅ `CONV-08` — T5 — multi-action 'summarize the above and email it' (content=referent, action=email, instruction excluded)
- **subsystem:** Conversation Intelligence · **status:** FIXED
- **proof:** test `gap_ainxt_convo_conv_08_summarize_and_email_content_is_referent_not_instruction` in `runtime/crates/ainxt-convo/tests/intent_cascade_test.rs`
- **design:** Acceptance T5: 'summarize the above and email it' ⇒ content = resolved referent, action = email; instruction excluded from body.
- **original evidence:** No email/summarize action intent exists (Intent enum lib.rs:141-148); 'email'/'summarize' are not gen_verbs/formats (lib.rs:167-202) so the turn falls through to Qa, and resolve_content is never called on the Qa branch (lib.rs:551-628). No convo test exercises
- **▶ verify yourself:** `sed -n '139,145p' runtime/crates/lib.rs`

### ✅ `CTX-08` — Federated privacy-preserving tier integrated (broker dispatch + tenant isolation)
- **subsystem:** context-fabric · **status:** FIXED
- **proof:** test `tests::gap_ctx_08_broker_dispatches_aggregates_and_debits_ledger, gap_ctx_08_broker_refuses_non_whitelisted_and_exhausted_budget, gap_ctx_08_broker_enforces_tenant_isolation, gap_ctx_08_broker_reports_unreachable_tenants_not_as_zero` in `/Users/admin/Desktop/ai-copilot/runtime/crates/ainxt-retrieval/src/federation.rs`
- **design:** STRUCTURED_FEDERATED §6: a Federated Query Broker dispatches the compiled template to each isolated bank tenant, aggregates noised partials; physical tenant isolation with no cross-tenant credential
- **original evidence:** broker/bank logic is real and tested in ainxt-retrieval/src/federation.rs (require_federated, noise_partial, EpsilonLedger, aggregate) but there is no dispatch/transport, no tenant-isolation enforcement (federation.rs:29 states isolation is deferred to infra),
- **▶ verify yourself:** `sed -n '27,33p' runtime/crates/federation.rs`

### 🔧 `CTX-09` — Cross-source conflict arbitration + faithfulness/groundedness wired
- **subsystem:** context-fabric · **status:** WIRING-IN-PROGRESS
- **design:** CONTEXT_FABRIC §3: prefer fresh sources, arbitrate conflicts by recency/authority, attach provenance; every assembled context carries lineage; unsupported claims flagged
- **original evidence:** synthesize/detect_conflicts/arbitrate/attribute all implemented+tested in ainxt-synthesis/src/lib.rs but the crate has zero dependents; the live assemble() (ainxt-context/src/lib.rs:352 build_context) records lineage but performs no conflict arbitration or fai
- **▶ verify yourself:** `sed -n '350,356p' runtime/crates/ainxt-context/src/lib.rs`

### ✅ `CTX-10` — Node/edge-level RBAC + department/ad_level scoping in the security filter
- **subsystem:** context-fabric · **status:** FIXED
- **proof:** test `tests::gap_ctx_10_node_edge_rbac_department_ad_level_prerank` in `/Users/admin/Desktop/ai-copilot/runtime/crates/ainxt-retrieval/src/lib.rs`
- **design:** CONTEXT_FABRIC §2 (node/edge-level RBAC + data-class labels) and §8.3 (department/ad_level pre-rank existence filtering)
- **original evidence:** the filter is a single DataClass scalar: Retriever::retrieve takes only clearance: DataClass (ainxt-context/src/lib.rs:69); Corpus::is_visible compares chunk.data_class.sensitivity() <= principal.clearance.sensitivity() only (ainxt-retrieval/src/lib.rs:254) — 
- **▶ verify yourself:** `sed -n '67,73p' runtime/crates/ainxt-context/src/lib.rs`

### 🔧 `CTX-11` — Position-aware assembly + freshness applied on the live path
- **subsystem:** context-fabric · **status:** WIRING-IN-PROGRESS
- **design:** CONTEXT_FABRIC §3: most-relevant at the window edges (lost-in-the-middle mitigation); prefer fresh sources
- **original evidence:** position_aware/budget_fit exist in ainxt-retrieval/src/lib.rs:580,599 but are only reachable via budget fitting; the live assemble()/build_context (ainxt-context/src/lib.rs:352) emits chunks in plain rank order with no positioning or freshness weighting
- **▶ verify yourself:** `sed -n '578,584p' runtime/crates/ainxt-retrieval/src/lib.rs`

### ✅ `CTX-12` — Global / sensemaking (GraphRAG) community-summary layer (15)
- **subsystem:** context-fabric · **status:** FIXED
- **proof:** test `optimizer::tests::gap_ctx_12_community_detection_with_rbac_labelled_summaries` in `/Users/admin/Desktop/ai-copilot/runtime/crates/ainxt-context/src/optimizer.rs`
- **design:** STRUCTURED_FEDERATED §7: incremental Leiden/Louvain community detection over the unified KG producing RBAC-labeled community summary nodes, map-reduce synthesis at query time
- **original evidence:** no leiden/louvain/community/graphrag code in the three crates (grep empty); GraphLayer::GlobalSummary (optimizer.rs) is only a planner label set by a keyword rule (optimizer.rs:179)
- **▶ verify yourself:** `sed -n '177,183p' runtime/crates/optimizer.rs`

### ✅ `CTX-13` — Multimodal artifact tier (16)
- **subsystem:** context-fabric · **status:** FIXED
- **proof:** test `artifact::tests::gap_ctx_13_regulated_artifact_never_routes_to_cloud, gap_ctx_13_namespace_isolation_and_existence_never_leaks, gap_ctx_13_erasure_cascades_to_derived_embeddings` in `/Users/admin/Desktop/ai-copilot/runtime/crates/ainxt-context/src/artifact.rs`
- **design:** STRUCTURED_FEDERATED §8: modality-isolated vision/ASR embedding pipelines + own namespaces, data-class model routing (no cloud vision/ASR), existence-never-leaks RBAC, erasure cascade to derived embeddings
- **original evidence:** only a keyword intent rule exists (ainxt-context/src/optimizer.rs:206 cheque/kyc/scan -> MultimodalArtifact); no embedding pipeline, namespace, model-routing, or erasure-cascade for artifacts in any of the three crates
- **▶ verify yourself:** `sed -n '204,210p' runtime/crates/ainxt-context/src/optimizer.rs`

### ✅ `EDIT-05` — Extract / inline / move semantic operations
- **subsystem:** semantic-editing-codereview · **status:** FIXED
- **proof:** test `gap_ainxt_semantic_edit_05_extract_function_pulls_range_into_new_fn; gap_ainxt_semantic_edit_05_inline_trivial_function_into_call_sites; gap_ainxt_semantic_edit_05_move_definition_across_files` in `runtime/crates/ainxt-semantic/src/ops.rs`
- **design:** SEMANTIC_EDITING.md §4: 'Extract / inline / move → structural AST transforms with reference rewrites' listed as core operations.
- **original evidence:** ladder.rs SemanticOp enum (l.60) has only RenameSymbol/ChangeSignature/ReplaceFunction/AddFunction/AnchorPatch; ops.rs implements only plan_rename_symbol and plan_change_signature; grep for extract_function/inline_function/move_* semantic ops returns none.

### ✅ `EDIT-06` — Change-signature application (declaration + every call site + adapters/defaults)
- **subsystem:** semantic-editing-codereview · **status:** FIXED
- **proof:** test `gap_ainxt_semantic_edit_06_change_signature_applies_decl_and_call_sites; change_signature_apply_into_empty_param_list` in `runtime/crates/ainxt-semantic/src/ops.rs`
- **design:** SEMANTIC_EDITING.md §4: change signature updates the declaration + every call site + imports; inserts defaults/adapters where needed.
- **original evidence:** ops.rs plan_change_signature (l.146) only RESOLVES declarations + affected_call_sites into a SignatureChangePlan; it applies nothing and inserts no adapters (comment l.131-133 states this is intentional pending the LSP rung).

### ✅ `EDIT-07` — Deterministic Architecture Review (import-edge diff vs declared allowed-edges contract)
- **subsystem:** semantic-editing-codereview · **status:** FIXED
- **proof:** test `gap_ainxt_semantic_edit_07_forbidden_edge_is_a_deterministic_violation; gap_ainxt_semantic_edit_07_only_new_edges_are_attributed_to_the_edit; gap_ainxt_pipeline_edit_07_pipeline_computes_arch_violations_not_caller` in `runtime/crates/ainxt-semantic/src/arch.rs (+ runtime/crates/ainxt-pipeline/src/review.rs)`
- **design:** CODE_REVIEW_PIPELINE.md §4 stage 7 + §12: a new import edge the architecture graph doesn't allow is a deterministic graph-membership violation — no model needed.
- **original evidence:** gate.rs/confidence.rs consume only a caller-supplied scalar `architecture_violations: u32` (gate.rs l.41,89; confidence.rs l.27,88). No allowed-edges contract or boundary check is computed; graph.rs exposes imports_of() but nothing diffs edges against a layeri

### ✅ `EDIT-08` — Regression Detection via test-graph coverage + git-history change-coupling
- **subsystem:** semantic-editing-codereview · **status:** FIXED
- **proof:** test `gap_ainxt_semantic_edit_08_uncovered_blast_radius_is_computed_from_the_test_graph; gap_ainxt_semantic_edit_08_change_coupling_flags_the_missing_partner; gap_ainxt_pipeline_edit_08_pipeline_computes_coverage_not_caller` in `runtime/crates/ainxt-semantic/src/regression.rs (+ runtime/crates/ainxt-pipeline/src/review.rs)`
- **design:** CODE_REVIEW_PIPELINE.md §4 stage 8: uncovered-blast-radius fraction = blast radius minus test-graph coverage; change-coupling cross-check from git-history graph.
- **original evidence:** confidence.rs takes `blast_radius_test_coverage: f64` as a caller-supplied number (l.30,98); no test graph or git-history graph exists in these crates to compute it, and no change-coupling advisory is produced.

### ✅ `EDIT-09` — Per-language pipeline capability-degradation matrix (§10, incl. COBOL manual-review-required)
- **subsystem:** semantic-editing-codereview · **status:** FIXED
- **proof:** test `gap_ainxt_pipeline_edit_09_python_typecheck_is_an_honest_skip_not_a_pass; gap_ainxt_pipeline_edit_09_cobol_forces_manual_review` in `runtime/crates/ainxt-pipeline/src/capability.rs`
- **design:** CODE_REVIEW_PIPELINE.md §10: a per-language matrix (Compile/Test/Type/SAST/Perf) read by every stage; missing tool → Skipped(reason) not a pass; legacy langs → 'manual review required'.
- **original evidence:** The honest-skip mechanism exists (stage.rs StageVerdict::Skipped + confidence.rs skip penalty l.122), and ladder.rs has an edit-rung capability matrix, but the pipeline crate has no language→stages capability table; whether a stage is Skipped is decided entire

### ✅ `EDIT-10` — Add/replace method import-restore + method-preservation guards run on the semantic apply path
- **subsystem:** semantic-editing-codereview · **status:** FIXED
- **proof:** test `gap_ainxt_pipeline_edit_10_guards_restore_imports_and_flag_dropped_methods; guarded_apply_is_a_noop_when_nothing_dropped` in `runtime/crates/ainxt-pipeline/src/ladder_driver.rs`
- **design:** SEMANTIC_EDITING.md §4: on add/replace method the import manager adds missing imports and the method-preservation + import-restore guards run as part of the atomic apply.
- **original evidence:** ainxt-edit restore_missing_imports (lib.rs l.357) and field_rename guards exist and are tested, but ainxt-semantic replace_function/apply_atomic never invoke them; the guards are not tied into the atomic apply protocol, and ainxt-edit is not a runtime dependen

### ⏳ `EVAL-03` — Production 'where it runs' wiring (§11) — real LLM judge, encrypted runner-only sealed store, Event-Log sink, git-native control plane, merge-blocking CI, live canary controller
- **subsystem:** eval-tester-scenarios · **status:** DEFERRED-INFRA
- **deferred reason:** Production 'where it runs' wiring (EVAL_PLATFORM.md §11) needs live infra that cannot be stood up or proven offline: an encrypted, access-controlled runner-only sealed data-plane store (KMS/Postgres, ADR-022 machine identity), the tamper-evident Event-Log sink (ADR-025 admissible evidence), git-native control-plane manifests + CODEOWNERS branch-protection making the offline gate a REQUIRED merge-blocking CI check, and a live canary controller reading env/prod vs env/prod-canary. All I/O is already trait seams (SealedCorpusStore, EventSink, VaultStore, QualityJudge, GroundednessJudge) and the full composition (run_release_gate) is exercised against in-memory/deterministic fakes; only the real impls + deployment (Postgres/KMS/CI/git/canary box) remain. Not code-closable without that live infra — will not fake it.
- **design:** §11: control-plane git manifests + data-plane encrypted stores; eval runner is a dogfooded harness on the runtime; offline gate is a required merge-blocking CI check; online gate is the canary controller reading env/prod vs env/prod-canary.
- **original evidence:** All I/O is trait seams with only in-memory/deterministic impls: SealedCorpusStore (integrity.rs:138), EventSink (audit.rs:63), VaultStore (vault.rs:190), QualityJudge (lib.rs:70), GroundednessJudge (rag.rs:120), PointerController/Notifier (experiment.rs:90/98)
- **▶ verify yourself:** `sed -n '136,142p' runtime/crates/integrity.rs`

### ✅ `EVAL-04` — Judge panels / ensemble voting + disagreement escalation
- **subsystem:** eval-tester-scenarios · **status:** FIXED
- **proof:** test `gap_ainxt_eval_04_disagreement_escalates_to_a_human_not_a_majority_vote (also gap_ainxt_eval_04_panel_requires_real_model_diversity, gap_ainxt_eval_04_systematic_disagreement_feeds_the_gold_set, gap_ainxt_eval_04_panel_verdict_serializes)` in `runtime/crates/ainxt-eval/src/judge.rs`
- **design:** §4.4: for high-stakes dimensions scoring is an ensemble of N pinned, model-diverse Judges that vote; disagreement is a first-class signal routed to human adjudication and, if systematic, into the Gold Set.
- **original evidence:** ainxt-eval/src/judge.rs implements single-judge admission (admit_judge:386) + bias controls (position_bias_flip_rate, self_preference_conflict, judge_drift) but no panel/ensemble vote struct or disagreement-routing type anywhere in the crate.

### ✅ `FI-06` — DPDP DPIA-per-feature CI gate on promotion (§4.1)
- **subsystem:** regulated-fi-responsible-lifecycle · **status:** FIXED
- **proof:** test `gap_ainxt_responsibleai_fi06_data_class_change_invalidates_dpia_approval (plus gap_ainxt_responsibleai_fi06_personal_data_feature_without_dpia_is_blocked, ..._purpose_change_invalidates_and_wrong_feature_rejected, ..._non_personal_feature_needs_no_dpia)` in `runtime/crates/ainxt-responsibleai/src/dpia.rs`
- **design:** A personal-data feature cannot promote to env/prod without referencing an approved, current DPIA; a change to data_class_ceiling/capabilities/purpose invalidates the DPIA by content-hash and re-blocks promotion.
- **original evidence:** grep 'DPIA'/'dpia' = 0 files across all runtime crates. No DPIA artifact type, no promotion gate consuming one. (The responsible-AI deploy_gate exists at ainxt-responsibleai/src/lib.rs:551 but gates on card/bias/approver, not on a DPIA, and is itself unwired.)
- **▶ verify yourself:** `sed -n '549,555p' runtime/crates/ainxt-responsibleai/src/lib.rs`

### 🔧 `FI-07` — SR-11-7 model-risk record + due-diligence gate present but not wired to router/promotion (§4.2, gap P)
- **subsystem:** regulated-fi-responsible-lifecycle · **status:** WIRING-IN-PROGRESS
- **design:** Before an SDF-relevant feature promotes, an algorithmic due-diligence checklist backed by the live eval scoreboard must be satisfied; a route whose scoreboard drops below the bar trips the quality circuit-breaker (§2.1) and raises an operational-risk incident.
- **original evidence:** ModelRiskRecord + due_diligence_gate (validation/challenger/monitoring/staleness) fully implemented and tested in ainxt-responsibleai/src/lib.rs:675-834, but ainxt-responsibleai has zero reverse dependencies — no promotion path or router calls due_diligence_ga
- **▶ verify yourself:** `sed -n '673,679p' runtime/crates/ainxt-responsibleai/src/lib.rs`

### ✅ `FI-08` — Pre-templated breach-report drafting Role (§2.4)
- **subsystem:** regulated-fi-responsible-lifecycle · **status:** FIXED
- **proof:** test `gap_ainxt_incident_fi08_draft_fills_template_from_incident_facts (plus ..._unknown_placeholder_is_surfaced_not_silently_blanked, ..._missing_template_or_incident_returns_none)` in `runtime/crates/ainxt-incident/src/report.rs`
- **design:** A drafting Role fills the CERT-In/DPDP/RBI report template from the incident register's structured facts + Event-Log evidence slice, producing a draft within minutes of t0, so the human's 6-hour budget is spent on judgment not data-gathering.
- **original evidence:** ainxt-incident records a Filing{template_version, submitted_tick, ack_ref} after a human files (lib.rs:167-175, record_filing lib.rs:713), but there is no template store, no draft generation, and no drafting Role — only the post-hoc recording of a filing exist
- **▶ verify yourself:** `sed -n '165,171p' runtime/crates/lib.rs`

### 🔧 `FI-09` — DSAR cross-tier lineage: only the lifecycle-store tier is concrete (§4.4 step 2)
- **subsystem:** regulated-fi-responsible-lifecycle · **status:** WIRING-IN-PROGRESS
- **design:** An access/portability export resolves the subject's data across EVERY tier (Redis session, Postgres episodic, KG MemoryFact, derived embeddings, traces, incident/DSAR registers); lineage is what makes 'find everything about this person' complete rather than best-effort.
- **original evidence:** LineageResolver trait + MultiTierLineage fan-out implemented (ainxt-lifecycle/src/dsar.rs:115-150) but the only concrete production tier is RecordStore ('lifecycle-store', dsar.rs:153-166); no resolver implementations exist for Redis/KG/embeddings/traces (the 
- **▶ verify yourself:** `sed -n '113,119p' runtime/crates/ainxt-lifecycle/src/dsar.rs`

### 🔧 `GUARD-04` — Egress DLP — outbound destination allow-listing
- **subsystem:** guardrails-injection · **status:** WIRING-IN-PROGRESS
- **design:** Part2 T: outbound allow-listing + DLP on what agents send out; injection-in/exfiltration-out full attack chain
- **original evidence:** ainxt-injection/src/egress.rs:81-132 scan_egress + domain_allowed:371-377 implement destination allow-list, but grep shows scan_egress/EgressPolicy referenced ONLY in egress.rs + tests; runtime egress guard lib.rs:1181-1195 uses only compliance ca.redactions>0
- **▶ verify yourself:** `sed -n '79,85p' runtime/crates/ainxt-injection/src/egress.rs`

### 🔧 `GUARD-05` — Egress DLP — provider-secret taxonomy (private-key/JWT/AWS/api-key) on outbound
- **subsystem:** guardrails-injection · **status:** WIRING-IN-PROGRESS
- **design:** Part2 T + Part3 AL: secret-scanning of everything the agent emits
- **original evidence:** egress.rs:155-274 detects PEM/JWT/AKIA/sk-/ghp_/high-entropy but is never invoked by the runtime; runtime instead depends on ainxt-compliance (ainxt-compliance/src/lib.rs:115-135 covers marked/prefixed/bearer/high-entropy) so overlap exists but the egress-spec
- **▶ verify yourself:** `sed -n '153,159p' runtime/crates/egress.rs`

### 🔧 `GUARD-06` — System-prompt-leak rail (recon defense, gap AM)
- **subsystem:** guardrails-injection · **status:** WIRING-IN-PROGRESS
- **design:** Part3 AM: detect/deny system-prompt/instruction extraction attempts as a guardrail
- **original evidence:** ainxt-guardrails/src/lib.rs:463-491 SystemPromptLeakRail + system_prompt_leak_score:450-458 implemented; grep shows usage ONLY in guardrails tests — not constructed/run on any output path in ainxt-runtime or ainxt-convo
- **▶ verify yourself:** `sed -n '461,467p' runtime/crates/ainxt-guardrails/src/lib.rs`

### 🔧 `GUARD-07` — Guardrails run on OUTPUT (toxicity/topic/jailbreak), not just input
- **subsystem:** guardrails-injection · **status:** WIRING-IN-PROGRESS
- **design:** Part1 B: configurable rails framework on input AND output
- **original evidence:** ainxt-runtime/src/lib.rs:822 rails.evaluate(&cin.text, &[]) runs only on INPUT; output path applies compliance redaction + convo groundedness (ainxt-convo/src/lib.rs:507-520) but no toxicity/topic rail on the model's answer
- **▶ verify yourself:** `sed -n '820,826p' runtime/crates/ainxt-runtime/src/lib.rs`

### ⏳ `GUARD-08` — Rails use ML/NLI classifiers
- **subsystem:** guardrails-injection · **status:** DEFERRED-INFRA
- **deferred reason:** 'Rails use ML/NLI classifiers' cannot be truly closed offline — it requires a real moderation/jailbreak/toxicity/NLI model plus a GPU/ONNX inference runtime (OpenAI-Moderation / NeMo / fine-tuned classifier), which is not available in this build and is load-bearing on live infra + model-weight licensing. I implemented the full pluggable seam in-crate and proved it end-to-end with fake injected classifiers: new trait ainxt_guardrails::TextClassifier + JailbreakRail::with_classifier() / ToxicityRail::with_classifier() (effective score = max(heuristic, classifier), so the model can only make a rail STRICTER, never lower the deterministic floor — fail-safe), plus the pre-existing FaithfulnessJudge / GroundednessRail::with_judge() NLI seam. Offline tests prove the seam catches paraphrases the phrase table misses and that a soft model cannot rescue floor-blocked content: gap_guard_08_jailbreak_ml_classifier_catches_paraphrase_outside_table, gap_guard_08_classifier_is_a_floor_never_lowers_heuristic, gap_guard_08_groundedness_nli_judge_seam_drives_support in crates/ainxt-guardrails/tests/gap_guardrails_closure_test.rs. Wiring a concrete model behind these traits is the remaining infra/model step.
- **design:** Part1 B: OpenAI Moderation / NeMo / constitutional filters — pluggable ML rails; groundedness/faithfulness (AA)
- **original evidence:** Detection is substring/heuristic: guardrails PATTERNS lib.rs:157-186 (jailbreak), :341-352 (toxicity); injection PHRASES detect.rs:151-209. ML seams exist but unfilled: FaithfulnessJudge (guardrails lib.rs:216-219, judge:None default) and InjectionScanner trai
- **▶ verify yourself:** `sed -n '155,161p' runtime/crates/lib.rs`

### 🔧 `GUARD-09` — Groundedness / citation-faithfulness rail
- **subsystem:** guardrails-injection · **status:** WIRING-IN-PROGRESS
- **design:** Part1 B + Part2 AA: is the answer supported by retrieved sources; verify citation actually supports the claim
- **original evidence:** ainxt-guardrails/src/lib.rs:236-304 GroundednessRail (lexical overlap min_overlap 0.3 + fabricated-numeric detection) wired on output via ainxt-convo/src/lib.rs:507-520; but it is word-overlap not entailment (judge None), returns Pass on empty context (lib.rs:
- **▶ verify yourself:** `sed -n '234,240p' runtime/crates/ainxt-guardrails/src/lib.rs`

### ✅ `HARN-03` — Autonomy (none/assisted/autonomous) + HITL approve/reject on writes
- **subsystem:** harness-sdk-governance · **status:** FIXED
- **proof:** test `gap_ainxt_harness_autonomy_hitl_enforced_on_writes (also: gap_ainxt_harness_side_effect_classifier_reads_vs_writes, gap_ainxt_harness_autonomy_read_step_never_needs_approval, and client-side gap_ainxt_client_autonomy_assisted_write_requires_approval)` in `/Users/admin/Desktop/ai-copilot/runtime/crates/ainxt-harness/src/lib.rs`
- **design:** §1/§2.2/§4: autonomy = none|assisted (HITL on any write/side-effect)|autonomous (judge-audited); SDK exposes approval.request with ev.approve()/ev.reject().
- **original evidence:** Autonomy is declared but explicitly non-enforcing: 'Informational to admission' (ainxt-harness/src/lib.rs:116-117); gate_step never consults autonomy. The client only captures approvals read-side — 'The approve/reject back-channel to the engine is a protocol/s
- **▶ verify yourself:** `sed -n '114,120p' runtime/crates/ainxt-harness/src/lib.rs`

### ⏳ `HARN-04` — SDK contract: Python SDK (first), TypeScript SDK, network REST/gRPC/SSE transport
- **subsystem:** harness-sdk-governance · **status:** DEFERRED-INFRA
- **deferred reason:** Python SDK (first) and TypeScript SDK are separate-language repositories with their own build/CI — not producible inside these four Rust crates. A real network REST/gRPC/SSE transport requires an HTTP client dependency (reqwest/hyper) plus a live ainxt-server to exercise end-to-end; only InProcessTransport is offline-testable. The Rust client remains the reference wire contract every SDK mirrors, and the approve/reject SDK back-channel (part of the contract surface) is now present via the ApprovalResolver seam; the remaining transport + cross-language SDKs need live infra/separate repos.
- **design:** §2.2: 'Python ships first (NPCI's ecosystem), TypeScript second'; the SDK is a thin client over the runtime protocol (REST/gRPC/SSE); the headless CLI is a wrapper over this SDK.
- **original evidence:** Only a Rust in-process SDK exists; comment states 'A network HTTP/SSE transport (feature `http`, not yet implemented)... The planned Python SDK (first) and TypeScript SDK do not exist yet' (ainxt-client/src/lib.rs:11-16). Transport trait has only InProcessTran
- **▶ verify yourself:** `sed -n '9,15p' runtime/crates/ainxt-client/src/lib.rs`

### 🔧 `HARN-05` — Publish actually opens a PR against the control repo; pre-receive gate + signature use real detectors/crypto
- **subsystem:** harness-sdk-governance · **status:** WIRING-IN-PROGRESS
- **design:** §3: `ainxt harness publish` opens a PR against the control repo; CI runs manifest-lint + Policy Engine dry-checks; ADR-026 §10 pre-receive gate; signed merge/tag by trusted keys.
- **original evidence:** publish() only builds a PullRequest descriptor (ainxt-governance/src/lib.rs:311-322) and the CLI prints it (ainxt-cli/src/lib.rs:413-448) — no GitLab API call/push. Pre-receive detector is a 12-digit-run/marker heuristic, not the PCI/DSS engine (MarkerPrerecei
- **▶ verify yourself:** `sed -n '309,315p' runtime/crates/ainxt-governance/src/lib.rs`

### ✅ `IDN-04` — Payment-Adjacent Mandate (PAM) model absent
- **subsystem:** Agent Identity & Payment Boundary · **status:** FIXED
- **proof:** test `gap_idn_04_pam_is_human_issued_only (+ _pam_cannot_spell_value_movement, _pam_is_single_use_and_scoped_and_bound, _pam_expires, _small_n_uses_allowed)` in `runtime/crates/ainxt-payments/src/mandate.rs`
- **design:** §6: adjacent writes (e.g. sandbox settlement simulation, draft dispute) require a human-signed, scoped, expiring, single-use PAM structurally incapable of expressing value, verified at dispatch as a FOURTH gate alongside the 3 OBO layers
- **original evidence:** no PAM/Mandate type in ainxt-payments or ainxt-identity (the only 'mandate' token is PayloadSignal::NachMandateExecution in boundary.rs:219, an unrelated payload signature)
- **▶ verify yourself:** `sed -n '217,223p' runtime/crates/boundary.rs`

### ✅ `IDN-05` — Transparency-log / external inclusion-proof for attestation (§13) not implemented
- **subsystem:** Agent Identity & Payment Boundary · **status:** FIXED
- **proof:** test `gap_idn_05_inclusion_proof_verifies_for_every_entry (+ _tampered_entry_fails_verification, _wrong_root_and_swapped_sibling_fail, _out_of_range_index_and_empty_log, _logs_awc_issuance_and_proves_it)` in `runtime/crates/ainxt-identity/src/transparency.rs`
- **design:** §13 + §22 scenario 3: issuance recorded to an append-only transparency log; an external auditor independently verifies code measurement + issuance via an inclusion proof without trusting the runtime — court-grade (ADR-025)
- **original evidence:** 'transparency log' appears only in doc comments (ainxt-identity/src/authority.rs:36, lib.rs:68); no TransparencyLog/InclusionProof type; external verifiability is limited to the ReferenceValueVerifier allow-list (authority.rs:189)
- **▶ verify yourself:** `sed -n '34,40p' runtime/crates/ainxt-identity/src/authority.rs`

### 🔧 `IDN-07` — Layer-4 git-native payment_boundary front-matter diverged from ADR-026 model
- **subsystem:** Agent Identity & Payment Boundary · **status:** WIRING-IN-PROGRESS
- **design:** §7 / ADR-026 §5: front-matter values are none|payment-adjacent; 'payment-initiating' is a RESERVED value CI+pre-receive REJECT; a payment-adjacent def requires payments-council CODEOWNERS + ad_level<=3 signed commit
- **original evidence:** the only payment_boundary is the harness manifest enum None|ReadOnly|Write (ainxt-harness/src/lib.rs:133,317,839) enforced at the step gate; no payments-council CODEOWNERS, no CI rejection of a payment-initiating value, no ad_level<=3 authoring catch in ainxt-
- **▶ verify yourself:** `sed -n '131,137p' runtime/crates/ainxt-harness/src/lib.rs`

### ✅ `LOOP-08` — MTG SCC/Tarjan handling, compatibility shims, decoupling-refactor prerequisites
- **subsystem:** loop-teams-longhorizon · **status:** FIXED
- **proof:** test `scc::tests::gap_loop_08_mutual_import_cluster_is_surfaced_as_an_scc_not_linearized (also ..._oversized_scc_becomes_a_human_checkpointed_decoupling_prerequisite, ..._reverse_order_edge_gets_a_shim_and_cleanup_node)` in `/Users/admin/Desktop/ai-copilot/runtime/crates/ainxt-planner/src/scc.rs`
- **design:** ADR-027 §3.3/§3.4: strongly-connected components become migration super-nodes or a human-checkpointed decoupling prerequisite; strangler-fig reverse-order inserts shim + shim-cleanup nodes; cycles are surfaced, never linearized.
- **original evidence:** program.rs validate_decomposition (:809)/detect_cycle (:837) only REJECT cyclic decompositions; there is no SCC super-node construction, no shim/shim-cleanup insertion, and no decoupling-refactor prerequisite generation. mtg.rs auto_split (:199) performs only 

### ✅ `LOOP-09` — Full ADR-027 §3 node contract fields on Program nodes
- **subsystem:** loop-teams-longhorizon · **status:** FIXED
- **proof:** test `program::tests::gap_loop_09_node_contract_fields_are_projected_and_round_trip` in `/Users/admin/Desktop/ai-copilot/runtime/crates/ainxt-planner/src/program.rs`
- **design:** ADR-027 §3: each MTG node carries module_ref, working_set_estimate, blast_radius, verification_plan, checkpoint_class, edit_ladder_floor, node_class, state.
- **original evidence:** ProgramNode (program.rs:170) carries only id/node_class/checkpoint_class/deps/state/commit_shas/failure_count/child_program_id — working_set_estimate, blast_radius, verification_plan, and edit_ladder_floor are absent. Working-set/blast-radius live only on the 
- **▶ verify yourself:** `sed -n '168,174p' runtime/crates/program.rs`

### ✅ `LOOP-10` — Plan anti-thrash: change-justification on mutations, freeze-on-thrash cooldown, append-only revision history
- **subsystem:** loop-teams-longhorizon · **status:** FIXED
- **proof:** test `revision::tests::gap_loop_10_excessive_churn_freezes_the_plan_until_a_checkpoint (also ..._mutation_without_a_signal_is_rejected, ..._revisions_are_append_only_with_their_signal)` in `/Users/admin/Desktop/ai-copilot/runtime/crates/ainxt-planner/src/revision.rs`
- **design:** LOOP §9: every plan mutation must carry a triggering signal (rejected at the API boundary if absent); a >40%-over-3-revisions churn freezes plan mutation for a cooldown then forces one consolidated re-plan; every plan version is an append-only Event-Log revision.
- **original evidence:** planner replan_failed (lib.rs:708) requires no triggering signal on the Alternative and escalates only at the per-step replan cap (ReplanOutcome::Escalated); there is no churn-percentage freeze/cooldown and Plan holds only an in-memory Vec<Step> with no append
- **▶ verify yourself:** `sed -n '706,712p' runtime/crates/lib.rs`

### ✅ `LOOP-11` — Hierarchical roles are inert identifiers; no Architect/Planner/Coder/Reviewer/Tester behavior
- **subsystem:** loop-teams-longhorizon · **status:** FIXED
- **proof:** test `tiers::tests::gap_ainxt_teams_loop_11_role_routing_and_self_heal_tier_escalation` in `/Users/admin/Desktop/ai-copilot/runtime/crates/ainxt-teams/src/tiers.rs`
- **design:** LOOP §4: composed roles (Architect/Planner/Coder/Reviewer/Tester) with real jobs, role→model-tier routing, and the Architect invoked fresh as the tier-3 judge.
- **original evidence:** teams Role (lib.rs:269) is only id + capabilities + model_tier; run_team (lib.rs:837) executes an injected `step` closure with no live role implementation, no model routing, and no Architect-as-judge freshness. No caller supplies a real step seam.
- **▶ verify yourself:** `sed -n '267,273p' runtime/crates/lib.rs`

### 🔧 `LOOP-12` — Sub-agent cost roll-up + budget enforcement applied to real runs
- **subsystem:** loop-teams-longhorizon · **status:** WIRING-IN-PROGRESS
- **design:** LOOP §4: every agent.invoke returns cost_used, rolled up into the Run total; budget middleware checks the Run aggregate, closing the per-agent-budget-bypass loophole.
- **original evidence:** teams run_team_budgeted (lib.rs:855) + AgentInvocation::rolled_up_cost (lib.rs:207) implement and test this — but only in the unreachable crate. The reachable Engine bills per-turn telemetry only (ainxt-runtime/src/lib.rs sum_usage:647) with no team/sub-agent 
- **▶ verify yourself:** `sed -n '853,859p' runtime/crates/lib.rs`

### ✅ `MEM-06` — Session (Redis) memory tier absent
- **subsystem:** Enterprise Memory & Continuous Learning · **status:** FIXED
- **proof:** test `gap_ainxt_memory_mem_06_session_tier_ages_out_by_last_activity` in `runtime/crates/ainxt-memory/src/store.rs`
- **design:** §3 Session (Redis): working memory for the live turn, TTL = conversation length, write every turn.
- **original evidence:** lib.rs:62-75 MemoryKind has Episodic/Semantic/Procedural/UserPreference/OrgKnowledge — no Session variant; no Redis, no per-conversation TTL anywhere in the crate.
- **▶ verify yourself:** `sed -n '60,66p' runtime/crates/lib.rs`

### ✅ `MEM-07` — Retention policy covers only episodic TTL; feedback-retention and offboarding auto-erasure missing
- **subsystem:** Enterprise Memory & Continuous Learning · **status:** FIXED
- **proof:** test `gap_ainxt_memory_mem_07_offboarding_auto_erasure_cascades_and_is_audited + gap_ainxt_memory_mem_07_raw_feedback_ages_out_but_derivatives_survive` in `runtime/crates/ainxt-memory/src/store.rs + runtime/crates/ainxt-memory/src/flywheel.rs`
- **design:** §5 retention table: Feedback events (raw) 180 days; Semantic MemoryFact(user) purged on 'account offboarding = automatic erasure job, not a manual step'.
- **original evidence:** store.rs:57-61 RetentionPolicy has only episodic_ttl; purge_expired (store.rs:310) purges only Episodic. flywheel.rs ImprovementEngine (fixes/seen/bad_trajectories) has no TTL — raw feedback is retained unbounded. No offboarding job triggers erase_subject.
- **▶ verify yourself:** `sed -n '55,61p' runtime/crates/store.rs`

### ⬜ `OS-03` — §6 Citizen-authored artifact lifecycle: decay signal, re-certification nudge, continuous orphan-owner sweep, ownership succession, forced-review-before-deprecation
- **subsystem:** AiNxt OS / Skill→Agent→Role→Team Workforce Ladder + Role Studio · **status:** OPEN
- **design:** WORKFORCE §6.1-6.5: nightly decay-sweep writing decay_flag rows; recert_after nudges; standing orphan_definitions sweep cross-referencing CODEOWNERS + AD org-tree is_active; owner-succession-as-a-reviewable-diff; deprecation floor requiring Breaker dry-run + manager sign-off for 
- **original evidence:** Zero implementation: grep decay_flag|decay-sweep|recert|orphan_def|succession|'deprecation-approval' = 0 non-comment hits. ainxt-governance only implements the PR-time state machine (advance_with_evidence:235) + one PR-time CODEOWNERS approver check; ainxt-lif
- **▶ verify yourself:** `sed -n '1,5p' runtime/crates/crates/ainxt-lifecycle/src/lib.rs`

### ⬜ `OS-04` — §7 Automation-complacency / oversight-health controls: approve-latency & override-rate metrics, attention-check decoys, competency status/expiry gating
- **subsystem:** AiNxt OS / Skill→Agent→Role→Team Workforce Ladder + Role Studio · **status:** OPEN
- **design:** WORKFORCE §7.1-7.3: nightly derivation of per-approver approve-latency + override-rate into an oversight_health table; unpredictable Breaker-generated known-bad decoys injected into high-stakes (payment_boundary!=none) approval queues; competency_status:expired flag re-routing ap
- **original evidence:** grep competency|decoy|attention.check|approve.latency|override.rate|oversight_health = 0 non-comment hits. The 12 'oversight' hits are all responsibleai system-card free-text (crates/ainxt-responsibleai/src/lib.rs:217 human_oversight: String), not a complacenc
- **▶ verify yourself:** `sed -n '215,221p' runtime/crates/crates/ainxt-responsibleai/src/lib.rs`

### ⬜ `OS-05` — Per-task autonomy dial ('the innovation' — autonomy per task, not per role)
- **subsystem:** AiNxt OS / Skill→Agent→Role→Team Workforce Ladder + Role Studio · **status:** OPEN
- **design:** AINXT_OS §4 Step 4: autonomy is per-task, not per-role — e.g. password reset auto, access request assisted/HITL, unrecognized → escalate; escalation thresholds wired to uncertainty/abstention.
- **original evidence:** Autonomy is a single manifest/surface-level enum, not per-task: ainxt-harness/src/lib.rs:300 `pub autonomy: Autonomy` (one value per whole harness) and HarnessStep (lib.rs:64-76) has no autonomy field; ainxt-profile Autonomy is one value per surface. No per-ta
- **▶ verify yourself:** `sed -n '298,304p' runtime/crates/ainxt-harness/src/lib.rs`

### ⬜ `OS-06` — Breaker as a mandatory, unskippable Role/definition publish gate
- **subsystem:** AiNxt OS / Skill→Agent→Role→Team Workforce Ladder + Role Studio · **status:** OPEN
- **design:** AINXT_OS §4 Step 7 + §5: 'nothing ships until it passes BOTH the quality-eval suite AND the Breaker'; the role cannot be published until the adversarial Test Agent passes.
- **original evidence:** The Breaker component is real (crates/ainxt-scenario/src/breaker.rs:189 Breaker::explore/verify/minimize) and the planner uses it as an adversarial verify gate (ainxt-planner/src/verify.rs:86), BUT the governance publish path does NOT invoke it — grep breaker|
- **▶ verify yourself:** `sed -n '187,193p' runtime/crates/crates/ainxt-scenario/src/breaker.rs`

### ✅ `PRMT-05` — Git-native control-plane loader (prompts-as-code as files + startup load + hot-reload)
- **subsystem:** Prompt engineering · **status:** FIXED
- **proof:** test `gap_ainxt_prompt_prmt_05_loads_prompts_from_files_into_the_registry (+ _hot_reload_picks_up_a_changed_variant_body, _tampered_body_fails_closed_against_the_lock, _missing_lock_is_a_hard_error, _malformed_manifest_fails_closed, _declared_but_missing_variant_file_is_rejected)` in `crates/ainxt-prompt/src/control.rs`
- **design:** Section 3: the Registry lives as versioned files in ainxt-control/prompts, loaded into the Definition Registry at startup and hot-reloaded on change; lifecycle re-hosted on git primitives (branch protection, signed tags, CODEOWNERS, control.lock content-address)
- **original evidence:** Manifest::into_artifact (registry.rs:339) accepts variant bodies as an in-memory BTreeMap supplied by the caller; there is no file/git reader, no control.lock, and content_fingerprint (registry.rs:42) is FNV-1a which the code itself (lines 36-41) says is 'deli
- **▶ verify yourself:** `sed -n '337,343p' runtime/crates/registry.rs`

### 🔧 `PRMT-06` — Before-call Event-Log record of the exact layer tuple is not produced in the live path
- **subsystem:** Prompt engineering · **status:** WIRING-IN-PROGRESS
- **design:** Section 7 / PE1 / PE11: the exact compiled prompt + (L1@v..L4@v) versions + control-plane SHA are written to the Event Log BEFORE the provider call for byte-for-byte forensic replay
- **original evidence:** CompiledSystemPrompt::event_record / PromptEventRecord (layered.rs:57, :70) implement this, but only the unwired LayeredAssembler produces them; the wired flat PromptEngine (lib.rs AssembledPrompt, line 151) carries only text+depth, with no layer-version tuple
- **▶ verify yourself:** `sed -n '55,61p' runtime/crates/layered.rs`

### ✅ `PRMT-08` — Continuous quality-drift detection in production
- **subsystem:** Prompt engineering · **status:** FIXED
- **proof:** test `gap_ainxt_prompt_prmt_08_significant_degradation_is_detected_and_recommends_rollback (+ _single_bad_turn_is_noise_not_drift, _below_min_samples_never_alerts, _trivial_shift_within_effect_size_is_ignored, _alerts_once_not_every_turn)` in `crates/ainxt-prompt/src/drift.rs`
- **design:** Section 8: continuously sample live turns, score via LLM-judge, track score distribution per (Role,model_family,version), alert on statistically significant degradation, auto-open a ticket / auto-rollback
- **original evidence:** No drift-monitor code in either audited crate; ainxt-prompt provides only the point-in-time canary gate (CanaryResult, registry.rs:424) and rollback-by-pointer (Deployment::rollback_canary, :756) — the continuous sampling/distribution/alert mechanism is absent
- **▶ verify yourself:** `sed -n '422,428p' runtime/crates/registry.rs`

### ✅ `SRV-02` — §8 attestation gate enforced on regulated traffic (ADR-021 routing precondition)
- **subsystem:** Serving-Ops · **status:** FIXED
- **proof:** test `gap_ainxt_serving_srv_02_regulated_request_fails_closed_on_unattested_node` in `runtime/crates/ainxt-serving/src/gate.rs`
- **design:** A regulated-class request must clear BOTH the Router's model-identity filter AND Serving-Ops's node-level filter to only cc-enclave/bare-metal-attested nodes with a valid quote; fails closed if no attested capacity; the precondition 'makes the Router's promise physically true rat
- **original evidence:** AttestationGate::evaluate is fully implemented and tested (attestation.rs:333-382) but has no caller — nothing invokes it before serving a turn. The gate is inert dead code; no request is actually fenced off an unattested node. (No live self-hosted GPU path ex
- **▶ verify yourself:** `sed -n '331,337p' runtime/crates/attestation.rs`

### ✅ `SRV-03` — §1 Disaggregated prefill/decode pools + KV Relay fabric (gap 7)
- **subsystem:** Serving-Ops · **status:** FIXED
- **proof:** test `gap_ainxt_serving_srv_03_link_drop_refunds_credits_and_retry_is_safe_no_double_bill` in `runtime/crates/ainxt-serving/src/kv_relay.rs`
- **design:** Separate independently-scaled Prefill and Decode GPU pools joined by a credit-based, GPU-to-GPU KV Relay with host-buffer fallback and idempotency-ledger-backed retry on relay failure; structurally eliminates prefill/decode interference.
- **original evidence:** lib.rs:64-67 explicitly lists 'the disaggregated prefill/decode pools and the KV relay (§1)' as seams owned elsewhere. Only a bare Phase{Prefill,Decode} enum exists (preemption.rs:35-38); no pool separation, no relay, no credit flow, no idempotency key. grep f
- **▶ verify yourself:** `sed -n '62,68p' runtime/crates/lib.rs`

### ✅ `SRV-04` — §3 Bin-packing placement + eviction/model-parking + autoscale (gap 26, gap W)
- **subsystem:** Serving-Ops · **status:** FIXED
- **proof:** test `gap_ainxt_serving_srv_04_regulated_model_never_lands_on_untrusted_bin_fails_closed` in `runtime/crates/ainxt-serving/src/placement.rs`
- **design:** A Placement Controller doing locality- and attestation-aware best-fit-decreasing bin-packing with an N+1 standby reservation, a rate-limited reconciler, eviction/model-parking (cold/warm tiers, minutes-scale re-warm), and per-model demand-EWMA autoscaling.
- **original evidence:** lib.rs:65 lists 'bin-packing placement (§3)' as a seam. grep for placement/binpack/best-fit/parking/re-warm/autoscale/EWMA across crates finds only unrelated hits (prompt-opt, compliance). health.rs add_standby/promote_standby is health-recovery, not placement
- **▶ verify yourself:** `sed -n '63,69p' runtime/crates/lib.rs`

### ✅ `SRV-05` — §5 Signed, staged, integrity-verified weight rollout + rollback SLA (gap 38)
- **subsystem:** Serving-Ops · **status:** FIXED
- **proof:** test `gap_ainxt_serving_srv_05_signature_and_hash_reverified_at_every_load` in `runtime/crates/ainxt-serving/src/rollout.rs`
- **design:** Every weight artifact signed and re-verified AT EVERY LOAD (supply-chain control), regulated-tier decryption key bound to a valid attestation quote, staged promotion P2-shadow→P2-canary→P1-canary→P0, true blue-green vs staged group-by-group, and a numeric rollback SLA with auto-r
- **original evidence:** lib.rs:66 lists 'weight rollout (§5)' as a seam. The only trace is comments on health.rs:55 and :200 ('e.g. for a staged weight rollout'). No rollout controller, no weight-artifact signature verification, no blue-green, no staged promotion, no rollback logic a
- **▶ verify yourself:** `sed -n '64,70p' runtime/crates/lib.rs`

### 🔧 `SRV-06` — §6 cache-isolation partition machinery not used by the live cache
- **subsystem:** Serving-Ops · **status:** WIRING-IN-PROGRESS
- **design:** All three cache tiers (coarse answer, prompt-prefix, KV) partitioned identically by {data_class, principal_scope, harness_id}, with per-user isolation for confidential+ and per-department for internal/public.
- **original evidence:** The isolation logic exists (cache_isolation.rs, ainxt-cache PartitionedCache) but the only wired surface, ainxt-chat, bypasses it: cache_key = clearance.sensitivity()|dc.sensitivity()|normalized_input (chat/src/lib.rs:107-114) — no principal_scope, no harness_
- **▶ verify yourself:** `sed -n '105,111p' runtime/crates/chat/src/lib.rs`

### 🔧 `SURF-03` — Chat response cache (scoping-safe semantic/prompt cache)
- **subsystem:** surfaces-profiles-skills-config · **status:** WIRING-IN-PROGRESS
- **design:** Chat surface caches answers; cache must be scoping-safe (keyed by clearance/data-class; sensitive classes never cached).
- **original evidence:** A correct scoping-safe cache exists in ainxt-chat/src/lib.rs:61-114 (ResponseCache, cache_key encodes clearance+data_class, cacheable_max=Internal) — but ChatSurface is orphaned. The daemon-served chat (ainxt-runtimed/src/lib.rs:372-402) wraps ConversationMana
- **▶ verify yourself:** `sed -n '59,65p' runtime/crates/ainxt-chat/src/lib.rs`

### 🔧 `SURF-04` — Skill Runtime wired into the runtime (behavioral + execution injection)
- **subsystem:** surfaces-profiles-skills-config · **status:** WIRING-IN-PROGRESS
- **design:** Skill Runtime injects behavioral SOPs into the system prompt and runs execution skills before the model, output into ## Context; profiles list skill refs the runtime resolves per turn.
- **original evidence:** ainxt-skill is complete and real: NativeSkillExecutor.execute (src/lib.rs:261-301) does real dispatch with panic isolation + output ceiling; SkillRuntime::prepare/system_prompt (src/lib.rs:422-468) enforce persona→behavioral→guard order. But the daemon never c
- **▶ verify yourself:** `sed -n '259,265p' runtime/crates/src/lib.rs`

### ✅ `SURF-05` — Execution-skill sandboxing (Tool/Skill Runtime isolation)
- **subsystem:** surfaces-profiles-skills-config · **status:** FIXED
- **proof:** test `gap_ainxt_skill_surf_05_wasm_executor_runs_sandboxed_skill_into_context / gap_ainxt_skill_surf_05_wasm_executor_traps_infinite_loop_via_fuel / gap_ainxt_skill_surf_05_wasm_executor_denies_ungranted_imports / gap_ainxt_skill_surf_05_wasm_executor_fails_closed_on_unregistered / gap_ainxt_skill_surf_05_wasm_executor_rejects_unparseable_arg` in `runtime/crates/ainxt-skill/src/lib.rs`
- **design:** Tool/Skill Runtime provides sandboxing for execution — isolated code execution (Docker/WASM), network-disabled, resource-capped.
- **original evidence:** ainxt-skill only ships an in-process NativeSkillExecutor (src/lib.rs:210) running compiled-in Rust handlers; sandboxed arbitrary user code is explicitly deferred: src/lib.rs:170-173 states 'sandboxed arbitrary user code (Docker/WASM) ... is out of scope for an
- **▶ verify yourself:** `sed -n '208,214p' runtime/crates/src/lib.rs`

### 🔧 `SURF-06` — Profile model policy (forced_provider / allowed_providers / max_data_class) enforced by router
- **subsystem:** surfaces-profiles-skills-config · **status:** WIRING-IN-PROGRESS
- **design:** Enterprise model policy is a hard constraint routed via the Model Router; a surface's allowed/forced provider and data-class ceiling constrain routing (still subject to the non-overridable data-class gate).
- **original evidence:** The non-overridable data-class exclusion gate IS enforced in the engine router (ainxt-runtime/src/lib.rs:270 select, :301 select_chain, :900 passes forced_provider+data_class) — this holds regardless of profiles. But ModelPolicy.allowed_providers (ainxt-profil
- **▶ verify yourself:** `sed -n '268,274p' runtime/crates/ainxt-runtime/src/lib.rs`

### ⏳ `SURF-12` — Semantic/prompt cache on the live turn path
- **subsystem:** data-surfaces-artifacts · **status:** DEFERRED-INFRA
- **deferred reason:** Semantic/prompt cache on the live turn path lives in ainxt-cache (get_semantic/PartitionedCache/erase_scope) and its consumer ainxt-chat — neither is in the four crates I am permitted to edit (ainxt-nl2sql, ainxt-graph, ainxt-artifact, ainxt-replay). Closing it requires enabling the semantic tier + partition isolation in ainxt-chat's cache calls and giving ainxt-chat a runtimed/server dependent, which is out of scope for this subsystem assignment and owned by another agent. No fake was added; the capability already exists in ainxt-cache and only needs wiring in those out-of-scope crates.
- **design:** gap I: exact + normalized + SEMANTIC (embedding-similarity) cache with partition isolation across trust/authz boundaries, in the runtime response path.
- **original evidence:** ainxt-cache used only by ainxt-chat/src/lib.rs:32,130,152 and ONLY the exact tier (get_exact + put(...,None,now) — embedding always None). grep get_semantic/PartitionedCache/erase_scope finds NONE outside crates/ainxt-cache/ (semantic + partition isolation are
- **▶ verify yourself:** `sed -n '30,36p' runtime/crates/ainxt-chat/src/lib.rs`

### 🔧 `SURF-13` — Artifact IR document-generation runtime in a live surface
- **subsystem:** data-surfaces-artifacts · **status:** WIRING-IN-PROGRESS
- **design:** Phase-3 Artifact Runtime: structured IR → renderers, audit-and-proceed compliance, used by Chat/Buddy/SDLC output paths.
- **original evidence:** ainxt_artifact is referenced only in crates/ainxt-surface/tests/dod_p3_matrix.rs — grep finds no usage in crates/ainxt-surface/src or any other src. ainxt-surface has no Cargo.toml dependents. Library (audit_document + Markdown/PlainText renderers, 8 tests) is

### ✅ `TURN-06` — Versioning: additive-safe, must-ignore, N-2 major window, negotiation
- **subsystem:** turn-pipeline · **status:** FIXED
- **proof:** test `gap_turn_06_n2_window_and_negotiation + gap_turn_06_unknown_event_type_is_must_ignored_not_fatal` in `runtime/crates/ainxt-protocol/src/lib.rs`
- **design:** PROTOCOL.md §10 — MINOR is additive-only and safe for old clients via must-ignore (I6/§10.3); unknown event types/fields MUST be ignored; enums are #[non_exhaustive] open discriminators (§10.5); runtime supports current major + 2 prior with handshake negotiation
- **original evidence:** ainxt-protocol/src/lib.rs:20-22 is_compatible = exact `client == server`; the doc-comment (:14-19) explicitly states adding an Event *variant* is BREAKING and bumps VERSION — the opposite of must-ignore. Event (:60) is a plain externally-tagged serde enum, NOT
- **▶ verify yourself:** `sed -n '18,24p' runtime/crates/ainxt-protocol/src/lib.rs`

### ✅ `TURN-07` — Typed Event vocabulary (turn lifecycle, artifact, reasoning, granular tool-call, snapshot, presence)
- **subsystem:** turn-pipeline · **status:** FIXED
- **proof:** test `gap_turn_07_event_vocabulary_round_trips` in `runtime/crates/ainxt-protocol/src/lib.rs`
- **design:** PROTOCOL.md §6 — reasoning.delta (policy-gated), tool.call.delta + tool.call.stop, artifact (with verification), turn.started/rationale/completed{outcome}/stopped/failed, session.snapshot, participant.*, typed error taxonomy (§6.5.1)
- **original evidence:** ainxt-protocol/src/lib.rs:61-82 the entire wire vocabulary is 7 variants: TextDelta, ToolCallStart, ToolResult, ApprovalRequest, Usage, Error, Done. Turn boundaries collapse to Done/Error (no typed outcome incl. the 'capped' honest-completion, §3.2); no artifa
- **▶ verify yourself:** `sed -n '59,65p' runtime/crates/ainxt-protocol/src/lib.rs`


## ⚪ LOW

### ✅ `CONN-07` — Encryption primitive: FERNET/MultiFernet vs XChaCha20-Poly1305
- **subsystem:** Connectors · **status:** FIXED
- **proof:** test `gap_ainxt_token_conn_07_crypto_agility_invariant_holds` in `runtime/crates/ainxt-token/src/lib.rs`
- **design:** Tokens encrypted (FERNET, versioned keys for rotation); MultiFernet decrypt-with-any/encrypt-with-newest.
- **original evidence:** ainxt-token/src/lib.rs uses XChaCha20-Poly1305 (l.34-35, AeadCodec l.184-229) over a versioned KeyRing (l.109-162) instead of Fernet. The invariant (authenticated encryption + versioned decrypt-with-any/encrypt-with-newest + zeroize) is met and arguably strong

### ✅ `CONN-08` — Tamper-evident / WORM audit sink for connector events
- **subsystem:** Connectors · **status:** FIXED
- **proof:** test `gap_ainxt_connector_conn_08_hash_chain_detects_tamper` in `runtime/crates/ainxt-connector/src/lib.rs`
- **design:** Every admission/egress outcome recorded; production audit is the tamper-evident/WORM sink (gap AK).
- **original evidence:** ainxt-connector/src/lib.rs defines the ConnectorAudit seam (l.507) and only an InMemoryConnectorAudit impl (l.513-537); the WORM sink is referenced solely in a doc comment (l.506). Every outcome is audited in-memory (authorize_use l.607-625, guard_egress l.644

### ✅ `CONV-09` — Stage-1 explicit UI affordance / slash commands (§2 Stage-1)
- **subsystem:** Conversation Intelligence · **status:** FIXED
- **proof:** test `gap_ainxt_convo_conv_09_slash_commands_and_affordance_are_stage1` in `runtime/crates/ainxt-convo/tests/intent_cascade_test.rs`
- **design:** Stage-1 deterministic signals include an explicit 'Generate document' action, mode toggle, and slash commands (/pdf, /doc, /ppt, /xlsx) — if present, intent is known, skip classification.
- **original evidence:** HeuristicClassifier only does lexical gen_verb+format matching (ainxt-convo/src/lib.rs:186-210); there is no handling of slash commands or a UI-affordance/mode signal anywhere in the classify or handle paths.
- **▶ verify yourself:** `sed -n '184,190p' runtime/crates/ainxt-convo/src/lib.rs`

### ✅ `CONV-10` — ainxt-answer composition/formatting (BK/BM/BN) integrated into a surface
- **subsystem:** Conversation Intelligence · **status:** FIXED
- **proof:** test `gap_ainxt_convo_conv_10_answer_composition_wired_into_convo, gap_ainxt_convo_conv_10_manager_answer_format_renders_references` in `runtime/crates/ainxt-convo/tests/intent_cascade_test.rs`
- **design:** (Out of this doc's strict scope — answer-quality gaps.) Included in audit file scope: typed answer model with verbosity right-sizing + citation UX.
- **original evidence:** The crate itself is complete and exhaustively tested (ainxt-answer/src/lib.rs:229 compose, :378 to_markdown, 1037 lines with adversarial tests), but grep for ainxt_answer/ainxt-answer across crates/*.rs is empty — no surface/convo consumes it, so its formattin
- **▶ verify yourself:** `sed -n '227,233p' runtime/crates/ainxt-answer/src/lib.rs`

### ✅ `CTX-14` — Embedding-model lifecycle connected to a live re-embed pipeline
- **subsystem:** context-fabric · **status:** FIXED
- **proof:** test `tests::gap_ctx_14_reembed_pipeline_drives_index_to_uniform_version (+ reembed::tests::run_reembed_records_failures_visibly, plan_splits_triggers_into_embed_and_delete)` in `/Users/admin/Desktop/ai-copilot/runtime/crates/ainxt-retrieval/src/lib.rs`
- **design:** CONTEXT_FABRIC §4: version-tracked embeddings + a re-embed pipeline so migrations never leave a mixed-version index; event-driven staleness triggers
- **original evidence:** strong library support exists (ainxt-retrieval/src/lib.rs:393 stale_embeddings, :404 is_embedding_uniform, maintenance.rs IndexState.apply/stale/freshness) but nothing connects it to an embed service or live index rebuild — it is a pure, unwired library
- **▶ verify yourself:** `sed -n '391,397p' runtime/crates/ainxt-retrieval/src/lib.rs`

### ✅ `EVAL-05` — RAG answer-relevance metric
- **subsystem:** eval-tester-scenarios · **status:** FIXED
- **proof:** test `gap_ainxt_eval_05_answer_relevance_scores_addressing_the_question` in `runtime/crates/ainxt-eval/src/rag.rs`
- **design:** §6 table lists 'Answer relevance — does the answer address the actual question?' as a scored RAG dimension (Judge).
- **original evidence:** ainxt-eval/src/rag.rs implements context_recall/precision, recall_at_k, mrr, average_precision, claim_groundedness, citation_span_faithfulness — but no answer-relevance-to-question scorer; RagReport (rag.rs:191) aggregates only retrieval metrics.
- **▶ verify yourself:** `sed -n '189,195p' runtime/crates/rag.rs`

### ✅ `EVAL-06` — Flywheel staging→promotion of eval-case candidates
- **subsystem:** eval-tester-scenarios · **status:** FIXED
- **proof:** test `gap_ainxt_eval_06_flywheel_case_never_auto_promotes` in `runtime/crates/ainxt-eval/src/integrity.rs`
- **design:** §3.3/§9.3: flywheel-derived candidates land in a human-promoted staging set, contamination-guarded, never auto-added to the live/holdout set.
- **original evidence:** ainxt-eval/src/integrity.rs implements rotation (plan_rotation:339) + tripwires (Tripwire:365) but has no staging-set / human-promotion type; provenance tags (§3.3) are not modeled on EvalCase (lib.rs:41).
- **▶ verify yourself:** `sed -n '39,45p' runtime/crates/lib.rs`

### ✅ `EVAL-07` — Global/sensemaking-mode own eval set
- **subsystem:** eval-tester-scenarios · **status:** FIXED
- **proof:** test `gap_ainxt_eval_07_sensemaking_has_its_own_eval_set` in `runtime/crates/ainxt-eval/src/rag.rs`
- **design:** §6: global/sensemaking (map-reduce) mode gets its OWN eval set because sparse-corpus map-reduce can produce noisy communities.
- **original evidence:** No sensemaking/global-mode eval set or metric present in ainxt-eval/src/rag.rs or elsewhere in the crate.

### 🔧 `FI-10` — Crypto-agility registry governs no actual cryptographic operation (ADR-023 / Pass-5 gap 42)
- **subsystem:** regulated-fi-responsible-lifecycle · **status:** WIRING-IN-PROGRESS
- **design:** The policy is the single source of truth for 'what may I use right now' so a broken primitive or the PQC transition is enacted by policy alone — no code silently keeps signing/encrypting with a deprecated algorithm.
- **original evidence:** AlgorithmRegistry::resolve / is_pqc_ready / must_rotate fully implemented and tested (ainxt-cryptoagility/src/lib.rs:187-231), but the crate has zero reverse dependencies and the runtime's own hash chains call sha2 directly (e.g. ainxt-incident/src/lib.rs:527,
- **▶ verify yourself:** `sed -n '185,191p' runtime/crates/ainxt-cryptoagility/src/lib.rs`

### ✅ `FI-11` — Break-glass PII-slipped-a-floor/hold remediation Program (§6.5) and shadow exit-rehearsal Program (§3.4)
- **subsystem:** regulated-fi-responsible-lifecycle · **status:** FIXED
- **proof:** test `gap_ainxt_lifecycle_fi11_resumable_checkpointed_partial_completion_with_intact_chain (plus ..._unauthorized_principal_cannot_open_break_glass, ..._tampered_attestation_trail_is_detected)` in `runtime/crates/ainxt-lifecycle/src/breakglass.rs`
- **design:** A detector miss landing erasable PII inside a floor/hold-bound record is remediated as a scoped, authorized, checkpointed Long-Horizon Program (redaction-with-attestation preserving the evidentiary hash-chain); the RBI tested exit plan is a rehearsable shadow Program.
- **original evidence:** No break-glass or exit-rehearsal Program in ainxt-lifecycle or elsewhere; the lifecycle crate has no redaction-with-attestation path for a record already persisted under a floor/hold (only erase/defer/purge on RecordStore, ainxt-lifecycle/src/lib.rs:455-750).
- **▶ verify yourself:** `sed -n '453,459p' runtime/crates/ainxt-lifecycle/src/lib.rs`

### ⏳ `FI-12` — OSS Gate #0 placeholder identity still present in shipped crate metadata
- **subsystem:** regulated-fi-responsible-lifecycle · **status:** DEFERRED-INFRA
- **deferred reason:** OSS Gate #0 identity is a locked human/legal gate (GATE_0_CHECKLIST.md §B, all marked 🔒): real copyright holder in NOTICE, a monitored security contact in SECURITY.md, and 'AiNxt' trademark clearance require legal sign-off, not code. Note: the stale claim (repository = https://example.invalid) is already refuted — the workspace repository is set to https://gitlab.com/npci/ainxt-runtime, and all five crates correctly inherit repository.workspace/license.workspace(Apache-2.0)/unsafe_code=forbid with permissive-only deps (serde/sha2). The repository field lives in the RESERVED workspace runtime/Cargo.toml (crates only inherit it), so it cannot be changed from within the five editable crates regardless.
- **design:** GATE_0_CHECKLIST §B: real copyright holder, real repository URL, and a monitored security contact must be set before any public release/external pilot; example.invalid is a release blocker.
- **original evidence:** All five crates inherit repository.workspace = true; the workspace repository is still the Gate-#0 placeholder per GATE_0_CHECKLIST.md:19 ('runtime/Cargo.toml repository = https://example.invalid/ainxt-runtime'). SPDX Apache-2.0 headers and unsafe_code=forbid 

### ⏳ `HARN-06` — Level-3 Extend: plugins isolated via WASM/WASI
- **subsystem:** harness-sdk-governance · **status:** DEFERRED-INFRA
- **deferred reason:** WASM/WASI plugin isolation requires the wasmtime runtime (a heavy engine dependency) and lives in ainxt-plugin/ainxt-wasm, which are OUTSIDE my editable crate set (RESERVED / not in {ainxt-harness, ainxt-client, ainxt-cli, ainxt-governance}). The current NativeHost (catch_unwind capability confinement) is the documented in-process interim; the memory/time-hard sandbox cannot be added from these crates without editing reserved crates and adding wasmtime.
- **design:** §1/§5: Plugin isolation will be WASM/WASI; in Phase 5 engineers register new capabilities as WASM plugins under the same permission model.
- **original evidence:** ainxt-plugin ships a NativeHost that enforces capability confinement and traps panics via std::panic::catch_unwind (crates/ainxt-plugin/src/lib.rs:181-205); WASM/wasmtime is only a documented future seam ('the real sandbox... via wasmtime', lib.rs:14-16). Nati
- **▶ verify yourself:** `sed -n '179,185p' runtime/crates/crates/ainxt-plugin/src/lib.rs`

### ✅ `IDN-06` — Layer-3 grant-vocabulary non-representability of PaymentInitiating is by-omission, not structural
- **subsystem:** Agent Identity & Payment Boundary · **status:** FIXED
- **proof:** test `gap_idn_06_reserved_payment_capability_is_not_representable_in_a_grant` in `runtime/crates/ainxt-identity/src/lib.rs`
- **design:** §3.3/§4 Layer 3: NO grant tuple can express a PaymentInitiating capability — the authority is 'not representable', so a fully-privileged human's OBO context cannot carry it (confused-deputy closed for this class)
- **original evidence:** Capability is an opaque String newtype (ainxt-identity/src/lib.rs:120) — `Capability::new("payment:initiate")` is representable in a scope; nothing structurally forbids it. It is denied only downstream by the absence of a dispatch arm (ainxt-tools Layer 1), no
- **▶ verify yourself:** `sed -n '118,124p' runtime/crates/ainxt-identity/src/lib.rs`

### ✅ `IDN-08` — Kill-switch authority (who may pull which scope) is not gated
- **subsystem:** Agent Identity & Payment Boundary · **status:** FIXED
- **proof:** test `gap_idn_08_kill_switch_pull_requires_authority_and_is_audited (+ _authorized_pull_actually_halts_issuance)` in `runtime/crates/ainxt-identity/src/authority.rs`
- **design:** §19: kill-switch authority is git-controlled policy, gated to ad_level<=3 + can_approve, master-switch-style, and its own use is audited with the pulling human's identity
- **original evidence:** KillSwitch::pull(&mut self, scope) (ainxt-identity/src/authority.rs:370) takes no principal/authority argument and performs no ad_level check; no audit record of who pulled it
- **▶ verify yourself:** `sed -n '368,374p' runtime/crates/ainxt-identity/src/authority.rs`

### ✅ `IDN-09` — UEBA anomaly detection is only the renewal-choke lever, not a detector
- **subsystem:** Agent Identity & Payment Boundary · **status:** FIXED
- **proof:** test `gap_idn_09_anomaly_detector_flags_behavioral_deviation (+ gap_idn_09_detected_anomaly_chokes_renewal_end_to_end)` in `runtime/crates/ainxt-identity/src/authority.rs`
- **design:** §20: a UEBA Run-Actor Anomaly Monitor with per-role behavioral baselines (capability mix, egress destinations, action/cost velocity) that FLAGS actor-behavior deviation across the whole renewed-identity chain
- **original evidence:** AnomalyMonitor is a manual flagged-set (ainxt-identity/src/authority.rs:400: flag/clear/is_flagged); no baseline, no deviation computation — the design honestly scopes learning as infra, but no scoring seam is present
- **▶ verify yourself:** `sed -n '398,404p' runtime/crates/ainxt-identity/src/authority.rs`

### ✅ `IDN-10` — Renewal-throughput capacity load test (§22 #16) not implemented
- **subsystem:** Agent Identity & Payment Boundary · **status:** FIXED
- **proof:** test `gap_idn_10_renewal_throughput_capacity_model_and_concurrent_load` in `runtime/crates/ainxt-identity/src/authority.rs`
- **design:** §15/§22 #16: a load harness spins 5,000 concurrent 5-min-TTL Program Runs with git disconnected, asserting zero git reads on the renewal path and ~17–22 renewals/sec within SLO
- **original evidence:** ainxt-identity has only unit tests in authority.rs (34 tests, all deterministic single-threaded); no load/soak test crate or bench exercising the capacity model

### 🔧 `IDN-11` — EffectClass enum omits the designed Idempotent variant
- **subsystem:** Agent Identity & Payment Boundary · **status:** WIRING-IN-PROGRESS
- **design:** §3.1: the Ledger enum becomes Pure | Idempotent | SideEffecting | PaymentInitiating
- **original evidence:** ainxt-tools/src/lib.rs:22 defines Pure | SideEffecting | PaymentInitiating only — idempotency is folded into SideEffecting via the ledger; harmless but a documented divergence from the 4-value enum
- **▶ verify yourself:** `sed -n '20,26p' runtime/crates/ainxt-tools/src/lib.rs`

### 🔧 `LOOP-13` — Learning flywheel emission + feed into evals/plan-priors/role-spec tuning
- **subsystem:** loop-teams-longhorizon · **status:** WIRING-IN-PROGRESS
- **design:** LOOP §10 / ADR-027 §13: every terminal Run emits a LearningRecord that feeds eval-set generation, plan-template priors, and Role-Spec tuning.
- **original evidence:** teams LearningRecord::from_run (lib.rs:1038) is a pure projection of a RunReport; it is never emitted on a real terminal run and nothing consumes it (no reference from ainxt-eval or any live path).
- **▶ verify yourself:** `sed -n '1036,1042p' runtime/crates/lib.rs`

### ⏳ `LOOP-14` — Real verification gates + saga compensation behind the pure seams
- **subsystem:** loop-teams-longhorizon · **status:** DEFERRED-INFRA
- **deferred reason:** The pure combiners and injection points are done and tested offline — three_way_gate + program_completed + attribute_regression (verify.rs), the ProgramVerifier seam driven by the Supervisor (test gap_loop_14_red_integration_edge_reopens_introducer... proves a red edge/sweep re-opens the introducing node and blocks Completed), and execute_rollback against a fake Compensator + poison route-around (gap_loop_14_poison_module...). But the REAL gates behind the seams require live infra I cannot run here: a real deterministic build/test/SAST runner, a live adversarial Breaker driving the real artifact, a live cross-model LLM Judge, and real git-revert + saga compensation against a real repo/Side-Effect-Ledger. Those are wired by the parent to live CI + models + git; the seams (ProgramVerifier, Compensator) are the ready injection points.
- **design:** LOOP §7 / ADR-027 §6/§9: deterministic build/test/SAST gate, adversarial Breaker, judge invocation, and git-revert + saga compensation for single-module rollback.
- **original evidence:** verify.rs DeterministicVerdict/AdversarialVerdict/JudgeVerdict (verify.rs:62/:87/:108) are caller-supplied data structs with no test-runner/breaker/judge behind them; Compensator (program.rs:913) is a trait with no git/saga implementation — execute_rollback (:
- **▶ verify yourself:** `sed -n '60,66p' runtime/crates/verify.rs`

### 🔧 `LOOP-15` — Base tier-1 reactive loop, cancellation, and coarse stuck detector (the one reachable piece)
- **subsystem:** loop-teams-longhorizon · **status:** WIRING-IN-PROGRESS
- **design:** LOOP §5 tier-1 / §8: act→observe→act, hard iteration cap, need-driven termination, deterministic stuck detector, prompt cancellation.
- **original evidence:** ainxt-runtime/src/lib.rs run_turn_cancellable: bounded 'agent loop (:888, max_iters), need-driven break when no tool calls (:1072), repetition/stuck break via seen_calls canonical-key dedup (:1092/:1295), and cooperative CancelToken checks throughout. This is 

### ✅ `MEM-08` — Confidence decay is write-recency based, not usage/last-confirmed based
- **subsystem:** Enterprise Memory & Continuous Learning · **status:** FIXED
- **proof:** test `gap_ainxt_memory_mem_08_decay_is_usage_based_not_write_recency` in `runtime/crates/ainxt-memory/src/store.rs`
- **design:** §6 'confidence decay (a fact unconfirmed and unused past N months drops priority)'.
- **original evidence:** lib.rs:507-518 decay_factor() halves by age = now - seq (write tick); there is no last-used/last-confirmed timestamp on MemoryItem, so 'unused' cannot be measured — decay penalizes old writes even if freshly used.
- **▶ verify yourself:** `sed -n '505,511p' runtime/crates/lib.rs`

### ✅ `MEM-09` — Fine-tune-corpus destination (5th flywheel output) not implemented
- **subsystem:** Enterprise Memory & Continuous Learning · **status:** FIXED
- **proof:** test `gap_ainxt_memory_mem_09_fine_tune_corpus_is_data_class_filtered_and_poison_scanned` in `runtime/crates/ainxt-memory/src/flywheel.rs`
- **design:** §4 destination 5 (optional, governed): poisoning-checked, data-class-filtered fine-tune examples.
- **original evidence:** flywheel.rs:99-110 CandidateDest has only Prompt/Retrieval/EvalCase/OrgKnowledge; no fine-tune candidate or poisoning-scan path. Design marks this optional/downstream.
- **▶ verify yourself:** `sed -n '97,103p' runtime/crates/flywheel.rs`

### 🔧 `MEM-10` — Consent is a library surface only; no API/UI, and Prompt/Retrieval/EvalCase candidates have no receiving subsystem
- **subsystem:** Enterprise Memory & Continuous Learning · **status:** WIRING-IN-PROGRESS
- **design:** §5 'a governed memory surface (API + UI)'; §4 four destinations each feeding a real gate (prompt registry, RAG eval, staging eval set).
- **original evidence:** store.rs:472/523 remembered_about/export_subject are Rust methods with no router/HTTP exposure; flywheel.rs:296-324 Prompt/Retrieval/EvalCase candidates carry only a summary string (oki: None) and nothing consumes them (no external caller — grep clean).
- **▶ verify yourself:** `sed -n '470,476p' runtime/crates/store.rs`

### ✅ `MEM-11` — Per-item rbac_scope (allowed roles/departments) not modeled
- **subsystem:** Enterprise Memory & Continuous Learning · **status:** FIXED
- **proof:** test `gap_ainxt_memory_mem_11_rbac_scope_enforced_pre_rank` in `runtime/crates/ainxt-memory/src/store.rs`
- **design:** §2 envelope field rbac_scope = 'roles/departments allowed to retrieve it — enforced pre-rank'.
- **original evidence:** lib.rs:323-371 MemoryItem has no rbac_scope field; visibility is derived solely from Scope (Org/Dept/Team/Repo/User) via access.rs can_see(). An item cannot be granted to an arbitrary set of roles independent of its scope.
- **▶ verify yourself:** `sed -n '321,327p' runtime/crates/lib.rs`

### ⬜ `OS-07` — Agent rung (persona + skills + capabilities + model policy) as a distinct declarative unit
- **subsystem:** AiNxt OS / Skill→Agent→Role→Team Workforce Ladder + Role Studio · **status:** OPEN
- **design:** WORKFORCE §1: Agent = persona+skills+capabilities+model policy, built declaratively by anyone; a rung between Skill and Role.
- **original evidence:** No dedicated Agent/AgentSpec/AgentManifest type (grep returns none). The fields are expressible via HarnessManifest (persona/requested_capabilities/model_policy/budget/autonomy — ainxt-harness/src/lib.rs:276) or the Surface Profile (ainxt-profile), but there i
- **▶ verify yourself:** `sed -n '274,280p' runtime/crates/ainxt-harness/src/lib.rs`

### ⬜ `OS-08` — Git-native governance control plane (DRAFT→PENDING→APPROVED→PRODUCTION→DEPRECATED via git primitives, CODEOWNERS-gated signed merge, signed promotion tag, publish=PR-not-DB, pre-receive block gate)
- **subsystem:** AiNxt OS / Skill→Agent→Role→Team Workforce Ladder + Role Studio · **status:** OPEN
- **design:** AINXT_OS §2/§4 Step 9 + WORKFORCE §4: lifecycle re-hosted on git primitives; CODEOWNERS = authoring RBAC + named accountable owner; git history = audit trail; conversational Studio emits a PR, not a DB row.
- **original evidence:** Fully implemented and tested in ainxt-governance/src/lib.rs: advance_with_evidence:235 (enforces CODEOWNERS approver + verified merge/tag signature), publish:311 (emits PullRequest, explicit 'writes NO database row'), MarkerPrereceiveGate:335 (blocks, never re

### ⬜ `OS-09` — Marketplace = federation of pinned git repos with TOFU hash-pin (app store)
- **subsystem:** AiNxt OS / Skill→Agent→Role→Team Workforce Ladder + Role Studio · **status:** OPEN
- **design:** AINXT_OS §4 Step 9 / WORKFORCE §4: Marketplace = federation of pinned git repos, TOFU hash-pin, publish/install is a PR, diff-and-re-approve on update.
- **original evidence:** ainxt-governance/src/lib.rs:432 Marketplace::resolve (TOFU: first-sight pins, later URL/hash mismatch fails closed with MarketError) + ainxt-harness resolve_dependencies:328 wiring manifest depends_on pins; tested (harness dod_p5_matrix + governance marketplac
- **▶ verify yourself:** `sed -n '430,436p' runtime/crates/ainxt-governance/src/lib.rs`

### ⬜ `OS-10` — Grant-and-govern by construction (least-privilege capability grant, data-class ceiling, payment boundary, OBO authz, execute-RBAC visibility) — the runtime enforcement half of Role Studio Step 3
- **subsystem:** AiNxt OS / Skill→Agent→Role→Team Workforce Ladder + Role Studio · **status:** OPEN
- **design:** AINXT_OS §4 Step 3 / WORKFORCE §5: each capability least-privilege and justified; sensitive ones need approval; on-behalf-of authority; data-class access; oversight baked in so a role cannot bypass governance.
- **original evidence:** The enforcement primitives exist in ainxt-harness (admit:751 requested∩granted∩principal + data_class_ceiling + role floor + visibility; gate_step:804 OBO authz via HarnessAuthorizer + payment-boundary classify) and are unbypassable-by-schema (deny_unknown_fie

### ✅ `PRMT-07` — Optimizer output does not bridge into the Registry as a DRAFT artifact
- **subsystem:** Prompt engineering · **status:** FIXED
- **proof:** test `gap_ainxt_promptopt_prmt_07_optimizer_winner_lands_as_draft_only (+ _no_winner_cannot_be_drafted, _overfit_winner_is_refused_at_the_bridge, _dangling_eval_set_fk_is_rejected)` in `crates/ainxt-promptopt/src/bridge.rs`
- **design:** Section 5.5: the optimizer's best candidate becomes a new DRAFT artifact version in the Registry, entering the normal REVIEW->CANARY->PRODUCTION pipeline; the optimizer never auto-promotes
- **original evidence:** ainxt-promptopt/Cargo.toml depends only on ainxt-eval + ainxt-types (no ainxt-prompt dependency); optimize/optimize_with_holdout (lib.rs:137, :304) return ModelOptimization/HoldoutOutcome with no path to Registry::register at Stage::Draft
- **▶ verify yourself:** `sed -n '135,141p' runtime/crates/lib.rs`

### ✅ `PRMT-09` — Optimizer cost-budget accounting (rounds x candidates x eval-size x cost)
- **subsystem:** Prompt engineering · **status:** FIXED
- **proof:** test `gap_ainxt_promptopt_prmt_09_run_never_exceeds_the_call_and_cost_budget (+ _zero_call_budget_stops_before_any_work, _multi_round_finds_the_winner_then_converges, _max_rounds_is_respected, _empty_gold_is_a_noop)` in `crates/ainxt-promptopt/src/budget.rs`
- **design:** Section 5.6: optimization runs are explicitly budgeted and scheduled as an offline job, not inline with user traffic
- **original evidence:** propose.rs ProposeConfig bounds the candidate cross-product (max_shots/max_candidates, :72) and a single optimize pass is bounded, but there is no round budget or cost accounting; optimize (lib.rs:137) is a single non-iterated scoring pass with no bounded mult
- **▶ verify yourself:** `sed -n '135,141p' runtime/crates/lib.rs`

### 🔧 `PRMT-10` — Indirect-injection defense: prompt-crate flagger duplicates the wired convo scanner
- **subsystem:** Prompt engineering · **status:** WIRING-IN-PROGRESS
- **design:** Section 6.B / PE6: L4 states the data/instruction contract, imperative patterns in untrusted L5 are flagged, and any tool call influenced by untrusted content requires confirmation
- **original evidence:** The wired defense lives in ainxt-convo (InjectionConfig + HeuristicInjectionScanner tainting turns to gate side-effecting tools, ainxt-convo/src/lib.rs:405-409); ainxt-prompt guard.rs flag_injected_imperatives (line 169) is a well-tested but unwired duplicate 
- **▶ verify yourself:** `sed -n '403,409p' runtime/crates/ainxt-convo/src/lib.rs`

### ✅ `SRV-07` — §2 per-tenant WFQ + chunked-prefill
- **subsystem:** Serving-Ops · **status:** FIXED
- **proof:** test `gap_ainxt_serving_srv_07_wfq_guarantees_min_service_for_a_backlogged_tenant` in `runtime/crates/ainxt-serving/src/wfq.rs`
- **design:** Weighted fair queuing that 'guarantees a minimum service rate per tenant', and chunked-prefill that interleaves a long prompt's prefill chunks with in-flight decode steps within a pool.
- **original evidence:** FairnessLimiter (lib.rs:641-742) is a concurrency-quota cap with a checkable starvation-proof invariant, not WFQ minimum-service scheduling (no queue ordering / deficit round-robin). PreemptionScheduler (preemption.rs) models slot-level preempt-and-resume-from
- **▶ verify yourself:** `sed -n '639,645p' runtime/crates/lib.rs`

### ✅ `SRV-08` — §4 in-flight idempotency-ledger disposition on drain
- **subsystem:** Serving-Ops · **status:** FIXED
- **proof:** test `gap_ainxt_serving_srv_08_drain_disposition_routes_by_priority_class` in `runtime/crates/ainxt-serving/src/idempotency.rs`
- **design:** On drain-the-group, P0/P1 in-flight generations fail back and retry against a healthy group under the idempotency-ledger discipline so a retry never double-bills tokens or returns two divergent answers.
- **original evidence:** Only described as a comment/seam in health.rs:22-23 ('recover under the existing idempotency-ledger discipline (a seam here, not reinvented)'). No idempotency key, dedup, or retry accounting is implemented in the health module.
- **▶ verify yourself:** `sed -n '20,26p' runtime/crates/health.rs`

### ✅ `SURF-07` — Layered config merge (defaults→deployment→tenant→profile→request)
- **subsystem:** surfaces-profiles-skills-config · **status:** FIXED
- **proof:** test `gap_ainxt_config_surf_07_full_canonical_five_layer_precedence` in `runtime/crates/ainxt-config/tests/config_test.rs`
- **design:** Everything declarative, merged from ordered layers, most-specific wins; typed + validated; safety gates selectable-never-removable.
- **original evidence:** ainxt-config: merge_toml deep table merge (src/lib.rs:291-305), Loader with canonical layer helpers (src/lib.rs:317-374), resolve_runtime validates (src/lib.rs:370). GatesConfig has no off/disable variant (src/lib.rs:246-285). CONSUMED by the daemon: load_laye
- **▶ verify yourself:** `sed -n '289,295p' runtime/crates/src/lib.rs`

### ✅ `SURF-08` — Profile schema + binding pipeline (as a library)
- **subsystem:** surfaces-profiles-skills-config · **status:** FIXED
- **proof:** test `gap_ainxt_surface_surf_01_plan_maps_onto_engine_request / gap_ainxt_surface_surf_01_context_block_reaches_the_request_input` in `runtime/crates/ainxt-surface/src/lib.rs`
- **design:** Profile declares persona/capabilities/skills/connectors/model-policy/autonomy/RBAC/context/prompt; binding admits principal, intersects caps (never escalates), maps autonomy→approval, resolves depth→tier floor, carries retrieval scope.
- **original evidence:** ainxt-profile/src/lib.rs:176-278 (schema, safe defaults, resolve/validate) and ainxt-surface/src/lib.rs:220-285 (SurfaceBinding::plan: admit, data-class ceiling, effective-cap intersection, autonomy→action, depth→tier floor, dept scope) are complete and unit-t
- **▶ verify yourself:** `sed -n '174,180p' runtime/crates/ainxt-profile/src/lib.rs`

### 🔧 `SURF-14` — Artifact binary renderers (docx/pptx/pdf/xlsx)
- **subsystem:** data-surfaces-artifacts · **status:** WIRING-IN-PROGRESS
- **design:** §6 Output: artifacts (docx/pptx/xlsx/pdf) via the Artifact Runtime.
- **original evidence:** ainxt-artifact/src/lib.rs implements only MarkdownRenderer + PlainTextRenderer; docx/pptx/pdf/xlsx are described as external 'skill renderers behind the same trait' (module doc lines 8-9) and none exist in-tree. Design-acknowledged seam, so low.

### ✅ `SURF-15` — Compliance detector behind artifact audit is a real PCI/DSS engine
- **subsystem:** data-surfaces-artifacts · **status:** FIXED
- **proof:** test `gap_ainxt_artifact_surf15_luhn_entropy_scanner (+ gap_ainxt_artifact_surf15_scanner_is_injectable_and_never_redacts)` in `runtime/crates/ainxt-artifact/src/lib.rs`
- **design:** CLAUDE.md: multi-layered PCI detection (regex+Luhn+entropy) on all output; artifact audit records findings.
- **original evidence:** ainxt-artifact/src/lib.rs MarkerScanner (lines 178-204) is a deterministic floor: >=12 digit run + literal markers ('PAN=','SECRET='...), no Luhn/entropy. Module doc explicitly labels it 'a deterministic floor' and says a real deployment plugs in the PCI detec

### ✅ `TURN-08` — compliance.notice event on the wire
- **subsystem:** turn-pipeline · **status:** FIXED
- **proof:** test `gap_turn_08_compliance_notice_reports_category_never_content` in `runtime/crates/ainxt-protocol/src/lib.rs`
- **design:** PROTOCOL.md §6.3 / I4 — after a redaction the renderer receives compliance.notice{categories[], action} so the user learns 'an account number was redacted and the turn proceeded', without the wire carrying the PII
- **original evidence:** No ComplianceNotice variant in ainxt-protocol Event (:61-82); redactions are only tallied into TurnSummary.redactions (:1352) and the audit summary text (:1327). The redaction itself is correct (stream is post-compliance), but the client is never told a catego

### ⬜ `TURN-09` — Compliance-out on model-emitted tool-call args before they hit the wire
- **subsystem:** turn-pipeline · **status:** OPEN
- **design:** PROTOCOL.md §9/I4 — no event reaches any transport before compliance-out; the wire stream is the post-redaction stream
- **original evidence:** ainxt-runtime/src/lib.rs:963-969 forwards the provider's ToolCallStart{args} to the sink with RAW args; compliance on args (7a, :1096) runs only on the dispatch path afterward. Low impact because compliance-IN already redacted the input the model sees, so mode
- **▶ verify yourself:** `sed -n '961,967p' runtime/crates/ainxt-runtime/src/lib.rs`


## REFUTED

### ➖ `GUARD-01` — Indirect-injection detector is scored/multi-signal, not a fixed list
- **subsystem:** guardrails-injection · **status:** REFUTED-already-implemented
- **design:** Part1 A: injection classifiers, taint-tracking, treat retrieved content as data not instructions
- **original evidence:** runtime/crates/ainxt-injection/src/detect.rs:103-145 (assess: phrase+imperative+role-spoof+tool+encoded, combined_score per-category-max summed) + detect_encoded_payloads:383-451 (base64/hex/percent decode-and-rescan, zero-width/bidi)
- **▶ verify yourself:** `sed -n '101,107p' runtime/crates/ainxt-injection/src/detect.rs`

### ➖ `GUARD-02` — Taint-gate wiring: tainted turn gates side-effecting tools
- **subsystem:** guardrails-injection · **status:** REFUTED-already-implemented
- **design:** Part1 A / Part2 R: tool-call gating per context, human confirmation on sensitive actions triggered by untrusted content, fail-closed
- **original evidence:** runtime/crates/ainxt-runtime/src/lib.rs:886 (taint seeded), :1148-1174 (gates side-effecting+egress fail-closed), :1284-1285 (tool result taints under Enforce); RAG seed ainxt-convo/src/lib.rs:590-597,692-698
- **▶ verify yourself:** `sed -n '884,890p' runtime/crates/ainxt-runtime/src/lib.rs`

### ➖ `GUARD-03` — Instruction/data fencing of untrusted content
- **subsystem:** guardrails-injection · **status:** REFUTED-already-implemented
- **design:** Part1 A: data/instruction separation; model treats retrieved content as data never instructions
- **original evidence:** ainxt-injection/src/lib.rs:133-144 (wrap_untrusted) + :109-128 (neutralize_fence_markers, delimiter-injection); wired ainxt-context/src/lib.rs:301 and ainxt-runtime/src/lib.rs:1288
- **▶ verify yourself:** `sed -n '131,137p' runtime/crates/ainxt-injection/src/lib.rs`
