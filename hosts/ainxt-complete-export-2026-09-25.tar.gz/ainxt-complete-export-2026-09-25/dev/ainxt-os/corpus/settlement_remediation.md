---
id = "settlement-003"
source = "settlement_remediation"
data_class = "internal"
department = "settlement-eng"
---
Banks that fail the UPI settlement reconciliation dry-run are placed in a 7-day remediation window. The settlement engineering team provides a root-cause report to the bank within 48 hours of failure.
