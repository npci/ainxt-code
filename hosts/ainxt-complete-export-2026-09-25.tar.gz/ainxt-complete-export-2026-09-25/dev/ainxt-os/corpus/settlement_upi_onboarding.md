---
id = "settlement-002"
source = "settlement_upi_onboarding"
data_class = "internal"
department = "settlement-eng"
---
From the settlement engineering view, UPI bank onboarding requires each bank to complete a settlement reconciliation dry-run over 3 consecutive days. As of the current onboarding cycle, 101 banks have cleared the settlement dry-run and are live on the UPI settlement rails.
