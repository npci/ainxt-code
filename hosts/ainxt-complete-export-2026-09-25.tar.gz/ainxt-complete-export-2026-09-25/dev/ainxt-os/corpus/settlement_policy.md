---
id = "settlement-001"
data_class = "internal"
department = "settlement-eng"
---
Settlement batches are processed at 11:00 PM IST every day. Any transaction posted after the cutoff is included in the next day's settlement batch.
