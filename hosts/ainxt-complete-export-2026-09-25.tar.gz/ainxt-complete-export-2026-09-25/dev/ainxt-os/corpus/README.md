# AiNxt OS — Sample Knowledge Base Corpus

This directory holds documents that the AiNxt runtime loads into the Context Fabric at startup.

## How it works

The daemon config (`local.toml` in dev, deployment config in prod) points to this directory:

```toml
[kb.loader]
dir = "corpus"
globs = ["*.jsonl", "*.md"]
```

At startup, `ainxt-runtimed` reads every matching file and converts each record/file into a `KbDocument`. These documents are then indexed into the live retrieval corpus that the chat surface grounds on.

## File formats

### 1. JSONL — one Chunk per line

Each line is a JSON object matching `ainxt_context::Chunk`:

```json
{"id":"upi-001","source":"upi_faq.md","text":"UPI enables instant bank transfer.","data_class":"Public"}
```

Optional fields: `timestamp`, `authority`, `topic`, `acl`, `attributes`.

### 2. Markdown / Text — one document per file

Frontmatter carries metadata; the body is the document text:

```markdown
---
id = "settlement-001"
data_class = "Internal"
department = "settlement-eng"
---
Settlement batches are processed at 11:00 PM IST every day.
```

Supported frontmatter fields:

- `id` — required if not using filename
- `source` — citation label
- `data_class` — `Public`, `Internal`, `Confidential`, `Pii`, `RegulatedPayment`
- `scope` — `platform`, `namespace`, `repo`
- `namespace`, `repo` — scope labels
- `department` — node-ACL department restriction
- `max_ad_level` — seniority ceiling (0 = most senior)
- `allow_groups`, `deny_groups` — group-based ACL
- `row_attributes` — RLS row labels

## Deployment rule

Same binary, different corpus. In production, point `dir` at the real NPCI knowledge base directory. No code rebuild is required.
